# Kde na západě

<b>Kde na západě</b> je interaktivní geografická mobilní hra nad mapou Karlovarského kraje. Hráči mají za úkol se pomocí nápověd seznámit s místy z otevřených dat regionu a motivovat se, aby místa navštívili osobně. Zároveň mohou lokace hodnotit, tak aby pomohli ostatním hráčům při objevování zajímavých míst. Hra je určena pro všechny věkové kategorie a je vhodná pro rodiny s dětmi, turisty i místní obyvatele.
- Jako prototyp vznikla multiplayer online hra, která rozšiřuje základní funkčnost aplikace.

<b>Přínosy aplikace:</b>
- motivace k návštěvě zajímavých míst v regionu
- zábavná forma poznávání regionu
- podpora lokálního cestovního ruchu
- podpora lokálních podnikatelů a služeb
- uzavřením smyčky sbíráním dat pro zlepšení kvality života v regionu, které mohou využít místní samosprávy, podnikatelé i turisté
- Nový herní mód v pilotní verzi: Multiplayer online hra 

## Použitá data

modifikace formátu a popis lokací byl agregován pomocí umělé inteligence

- [Hrady a jejich zříceniny v Karlovarském kraji](https://www.datazapad.cz/datasets/c3a42c283f0649248326a0bbd7dc5cc3_0/explore?location=50.192406%2C12.721040%2C10), CC BY 4.0 upraveno
- [Koupací místa s kontrolou kvality vody v roce 2026 v Karlovarském kraji](https://www.datazapad.cz/datasets/239805159c8649609d1bd40a30439623_0/explore?location=50.137572%2C12.734079%2C10), CC BY 4.0 upraveno 
- [Lanová a zábavní centra v Karlovarském kraji](https://www.datazapad.cz/datasets/90441fa783444e1ead5ad71464504d6a_0/explore?location=50.176624%2C12.566412%2C10), CC BY 4.0 upraveno 
- [Letiště v Karlovarském kraji](https://www.datazapad.cz/datasets/fc44327a17e04959b7c5209d9ce32820_3/explore?location=50.130308%2C12.690579%2C10), CC BY 4.0 upraveno
- [Památkově chráněná území v Karlovarském kraji](https://www.datazapad.cz/datasets/54223e92a9b04a0ba27e9800f41c4f1f_3/explore?location=50.190137%2C12.801708%2C10), CC0 1.0 upraveno 
- (lze volně přidat další)


## Použití AI
Claude code, Gemini, ChatGPT - psaní kódu, generování textů, generování popisů lokací a nápověd.

## Spuštění
Frontend, backend i databáze jsou v technologii Docker. Pro spuštění je potřeba mít nainstalovaný Docker a Docker Compose. 
V kořenovém adresáři projektu spusťte:
```bash
docker compose up -d 
```
Klíče a hesla do repozitáře nepatří, použijte `.env.example` nebo lépe proměnné prostředí docker-compose souboru.
.env.example případně .env se nastavuje produkční nebo vývojové prostředí. 

## Tým
- Daniel Vodička (DanielRafaello - Github) – vedoucí programátor, backend
- Jiří Špetka – konzultant, datová analýza
- Miroslav Pašek – programátor, frontend
- Romis Pejs – programátor, fullstack
- Trong Quoc Huy Dinh – programátor, fullstack

## Licence
Kód: [MIT](LICENSE). Ostatní obsah: CC BY 4.0.

---
Prototyp z Hackathonu otevřených dat Karlovarského kraje 2026. Není oficiální službou Karlovarského kraje ani KIC KK.