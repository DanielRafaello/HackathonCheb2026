# Multiplayer server

The WebSocket server for the multiplayer game "Hra s kamarády". Players create a lobby, others join with a six-character code, and the host starts a game. Every participant gets the same places in the same order and makes one guess per place before a shared timer runs out.

The server is a Node 22 + TypeScript (ESM) process. It keeps all lobbies and games in memory, so run exactly one replica. It reads places and user names from the backend's Postgres database and never writes to it. Multiplayer guesses are not recorded in a player's progress.

## Run it

Requirements: Node 22 or later, and the backend's Postgres database for `npm run dev` and `npm start`.

```sh
npm ci              # install dependencies
npm test            # unit and integration tests (vitest)
npm run typecheck   # type-check src and test
npm run build       # compile src to dist
npm start           # run dist/index.js
npm run dev         # run src/index.ts with tsx and restart on change
```

To run against the local dev stack from the host, use the database port that the dev stack publishes on `localhost:5432`:

```sh
npm run build
MP_PORT=8090 \
DB_HOST=localhost DB_PORT=5432 DB_NAME=myapp DB_USER=myapp DB_PASSWORD=myapp \
JWT_SECRET=<JWT_SECRET from ../.env.development> \
FRONTEND_URL=http://localhost:5173 \
npm start
```

The client then connects to `ws://localhost:8090/ws`. The Android emulator uses `ws://10.0.2.2:8090/ws`.

Check that the server is up:

```sh
curl http://localhost:8090/ws/health   # {"status":"ok"}
```

## Docker

The `Dockerfile` has three stages: it compiles TypeScript, installs production dependencies, and then runs `node dist/index.js` on `node:22-alpine` as the non-root `node` user. The image has a `HEALTHCHECK` that calls `GET /ws/health`. On `SIGTERM` the server closes every socket with code 1001 and stops within 10 seconds.

```sh
docker build -t kdz-multiplayer .
docker run --rm -p 8090:8090 --env-file <env file> kdz-multiplayer
```

In production, Traefik routes `PathPrefix(/ws)` on the main domain to port 8090 and terminates TLS, so clients use `wss://<domain>/ws`. The server shares the backend's `ENV_FILE` (`DB_*`, `JWT_SECRET`, `FRONTEND_URL`).

## Configuration

All settings come from environment variables. The server exits at start-up when a value is not an integer within its range.

| Variable | Default | Meaning |
|---|---|---|
| `MP_PORT` | 8090 | Listen port. |
| `MP_MAX_PLAYERS` | 8 | Hard cap and default for players per lobby. |
| `MP_MIN_PLAYERS` | 1 | Players in the lobby view needed to start a game. |
| `MP_PLACES_PER_GAME` | 10 | Default number of places per game. |
| `MP_MAX_PLACES_PER_GAME` | 20 | Largest number of places the host may set. |
| `MP_GAME_DURATION_SECONDS` | 300 | Default game timer. |
| `MP_MIN_GAME_DURATION_SECONDS` | 60 | Shortest timer the host may set. |
| `MP_MAX_GAME_DURATION_SECONDS` | 1800 | Longest timer the host may set. |
| `MP_PENALTY_DISTANCE_METERS` | 100000 | Offset counted for a place that a participant did not guess. |
| `MP_RECONNECT_GRACE_SECONDS` | 60 | How long a disconnected player keeps their seat. |
| `MP_LOBBY_IDLE_TTL_SECONDS` | 1800 | A lobby with no activity for this long, and no running game, is deleted. |
| `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` | `localhost`, 5432, `myapp`, `myapp`, empty | The backend's Postgres. `DB_DRIVER` is ignored. |
| `JWT_SECRET` | none | The backend's HS256 secret. Without it, signed-in players cannot connect and only guests can play. |
| `FRONTEND_URL` | none | Allowed `Origin` values, comma separated. A request without an `Origin` header (mobile apps) is always allowed. Without this variable, every browser origin is rejected. |

## HTTP endpoints

- `GET /ws/health` (also `HEAD`) returns `200 {"status":"ok"}`.
- A WebSocket upgrade on `/ws` opens a game connection. An upgrade with a disallowed `Origin` gets `403`.
- Every other path returns `404`.

## Protocol

Messages are JSON text frames, and each has a `type`. The first client message must be `hello`. The full contract (message fields, `LobbyView`, `GameView`, lifecycle rules) is kept with the multiplayer specification. This is a summary.

Client to server:

| `type` | Fields | Notes |
|---|---|---|
| `hello` | `token?`, `nickname?`, `resumeToken?` | `token` is the backend access token; the nickname is then `users.name`. A guest sends `nickname` (2–24 characters, no control characters). A `resumeToken` of a seat that is still held rejoins that seat. |
| `createLobby` | none | The sender becomes the host. |
| `joinLobby` | `code` | Case-insensitive. |
| `leaveLobby` | none | Frees the seat. |
| `updateSettings` | `settings: {maxPlayers?, placeCount?, durationSeconds?}` | Host only, not while a game is playing, within the limits. |
| `startGame` | none | Host only. The host must be in the lobby view. |
| `guess` | `index`, `latitude`, `longitude` | `index` must be the player's current place. The point must lie inside the region. |
| `returnToLobby` | none | From the results view back to the lobby view. |
| `ping` | none | The server answers `pong`. |

Server to client: `welcome` (player id, resume token, limits, defaults), `state` (`serverNow` and a personalised `lobby` snapshot after every change), `guessResult` (offset and place reveal, only to the guesser), `error` (`code`, optional `message`), and `pong`.

Error codes: `hello.required`, `hello.duplicate`, `auth.invalid_token`, `nickname.invalid`, `lobby.not_found`, `lobby.full`, `lobby.not_in_lobby`, `lobby.not_host`, `lobby.not_enough_players`, `lobby.in_game`, `settings.invalid`, `game.not_playing`, `game.no_places`, `guess.invalid`, `guess.wrong_index`, `guess.outside_region`, `resume.invalid`, `message.invalid`, `rate_limited`, `server.error`.

What a client receives before its own guess on a place:

- Only the name of the player's current place.
- No coordinates, description, category, source, or database id.
- For other players, only how many places they have guessed.

All places and every participant's guesses are revealed when the game ends.

### Scoring

The offset is the haversine distance from the guess to the place, with R = 6371008.8 m, rounded to whole metres. This matches the backend's `GeoCalculator`. A player's score is the average offset over all places of the game, and each unguessed place counts as `MP_PENALTY_DISTANCE_METERS`. Lower is better. Ties are broken in this order:

1. more guesses made;
2. earlier time of the last guess;
3. nickname in Czech collation;
4. player id.

Ranks are unique, from 1 to n.

### Robustness

- The largest accepted frame is 4 KiB. A larger frame closes the socket with code 1009.
- Invalid JSON, a binary frame, or an unknown `type` gets `error message.invalid`, and the socket stays open.
- A connection may send at most 20 messages per 5 seconds. Extra messages get `rate_limited` and are dropped.
- The server pings every connection every 30 seconds and terminates a socket that did not answer the previous ping.
- When a new socket resumes a seat that is still connected, the old socket is closed with code 4001.

## Code layout

| Path | Contents |
|---|---|
| `src/index.ts` | Entry point: configuration, database pool, signal handling. |
| `src/server.ts` | Transport: HTTP server, health endpoint, upgrade with origin check, heartbeat, rate limit, timer scheduling, shutdown. |
| `src/hub.ts` | The lobby and game state machine. It is pure, with an injected clock, place source, account resolver, id generator, and outbox. |
| `src/scoring.ts`, `src/geo.ts`, `src/region.ts` | Ranking, haversine, point in polygon, and the region outline. |
| `src/places.ts`, `src/auth.ts`, `src/db.ts` | Postgres place source, JWT verification with the `users.name` lookup, and the pool. |
| `src/protocol.ts`, `src/config.ts` | Wire types and message parsing, and environment configuration. |
| `test/` | Unit tests for the state machine and helpers (fake clock and fake place source), and an integration test that starts the real server on a random port and plays a game with real WebSocket clients. |

`src/region.ts` is a copy of `Region.outline` from the frontend's `lib/game/region.dart`. When the outline changes, update both copies.
