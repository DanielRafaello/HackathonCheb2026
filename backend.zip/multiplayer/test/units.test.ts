import jwt from 'jsonwebtoken';
import { describe, expect, it } from 'vitest';
import { JwtAccountResolver, type UserDirectory } from '../src/auth.js';
import { ConfigError, loadConfig, parseOrigins } from '../src/config.js';
import { distanceMeters, isInRegion, isValidCoordinate, polygonContains } from '../src/geo.js';
import { cryptoIds, LOBBY_CODE_ALPHABET } from '../src/hub.js';
import { placeFromRow } from '../src/places.js';
import { parseClientMessage } from '../src/protocol.js';
import { RateLimiter } from '../src/rateLimit.js';
import { REGION_OUTLINE } from '../src/region.js';
import { rankParticipants } from '../src/scoring.js';
import { isOriginAllowed } from '../src/server.js';
import { REGION_POINTS } from './helpers.js';

describe('geo', () => {
  it('matches the backend GeoCalculator test values', () => {
    expect(distanceMeters(50.22768, 12.879553, 50.22768, 12.879553)).toBe(0);
    const d = distanceMeters(50.22768, 12.879553, 50.236, 12.879553);
    expect(d).toBeGreaterThan(900);
    expect(d).toBeLessThan(950);
    expect(Number.isInteger(d)).toBe(true);
  });

  it('computes a known distance (Cheb to Karlovy Vary, about 36 km) symmetrically', () => {
    const d = distanceMeters(50.0796, 12.3739, 50.231, 12.872);
    expect(d).toBeGreaterThan(38_000);
    expect(d).toBeLessThan(40_000);
    expect(distanceMeters(50.231, 12.872, 50.0796, 12.3739)).toBe(d);
  });

  it('uses R = 6371008.8 m (one degree of latitude ≈ 111195 m)', () => {
    expect(distanceMeters(0, 0, 1, 0)).toBe(Math.round((6371008.8 * Math.PI) / 180));
  });

  it('copies the frontend region outline', () => {
    expect(REGION_OUTLINE).toHaveLength(76);
    expect(REGION_OUTLINE[0]).toEqual([50.229, 12.137]);
    expect(REGION_OUTLINE.at(-1)).toEqual([50.256, 12.107]);
  });

  it('contains the region towns and excludes places outside', () => {
    for (const [lat, lon] of REGION_POINTS) expect(isInRegion(lat, lon), `${lat},${lon}`).toBe(true);
    expect(isInRegion(50.0755, 14.4378)).toBe(false); // Prague
    expect(isInRegion(49.7384, 13.3736)).toBe(false); // Plzeň
    expect(isInRegion(50.3167, 11.9167)).toBe(false); // Hof (DE)
    expect(isInRegion(0, 0)).toBe(false);
  });

  it('point in polygon works on a square', () => {
    const square: Array<[number, number]> = [
      [0, 0],
      [0, 10],
      [10, 10],
      [10, 0],
    ];
    expect(polygonContains(square, 5, 5)).toBe(true);
    expect(polygonContains(square, 11, 5)).toBe(false);
    expect(polygonContains(square, 5, -1)).toBe(false);
  });

  it('validates coordinates', () => {
    expect(isValidCoordinate(50, 12)).toBe(true);
    expect(isValidCoordinate(-90, 180)).toBe(true);
    expect(isValidCoordinate(90.0001, 0)).toBe(false);
    expect(isValidCoordinate(0, -180.1)).toBe(false);
    expect(isValidCoordinate(Number.NaN, 0)).toBe(false);
    expect(isValidCoordinate('50', 12)).toBe(false);
  });
});

describe('scoring', () => {
  it('averages over all places with the penalty for unguessed ones', () => {
    const rows = rankParticipants(
      [
        { playerId: 'a', nickname: 'A', distances: [100, 200], lastGuessAt: 5 },
        { playerId: 'b', nickname: 'B', distances: [10, 20, 30], lastGuessAt: 9 },
      ],
      3,
      1000,
    );
    expect(rows).toEqual([
      { rank: 1, playerId: 'b', nickname: 'B', averageDistanceMeters: 20, guessedCount: 3, totalDistanceMeters: 60, finishedAt: 9 },
      { rank: 2, playerId: 'a', nickname: 'A', averageDistanceMeters: 433, guessedCount: 2, totalDistanceMeters: 1300, finishedAt: 5 },
    ]);
  });

  it('breaks ties by guesses, then finish time, then nickname, with unique ranks', () => {
    const rows = rankParticipants(
      [
        { playerId: '1', nickname: 'Žofie', distances: [0, 0], lastGuessAt: 10 },
        { playerId: '2', nickname: 'Čeněk', distances: [0, 0], lastGuessAt: 10 },
        { playerId: '3', nickname: 'Adam', distances: [0, 0], lastGuessAt: 20 },
        { playerId: '4', nickname: 'Bob', distances: [0], lastGuessAt: 1 },
        { playerId: '5', nickname: 'Cyril', distances: [], lastGuessAt: null },
        { playerId: '6', nickname: 'Cyril', distances: [], lastGuessAt: null },
      ],
      2,
      0,
    );
    expect(rows.map((r) => [r.rank, r.playerId])).toEqual([
      [1, '2'], // Čeněk before Žofie (Czech collation)
      [2, '1'],
      [3, '3'],
      [4, '4'],
      [5, '5'],
      [6, '6'],
    ]);
  });

  it('handles zero places', () => {
    // Regression: rows that show the same (rounded) average are ordered by "more
    // guesses", even when the exact totals differ by less than a metre per place.
    const tied = rankParticipants(
      [
        { playerId: 'few', nickname: 'A', distances: [0], lastGuessAt: 1 }, // 0 + 1001 penalty -> avg 500.5 -> 501
        { playerId: 'all', nickname: 'B', distances: [501, 501], lastGuessAt: 2 }, // 1002 -> avg 501
      ],
      2,
      1001,
    );
    expect(tied.map((r) => [r.rank, r.playerId, r.averageDistanceMeters])).toEqual([
      [1, 'all', 501],
      [2, 'few', 501],
    ]);
    expect(rankParticipants([{ playerId: 'a', nickname: 'A', distances: [], lastGuessAt: null }], 0, 100)[0])
      .toMatchObject({ averageDistanceMeters: 0, totalDistanceMeters: 0 });
  });
});

describe('config', () => {
  it('uses the documented defaults', () => {
    const config = loadConfig({});
    expect(config.port).toBe(8090);
    expect(config.game).toEqual({
      maxPlayers: 8,
      minPlayers: 1,
      defaultPlaceCount: 10,
      maxPlaceCount: 20,
      defaultDurationSeconds: 300,
      minDurationSeconds: 60,
      maxDurationSeconds: 1800,
      penaltyDistanceMeters: 100000,
      reconnectGraceSeconds: 60,
      lobbyIdleTtlSeconds: 1800,
    });
    expect(config.jwtSecret).toBeNull();
    expect(config.allowedOrigins).toEqual([]);
  });

  it('reads the environment', () => {
    const config = loadConfig({
      MP_PORT: '9000',
      MP_MAX_PLAYERS: '4',
      MP_MIN_PLAYERS: '2',
      MP_PLACES_PER_GAME: '5',
      MP_MAX_PLACES_PER_GAME: '6',
      MP_GAME_DURATION_SECONDS: '120',
      MP_MIN_GAME_DURATION_SECONDS: '30',
      MP_MAX_GAME_DURATION_SECONDS: '600',
      MP_PENALTY_DISTANCE_METERS: '5000',
      MP_RECONNECT_GRACE_SECONDS: '10',
      MP_LOBBY_IDLE_TTL_SECONDS: '100',
      DB_HOST: 'db',
      DB_PORT: '5433',
      DB_NAME: 'n',
      DB_USER: 'u',
      DB_PASSWORD: 'p',
      DB_DRIVER: 'pdo_pgsql',
      JWT_SECRET: 's',
      FRONTEND_URL: 'http://localhost:5173, https://example.org/',
    });
    expect(config.port).toBe(9000);
    expect(config.game).toMatchObject({ maxPlayers: 4, minPlayers: 2, defaultPlaceCount: 5, maxPlaceCount: 6 });
    expect(config.game.defaultDurationSeconds).toBe(120);
    expect(config.db).toEqual({ host: 'db', port: 5433, database: 'n', user: 'u', password: 'p' });
    expect(config.jwtSecret).toBe('s');
    expect(config.allowedOrigins).toEqual(['http://localhost:5173', 'https://example.org']);
  });

  it.each([
    [{ MP_PORT: 'abc' }],
    [{ MP_MAX_PLAYERS: '0' }],
    [{ MP_MAX_PLAYERS: '2', MP_MIN_PLAYERS: '3' }],
    [{ MP_MAX_PLACES_PER_GAME: '5', MP_PLACES_PER_GAME: '6' }],
    [{ MP_GAME_DURATION_SECONDS: '10' }],
    [{ MP_PENALTY_DISTANCE_METERS: '-1' }],
    [{ MP_MAX_PLAYERS: '2.5' }],
  ])('rejects inconsistent values %j', (env) => {
    expect(() => loadConfig(env)).toThrow(ConfigError);
  });

  it('parses origins', () => {
    expect(parseOrigins(undefined)).toEqual([]);
    expect(parseOrigins(' a , ,b/ ')).toEqual(['a', 'b']);
  });
});

describe('origin check', () => {
  const allowed = ['http://localhost:5173'];
  it('allows a missing origin and an exact match', () => {
    expect(isOriginAllowed(undefined, allowed)).toBe(true);
    expect(isOriginAllowed('http://localhost:5173', allowed)).toBe(true);
  });
  it('rejects anything else', () => {
    expect(isOriginAllowed('http://localhost:5174', allowed)).toBe(false);
    expect(isOriginAllowed('https://evil.example', allowed)).toBe(false);
    expect(isOriginAllowed('null', allowed)).toBe(false);
    expect(isOriginAllowed('http://localhost:5173', [])).toBe(false);
  });
});

describe('protocol', () => {
  it('parses known message types', () => {
    expect(parseClientMessage('{"type":"joinLobby","code":"abc"}')).toEqual({
      ok: true,
      message: { type: 'joinLobby', code: 'abc' },
    });
  });
  it.each(['', '{', '1', '"hello"', '[]', '{}', '{"type":"nope"}', '{"type":null}'])('rejects %j', (text) => {
    expect(parseClientMessage(text).ok).toBe(false);
  });
});

describe('rate limiter', () => {
  it('allows N events per window', () => {
    let now = 0;
    const limiter = new RateLimiter(3, 1000, () => now);
    expect([limiter.allow(), limiter.allow(), limiter.allow(), limiter.allow()]).toEqual([true, true, true, false]);
    now = 999;
    expect(limiter.allow()).toBe(false);
    now = 1000;
    expect(limiter.allow()).toBe(true);
  });
});

describe('ids', () => {
  it('generates 6-character lobby codes from the safe alphabet', () => {
    expect(LOBBY_CODE_ALPHABET).not.toMatch(/[0O1IL]/);
    for (let i = 0; i < 200; i++) expect(cryptoIds.lobbyCode()).toMatch(/^[ABCDEFGHJKMNPQRSTUVWXYZ2-9]{6}$/);
    expect(cryptoIds.resumeToken()).not.toBe(cryptoIds.resumeToken());
    expect(cryptoIds.resumeToken().length).toBeGreaterThanOrEqual(40);
  });
});

describe('places', () => {
  it('maps a database row to a place', () => {
    expect(
      placeFromRow({
        id: '5',
        name: 'Loket',
        latitude: '50.186',
        longitude: 12.754,
        description: null,
        content_source_url: null,
        category: 'Hrady',
        title: 'T',
        publisher: 'P',
        portal_url: 'U',
        license_code: 'CC BY 4.0',
        license_url: 'L',
        attribution_text: 'A',
      }),
    ).toEqual({
      id: 5,
      name: 'Loket',
      latitude: 50.186,
      longitude: 12.754,
      category: 'Hrady',
      description: '',
      contentSourceUrl: null,
      source: { title: 'T', publisher: 'P', portalUrl: 'U', licenseCode: 'CC BY 4.0', licenseUrl: 'L', attributionText: 'A' },
    });
  });
});

describe('JwtAccountResolver', () => {
  const secret = 'unit-test-secret-that-is-long-enough-for-hs256';
  const users: UserDirectory = { findName: async (id) => (id === 7 ? '  Jana  ' : null) };
  const resolver = new JwtAccountResolver(secret, users);
  const sign = (payload: object, options: jwt.SignOptions = {}, key = secret): string =>
    jwt.sign(payload, key, { algorithm: 'HS256', expiresIn: 3600, ...options });

  it('resolves a valid backend token to the user name', async () => {
    expect(await resolver.resolve(sign({ sub: 7, role: 'user' }))).toEqual({ userId: 7, name: 'Jana' });
  });

  it('accepts a numeric string sub', async () => {
    expect(await resolver.resolve(sign({ sub: '7', role: 'user' }))).toEqual({ userId: 7, name: 'Jana' });
  });

  it('rejects unknown users, bad subs, wrong secrets, expired and malformed tokens', async () => {
    expect(await resolver.resolve(sign({ sub: 8 }))).toBeNull();
    expect(await resolver.resolve(sign({ sub: 'abc' }))).toBeNull();
    expect(await resolver.resolve(sign({ role: 'user' }))).toBeNull();
    expect(await resolver.resolve(sign({ sub: 7 }, {}, 'another-secret-another-secret-another'))).toBeNull();
    const expired = jwt.sign({ sub: 7, exp: Math.floor(Date.now() / 1000) - 10 }, secret, { algorithm: 'HS256' });
    expect(await resolver.resolve(expired)).toBeNull();
    expect(await resolver.resolve('not-a-jwt')).toBeNull();
    const none = jwt.sign({ sub: 7 }, '', { algorithm: 'none' });
    expect(await resolver.resolve(none)).toBeNull();
  });

  it('rejects everything without a secret', async () => {
    expect(await new JwtAccountResolver(null, users).resolve(sign({ sub: 7 }))).toBeNull();
  });
});
