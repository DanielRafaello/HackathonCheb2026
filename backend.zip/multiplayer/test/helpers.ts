import type { Account, AccountResolver } from '../src/auth.js';
import type { GameConfig } from '../src/config.js';
import type { Clock, ConnId, IdGenerator, Outbox } from '../src/hub.js';
import { GameHub } from '../src/hub.js';
import type { Place, PlaceSource } from '../src/places.js';
import { StaticPlaceSource } from '../src/places.js';
import type { LobbyView, ServerMessage } from '../src/protocol.js';

/** Points inside the Karlovy Vary Region (distinct, easy to recognise in payloads). */
export const REGION_POINTS: Array<[number, number]> = [
  [50.0796, 12.3739], // Cheb
  [50.231, 12.872], // Karlovy Vary
  [50.1813, 12.6401], // Sokolov
  [49.9646, 12.7012], // Mariánské Lázně
  [50.3059, 12.939], // Ostrov
  [50.1997, 12.1985], // Aš (approx)
  [50.1497, 12.4571], // Kynšperk
  [50.0573, 12.8264], // Bečov (approx)
  [50.0951, 13.0731], // Toužim (approx)
  [50.3212, 12.7932], // Nejdek (approx)
  [50.2632, 12.6025], // Kraslice (approx)
  [50.1361, 12.9822], // Teplá (approx)
];

export function makePlaces(count = 10): Place[] {
  return Array.from({ length: count }, (_, i) => {
    const [latitude, longitude] = REGION_POINTS[i % REGION_POINTS.length]!;
    return {
      id: 1000 + i,
      name: `Místo ${i}`,
      latitude: latitude + 0.000123 * (i + 1),
      longitude: longitude + 0.000321 * (i + 1),
      category: `Kategorie ${i}`,
      description: `SECRET-DESCRIPTION-${i}`,
      contentSourceUrl: i % 2 === 0 ? `https://example.org/place/${i}` : null,
      source: {
        title: 'Zdroj',
        publisher: 'DATA ZÁPAD',
        portalUrl: 'https://example.org',
        licenseCode: 'CC BY 4.0',
        licenseUrl: 'https://creativecommons.org/licenses/by/4.0/',
        attributionText: 'Zdroj: DATA ZÁPAD',
      },
    };
  });
}

export const TEST_CONFIG: GameConfig = {
  maxPlayers: 4,
  minPlayers: 1,
  defaultPlaceCount: 3,
  maxPlaceCount: 10,
  defaultDurationSeconds: 300,
  minDurationSeconds: 60,
  maxDurationSeconds: 1800,
  penaltyDistanceMeters: 100000,
  reconnectGraceSeconds: 60,
  lobbyIdleTtlSeconds: 1800,
};

export class FakeClock implements Clock {
  constructor(public t = 1_800_000_000_000) {}
  now(): number {
    return this.t;
  }
  advance(ms: number): void {
    this.t += ms;
  }
}

export function sequentialIds(codes: string[] = ['ABCDEF', 'GHJKMN', 'PQRSTU', 'VWXYZ2']): IdGenerator {
  let p = 0;
  let r = 0;
  let c = 0;
  return {
    playerId: () => `p${++p}`,
    resumeToken: () => `resume-${++r}`,
    lobbyCode: () => codes[c++ % codes.length]!,
  };
}

export class RecordingOutbox implements Outbox {
  readonly messages = new Map<ConnId, ServerMessage[]>();
  readonly closed: Array<{ connId: ConnId; code: number; reason: string }> = [];

  send(connId: ConnId, message: ServerMessage): void {
    // Store a JSON round trip, exactly what a client would receive.
    const list = this.messages.get(connId) ?? [];
    list.push(JSON.parse(JSON.stringify(message)) as ServerMessage);
    this.messages.set(connId, list);
  }

  close(connId: ConnId, code: number, reason: string): void {
    this.closed.push({ connId, code, reason });
  }

  all(connId: ConnId): ServerMessage[] {
    return this.messages.get(connId) ?? [];
  }

  ofType<T extends ServerMessage['type']>(connId: ConnId, type: T): Array<Extract<ServerMessage, { type: T }>> {
    return this.all(connId).filter((m): m is Extract<ServerMessage, { type: T }> => m.type === type);
  }

  last<T extends ServerMessage['type']>(connId: ConnId, type: T): Extract<ServerMessage, { type: T }> | undefined {
    return this.ofType(connId, type).at(-1);
  }

  lobby(connId: ConnId): LobbyView | null {
    const state = this.last(connId, 'state');
    if (!state) throw new Error(`no state for ${connId}`);
    return state.lobby;
  }

  errors(connId: ConnId): string[] {
    return this.ofType(connId, 'error').map((e) => e.code);
  }

  lastError(connId: ConnId): string | undefined {
    return this.last(connId, 'error')?.code;
  }

  clear(connId?: ConnId): void {
    if (connId === undefined) this.messages.clear();
    else this.messages.delete(connId);
  }
}

export class FakeAccounts implements AccountResolver {
  readonly tokens = new Map<string, Account>();
  async resolve(token: string): Promise<Account | null> {
    return this.tokens.get(token) ?? null;
  }
}

export interface Harness {
  hub: GameHub;
  clock: FakeClock;
  outbox: RecordingOutbox;
  accounts: FakeAccounts;
  places: Place[];
  /** Connects a socket and says hello as a guest; returns the player id. */
  join(connId: ConnId, nickname: string): Promise<string>;
  send(connId: ConnId, message: Record<string, unknown>): Promise<void>;
}

export function harness(
  options: { config?: Partial<GameConfig>; places?: Place[]; placeSource?: PlaceSource; ids?: IdGenerator } = {},
): Harness {
  const clock = new FakeClock();
  const outbox = new RecordingOutbox();
  const accounts = new FakeAccounts();
  const places = options.places ?? makePlaces(10);
  const hub = new GameHub({
    config: { ...TEST_CONFIG, ...options.config },
    places: options.placeSource ?? new StaticPlaceSource(places),
    accounts,
    outbox,
    clock,
    ids: options.ids ?? sequentialIds(),
  });
  const send = (connId: ConnId, message: Record<string, unknown>): Promise<void> =>
    hub.handleText(connId, JSON.stringify(message));
  return {
    hub,
    clock,
    outbox,
    accounts,
    places,
    send,
    async join(connId, nickname) {
      hub.connect(connId);
      await send(connId, { type: 'hello', nickname });
      const welcome = outbox.last(connId, 'welcome');
      if (!welcome) throw new Error(`hello failed: ${outbox.lastError(connId)}`);
      return welcome.playerId;
    },
  };
}
