import { randomBytes } from 'node:crypto';
import http from 'node:http';
import net from 'node:net';
import { afterEach, describe, expect, it } from 'vitest';
import { WebSocket } from 'ws';
import { StaticPlaceSource } from '../src/places.js';
import type { LobbyView, ServerMessage } from '../src/protocol.js';
import { startServer, type RunningServer, type ServerOptions } from '../src/server.js';
import { FakeAccounts, makePlaces, TEST_CONFIG } from './helpers.js';

const ORIGIN = 'http://localhost:5173';

class Client {
  readonly messages: ServerMessage[] = [];
  private waiters: Array<() => void> = [];
  closeCode: number | null = null;

  private constructor(readonly ws: WebSocket) {
    ws.on('message', (data) => {
      this.messages.push(JSON.parse(data.toString()) as ServerMessage);
      this.notify();
    });
    ws.on('close', (code) => {
      this.closeCode = code;
      this.notify();
    });
  }

  static open(port: number, headers: Record<string, string> = { Origin: ORIGIN }): Promise<Client> {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, { headers });
      const client = new Client(ws);
      ws.once('open', () => resolve(client));
      ws.once('error', reject);
    });
  }

  private notify(): void {
    for (const waiter of this.waiters.splice(0)) waiter();
  }

  send(message: Record<string, unknown>): void {
    this.ws.send(JSON.stringify(message));
  }

  /** Waits for the first message after `from` that matches. */
  async waitFor<T extends ServerMessage>(
    predicate: (m: ServerMessage) => m is T,
    from = 0,
    timeoutMs = 5000,
  ): Promise<T> {
    const deadline = Date.now() + timeoutMs;
    for (;;) {
      const found = this.messages.slice(from).find(predicate);
      if (found) return found;
      if (Date.now() > deadline) throw new Error(`timed out; got ${JSON.stringify(this.messages.slice(from))}`);
      await new Promise<void>((resolve) => {
        this.waiters.push(resolve);
        setTimeout(resolve, 50);
      });
    }
  }

  /** Sends a message and waits for the next message of the given type. */
  async request<K extends ServerMessage['type']>(
    message: Record<string, unknown>,
    type: K,
  ): Promise<Extract<ServerMessage, { type: K }>> {
    const from = this.messages.length;
    this.send(message);
    return this.waitFor((m): m is Extract<ServerMessage, { type: K }> => m.type === type, from);
  }

  /** Waits for a state whose lobby satisfies the predicate. */
  waitForState(predicate: (lobby: LobbyView | null) => boolean, from = 0): Promise<ServerMessage> {
    return this.waitFor((m): m is Extract<ServerMessage, { type: 'state' }> => m.type === 'state' && predicate(m.lobby), from);
  }

  lastLobby(): LobbyView | null {
    const states = this.messages.filter((m): m is Extract<ServerMessage, { type: 'state' }> => m.type === 'state');
    return states.at(-1)?.lobby ?? null;
  }

  close(): Promise<void> {
    return new Promise((resolve) => {
      if (this.ws.readyState === WebSocket.CLOSED) return resolve();
      this.ws.once('close', () => resolve());
      this.ws.close();
    });
  }
}

function httpGet(port: number, path: string, method = 'GET'): Promise<{ status: number; body: string }> {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path, method }, (res) => {
      let body = '';
      res.on('data', (chunk) => (body += chunk));
      res.on('end', () => resolve({ status: res.statusCode ?? 0, body }));
    });
    req.on('error', reject);
    req.end();
  });
}

function upgradeStatus(port: number, path: string, origin?: string): Promise<number> {
  return new Promise((resolve) => {
    const ws = new WebSocket(`ws://127.0.0.1:${port}${path}`, origin ? { headers: { Origin: origin } } : {});
    ws.on('unexpected-response', (_req, res) => {
      resolve(res.statusCode ?? 0);
      ws.terminate();
    });
    ws.on('open', () => {
      resolve(101);
      ws.close();
    });
    ws.on('error', () => undefined);
  });
}

/** A raw TCP client that sends the /ws upgrade request and then does nothing on its own. */
function rawUpgrade(port: number): net.Socket {
  const socket = net.connect(port, '127.0.0.1');
  socket.write(
    'GET /ws HTTP/1.1\r\nHost: 127.0.0.1\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n' +
      `Sec-WebSocket-Key: ${randomBytes(16).toString('base64')}\r\nSec-WebSocket-Version: 13\r\n\r\n`,
  );
  return socket;
}

/** A masked client-to-server text frame for a payload shorter than 126 bytes. */
function maskedTextFrame(text: string): Buffer {
  const payload = Buffer.from(text, 'utf8');
  const mask = randomBytes(4);
  const masked = Buffer.from(payload.map((byte, i) => byte ^ mask[i % 4]!));
  return Buffer.concat([Buffer.from([0x81, 0x80 | payload.length]), mask, masked]);
}

describe('multiplayer server (integration)', () => {
  let server: RunningServer | null = null;
  const clients: Client[] = [];
  const places = makePlaces(10);

  async function boot(overrides: Partial<ServerOptions> = {}): Promise<{ port: number; accounts: FakeAccounts }> {
    const accounts = new FakeAccounts();
    server = await startServer(
      {
        game: { ...TEST_CONFIG, minDurationSeconds: 1, reconnectGraceSeconds: 30 },
        allowedOrigins: [ORIGIN],
        places: new StaticPlaceSource(places),
        accounts,
        ...overrides,
      },
      0,
      '127.0.0.1',
    );
    return { port: server.port, accounts };
  }

  async function connect(port: number, headers?: Record<string, string>): Promise<Client> {
    const client = await Client.open(port, headers);
    clients.push(client);
    return client;
  }

  async function hello(client: Client, fields: Record<string, unknown>) {
    return client.request({ type: 'hello', ...fields }, 'welcome');
  }

  afterEach(async () => {
    await Promise.all(clients.splice(0).map((c) => c.close()));
    await server?.close();
    server = null;
  });

  it('serves the health endpoint and 404 elsewhere', async () => {
    const { port } = await boot();
    expect(await httpGet(port, '/ws/health')).toEqual({ status: 200, body: '{"status":"ok"}' });
    expect((await httpGet(port, '/ws/health', 'HEAD')).status).toBe(200);
    expect((await httpGet(port, '/')).status).toBe(404);
    expect((await httpGet(port, '/ws')).status).toBe(404);
    expect((await httpGet(port, '/ws/health', 'POST')).status).toBe(404);
  });

  it('checks the upgrade path and the Origin header', async () => {
    const { port } = await boot();
    expect(await upgradeStatus(port, '/ws', ORIGIN)).toBe(101);
    expect(await upgradeStatus(port, '/ws')).toBe(101); // mobile: no Origin
    expect(await upgradeStatus(port, '/ws', 'https://evil.example')).toBe(403);
    expect(await upgradeStatus(port, '/other', ORIGIN)).toBe(404);
  });

  it('plays a full game with three clients, a reconnect and a return to the lobby', async () => {
    const { port, accounts } = await boot();
    accounts.tokens.set('jwt-bob', { userId: 42, name: 'Bob Účet' });

    const anna = await connect(port);
    const bob = await connect(port);
    const cyril = await connect(port, {}); // no Origin header

    const annaWelcome = await hello(anna, { nickname: 'Anna' });
    const bobWelcome = await hello(bob, { token: 'jwt-bob' });
    const cyrilWelcome = await hello(cyril, { nickname: 'Cyril' });
    expect(bobWelcome).toMatchObject({ nickname: 'Bob Účet', isGuest: false });
    expect(annaWelcome.defaults).toEqual({ maxPlayers: 4, placeCount: 3, durationSeconds: 300 });

    const created = await anna.request({ type: 'createLobby' }, 'state');
    const code = created.lobby!.code;
    expect(code).toMatch(/^[ABCDEFGHJKMNPQRSTUVWXYZ2-9]{6}$/);
    await bob.request({ type: 'joinLobby', code: code.toLowerCase() }, 'state');
    await cyril.request({ type: 'joinLobby', code }, 'state');
    await anna.waitForState((l) => l?.players.length === 3);

    await anna.request({ type: 'updateSettings', settings: { placeCount: 2, durationSeconds: 60 } }, 'state');
    const notHost = await bob.request({ type: 'startGame' }, 'error');
    expect(notHost.code).toBe('lobby.not_host');

    const from = cyril.messages.length;
    anna.send({ type: 'startGame' });
    await cyril.waitForState((l) => l?.phase === 'playing', from);
    const cyrilGame = cyril.lastLobby()!.game!;
    expect(cyrilGame.placeCount).toBe(2);
    expect(cyrilGame.self).toEqual({ currentIndex: 0, currentPlaceName: 'Místo 0', rounds: [] });
    expect(JSON.stringify(cyril.messages)).not.toContain('SECRET');

    // Anna guesses both places; the second guess is outside the region first.
    const r0 = await anna.request({ type: 'guess', index: 0, latitude: places[0]!.latitude, longitude: places[0]!.longitude }, 'guessResult');
    expect(r0).toMatchObject({ index: 0, distanceMeters: 0, place: { id: places[0]!.id, description: 'SECRET-DESCRIPTION-0' } });
    const outside = await anna.request({ type: 'guess', index: 1, latitude: 50.08, longitude: 14.43 }, 'error');
    expect(outside.code).toBe('guess.outside_region');
    const wrong = await anna.request({ type: 'guess', index: 0, latitude: 50.08, longitude: 12.37 }, 'error');
    expect(wrong.code).toBe('guess.wrong_index');
    await anna.request({ type: 'guess', index: 1, latitude: 50.08, longitude: 12.37 }, 'guessResult');

    // Others see only Anna's count.
    await cyril.waitForState((l) => l?.players.find((p) => p.id === annaWelcome.playerId)?.guessedCount === 2);
    expect(cyril.messages.some((m) => m.type === 'guessResult')).toBe(false);
    expect(JSON.stringify(cyril.messages)).not.toContain('SECRET');

    // Bob guesses once, then Cyril drops and comes back with the resume token.
    await bob.request({ type: 'guess', index: 0, latitude: 50.2, longitude: 12.8 }, 'guessResult');
    await cyril.close();
    await anna.waitForState((l) => l?.players.find((p) => p.id === cyrilWelcome.playerId)?.connected === false);
    const cyril2 = await connect(port);
    const resumed = await hello(cyril2, { resumeToken: cyrilWelcome.resumeToken });
    expect(resumed.playerId).toBe(cyrilWelcome.playerId);
    await cyril2.waitForState((l) => l?.phase === 'playing' && l.game?.self?.currentIndex === 0);
    await anna.waitForState((l) => l?.players.find((p) => p.id === cyrilWelcome.playerId)?.connected === true);

    await cyril2.request({ type: 'guess', index: 0, latitude: places[0]!.latitude, longitude: places[0]!.longitude }, 'guessResult');
    await cyril2.request({ type: 'guess', index: 1, latitude: places[1]!.latitude, longitude: places[1]!.longitude }, 'guessResult');
    const fromBob = bob.messages.length;
    bob.send({ type: 'guess', index: 1, latitude: places[1]!.latitude, longitude: places[1]!.longitude });
    await bob.waitForState((l) => l?.phase === 'finished', fromBob);

    // Everybody gets the full results.
    for (const client of [anna, bob, cyril2]) {
      const lobby = await client.waitForState((l) => l?.phase === 'finished').then(() => client.lastLobby()!);
      expect(lobby.players.every((p) => p.view === 'results')).toBe(true);
      const game = lobby.game!;
      expect(game.status).toBe('finished');
      expect(game.places!.map((p) => p.id)).toEqual([places[0]!.id, places[1]!.id]);
      expect(Object.keys(game.guesses!).sort()).toEqual(
        [annaWelcome.playerId, bobWelcome.playerId, cyrilWelcome.playerId].sort(),
      );
      expect(game.leaderboard!.map((r) => r.rank)).toEqual([1, 2, 3]);
      expect(game.leaderboard![0]!.playerId).toBe(cyrilWelcome.playerId); // two exact guesses
      expect(game.self!.rounds).toHaveLength(2);
    }

    // Back to the lobby and a second game for the ones who returned.
    await bob.request({ type: 'returnToLobby' }, 'state');
    await anna.request({ type: 'returnToLobby' }, 'state');
    const second = anna.messages.length;
    const secondForCyril = cyril2.messages.length;
    anna.send({ type: 'startGame' });
    await anna.waitForState((l) => l?.phase === 'playing', second);
    expect(anna.lastLobby()!.game!.participantIds.sort()).toEqual([annaWelcome.playerId, bobWelcome.playerId].sort());
    await cyril2.waitForState((l) => l?.phase === 'playing', secondForCyril);
    expect(cyril2.lastLobby()!.game!.self).toBeNull();
    expect(cyril2.lastLobby()!.players.find((p) => p.id === cyrilWelcome.playerId)?.view).toBe('results');

    const left = await cyril2.request({ type: 'leaveLobby' }, 'state');
    expect(left.lobby).toBeNull();
  });

  it('ends the game when the server timer runs out', async () => {
    const { port } = await boot();
    const anna = await connect(port);
    await hello(anna, { nickname: 'Anna' });
    await anna.request({ type: 'createLobby' }, 'state');
    await anna.request({ type: 'updateSettings', settings: { durationSeconds: 1 } }, 'state');
    const started = await anna.request({ type: 'startGame' }, 'state');
    expect(started.lobby!.game!.endsAt - started.lobby!.game!.startedAt).toBe(1000);
    await anna.waitForState((l) => l?.phase === 'finished');
    const board = anna.lastLobby()!.game!.leaderboard!;
    expect(board).toEqual([
      expect.objectContaining({ guessedCount: 0, averageDistanceMeters: 100000, finishedAt: null }),
    ]);
  });

  it('answers bad frames with errors and keeps the socket open', async () => {
    const { port } = await boot();
    const client = await connect(port);
    client.ws.send('{oops');
    await client.waitFor((m): m is ServerMessage => m.type === 'error' && m.code === 'message.invalid');
    client.ws.send(Buffer.from([1, 2, 3]), { binary: true });
    await client.waitFor((m): m is ServerMessage => m.type === 'error' && m.code === 'message.invalid', 1);
    const required = await client.request({ type: 'joinLobby', code: 'ABCDEF' }, 'error');
    expect(required.code).toBe('hello.required');
    expect(await client.request({ type: 'ping' }, 'pong')).toEqual({ type: 'pong' });
  });

  it('rate-limits a chatty connection and answers rate_limited once per burst', async () => {
    const { port } = await boot({ rateLimit: { limit: 5, windowMs: 10_000 } });
    const client = await connect(port);
    for (let i = 0; i < 7; i++) client.send({ type: 'ping' });
    const limited = await client.waitFor((m): m is ServerMessage => m.type === 'error' && m.code === 'rate_limited');
    expect(limited).toBeTruthy();
    await client.waitFor((m): m is ServerMessage => client.messages.filter((x) => x.type === 'pong').length >= 5);
    await new Promise((resolve) => setTimeout(resolve, 100));
    expect(client.messages.filter((m) => m.type === 'pong')).toHaveLength(5);
    expect(client.messages.filter((m) => m.type === 'error' && m.code === 'rate_limited')).toHaveLength(1);
    expect(client.closeCode).toBeNull();
  });

  it('closes a connection with 1008 when it keeps sending after rate_limited', async () => {
    const { port } = await boot({ rateLimit: { limit: 5, windowMs: 10_000 } });
    const client = await connect(port);
    for (let i = 0; i < 30; i++) client.ws.send('{}');
    await client.waitFor((m): m is ServerMessage => false, 0, 1000).catch(() => undefined);
    expect(client.messages.filter((m) => m.type === 'error' && m.code === 'rate_limited')).toHaveLength(1);
    expect(client.closeCode).toBe(1008);
  });

  it('terminates a socket that keeps sending but never answers pings', async () => {
    const { port } = await boot({ heartbeatIntervalMs: 100, rateLimit: { limit: 10_000, windowMs: 1_000 } });
    const socket = rawUpgrade(port);
    socket.on('data', () => undefined);
    socket.on('error', () => undefined);
    await new Promise((resolve) => setTimeout(resolve, 50));
    expect(server!.hub.connectionCount).toBe(1);
    const flood = setInterval(() => socket.write(maskedTextFrame('{"type":"ping"}')), 10);
    try {
      for (let i = 0; i < 40 && server!.hub.connectionCount > 0; i++) await new Promise((r) => setTimeout(r, 25));
    } finally {
      clearInterval(flood);
      socket.destroy();
    }
    expect(server!.hub.connectionCount).toBe(0);
  });

  it('terminates a socket that sends but never reads before its output buffer grows without limit', async () => {
    // A high heartbeat interval and rate limit, so only the output-buffer cap can end the connection.
    const { port } = await boot({ heartbeatIntervalMs: 60_000, rateLimit: { limit: 1_000_000, windowMs: 1_000 } });
    const socket = rawUpgrade(port);
    socket.on('error', () => undefined);
    await new Promise((resolve) => setTimeout(resolve, 50));
    socket.pause();
    expect(server!.hub.connectionCount).toBe(1);
    // Each '{}' gets a message.invalid reply that the client never reads.
    const chunk = Buffer.concat(Array.from({ length: 1000 }, () => maskedTextFrame('{}')));
    try {
      for (let i = 0; i < 400 && server!.hub.connectionCount > 0; i++) {
        if (!socket.destroyed) socket.write(chunk);
        await new Promise((r) => setTimeout(r, 10));
      }
    } finally {
      socket.destroy();
    }
    expect(server!.hub.connectionCount).toBe(0);
  });

  it('closes a socket that sends more than 4 KiB in one frame', async () => {
    const { port } = await boot();
    const client = await connect(port);
    client.send({ type: 'hello', nickname: 'x'.repeat(5000) });
    await client.waitFor((m): m is ServerMessage => false, 0, 2000).catch(() => undefined);
    expect(client.closeCode).toBe(1009);
  });

  it('terminates sockets that stop answering pings', async () => {
    const { port } = await boot({ heartbeatIntervalMs: 100 });
    // A raw TCP client that completes the handshake but never answers a ping.
    const socket = rawUpgrade(port);
    let received = '';
    socket.on('data', (chunk) => (received += chunk.toString('latin1')));
    const closed = new Promise<void>((resolve) => socket.on('close', () => resolve()));
    await new Promise((resolve) => setTimeout(resolve, 50));
    expect(received).toContain('101 Switching Protocols');
    expect(server!.hub.connectionCount).toBe(1);
    await closed;
    for (let i = 0; i < 20 && server!.hub.connectionCount > 0; i++) await new Promise((r) => setTimeout(r, 25));
    expect(server!.hub.connectionCount).toBe(0);
  });

  it('closes every socket with 1001 on shutdown', async () => {
    const { port } = await boot();
    const client = await connect(port);
    await hello(client, { nickname: 'Anna' });
    await server!.close();
    server = null;
    await client.close();
    expect(client.closeCode).toBe(1001);
  });
});
