import { describe, expect, it } from 'vitest';
import { CLOSE_REPLACED, normalizeNickname } from '../src/hub.js';
import { distanceMeters } from '../src/geo.js';
import { MAX_BUFFERED_BYTES } from '../src/server.js';
import type { Place, PlaceSource } from '../src/places.js';
import type { LobbyView } from '../src/protocol.js';
import { harness, makePlaces, sequentialIds, type Harness } from './helpers.js';

const CHEB: [number, number] = [50.0796, 12.3739];

/** Nickname used for a connection id (one-letter ids are doubled: 'a' -> 'aa'). */
const nick = (conn: string): string => (conn.length < 2 ? conn + conn : conn);

/** Each name is both the connection id and (via `nick`) the nickname. */
async function lobbyWith(h: Harness, names: string[]): Promise<{ code: string; ids: string[] }> {
  const ids: string[] = [];
  const first = names[0]!;
  ids.push(await h.join(first, nick(first)));
  await h.send(first, { type: 'createLobby' });
  const code = h.outbox.lobby(first)!.code;
  for (const name of names.slice(1)) {
    ids.push(await h.join(name, nick(name)));
    await h.send(name, { type: 'joinLobby', code });
  }
  return { code, ids };
}

function guessAt(h: Harness, conn: string, index: number, latitude: number, longitude: number): Promise<void> {
  return h.send(conn, { type: 'guess', index, latitude, longitude });
}

/** Guesses exactly on the place (distance 0). */
function guessExact(h: Harness, conn: string, index: number): Promise<void> {
  const place = h.places[index]!;
  return guessAt(h, conn, index, place.latitude, place.longitude);
}

function lobby(h: Harness, conn: string): LobbyView {
  const view = h.outbox.lobby(conn);
  if (!view) throw new Error(`${conn} has no lobby`);
  return view;
}

describe('hello', () => {
  it('welcomes a guest with limits and defaults and an empty state', async () => {
    const h = harness();
    h.hub.connect('a');
    await h.send('a', { type: 'hello', nickname: '  Anička  ' });
    const welcome = h.outbox.last('a', 'welcome')!;
    expect(welcome).toMatchObject({
      playerId: 'p1',
      resumeToken: 'resume-1',
      nickname: 'Anička',
      isGuest: true,
      limits: {
        maxPlayers: 4,
        minPlayers: 1,
        maxPlaceCount: 10,
        minDurationSeconds: 60,
        maxDurationSeconds: 1800,
        penaltyDistanceMeters: 100000,
      },
      defaults: { maxPlayers: 4, placeCount: 3, durationSeconds: 300 },
    });
    expect(h.outbox.last('a', 'state')).toEqual({ type: 'state', serverNow: h.clock.now(), lobby: null });
  });

  it.each([
    [undefined],
    [''],
    ['a'],
    ['   b   '],
    ['x'.repeat(25)],
    ['bad\u0007name'],
    ['bad\nname'],
    ['rtl‮name'],
    [42],
  ])('rejects nickname %j', async (nickname) => {
    const h = harness();
    h.hub.connect('a');
    await h.send('a', { type: 'hello', nickname });
    expect(h.outbox.lastError('a')).toBe('nickname.invalid');
    expect(h.outbox.last('a', 'welcome')).toBeUndefined();
  });

  it('accepts nicknames of 2 and 24 characters (counted as code points)', () => {
    expect(normalizeNickname('ab')).toBe('ab');
    expect(normalizeNickname('ž'.repeat(24))).toBe('ž'.repeat(24));
    expect(normalizeNickname('😀😀')).toBe('😀😀');
    expect(normalizeNickname('a   b')).toBe('a b');
  });

  it('requires hello before anything else', async () => {
    const h = harness();
    h.hub.connect('a');
    await h.send('a', { type: 'createLobby' });
    expect(h.outbox.lastError('a')).toBe('hello.required');
  });

  it('answers ping with pong even before hello', async () => {
    const h = harness();
    h.hub.connect('a');
    await h.send('a', { type: 'ping' });
    expect(h.outbox.all('a')).toEqual([{ type: 'pong' }]);
  });

  it('rejects a second hello on the same socket', async () => {
    const h = harness();
    await h.join('a', 'Anna');
    await h.send('a', { type: 'hello', nickname: 'Other' });
    expect(h.outbox.lastError('a')).toBe('hello.duplicate');
    expect(h.outbox.ofType('a', 'welcome')).toHaveLength(1);
  });

  it('signs in an account with a valid token and takes the name from the account', async () => {
    const h = harness();
    h.accounts.tokens.set('good', { userId: 7, name: 'Jana Nováková' });
    h.hub.connect('a');
    await h.send('a', { type: 'hello', token: 'good', nickname: 'ignored' });
    expect(h.outbox.last('a', 'welcome')).toMatchObject({ nickname: 'Jana Nováková', isGuest: false });
  });

  it('rejects an invalid token and lets the socket try again', async () => {
    const h = harness();
    h.hub.connect('a');
    await h.send('a', { type: 'hello', token: 'bad' });
    expect(h.outbox.lastError('a')).toBe('auth.invalid_token');
    await h.send('a', { type: 'hello', nickname: 'Guest' });
    expect(h.outbox.last('a', 'welcome')?.isGuest).toBe(true);
  });

  it('queues a second hello behind a pending token check and rejects it as a duplicate', async () => {
    const h = harness();
    let release: () => void = () => {};
    h.accounts.resolve = (token) =>
      new Promise((resolve) => {
        release = () => resolve(token === 'good' ? { userId: 1, name: 'Petr' } : null);
      });
    h.hub.connect('a');
    const first = h.hub.handle('a', { type: 'hello', token: 'good' });
    // The second message is queued behind the first one on the same connection.
    const second = h.hub.handle('a', { type: 'hello', nickname: 'Again' });
    await new Promise((resolve) => setTimeout(resolve, 0));
    release();
    await first;
    await second;
    expect(h.outbox.errors('a')).toEqual(['hello.duplicate']);
    expect(h.outbox.ofType('a', 'welcome')).toHaveLength(1);
  });

  it('rejects malformed and unknown messages without crashing', async () => {
    const h = harness();
    h.hub.connect('a');
    await h.hub.handleText('a', 'not json');
    await h.hub.handleText('a', '[1,2]');
    await h.hub.handleText('a', '{"type":"teleport"}');
    await h.hub.handleText('a', '{"type":42}');
    await h.hub.handleText('a', 'null');
    expect(h.outbox.errors('a')).toEqual([
      'message.invalid',
      'message.invalid',
      'message.invalid',
      'message.invalid',
      'message.invalid',
    ]);
  });

  it('reports server.error when a dependency throws', async () => {
    const h = harness();
    h.accounts.resolve = async () => {
      throw new Error('db down');
    };
    h.hub.connect('a');
    await h.send('a', { type: 'hello', token: 'x' });
    expect(h.outbox.lastError('a')).toBe('server.error');
  });
});

describe('lobby', () => {
  it('creates a lobby with the creator as host and default settings', async () => {
    const h = harness();
    await h.join('a', 'Anna');
    await h.send('a', { type: 'createLobby' });
    const view = lobby(h, 'a');
    expect(view).toEqual({
      code: 'ABCDEF',
      hostId: 'p1',
      selfId: 'p1',
      phase: 'waiting',
      settings: { maxPlayers: 4, placeCount: 3, durationSeconds: 300 },
      players: [
        { id: 'p1', nickname: 'Anna', isGuest: true, isHost: true, connected: true, view: 'lobby', guessedCount: 0 },
      ],
      game: null,
    });
  });

  it('joins case-insensitively and broadcasts personalised state to everyone', async () => {
    const h = harness();
    await h.join('a', 'Anna');
    await h.send('a', { type: 'createLobby' });
    await h.join('b', 'Bob');
    await h.send('b', { type: 'joinLobby', code: ' abcdef ' });
    expect(lobby(h, 'b').selfId).toBe('p2');
    expect(lobby(h, 'a').selfId).toBe('p1');
    expect(lobby(h, 'a').players.map((p) => p.nickname)).toEqual(['Anna', 'Bob']);
    expect(lobby(h, 'b').hostId).toBe('p1');
  });

  it('reports an unknown code and a non-string code', async () => {
    const h = harness();
    await h.join('a', 'Anna');
    await h.send('a', { type: 'joinLobby', code: 'ZZZZZZ' });
    expect(h.outbox.lastError('a')).toBe('lobby.not_found');
    await h.send('a', { type: 'joinLobby', code: 12 });
    expect(h.outbox.lastError('a')).toBe('message.invalid');
  });

  it('rejects joining a full lobby', async () => {
    const h = harness({ config: { maxPlayers: 2 } });
    const { code } = await lobbyWith(h, ['a', 'b']);
    await h.join('c', 'Cyril');
    await h.send('c', { type: 'joinLobby', code });
    expect(h.outbox.lastError('c')).toBe('lobby.full');
    expect(lobby(h, 'a').players).toHaveLength(2);
  });

  it('counts disconnected seats as occupied', async () => {
    const h = harness({ config: { maxPlayers: 2 } });
    const { code } = await lobbyWith(h, ['a', 'b']);
    h.hub.disconnect('b');
    await h.join('c', 'Cyril');
    await h.send('c', { type: 'joinLobby', code });
    expect(h.outbox.lastError('c')).toBe('lobby.full');
  });

  it('re-joining the lobby the player is already in only resends the state', async () => {
    const h = harness();
    const { code } = await lobbyWith(h, ['a', 'b']);
    await h.send('b', { type: 'joinLobby', code });
    expect(h.outbox.errors('b')).toEqual([]);
    expect(lobby(h, 'b').players).toHaveLength(2);
  });

  it('leaves the old lobby implicitly when joining or creating another', async () => {
    const h = harness();
    const { code: first } = await lobbyWith(h, ['a', 'b']);
    await h.join('c', 'Cyril');
    await h.send('c', { type: 'createLobby' });
    const second = lobby(h, 'c').code;
    await h.send('b', { type: 'joinLobby', code: second });
    expect(lobby(h, 'a').players.map((p) => p.id)).toEqual(['p1']);
    expect(lobby(h, 'b').code).toBe(second);
    await h.send('a', { type: 'createLobby' });
    expect(h.hub.hasLobby(first)).toBe(false);
  });

  it('leaving sends a null state to the leaver and updates the others', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('b', { type: 'leaveLobby' });
    expect(h.outbox.lobby('b')).toBeNull();
    expect(lobby(h, 'a').players.map((p) => p.id)).toEqual(['p1']);
    await h.send('b', { type: 'leaveLobby' });
    expect(h.outbox.lastError('b')).toBe('lobby.not_in_lobby');
  });

  it('migrates the host to the longest-present player and deletes an empty lobby', async () => {
    const h = harness();
    const { code } = await lobbyWith(h, ['a', 'b', 'c']);
    await h.send('a', { type: 'leaveLobby' });
    expect(lobby(h, 'c').hostId).toBe('p2');
    expect(lobby(h, 'b').players.find((p) => p.id === 'p2')?.isHost).toBe(true);
    // A returning player goes to the back of the queue.
    await h.send('a', { type: 'joinLobby', code });
    await h.send('b', { type: 'leaveLobby' });
    expect(lobby(h, 'a').hostId).toBe('p3');
    await h.send('c', { type: 'leaveLobby' });
    await h.send('a', { type: 'leaveLobby' });
    expect(h.hub.hasLobby(code)).toBe(false);
    expect(h.hub.lobbyCount).toBe(0);
  });

  it('requires a lobby for lobby actions', async () => {
    const h = harness();
    await h.join('a', 'Anna');
    for (const type of ['startGame', 'returnToLobby']) {
      await h.send('a', { type });
      expect(h.outbox.lastError('a')).toBe('lobby.not_in_lobby');
    }
    await h.send('a', { type: 'updateSettings', settings: {} });
    expect(h.outbox.lastError('a')).toBe('lobby.not_in_lobby');
    await guessAt(h, 'a', 0, ...CHEB);
    expect(h.outbox.lastError('a')).toBe('lobby.not_in_lobby');
  });

  it('retries a colliding lobby code', async () => {
    const h = harness({ ids: sequentialIds(['ABCDEF', 'ABCDEF', 'GHJKMN']) });
    await lobbyWith(h, ['a']);
    await h.join('b', 'Bob');
    await h.send('b', { type: 'createLobby' });
    expect(lobby(h, 'a').code).toBe('ABCDEF');
    expect(lobby(h, 'b').code).toBe('GHJKMN');
    expect(h.hub.lobbyCount).toBe(2);
  });
});

describe('settings', () => {
  it('lets the host change settings within limits', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'updateSettings', settings: { maxPlayers: 3, placeCount: 10, durationSeconds: 60 } });
    expect(lobby(h, 'b').settings).toEqual({ maxPlayers: 3, placeCount: 10, durationSeconds: 60 });
    await h.send('a', { type: 'updateSettings', settings: { durationSeconds: 1800 } });
    expect(lobby(h, 'a').settings).toEqual({ maxPlayers: 3, placeCount: 10, durationSeconds: 1800 });
  });

  it.each([
    [{ maxPlayers: 5 }],
    [{ maxPlayers: 1 }], // fewer than current players
    [{ maxPlayers: 2.5 }],
    [{ placeCount: 0 }],
    [{ placeCount: 11 }],
    [{ placeCount: '5' }],
    [{ durationSeconds: 59 }],
    [{ durationSeconds: 1801 }],
    [null],
    [[1]],
    ['x'],
  ])('rejects %j', async (settings) => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'updateSettings', settings });
    expect(h.outbox.lastError('a')).toBe('settings.invalid');
    expect(lobby(h, 'a').settings).toEqual({ maxPlayers: 4, placeCount: 3, durationSeconds: 300 });
  });

  it('applies nothing when one field of several is invalid', async () => {
    const h = harness();
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'updateSettings', settings: { placeCount: 5, durationSeconds: 5 } });
    expect(h.outbox.lastError('a')).toBe('settings.invalid');
    expect(lobby(h, 'a').settings.placeCount).toBe(3);
  });

  it('allows only the host', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('b', { type: 'updateSettings', settings: { placeCount: 5 } });
    expect(h.outbox.lastError('b')).toBe('lobby.not_host');
  });

  it('is locked while a game is playing', async () => {
    const h = harness();
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    await h.send('a', { type: 'updateSettings', settings: { placeCount: 5 } });
    expect(h.outbox.lastError('a')).toBe('lobby.in_game');
  });
});

describe('starting a game', () => {
  it('starts with the configured places and timer for every lobby-view player', async () => {
    const h = harness();
    const { ids } = await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    const view = lobby(h, 'b');
    expect(view.phase).toBe('playing');
    expect(view.players.map((p) => p.view)).toEqual(['game', 'game']);
    expect(view.game).toMatchObject({
      status: 'playing',
      startedAt: h.clock.now(),
      endsAt: h.clock.now() + 300_000,
      placeCount: 3,
      participantIds: ids,
      self: { currentIndex: 0, currentPlaceName: 'Místo 0', rounds: [] },
      leaderboard: null,
      places: null,
      guesses: null,
    });
  });

  it('only the host may start', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('b', { type: 'startGame' });
    expect(h.outbox.lastError('b')).toBe('lobby.not_host');
  });

  it('needs MP_MIN_PLAYERS connected lobby-view players', async () => {
    const h = harness({ config: { minPlayers: 2 } });
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    expect(h.outbox.lastError('a')).toBe('lobby.not_enough_players');
    await h.join('b', 'Bob');
    await h.send('b', { type: 'joinLobby', code: 'ABCDEF' });
    h.hub.disconnect('b');
    await h.send('a', { type: 'startGame' });
    expect(h.outbox.lastError('a')).toBe('lobby.not_enough_players');
  });

  it('cannot start twice', async () => {
    const h = harness();
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    await h.send('a', { type: 'startGame' });
    expect(h.outbox.lastError('a')).toBe('lobby.in_game');
  });

  it('players who join while the places are loading become participants', async () => {
    let release: () => void = () => {};
    const slow: PlaceSource = {
      randomPlaces: (n) =>
        new Promise<Place[]>((resolve) => {
          release = () => resolve(makePlaces(n));
        }),
    };
    const h = harness({ placeSource: slow });
    const { code } = await lobbyWith(h, ['a']);
    const starting = h.hub.handle('a', { type: 'startGame' });
    await h.join('b', 'Bob');
    await h.send('b', { type: 'joinLobby', code });
    expect(lobby(h, 'b').phase).toBe('waiting');
    release();
    await starting;
    expect(lobby(h, 'b').game?.participantIds).toEqual(['p1', 'p2']);
  });

  it('does not report a past idle deadline while places are loading (no timer spin)', async () => {
    let release: () => void = () => {};
    const slow: PlaceSource = {
      randomPlaces: (n) =>
        new Promise<Place[]>((resolve) => {
          release = () => resolve(makePlaces(n));
        }),
    };
    const h = harness({ placeSource: slow, config: { lobbyIdleTtlSeconds: 10 } });
    await lobbyWith(h, ['a']);
    const starting = h.hub.handle('a', { type: 'startGame' });
    await Promise.resolve();
    h.clock.advance(20_000); // idle TTL passes while the query runs
    const deadline = h.hub.nextDeadline();
    expect(deadline === null || deadline > h.clock.now()).toBe(true);
    h.hub.tick();
    release();
    await starting;
    expect(lobby(h, 'a').phase).toBe('playing');
  });

  it('reports game.no_places when the catalog is empty', async () => {
    const h = harness({ places: [] });
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    expect(h.outbox.lastError('a')).toBe('game.no_places');
    expect(lobby(h, 'a').phase).toBe('waiting');
    // The lobby can still start later.
    await h.send('a', { type: 'startGame' });
    expect(h.outbox.lastError('a')).toBe('game.no_places');
  });

  it('plays fewer places when the catalog is smaller, and ignores duplicates', async () => {
    const places = makePlaces(2);
    const h = harness({ placeSource: { randomPlaces: async () => [places[0]!, places[0]!, places[1]!] } });
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    expect(lobby(h, 'a').game?.placeCount).toBe(2);
  });

  it('reports server.error when the place source fails and stays startable', async () => {
    let fail = true;
    const h = harness({
      placeSource: {
        randomPlaces: async (n) => {
          if (fail) throw new Error('db down');
          return makePlaces(n);
        },
      },
    });
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    expect(h.outbox.lastError('a')).toBe('server.error');
    fail = false;
    await h.send('a', { type: 'startGame' });
    expect(lobby(h, 'a').phase).toBe('playing');
  });

  it('players who join during a game wait in the lobby view', async () => {
    const h = harness();
    const { code } = await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    await h.join('b', 'Bob');
    await h.send('b', { type: 'joinLobby', code });
    const view = lobby(h, 'b');
    expect(view.phase).toBe('playing');
    expect(view.players.find((p) => p.id === 'p2')?.view).toBe('lobby');
    expect(view.game?.self).toBeNull();
    expect(view.game?.participantIds).toEqual(['p1']);
    await guessAt(h, 'b', 0, ...CHEB);
    expect(h.outbox.lastError('b')).toBe('game.not_playing');
  });
});

describe('guessing', () => {
  it('validates the guess payload', async () => {
    const h = harness();
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    const bad = [
      { index: 0, latitude: '50', longitude: 12.5 },
      { index: 0, latitude: 50.1 },
      { index: 0.5, latitude: 50.1, longitude: 12.5 },
      { index: '0', latitude: 50.1, longitude: 12.5 },
      { index: 0, latitude: 91, longitude: 12.5 },
      { index: 0, latitude: 50.1, longitude: -181 },
      { index: 0, latitude: null, longitude: 12.5 },
    ];
    for (const fields of bad) {
      await h.send('a', { type: 'guess', ...fields });
      expect(h.outbox.lastError('a')).toBe('guess.invalid');
    }
    // NaN / Infinity cannot be sent as JSON; check the handler directly.
    await h.hub.handle('a', { type: 'guess', index: 0, latitude: Number.NaN, longitude: 12.5 });
    expect(h.outbox.lastError('a')).toBe('guess.invalid');
    await h.hub.handle('a', { type: 'guess', index: 0, latitude: 50, longitude: Number.POSITIVE_INFINITY });
    expect(h.outbox.lastError('a')).toBe('guess.invalid');
    expect(lobby(h, 'a').game?.self?.currentIndex).toBe(0);
  });

  it('rejects a guess outside the region', async () => {
    const h = harness();
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    await guessAt(h, 'a', 0, 50.0755, 14.4378); // Prague
    expect(h.outbox.lastError('a')).toBe('guess.outside_region');
    await guessAt(h, 'a', 0, 0, 0);
    expect(h.outbox.lastError('a')).toBe('guess.outside_region');
    expect(h.outbox.ofType('a', 'guessResult')).toHaveLength(0);
  });

  it('accepts only the current index: exactly one guess per place, in order', async () => {
    const h = harness();
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    await guessExact(h, 'a', 1);
    expect(h.outbox.lastError('a')).toBe('guess.wrong_index');
    await guessAt(h, 'a', 0, ...CHEB);
    expect(h.outbox.errors('a')).toEqual(['guess.wrong_index']);
    await guessExact(h, 'a', 0);
    expect(h.outbox.lastError('a')).toBe('guess.wrong_index');
    expect(h.outbox.ofType('a', 'guessResult')).toHaveLength(1);
    await guessAt(h, 'a', -1, ...CHEB);
    expect(h.outbox.lastError('a')).toBe('guess.wrong_index');
  });

  it('sends guessResult with the haversine offset and the reveal, then the next name', async () => {
    const h = harness();
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    h.clock.advance(1000);
    await guessAt(h, 'a', 0, ...CHEB);
    const place = h.places[0]!;
    const expected = distanceMeters(CHEB[0], CHEB[1], place.latitude, place.longitude);
    const messages = h.outbox.all('a');
    const resultIndex = messages.findIndex((m) => m.type === 'guessResult');
    expect(messages[resultIndex]).toEqual({
      type: 'guessResult',
      index: 0,
      distanceMeters: expected,
      guess: { latitude: CHEB[0], longitude: CHEB[1] },
      place: {
        index: 0,
        id: place.id,
        name: place.name,
        latitude: place.latitude,
        longitude: place.longitude,
        category: place.category,
        description: place.description,
        contentSourceUrl: place.contentSourceUrl,
        source: place.source,
      },
    });
    // guessResult comes immediately before the next state.
    expect(messages[resultIndex + 1]?.type).toBe('state');
    const self = lobby(h, 'a').game!.self!;
    expect(self.currentIndex).toBe(1);
    expect(self.currentPlaceName).toBe('Místo 1');
    expect(self.rounds).toEqual([
      {
        index: 0,
        name: 'Místo 0',
        guess: { latitude: CHEB[0], longitude: CHEB[1] },
        distanceMeters: expected,
        place: expect.objectContaining({ id: place.id }),
      },
    ]);
  });

  it('reveals a place only to the guesser; others see only counts', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    h.outbox.clear();
    await guessExact(h, 'a', 0);
    expect(h.outbox.ofType('a', 'guessResult')).toHaveLength(1);
    expect(h.outbox.ofType('b', 'guessResult')).toHaveLength(0);
    const bView = lobby(h, 'b');
    expect(bView.players.find((p) => p.id === 'p1')?.guessedCount).toBe(1);
    expect(bView.game?.self?.currentIndex).toBe(0);
    expect(bView.game?.self?.rounds).toEqual([]);
    expect(JSON.stringify(h.outbox.all('b'))).not.toContain('SECRET-DESCRIPTION-0');
  });

  it('never leaks coordinates, texts or later names of places the player has not guessed', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.join('w', 'Watcher');
    await h.send('w', { type: 'joinLobby', code: 'ABCDEF' });
    await h.send('a', { type: 'updateSettings', settings: { placeCount: 4 } });
    h.outbox.clear();
    await h.send('a', { type: 'startGame' });
    await guessExact(h, 'a', 0);
    await guessExact(h, 'a', 1);
    await guessExact(h, 'a', 2);
    await guessExact(h, 'b', 0);

    const secretsOf = (index: number): string[] => {
      const p = h.places[index]!;
      return [String(p.latitude), String(p.longitude), p.description, p.category, `"id":${p.id}`];
    };
    const forB = JSON.stringify(h.outbox.all('b'));
    for (const index of [1, 2, 3]) for (const secret of secretsOf(index)) expect(forB).not.toContain(secret);
    expect(forB).toContain('Místo 1'); // b's current place name
    expect(forB).not.toContain('Místo 2');
    expect(forB).not.toContain('Místo 3');

    const forA = JSON.stringify(h.outbox.all('a'));
    for (const secret of secretsOf(3)) expect(forA).not.toContain(secret);
    expect(forA).toContain('Místo 3'); // a's current place: the name only

    // The watcher (a participant who has not guessed) knows only the first name.
    const forW = JSON.stringify(h.outbox.all('w'));
    for (const index of [0, 1, 2, 3]) for (const secret of secretsOf(index)) expect(forW).not.toContain(secret);
    expect(forW).toContain('Místo 0');
    expect(forW).not.toMatch(/Místo [123]/);
    expect(h.outbox.ofType('w', 'guessResult')).toHaveLength(0);
  });

  it('a waiting non-participant sees no place names at all', async () => {
    const h = harness();
    const { code } = await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    await h.join('b', 'Bob');
    h.outbox.clear('b');
    await h.send('b', { type: 'joinLobby', code });
    await guessExact(h, 'a', 0);
    const forB = JSON.stringify(h.outbox.all('b'));
    expect(forB).not.toContain('Místo');
    expect(forB).not.toContain('SECRET');
  });
});

describe('game end', () => {
  it('ends when the timer runs out (tick) and reveals everything', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    await guessExact(h, 'a', 0);
    expect(h.hub.nextDeadline()).toBe(h.clock.now() + 300_000);
    h.clock.advance(299_999);
    h.hub.tick();
    expect(lobby(h, 'a').phase).toBe('playing');
    h.clock.advance(1);
    h.hub.tick();
    const view = lobby(h, 'b');
    expect(view.phase).toBe('finished');
    expect(view.players.map((p) => p.view)).toEqual(['results', 'results']);
    const game = view.game!;
    expect(game.status).toBe('finished');
    expect(game.places).toHaveLength(3);
    expect(game.places![2]!.description).toBe('SECRET-DESCRIPTION-2');
    expect(game.guesses).toEqual({
      p1: [{ latitude: h.places[0]!.latitude, longitude: h.places[0]!.longitude, distanceMeters: 0 }, null, null],
      p2: [null, null, null],
    });
    // All rounds are visible to self when finished, unguessed with null guess.
    expect(game.self?.rounds).toHaveLength(3);
    expect(game.self?.rounds[0]).toMatchObject({ guess: null, distanceMeters: null, place: { index: 0 } });
    expect(game.self?.currentPlaceName).toBeNull();
  });

  it('a late guess after endsAt ends the game instead of counting', async () => {
    const h = harness();
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    h.clock.advance(300_000);
    await guessExact(h, 'a', 0);
    expect(h.outbox.lastError('a')).toBe('game.not_playing');
    expect(lobby(h, 'a').phase).toBe('finished');
    expect(h.outbox.ofType('a', 'guessResult')).toHaveLength(0);
  });

  it('ends early when every participant has guessed everything', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    for (const i of [0, 1, 2]) await guessExact(h, 'a', i);
    let view = lobby(h, 'a');
    expect(view.phase).toBe('playing');
    // Done players wait in the game view with no current place.
    expect(view.players.find((p) => p.id === 'p1')?.view).toBe('game');
    expect(view.game?.self).toMatchObject({ currentIndex: 3, currentPlaceName: null });
    await guessExact(h, 'a', 3);
    expect(h.outbox.lastError('a')).toBe('guess.wrong_index');
    for (const i of [0, 1, 2]) await guessExact(h, 'b', i);
    view = lobby(h, 'a');
    expect(view.phase).toBe('finished');
    expect(view.game?.leaderboard?.map((r) => r.playerId)).toEqual(['p1', 'p2']);
  });

  it('scores unguessed places with the penalty distance', async () => {
    const h = harness({ config: { penaltyDistanceMeters: 50_000 } });
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    await guessAt(h, 'a', 0, ...CHEB);
    const d0 = distanceMeters(CHEB[0], CHEB[1], h.places[0]!.latitude, h.places[0]!.longitude);
    h.clock.advance(300_000);
    h.hub.tick();
    const board = lobby(h, 'a').game!.leaderboard!;
    expect(board[0]).toEqual({
      rank: 1,
      playerId: 'p1',
      nickname: 'aa',
      averageDistanceMeters: Math.round((d0 + 100_000) / 3),
      guessedCount: 1,
      totalDistanceMeters: d0 + 100_000,
      finishedAt: h.clock.now() - 300_000,
    });
    expect(board[1]).toEqual({
      rank: 2,
      playerId: 'p2',
      nickname: 'bb',
      averageDistanceMeters: 50_000,
      guessedCount: 0,
      totalDistanceMeters: 150_000,
      finishedAt: null,
    });
  });

  it('a participant who leaves mid-game keeps a row with penalties; the rest can finish early', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    await guessExact(h, 'b', 0);
    await h.send('b', { type: 'leaveLobby' });
    for (const i of [0, 1, 2]) await guessExact(h, 'a', i);
    const view = lobby(h, 'a');
    expect(view.phase).toBe('finished');
    expect(view.players.map((p) => p.id)).toEqual(['p1']);
    expect(view.game!.participantIds).toEqual(['p1', 'p2']);
    expect(view.game!.leaderboard!.map((r) => [r.playerId, r.guessedCount, r.totalDistanceMeters])).toEqual([
      ['p1', 3, 0],
      ['p2', 1, 200_000],
    ]);
  });

  it('a participant who left and rejoins during the game waits and cannot guess', async () => {
    const h = harness();
    const { code } = await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    await h.send('b', { type: 'leaveLobby' });
    await h.send('b', { type: 'joinLobby', code });
    const view = lobby(h, 'b');
    expect(view.players.find((p) => p.id === 'p2')?.view).toBe('lobby');
    expect(view.game?.self).toBeNull();
    await guessExact(h, 'b', 0);
    expect(h.outbox.lastError('b')).toBe('game.not_playing');
  });
});

describe('leaderboard tie-breaks', () => {
  it('equal average: more guesses wins, then earlier last guess, then nickname', async () => {
    // Penalty 0 makes all exact guessers equal on distance.
    const h = harness({ config: { penaltyDistanceMeters: 0, maxPlayers: 4 } });
    await lobbyWith(h, ['Zuzana', 'Adam', 'Bára', 'Cyril']);
    await h.send('Zuzana', { type: 'startGame' });
    // Cyril: 1 guess (fewest) -> last. Zuzana and Adam: 2 guesses; Zuzana earlier. Bára: 2 guesses same time as Adam.
    await guessExact(h, 'Zuzana', 0);
    await guessExact(h, 'Zuzana', 1);
    h.clock.advance(1000);
    await guessExact(h, 'Adam', 0);
    await guessExact(h, 'Bára', 0);
    await guessExact(h, 'Adam', 1);
    await guessExact(h, 'Bára', 1);
    await guessExact(h, 'Cyril', 0);
    h.clock.advance(300_000);
    h.hub.tick();
    const board = lobby(h, 'Adam').game!.leaderboard!;
    expect(board.map((r) => [r.rank, r.nickname])).toEqual([
      [1, 'Zuzana'],
      [2, 'Adam'],
      [3, 'Bára'],
      [4, 'Cyril'],
    ]);
  });

  it('a lower average always beats more guesses', async () => {
    const h = harness({ config: { penaltyDistanceMeters: 1000 } });
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    for (const i of [0, 1, 2]) await guessAt(h, 'a', i, ...CHEB); // far away on most
    h.clock.advance(300_000);
    h.hub.tick();
    const board = lobby(h, 'a').game!.leaderboard!;
    expect(board.map((r) => r.playerId)).toEqual(['p2', 'p1']);
    expect(board[0]!.averageDistanceMeters).toBe(1000);
  });
});

describe('after a game', () => {
  async function finishedGame(h: Harness): Promise<void> {
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    h.clock.advance(300_000);
    h.hub.tick();
  }

  it('returnToLobby moves a player from results to the lobby view', async () => {
    const h = harness();
    await finishedGame(h);
    await h.send('b', { type: 'returnToLobby' });
    const view = lobby(h, 'a');
    expect(view.players.map((p) => p.view)).toEqual(['results', 'lobby']);
    expect(view.phase).toBe('finished');
    expect(view.game?.status).toBe('finished');
  });

  it('the host must return to the lobby before starting again', async () => {
    const h = harness();
    await finishedGame(h);
    await h.send('a', { type: 'startGame' });
    expect(h.outbox.lastError('a')).toBe('lobby.not_in_lobby');
    await h.send('a', { type: 'returnToLobby' });
    await h.send('a', { type: 'updateSettings', settings: { placeCount: 2 } });
    expect(h.outbox.errors('a').at(-1)).toBe('lobby.not_in_lobby');
    await h.send('a', { type: 'startGame' });
    const view = lobby(h, 'a');
    expect(view.phase).toBe('playing');
    expect(view.game?.placeCount).toBe(2);
    // b stayed on the results screen and is not in the new game.
    expect(view.game?.participantIds).toEqual(['p1']);
    expect(view.players.find((p) => p.id === 'p2')?.view).toBe('results');
    expect(lobby(h, 'b').game?.self).toBeNull();
    // b can return during the game and waits in the lobby.
    await h.send('b', { type: 'returnToLobby' });
    expect(lobby(h, 'b').players.find((p) => p.id === 'p2')?.view).toBe('lobby');
  });

  it('returnToLobby is refused while playing as a participant', async () => {
    const h = harness();
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    await h.send('a', { type: 'returnToLobby' });
    expect(h.outbox.lastError('a')).toBe('lobby.in_game');
  });

  it('a new game resets per-player guess counts', async () => {
    const h = harness();
    await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    for (const i of [0, 1, 2]) await guessExact(h, 'a', i);
    expect(lobby(h, 'a').players[0]!.guessedCount).toBe(3);
    await h.send('a', { type: 'returnToLobby' });
    await h.send('a', { type: 'startGame' });
    expect(lobby(h, 'a').players[0]!.guessedCount).toBe(0);
    expect(lobby(h, 'a').game?.self?.currentIndex).toBe(0);
  });
});

describe('disconnect and resume', () => {
  it('keeps the seat while disconnected and resumes with the resume token', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    await guessExact(h, 'b', 0);
    h.hub.disconnect('b');
    expect(lobby(h, 'a').players.find((p) => p.id === 'p2')?.connected).toBe(false);

    h.clock.advance(59_000);
    h.hub.tick();
    h.hub.connect('b2');
    await h.send('b2', { type: 'hello', resumeToken: 'resume-2' });
    expect(h.outbox.last('b2', 'welcome')).toMatchObject({ playerId: 'p2', resumeToken: 'resume-2', nickname: 'bb' });
    const view = lobby(h, 'b2');
    expect(view.selfId).toBe('p2');
    expect(view.game?.self?.currentIndex).toBe(1);
    expect(view.game?.self?.rounds).toHaveLength(1);
    expect(lobby(h, 'a').players.find((p) => p.id === 'p2')?.connected).toBe(true);
    await guessExact(h, 'b2', 1);
    expect(h.outbox.ofType('b2', 'guessResult')).toHaveLength(1);
  });

  it('frees the seat after the grace period, migrating the host', async () => {
    const h = harness();
    const { code } = await lobbyWith(h, ['a', 'b']);
    h.hub.disconnect('a');
    expect(h.hub.nextDeadline()).toBe(h.clock.now() + 60_000);
    h.clock.advance(60_000);
    h.hub.tick();
    const view = lobby(h, 'b');
    expect(view.players.map((p) => p.id)).toEqual(['p2']);
    expect(view.hostId).toBe('p2');
    h.hub.connect('a2');
    await h.send('a2', { type: 'hello', resumeToken: 'resume-1', nickname: 'Anna' });
    expect(h.outbox.errors('a2')).toEqual(['resume.invalid']);
    expect(h.outbox.last('a2', 'welcome')).toMatchObject({ playerId: 'p3', nickname: 'Anna' });
    expect(h.outbox.lobby('a2')).toBeNull();
    expect(h.hub.hasLobby(code)).toBe(true);
  });

  it('deletes the lobby when the last seat expires', async () => {
    const h = harness();
    const { code } = await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    h.hub.disconnect('a');
    h.clock.advance(60_000);
    h.hub.tick();
    expect(h.hub.hasLobby(code)).toBe(false);
    expect(h.hub.playerCount).toBe(0);
  });

  it('an unknown resume token without a nickname fails the hello after resume.invalid', async () => {
    const h = harness();
    h.hub.connect('a');
    await h.send('a', { type: 'hello', resumeToken: 'nope' });
    expect(h.outbox.errors('a')).toEqual(['resume.invalid', 'nickname.invalid']);
  });

  it('a player without a lobby is forgotten on disconnect', async () => {
    const h = harness();
    await h.join('a', 'Anna');
    h.hub.disconnect('a');
    expect(h.hub.playerCount).toBe(0);
    h.hub.connect('a2');
    await h.send('a2', { type: 'hello', resumeToken: 'resume-1', nickname: 'Anna' });
    expect(h.outbox.errors('a2')).toEqual(['resume.invalid']);
  });

  it('resuming on a new socket while the old one is open takes the seat over', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    h.hub.connect('a2');
    await h.send('a2', { type: 'hello', resumeToken: 'resume-1' });
    expect(h.outbox.closed).toEqual([{ connId: 'a', code: CLOSE_REPLACED, reason: expect.any(String) }]);
    // The old socket closing afterwards must not mark the player disconnected.
    h.hub.disconnect('a');
    expect(lobby(h, 'b').players.find((p) => p.id === 'p1')?.connected).toBe(true);
    await h.send('a2', { type: 'startGame' });
    expect(lobby(h, 'a2').phase).toBe('playing');
  });

  it('leaving makes the resume token useless for that lobby', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('b', { type: 'leaveLobby' });
    h.hub.disconnect('b');
    h.hub.connect('b2');
    await h.send('b2', { type: 'hello', resumeToken: 'resume-2', nickname: 'Bob' });
    expect(h.outbox.errors('b2')).toEqual(['resume.invalid']);
    expect(h.outbox.lobby('b2')).toBeNull();
  });

  it('a disconnected participant still holds up the early end until the timer', async () => {
    const h = harness();
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'updateSettings', settings: { durationSeconds: 60 } });
    await h.send('a', { type: 'startGame' });
    h.hub.disconnect('b');
    for (const i of [0, 1, 2]) await guessExact(h, 'a', i);
    expect(lobby(h, 'a').phase).toBe('playing');
    expect(h.hub.nextDeadline()).toBe(h.clock.now() + 60_000);
    h.clock.advance(60_000);
    h.hub.tick();
    expect(lobby(h, 'a').phase).toBe('finished');
  });

  it('a disconnected participant losing the seat lets the game end early', async () => {
    const h = harness({ config: { reconnectGraceSeconds: 10 } });
    await lobbyWith(h, ['a', 'b']);
    await h.send('a', { type: 'startGame' });
    for (const i of [0, 1, 2]) await guessExact(h, 'a', i);
    h.hub.disconnect('b');
    h.clock.advance(10_000);
    h.hub.tick();
    const view = lobby(h, 'a');
    expect(view.phase).toBe('finished');
    expect(view.game!.leaderboard!.map((r) => r.playerId)).toEqual(['p1', 'p2']);
  });
});

describe('idle lobbies', () => {
  it('removes a lobby after the idle TTL and tells connected members', async () => {
    const h = harness({ config: { lobbyIdleTtlSeconds: 100 } });
    const { code } = await lobbyWith(h, ['a', 'b']);
    h.hub.disconnect('b');
    h.clock.advance(50_000);
    await h.send('a', { type: 'updateSettings', settings: { placeCount: 4 } });
    h.clock.advance(60_000); // b's seat expires (grace 60 s) but a is still there
    h.hub.tick();
    expect(h.hub.hasLobby(code)).toBe(true);
    // Freeing b's seat counted as activity.
    h.clock.advance(99_999);
    h.hub.tick();
    expect(h.hub.hasLobby(code)).toBe(true);
    h.clock.advance(1);
    h.hub.tick();
    expect(h.hub.hasLobby(code)).toBe(false);
    expect(h.outbox.lobby('a')).toBeNull();
  });

  it('does not remove a lobby while a game is playing', async () => {
    const h = harness({ config: { lobbyIdleTtlSeconds: 100, maxDurationSeconds: 1800 } });
    const { code } = await lobbyWith(h, ['a']);
    await h.send('a', { type: 'startGame' });
    h.clock.advance(200_000);
    h.hub.tick();
    expect(h.hub.hasLobby(code)).toBe(true);
    expect(lobby(h, 'a').phase).toBe('playing');
  });

  it('nextDeadline is null without lobbies or held seats', () => {
    const h = harness();
    expect(h.hub.nextDeadline()).toBeNull();
  });
});

describe('finished-game state size', () => {
  it('fits many times into the server send buffer limit, so a briefly stalled client is not cut off', async () => {
    // Worst case under the default limits: 8 players, 20 places, long Czech descriptions and URLs.
    const places = makePlaces(20).map((p) => ({
      ...p,
      name: `${p.name} – Kostel svatého Mikuláše a Alžběty`,
      description: 'Žluťoučký kůň úpěl ďábelské ódy. '.repeat(11).slice(0, 340),
      contentSourceUrl: `https://www.example.org/turisticke-cile/karlovarsky-kraj/misto-${p.id}?lang=cs`,
    }));
    const h = harness({ places, config: { maxPlayers: 8, maxPlaceCount: 20 } });
    const names = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'hh'];
    const { code } = await lobbyWith(h, names);
    await h.send('a', { type: 'updateSettings', settings: { maxPlayers: 8, placeCount: 20 } });
    await h.send('a', { type: 'startGame' });
    for (const name of names) for (let i = 0; i < 20; i++) await guessExact(h, name, i);
    const view = lobby(h, 'a');
    expect(view.code).toBe(code);
    expect(view.phase).toBe('finished');
    expect(view.game?.places).toHaveLength(20);
    const bytes = Buffer.byteLength(JSON.stringify(h.outbox.last('a', 'state')));
    // A results screen sees a broadcast per lobby change (each player returning, settings, joins);
    // allow a few dozen of them to queue before the socket is treated as not reading.
    expect(MAX_BUFFERED_BYTES).toBeGreaterThanOrEqual(24 * bytes);
  });
});
