/**
 * The lobby and game state machine. It knows nothing about sockets: the transport
 * feeds it connection events and parsed messages and it answers through an
 * injected outbox. Time, ids, places and accounts are injected, so it is fully
 * unit-testable. Timers are driven from outside through `tick()` and
 * `nextDeadline()`.
 */
import { randomBytes, randomInt } from 'node:crypto';
import type { AccountResolver } from './auth.js';
import type { GameConfig } from './config.js';
import { distanceMeters, isInRegion, isValidCoordinate } from './geo.js';
import type { Logger } from './logger.js';
import { silentLogger } from './logger.js';
import type { Place, PlaceSource } from './places.js';
import type {
  ClientMessage,
  ErrorCode,
  GameView,
  GuessSummary,
  LeaderboardRow,
  Limits,
  LobbySettings,
  LobbyView,
  Phase,
  PlaceReveal,
  RoundView,
  ServerMessage,
  SelfGameView,
  View,
} from './protocol.js';
import { parseClientMessage } from './protocol.js';
import { rankParticipants } from './scoring.js';

export type ConnId = string;

export interface Clock {
  now(): number;
}

export const systemClock: Clock = { now: () => Date.now() };

export interface IdGenerator {
  playerId(): string;
  resumeToken(): string;
  lobbyCode(): string;
}

/** Lobby code alphabet: no 0 O 1 I L. */
export const LOBBY_CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
export const LOBBY_CODE_LENGTH = 6;

export const cryptoIds: IdGenerator = {
  playerId: () => `p_${randomBytes(9).toString('base64url')}`,
  resumeToken: () => randomBytes(32).toString('base64url'),
  lobbyCode: () => {
    let code = '';
    for (let i = 0; i < LOBBY_CODE_LENGTH; i++) code += LOBBY_CODE_ALPHABET[randomInt(LOBBY_CODE_ALPHABET.length)];
    return code;
  },
};

export interface Outbox {
  send(connId: ConnId, message: ServerMessage): void;
  /** Closes a socket, e.g. when its player was taken over by a newer connection. */
  close(connId: ConnId, code: number, reason: string): void;
}

export interface HubDeps {
  config: GameConfig;
  places: PlaceSource;
  accounts: AccountResolver;
  outbox: Outbox;
  clock?: Clock;
  ids?: IdGenerator;
  logger?: Logger;
}

/** WebSocket close code sent to a socket whose player resumed on another socket. */
export const CLOSE_REPLACED = 4001;

const NICKNAME_MIN = 2;
const NICKNAME_MAX = 24;
// Control characters, line/paragraph separators, and bidi/format characters.
const FORBIDDEN_NICKNAME_CHARS = /[\p{Cc}\p{Cf}\p{Zl}\p{Zp}]/u;

/** Trims and validates a guest nickname; null when it is not acceptable. */
export function normalizeNickname(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const trimmed = raw.trim();
  if (FORBIDDEN_NICKNAME_CHARS.test(trimmed)) return null;
  const nickname = trimmed.replace(/\s+/gu, ' ');
  const length = [...nickname].length;
  if (length < NICKNAME_MIN || length > NICKNAME_MAX) return null;
  return nickname;
}

interface Connection {
  id: ConnId;
  playerId: string | null;
  helloPending: boolean;
  queue: Promise<void>;
}

interface Player {
  id: string;
  resumeToken: string;
  nickname: string;
  isGuest: boolean;
  userId: number | null;
  connId: ConnId | null;
  lobbyCode: string | null;
  view: View;
  disconnectedAt: number | null;
}

interface RecordedGuess {
  latitude: number;
  longitude: number;
  distanceMeters: number;
  at: number;
}

interface Participant {
  playerId: string;
  nickname: string;
  guesses: RecordedGuess[];
  /** True once the participant left the lobby (or lost their seat) during the game. */
  left: boolean;
}

interface Game {
  places: Place[];
  startedAt: number;
  endsAt: number;
  status: 'playing' | 'finished';
  participants: Map<string, Participant>;
  endedAt: number | null;
  leaderboard: LeaderboardRow[] | null;
}

interface Lobby {
  code: string;
  hostId: string;
  /** Members in the order they joined; the first one is the longest present. */
  playerIds: string[];
  settings: LobbySettings;
  phase: Phase;
  game: Game | null;
  starting: boolean;
  lastActivityAt: number;
}

class HubError extends Error {
  constructor(
    readonly code: ErrorCode,
    message?: string,
  ) {
    super(message ?? code);
  }
}

export class GameHub {
  private readonly config: GameConfig;
  private readonly places: PlaceSource;
  private readonly accounts: AccountResolver;
  private readonly outbox: Outbox;
  private readonly clock: Clock;
  private readonly ids: IdGenerator;
  private readonly logger: Logger;

  private readonly connections = new Map<ConnId, Connection>();
  private readonly players = new Map<string, Player>();
  private readonly playersByResumeToken = new Map<string, Player>();
  private readonly lobbies = new Map<string, Lobby>();

  constructor(deps: HubDeps) {
    this.config = deps.config;
    this.places = deps.places;
    this.accounts = deps.accounts;
    this.outbox = deps.outbox;
    this.clock = deps.clock ?? systemClock;
    this.ids = deps.ids ?? cryptoIds;
    this.logger = deps.logger ?? silentLogger;
  }

  // ─── Introspection (tests, health, logs) ────────────────────────────────

  get lobbyCount(): number {
    return this.lobbies.size;
  }

  get playerCount(): number {
    return this.players.size;
  }

  get connectionCount(): number {
    return this.connections.size;
  }

  hasLobby(code: string): boolean {
    return this.lobbies.has(code);
  }

  /** The state snapshot a player would receive now (null when not in a lobby). */
  snapshotFor(playerId: string): LobbyView | null {
    const player = this.players.get(playerId);
    if (!player || player.lobbyCode === null) return null;
    const lobby = this.lobbies.get(player.lobbyCode);
    return lobby ? this.buildLobbyView(lobby, player) : null;
  }

  limits(): Limits {
    return {
      maxPlayers: this.config.maxPlayers,
      minPlayers: this.config.minPlayers,
      maxPlaceCount: this.config.maxPlaceCount,
      minDurationSeconds: this.config.minDurationSeconds,
      maxDurationSeconds: this.config.maxDurationSeconds,
      penaltyDistanceMeters: this.config.penaltyDistanceMeters,
    };
  }

  defaults(): LobbySettings {
    return {
      maxPlayers: this.config.maxPlayers,
      placeCount: this.config.defaultPlaceCount,
      durationSeconds: this.config.defaultDurationSeconds,
    };
  }

  // ─── Connection events ─────────────────────────────────────────────────

  connect(connId: ConnId): void {
    this.connections.set(connId, { id: connId, playerId: null, helloPending: false, queue: Promise.resolve() });
  }

  /** Handles one raw text frame. Messages of one connection are processed in order. */
  handleText(connId: ConnId, text: string): Promise<void> {
    const parsed = parseClientMessage(text);
    if (!parsed.ok) {
      this.sendError(connId, 'message.invalid', parsed.reason);
      return Promise.resolve();
    }
    return this.handle(connId, parsed.message);
  }

  handle(connId: ConnId, message: ClientMessage): Promise<void> {
    const conn = this.connections.get(connId);
    if (!conn) return Promise.resolve();
    const run = conn.queue.then(() => this.dispatch(connId, message));
    conn.queue = run.catch(() => undefined);
    return run;
  }

  disconnect(connId: ConnId): void {
    const conn = this.connections.get(connId);
    if (!conn) return;
    this.connections.delete(connId);
    const player = conn.playerId ? this.players.get(conn.playerId) : undefined;
    if (!player || player.connId !== connId) return;
    player.connId = null;
    const lobby = this.lobbyOf(player);
    if (!lobby) {
      this.deletePlayer(player);
      return;
    }
    player.disconnectedAt = this.clock.now();
    this.logger.info('player disconnected', { playerId: player.id, lobby: lobby.code });
    this.broadcast(lobby);
  }

  // ─── Timers ────────────────────────────────────────────────────────────

  /** The earliest time at which `tick()` has something to do, or null. */
  nextDeadline(): number | null {
    let next: number | null = null;
    const consider = (at: number): void => {
      if (next === null || at < next) next = at;
    };
    const graceMs = this.config.reconnectGraceSeconds * 1000;
    for (const player of this.players.values()) {
      if (player.disconnectedAt !== null) consider(player.disconnectedAt + graceMs);
    }
    const idleMs = this.config.lobbyIdleTtlSeconds * 1000;
    for (const lobby of this.lobbies.values()) {
      // A lobby that is loading places is never removed by tick(); its deadline is
      // considered again once startGame settles (the transport re-arms after every
      // message). Counting it here would make the timer spin while the query runs.
      if (lobby.starting) continue;
      if (lobby.phase === 'playing' && lobby.game) consider(lobby.game.endsAt);
      else consider(lobby.lastActivityAt + idleMs);
    }
    return next;
  }

  /** Ends games whose timer ran out, frees expired seats, removes idle lobbies. */
  tick(): void {
    const now = this.clock.now();
    for (const lobby of [...this.lobbies.values()]) {
      if (lobby.phase === 'playing' && lobby.game && now >= lobby.game.endsAt) {
        this.endGame(lobby);
        this.broadcast(lobby);
      }
    }
    const graceMs = this.config.reconnectGraceSeconds * 1000;
    for (const player of [...this.players.values()]) {
      if (player.disconnectedAt !== null && now >= player.disconnectedAt + graceMs) {
        this.logger.info('seat expired', { playerId: player.id });
        const lobby = this.lobbyOf(player);
        if (lobby) this.removeFromLobby(player, lobby);
        this.deletePlayer(player);
      }
    }
    const idleMs = this.config.lobbyIdleTtlSeconds * 1000;
    for (const lobby of [...this.lobbies.values()]) {
      if (lobby.phase !== 'playing' && !lobby.starting && now >= lobby.lastActivityAt + idleMs) {
        this.logger.info('idle lobby removed', { lobby: lobby.code });
        this.dissolveLobby(lobby);
      }
    }
  }

  /** Closes every lobby (used on shutdown). */
  shutdown(): void {
    for (const lobby of [...this.lobbies.values()]) this.lobbies.delete(lobby.code);
  }

  // ─── Dispatch ──────────────────────────────────────────────────────────

  private async dispatch(connId: ConnId, message: ClientMessage): Promise<void> {
    try {
      await this.route(connId, message);
    } catch (error) {
      if (error instanceof HubError) {
        this.sendError(connId, error.code, error.message === error.code ? undefined : error.message);
      } else {
        this.logger.error('handler failed', { type: message.type, error: String(error) });
        this.sendError(connId, 'server.error');
      }
    }
  }

  private async route(connId: ConnId, message: ClientMessage): Promise<void> {
    const conn = this.connections.get(connId);
    if (!conn) return;
    if (message.type === 'ping') {
      this.outbox.send(connId, { type: 'pong' });
      return;
    }
    if (message.type === 'hello') {
      await this.hello(conn, message);
      return;
    }
    const player = conn.playerId ? this.players.get(conn.playerId) : undefined;
    if (!player) throw new HubError('hello.required');
    switch (message.type) {
      case 'createLobby':
        return this.createLobby(player);
      case 'joinLobby':
        return this.joinLobby(player, message.code);
      case 'leaveLobby':
        return this.leaveLobby(player);
      case 'updateSettings':
        return this.updateSettings(player, message.settings);
      case 'startGame':
        return this.startGame(player);
      case 'guess':
        return this.guess(player, message);
      case 'returnToLobby':
        return this.returnToLobby(player);
    }
  }

  // ─── hello / resume ────────────────────────────────────────────────────

  private async hello(conn: Connection, message: ClientMessage): Promise<void> {
    if (conn.playerId !== null || conn.helloPending) throw new HubError('hello.duplicate');
    const { token, nickname, resumeToken } = message;
    if (token !== undefined && token !== null && typeof token !== 'string') throw new HubError('message.invalid');
    if (resumeToken !== undefined && resumeToken !== null && typeof resumeToken !== 'string') {
      throw new HubError('message.invalid');
    }

    if (typeof resumeToken === 'string' && resumeToken.length > 0) {
      const held = this.playersByResumeToken.get(resumeToken);
      if (held && this.lobbyOf(held)) {
        this.resume(conn, held);
        return;
      }
      this.sendError(conn.id, 'resume.invalid');
    }

    let identity: { nickname: string; isGuest: boolean; userId: number | null };
    if (typeof token === 'string' && token.length > 0) {
      conn.helloPending = true;
      let account;
      try {
        account = await this.accounts.resolve(token);
      } finally {
        conn.helloPending = false;
      }
      if (!account) throw new HubError('auth.invalid_token');
      identity = { nickname: account.name, isGuest: false, userId: account.userId };
    } else {
      const normalized = normalizeNickname(nickname);
      if (normalized === null) throw new HubError('nickname.invalid');
      identity = { nickname: normalized, isGuest: true, userId: null };
    }
    // The socket may have closed (or said hello) while the token was checked.
    if (!this.connections.has(conn.id) || conn.playerId !== null) return;

    const player: Player = {
      id: this.ids.playerId(),
      resumeToken: this.ids.resumeToken(),
      nickname: identity.nickname,
      isGuest: identity.isGuest,
      userId: identity.userId,
      connId: conn.id,
      lobbyCode: null,
      view: 'lobby',
      disconnectedAt: null,
    };
    this.players.set(player.id, player);
    this.playersByResumeToken.set(player.resumeToken, player);
    conn.playerId = player.id;
    this.logger.info('hello', { playerId: player.id, guest: player.isGuest });
    this.sendWelcome(player);
    this.sendState(player, null);
  }

  private resume(conn: Connection, player: Player): void {
    if (player.connId !== null && player.connId !== conn.id) {
      const old = this.connections.get(player.connId);
      if (old) old.playerId = null;
      this.outbox.close(player.connId, CLOSE_REPLACED, 'resumed on another connection');
    }
    player.connId = conn.id;
    player.disconnectedAt = null;
    conn.playerId = player.id;
    this.logger.info('resume', { playerId: player.id, lobby: player.lobbyCode });
    this.sendWelcome(player);
    const lobby = this.lobbyOf(player);
    if (lobby) {
      this.checkGameTimer(lobby);
      this.broadcast(lobby);
    } else {
      this.sendState(player, null);
    }
  }

  // ─── Lobby membership ──────────────────────────────────────────────────

  private createLobby(player: Player): void {
    this.leaveCurrentLobby(player);
    let code = this.ids.lobbyCode();
    for (let attempt = 0; this.lobbies.has(code); attempt++) {
      if (attempt > 100) throw new Error('could not allocate a lobby code');
      code = this.ids.lobbyCode();
    }
    const lobby: Lobby = {
      code,
      hostId: player.id,
      playerIds: [player.id],
      settings: this.defaults(),
      phase: 'waiting',
      game: null,
      starting: false,
      lastActivityAt: this.clock.now(),
    };
    this.lobbies.set(code, lobby);
    player.lobbyCode = code;
    player.view = 'lobby';
    this.logger.info('lobby created', { lobby: code, playerId: player.id });
    this.broadcast(lobby);
  }

  private joinLobby(player: Player, rawCode: unknown): void {
    if (typeof rawCode !== 'string') throw new HubError('message.invalid', 'code must be a string');
    const code = rawCode.trim().toUpperCase();
    const lobby = this.lobbies.get(code);
    if (!lobby) throw new HubError('lobby.not_found');
    if (player.lobbyCode === code) {
      this.sendState(player, lobby);
      return;
    }
    this.checkGameTimer(lobby);
    if (lobby.playerIds.length >= lobby.settings.maxPlayers) throw new HubError('lobby.full');
    this.leaveCurrentLobby(player);
    lobby.playerIds.push(player.id);
    player.lobbyCode = code;
    player.view = 'lobby';
    this.touch(lobby);
    this.logger.info('lobby joined', { lobby: code, playerId: player.id });
    this.broadcast(lobby);
  }

  private leaveLobby(player: Player): void {
    const lobby = this.lobbyOf(player);
    if (!lobby) throw new HubError('lobby.not_in_lobby');
    this.removeFromLobby(player, lobby);
    this.sendState(player, null);
  }

  private leaveCurrentLobby(player: Player): void {
    const lobby = this.lobbyOf(player);
    if (lobby) this.removeFromLobby(player, lobby);
  }

  /** Frees the player's seat, migrates the host, deletes an empty lobby. */
  private removeFromLobby(player: Player, lobby: Lobby): void {
    lobby.playerIds = lobby.playerIds.filter((id) => id !== player.id);
    player.lobbyCode = null;
    player.view = 'lobby';
    const participant = lobby.game?.participants.get(player.id);
    if (participant && lobby.game?.status === 'playing') participant.left = true;
    this.logger.info('lobby left', { lobby: lobby.code, playerId: player.id });

    const nextHost = lobby.playerIds[0];
    if (nextHost === undefined) {
      this.lobbies.delete(lobby.code);
      this.logger.info('lobby deleted', { lobby: lobby.code });
      return;
    }
    if (lobby.hostId === player.id) lobby.hostId = nextHost;
    this.touch(lobby);
    if (lobby.phase === 'playing') this.endGameIfAllDone(lobby);
    this.broadcast(lobby);
  }

  private dissolveLobby(lobby: Lobby): void {
    this.lobbies.delete(lobby.code);
    for (const id of lobby.playerIds) {
      const player = this.players.get(id);
      if (!player) continue;
      player.lobbyCode = null;
      player.view = 'lobby';
      if (player.connId === null) this.deletePlayer(player);
      else this.sendState(player, null);
    }
  }

  private deletePlayer(player: Player): void {
    this.players.delete(player.id);
    this.playersByResumeToken.delete(player.resumeToken);
  }

  // ─── Settings and game start ───────────────────────────────────────────

  private updateSettings(player: Player, raw: unknown): void {
    const lobby = this.requireLobby(player);
    if (lobby.hostId !== player.id) throw new HubError('lobby.not_host');
    if (lobby.phase === 'playing' || lobby.starting) throw new HubError('lobby.in_game');
    if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) throw new HubError('settings.invalid');
    const input = raw as Record<string, unknown>;
    const next = { ...lobby.settings };
    const c = this.config;
    const field = (name: keyof LobbySettings, min: number, max: number): void => {
      const value = input[name];
      if (value === undefined || value === null) return;
      if (typeof value !== 'number' || !Number.isInteger(value) || value < min || value > max) {
        throw new HubError('settings.invalid', `${name} must be an integer between ${min} and ${max}`);
      }
      next[name] = value;
    };
    field('maxPlayers', Math.max(c.minPlayers, lobby.playerIds.length, 1), c.maxPlayers);
    field('placeCount', 1, c.maxPlaceCount);
    field('durationSeconds', c.minDurationSeconds, c.maxDurationSeconds);
    lobby.settings = next;
    this.touch(lobby);
    this.broadcast(lobby);
  }

  private async startGame(player: Player): Promise<void> {
    const lobby = this.requireLobby(player);
    if (lobby.hostId !== player.id) throw new HubError('lobby.not_host');
    this.checkGameTimer(lobby);
    if (lobby.phase === 'playing' || lobby.starting) throw new HubError('lobby.in_game');
    if (player.view !== 'lobby') throw new HubError('lobby.not_in_lobby', 'Return to the lobby first');
    if (this.eligibleParticipants(lobby).length < this.config.minPlayers) {
      throw new HubError('lobby.not_enough_players');
    }

    lobby.starting = true;
    this.touch(lobby);
    let places: Place[];
    try {
      places = await this.places.randomPlaces(lobby.settings.placeCount);
    } finally {
      lobby.starting = false;
    }
    if (this.lobbies.get(lobby.code) !== lobby) return; // dissolved meanwhile

    const unique = [...new Map(places.map((place) => [place.id, place])).values()].slice(
      0,
      lobby.settings.placeCount,
    );
    if (unique.length === 0) throw new HubError('game.no_places');
    const participants = this.eligibleParticipants(lobby);
    if (participants.length < this.config.minPlayers) throw new HubError('lobby.not_enough_players');

    const now = this.clock.now();
    lobby.game = {
      places: unique,
      startedAt: now,
      endsAt: now + lobby.settings.durationSeconds * 1000,
      status: 'playing',
      participants: new Map(
        participants.map((p) => [p.id, { playerId: p.id, nickname: p.nickname, guesses: [], left: false }]),
      ),
      endedAt: null,
      leaderboard: null,
    };
    lobby.phase = 'playing';
    for (const p of participants) p.view = 'game';
    this.touch(lobby);
    this.logger.info('game started', { lobby: lobby.code, players: participants.length, places: unique.length });
    this.broadcast(lobby);
  }

  /** Connected players in the lobby view, in join order. */
  private eligibleParticipants(lobby: Lobby): Player[] {
    return lobby.playerIds
      .map((id) => this.players.get(id))
      .filter((p): p is Player => p !== undefined && p.view === 'lobby' && p.connId !== null);
  }

  // ─── Guessing ──────────────────────────────────────────────────────────

  private guess(player: Player, message: ClientMessage): void {
    const lobby = this.requireLobby(player);
    this.checkGameTimer(lobby);
    const game = lobby.game;
    const participant = game?.participants.get(player.id);
    if (!game || game.status !== 'playing' || !participant || participant.left || player.view !== 'game') {
      throw new HubError('game.not_playing');
    }
    const { index, latitude, longitude } = message;
    if (typeof index !== 'number' || !Number.isInteger(index) || !isValidCoordinate(latitude, longitude)) {
      throw new HubError('guess.invalid');
    }
    const currentIndex = participant.guesses.length;
    if (index !== currentIndex || currentIndex >= game.places.length) throw new HubError('guess.wrong_index');
    const lon = longitude as number;
    if (!isInRegion(latitude, lon)) throw new HubError('guess.outside_region');

    const place = game.places[index]!;
    const now = this.clock.now();
    const distance = distanceMeters(latitude, lon, place.latitude, place.longitude);
    participant.guesses.push({ latitude, longitude: lon, distanceMeters: distance, at: now });
    this.touch(lobby);

    if (player.connId !== null) {
      this.outbox.send(player.connId, {
        type: 'guessResult',
        index,
        distanceMeters: distance,
        guess: { latitude, longitude: lon },
        place: revealOf(place, index),
      });
    }
    this.endGameIfAllDone(lobby);
    this.broadcast(lobby);
  }

  private returnToLobby(player: Player): void {
    const lobby = this.requireLobby(player);
    this.checkGameTimer(lobby);
    if (player.view === 'game') throw new HubError('lobby.in_game');
    player.view = 'lobby';
    this.touch(lobby);
    this.broadcast(lobby);
  }

  // ─── Game end ──────────────────────────────────────────────────────────

  /** Ends the game if its timer ran out (without broadcasting). */
  private checkGameTimer(lobby: Lobby): void {
    if (lobby.phase === 'playing' && lobby.game && this.clock.now() >= lobby.game.endsAt) {
      this.endGame(lobby);
      this.broadcast(lobby);
    }
  }

  private endGameIfAllDone(lobby: Lobby): void {
    const game = lobby.game;
    if (!game || game.status !== 'playing') return;
    const allDone = [...game.participants.values()]
      .filter((p) => !p.left)
      .every((p) => p.guesses.length >= game.places.length);
    if (allDone) this.endGame(lobby);
  }

  private endGame(lobby: Lobby): void {
    const game = lobby.game;
    if (!game || game.status !== 'playing') return;
    game.status = 'finished';
    game.endedAt = this.clock.now();
    game.leaderboard = rankParticipants(
      [...game.participants.values()].map((p) => ({
        playerId: p.playerId,
        nickname: p.nickname,
        distances: p.guesses.map((g) => g.distanceMeters),
        lastGuessAt: p.guesses.at(-1)?.at ?? null,
      })),
      game.places.length,
      this.config.penaltyDistanceMeters,
    );
    lobby.phase = 'finished';
    for (const id of lobby.playerIds) {
      const player = this.players.get(id);
      const participant = game.participants.get(id);
      if (player && participant && !participant.left) player.view = 'results';
    }
    this.touch(lobby);
    this.logger.info('game finished', { lobby: lobby.code });
  }

  // ─── Views ─────────────────────────────────────────────────────────────

  private buildLobbyView(lobby: Lobby, self: Player): LobbyView {
    const game = lobby.game;
    return {
      code: lobby.code,
      hostId: lobby.hostId,
      selfId: self.id,
      phase: lobby.phase,
      settings: { ...lobby.settings },
      players: lobby.playerIds
        .map((id) => this.players.get(id))
        .filter((p): p is Player => p !== undefined)
        .map((p) => ({
          id: p.id,
          nickname: p.nickname,
          isGuest: p.isGuest,
          isHost: p.id === lobby.hostId,
          connected: p.connId !== null,
          view: p.view,
          guessedCount: game?.participants.get(p.id)?.guesses.length ?? 0,
        })),
      game: game ? this.buildGameView(game, self) : null,
    };
  }

  private buildGameView(game: Game, self: Player): GameView {
    const finished = game.status === 'finished';
    const participant = game.participants.get(self.id);
    let selfView: SelfGameView | null = null;
    if (participant && (finished || !participant.left)) {
      const currentIndex = participant.guesses.length;
      const visible = finished ? game.places.length : currentIndex;
      const rounds: RoundView[] = [];
      for (let index = 0; index < visible; index++) {
        const place = game.places[index]!;
        const guess = participant.guesses[index];
        rounds.push({
          index,
          name: place.name,
          guess: guess ? { latitude: guess.latitude, longitude: guess.longitude } : null,
          distanceMeters: guess ? guess.distanceMeters : null,
          place: revealOf(place, index),
        });
      }
      selfView = {
        currentIndex,
        currentPlaceName: !finished && currentIndex < game.places.length ? game.places[currentIndex]!.name : null,
        rounds,
      };
    }
    let guesses: Record<string, (GuessSummary | null)[]> | null = null;
    if (finished) {
      guesses = {};
      for (const p of game.participants.values()) {
        guesses[p.playerId] = game.places.map((_, i) => {
          const g = p.guesses[i];
          return g ? { latitude: g.latitude, longitude: g.longitude, distanceMeters: g.distanceMeters } : null;
        });
      }
    }
    return {
      status: game.status,
      startedAt: game.startedAt,
      endsAt: game.endsAt,
      placeCount: game.places.length,
      participantIds: [...game.participants.keys()],
      self: selfView,
      leaderboard: finished ? (game.leaderboard ?? []) : null,
      places: finished ? game.places.map((place, i) => revealOf(place, i)) : null,
      guesses,
    };
  }

  // ─── Helpers ───────────────────────────────────────────────────────────

  private lobbyOf(player: Player): Lobby | undefined {
    return player.lobbyCode === null ? undefined : this.lobbies.get(player.lobbyCode);
  }

  private requireLobby(player: Player): Lobby {
    const lobby = this.lobbyOf(player);
    if (!lobby) throw new HubError('lobby.not_in_lobby');
    return lobby;
  }

  private touch(lobby: Lobby): void {
    lobby.lastActivityAt = this.clock.now();
  }

  private broadcast(lobby: Lobby): void {
    if (this.lobbies.get(lobby.code) !== lobby) return;
    for (const id of lobby.playerIds) {
      const player = this.players.get(id);
      if (player) this.sendState(player, lobby);
    }
  }

  private sendState(player: Player, lobby: Lobby | null): void {
    if (player.connId === null) return;
    this.outbox.send(player.connId, {
      type: 'state',
      serverNow: this.clock.now(),
      lobby: lobby ? this.buildLobbyView(lobby, player) : null,
    });
  }

  private sendWelcome(player: Player): void {
    if (player.connId === null) return;
    this.outbox.send(player.connId, {
      type: 'welcome',
      playerId: player.id,
      resumeToken: player.resumeToken,
      nickname: player.nickname,
      isGuest: player.isGuest,
      limits: this.limits(),
      defaults: this.defaults(),
    });
  }

  sendError(connId: ConnId, code: ErrorCode, message?: string): void {
    this.outbox.send(connId, message === undefined ? { type: 'error', code } : { type: 'error', code, message });
  }
}

export function revealOf(place: Place, index: number): PlaceReveal {
  return {
    index,
    id: place.id,
    name: place.name,
    latitude: place.latitude,
    longitude: place.longitude,
    category: place.category,
    description: place.description,
    contentSourceUrl: place.contentSourceUrl,
    source: { ...place.source },
  };
}
