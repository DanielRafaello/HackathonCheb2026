import pg from 'pg';
import type { DbConfig } from './config.js';

export function createPool(db: DbConfig): pg.Pool {
  return new pg.Pool({
    host: db.host,
    port: db.port,
    database: db.database,
    user: db.user,
    password: db.password,
    max: 5,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
    application_name: 'kdz-multiplayer',
  });
}
