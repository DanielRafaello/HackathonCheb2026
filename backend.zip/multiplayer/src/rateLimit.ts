/** Sliding-window limiter: at most `limit` events per `windowMs` per connection. */
export class RateLimiter {
  private readonly stamps: number[] = [];

  constructor(
    private readonly limit: number,
    private readonly windowMs: number,
    private readonly now: () => number = Date.now,
  ) {}

  /** Records an event; false when it exceeds the limit (the event is not counted). */
  allow(): boolean {
    const now = this.now();
    while (this.stamps.length > 0 && this.stamps[0]! <= now - this.windowMs) this.stamps.shift();
    if (this.stamps.length >= this.limit) return false;
    this.stamps.push(now);
    return true;
  }
}
