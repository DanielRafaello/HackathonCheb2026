/** Transport: HTTP server, health endpoint, WebSocket upgrade on /ws, heartbeat, rate limit, timers. */
import http from 'node:http';
import type { AddressInfo, Socket } from 'node:net';
import { WebSocket, WebSocketServer } from 'ws';
import type { AccountResolver } from './auth.js';
import type { GameConfig } from './config.js';
import type { Clock, ConnId, IdGenerator } from './hub.js';
import { GameHub, systemClock } from './hub.js';
import type { Logger } from './logger.js';
import { silentLogger } from './logger.js';
import type { PlaceSource } from './places.js';
import type { ServerMessage } from './protocol.js';
import { RateLimiter } from './rateLimit.js';

export const WS_PATH = '/ws';
export const HEALTH_PATH = '/ws/health';
export const MAX_PAYLOAD_BYTES = 4 * 1024;
/**
 * A socket whose unsent output grows past this is not reading; it is terminated instead of buffered further.
 * A finished-game state with 20 places and 8 players is about 55 KB, so this leaves room for a few dozen
 * broadcasts while a phone briefly stops reading (tunnel, locked screen); the heartbeat handles longer stalls.
 */
export const MAX_BUFFERED_BYTES = 2 * 1024 * 1024;
/** Close code for a connection that keeps sending after it was rate-limited. */
export const CLOSE_POLICY_VIOLATION = 1008;

export interface ServerOptions {
  game: GameConfig;
  /** Allowed `Origin` values; a request without an Origin header is always allowed. */
  allowedOrigins: string[];
  places: PlaceSource;
  accounts: AccountResolver;
  logger?: Logger;
  clock?: Clock;
  ids?: IdGenerator;
  heartbeatIntervalMs?: number;
  rateLimit?: { limit: number; windowMs: number };
}

export interface RunningServer {
  port: number;
  hub: GameHub;
  close(): Promise<void>;
}

function pathnameOf(url: string | undefined): string {
  try {
    return new URL(url ?? '/', 'http://localhost').pathname.replace(/\/+$/, '') || '/';
  } catch {
    return '/';
  }
}

function rejectUpgrade(socket: Socket, status: number, text: string): void {
  socket.write(`HTTP/1.1 ${status} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
  socket.destroy();
}

export function isOriginAllowed(origin: string | undefined, allowed: string[]): boolean {
  if (origin === undefined) return true;
  return allowed.includes(origin.trim().replace(/\/+$/, ''));
}

export async function startServer(options: ServerOptions, port: number, host?: string): Promise<RunningServer> {
  const logger = options.logger ?? silentLogger;
  const clock = options.clock ?? systemClock;
  const heartbeatIntervalMs = options.heartbeatIntervalMs ?? 30_000;
  const rateLimit = options.rateLimit ?? { limit: 20, windowMs: 5_000 };

  const sockets = new Map<ConnId, WebSocket>();
  const alive = new Map<ConnId, boolean>();

  const send = (connId: ConnId, message: ServerMessage): void => {
    const ws = sockets.get(connId);
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    if (ws.bufferedAmount > MAX_BUFFERED_BYTES) {
      logger.warn('socket not reading, terminating', { connId, bufferedAmount: ws.bufferedAmount });
      ws.terminate();
      return;
    }
    ws.send(JSON.stringify(message));
  };

  const hub = new GameHub({
    config: options.game,
    places: options.places,
    accounts: options.accounts,
    clock,
    ids: options.ids,
    logger,
    outbox: {
      send,
      close: (connId, code, reason) => sockets.get(connId)?.close(code, reason),
    },
  });

  let timer: NodeJS.Timeout | undefined;
  const armTimer = (): void => {
    if (timer) clearTimeout(timer);
    timer = undefined;
    const deadline = hub.nextDeadline();
    if (deadline === null) return;
    const delay = Math.min(Math.max(0, deadline - clock.now()), 2 ** 31 - 1);
    timer = setTimeout(() => {
      try {
        hub.tick();
      } catch (error) {
        logger.error('tick failed', { error: String(error) });
      }
      armTimer();
    }, delay);
  };

  const server = http.createServer((req, res) => {
    const path = pathnameOf(req.url);
    if (path === HEALTH_PATH && (req.method === 'GET' || req.method === 'HEAD')) {
      res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      res.end(req.method === 'HEAD' ? undefined : JSON.stringify({ status: 'ok' }));
      return;
    }
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'not_found' }));
  });

  const wss = new WebSocketServer({ noServer: true, maxPayload: MAX_PAYLOAD_BYTES });

  server.on('upgrade', (req, socket: Socket, head) => {
    if (pathnameOf(req.url) !== WS_PATH) return rejectUpgrade(socket, 404, 'Not Found');
    if (!isOriginAllowed(req.headers.origin, options.allowedOrigins)) {
      logger.warn('origin rejected', { origin: req.headers.origin });
      return rejectUpgrade(socket, 403, 'Forbidden');
    }
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  });

  let nextConnId = 0;
  wss.on('connection', (ws: WebSocket) => {
    const connId = `c${++nextConnId}`;
    const limiter = new RateLimiter(rateLimit.limit, rateLimit.windowMs);
    // Frames rejected since the last accepted one: the first gets `rate_limited`, too many close the socket.
    let rejected = 0;
    sockets.set(connId, ws);
    alive.set(connId, true);
    hub.connect(connId);

    ws.on('pong', () => alive.set(connId, true));
    ws.on('message', (data, isBinary) => {
      if (!limiter.allow()) {
        rejected += 1;
        if (rejected === 1) send(connId, { type: 'error', code: 'rate_limited' });
        else if (rejected > rateLimit.limit && ws.readyState === WebSocket.OPEN) {
          logger.warn('rate limit exceeded, closing', { connId });
          ws.close(CLOSE_POLICY_VIOLATION, 'rate limit exceeded');
        }
        return;
      }
      rejected = 0;
      if (isBinary) {
        send(connId, { type: 'error', code: 'message.invalid', message: 'Binary frames are not supported' });
        return;
      }
      const text = Array.isArray(data) ? Buffer.concat(data).toString('utf8') : Buffer.from(data as ArrayBuffer).toString('utf8');
      hub
        .handleText(connId, text)
        .catch((error: unknown) => logger.error('message failed', { error: String(error) }))
        .finally(armTimer);
    });
    ws.on('close', () => {
      sockets.delete(connId);
      alive.delete(connId);
      hub.disconnect(connId);
      armTimer();
    });
    ws.on('error', (error) => logger.warn('socket error', { connId, error: String(error) }));
  });

  const heartbeat = setInterval(() => {
    for (const [connId, ws] of sockets) {
      if (!alive.get(connId) || ws.bufferedAmount > MAX_BUFFERED_BYTES) {
        ws.terminate();
        continue;
      }
      alive.set(connId, false);
      try {
        ws.ping();
      } catch {
        ws.terminate();
      }
    }
  }, heartbeatIntervalMs);

  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, () => {
      server.off('error', reject);
      resolve();
    });
  });
  const actualPort = (server.address() as AddressInfo).port;

  let closing: Promise<void> | null = null;
  const close = (): Promise<void> => {
    closing ??= new Promise<void>((resolve) => {
      clearInterval(heartbeat);
      if (timer) clearTimeout(timer);
      for (const ws of sockets.values()) ws.close(1001, 'server shutting down');
      hub.shutdown();
      const force = setTimeout(() => {
        for (const ws of sockets.values()) ws.terminate();
        server.closeAllConnections();
      }, 2_000);
      force.unref();
      wss.close();
      server.close(() => {
        clearTimeout(force);
        resolve();
      });
      server.closeIdleConnections();
    });
    return closing;
  };

  return { port: actualPort, hub, close };
}
