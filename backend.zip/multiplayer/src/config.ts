/** Server configuration, read from the environment (see README.md). */

export interface GameConfig {
  /** Hard cap and default for players per lobby. */
  maxPlayers: number;
  /** Players in the lobby view needed to start a game. */
  minPlayers: number;
  defaultPlaceCount: number;
  maxPlaceCount: number;
  defaultDurationSeconds: number;
  minDurationSeconds: number;
  maxDurationSeconds: number;
  /** Offset counted for a place a participant did not guess. */
  penaltyDistanceMeters: number;
  /** How long a disconnected player keeps their seat. */
  reconnectGraceSeconds: number;
  /** A lobby with no activity for this long (and no running game) is deleted. */
  lobbyIdleTtlSeconds: number;
}

export interface DbConfig {
  host: string;
  port: number;
  database: string;
  user: string;
  password: string;
}

export interface Config {
  port: number;
  /** Allowed values of the `Origin` header. Requests without one are allowed. */
  allowedOrigins: string[];
  jwtSecret: string | null;
  db: DbConfig;
  game: GameConfig;
}

export class ConfigError extends Error {}

type Env = Record<string, string | undefined>;

function intVar(env: Env, name: string, fallback: number, min: number, max = Number.MAX_SAFE_INTEGER): number {
  const raw = env[name];
  if (raw === undefined || raw.trim() === '') return fallback;
  const value = Number(raw.trim());
  if (!Number.isInteger(value) || value < min || value > max) {
    throw new ConfigError(`${name} must be an integer between ${min} and ${max}, got "${raw}"`);
  }
  return value;
}

function strVar(env: Env, name: string, fallback: string): string {
  const raw = env[name];
  return raw === undefined || raw.trim() === '' ? fallback : raw.trim();
}

/** Parses an allowed-origin list: comma separated, trailing slashes ignored. */
export function parseOrigins(raw: string | undefined): string[] {
  if (!raw) return [];
  return raw
    .split(',')
    .map((origin) => origin.trim().replace(/\/+$/, ''))
    .filter((origin) => origin.length > 0);
}

export function loadConfig(env: Env = process.env): Config {
  const maxPlayers = intVar(env, 'MP_MAX_PLAYERS', 8, 1, 100);
  const minPlayers = intVar(env, 'MP_MIN_PLAYERS', 1, 1, maxPlayers);
  const maxPlaceCount = intVar(env, 'MP_MAX_PLACES_PER_GAME', 20, 1, 1000);
  const defaultPlaceCount = intVar(env, 'MP_PLACES_PER_GAME', 10, 1, maxPlaceCount);
  const minDurationSeconds = intVar(env, 'MP_MIN_GAME_DURATION_SECONDS', 60, 1);
  const maxDurationSeconds = intVar(env, 'MP_MAX_GAME_DURATION_SECONDS', 1800, minDurationSeconds);
  const defaultDurationSeconds = intVar(
    env,
    'MP_GAME_DURATION_SECONDS',
    Math.min(Math.max(300, minDurationSeconds), maxDurationSeconds),
    minDurationSeconds,
    maxDurationSeconds,
  );
  const jwtSecret = env.JWT_SECRET?.trim() ? env.JWT_SECRET.trim() : null;

  return {
    port: intVar(env, 'MP_PORT', 8090, 0, 65535),
    allowedOrigins: parseOrigins(env.FRONTEND_URL),
    jwtSecret,
    db: {
      host: strVar(env, 'DB_HOST', 'localhost'),
      port: intVar(env, 'DB_PORT', 5432, 1, 65535),
      database: strVar(env, 'DB_NAME', 'myapp'),
      user: strVar(env, 'DB_USER', 'myapp'),
      password: env.DB_PASSWORD ?? '',
    },
    game: {
      maxPlayers,
      minPlayers,
      defaultPlaceCount,
      maxPlaceCount,
      defaultDurationSeconds,
      minDurationSeconds,
      maxDurationSeconds,
      penaltyDistanceMeters: intVar(env, 'MP_PENALTY_DISTANCE_METERS', 100000, 0),
      reconnectGraceSeconds: intVar(env, 'MP_RECONNECT_GRACE_SECONDS', 60, 0),
      lobbyIdleTtlSeconds: intVar(env, 'MP_LOBBY_IDLE_TTL_SECONDS', 1800, 1),
    },
  };
}
