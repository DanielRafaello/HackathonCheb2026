import type { LeaderboardRow } from './protocol.js';

export interface ScoreInput {
  playerId: string;
  nickname: string;
  /** Offsets of the places this participant guessed, in metres. */
  distances: number[];
  /** Time of the participant's last guess (epoch ms), null without guesses. */
  lastGuessAt: number | null;
}

const collator = new Intl.Collator('cs', { sensitivity: 'base' });

/**
 * Ranks participants by average offset over all places (an unguessed place counts
 * as the penalty distance). Ties: more guesses, then earlier last guess, then
 * nickname (and the player id so the order is total). Ranks are 1..n, unique.
 */
export function rankParticipants(inputs: ScoreInput[], placeCount: number, penaltyMeters: number): LeaderboardRow[] {
  const rows = inputs.map((input) => {
    const guessedCount = Math.min(input.distances.length, placeCount);
    const guessedTotal = input.distances.slice(0, placeCount).reduce((sum, d) => sum + d, 0);
    const totalDistanceMeters = guessedTotal + (placeCount - guessedCount) * penaltyMeters;
    return {
      rank: 0,
      playerId: input.playerId,
      nickname: input.nickname,
      averageDistanceMeters: placeCount > 0 ? Math.round(totalDistanceMeters / placeCount) : 0,
      guessedCount,
      totalDistanceMeters,
      finishedAt: input.lastGuessAt,
    };
  });
  rows.sort(
    (a, b) =>
      // Rank by the average the leaderboard shows (whole metres), so two rows that
      // display the same average are ordered by the documented tie-breaks.
      a.averageDistanceMeters - b.averageDistanceMeters ||
      b.guessedCount - a.guessedCount ||
      (a.finishedAt ?? Number.POSITIVE_INFINITY) - (b.finishedAt ?? Number.POSITIVE_INFINITY) ||
      collator.compare(a.nickname, b.nickname) ||
      (a.playerId < b.playerId ? -1 : a.playerId > b.playerId ? 1 : 0),
  );
  rows.forEach((row, i) => {
    row.rank = i + 1;
  });
  return rows;
}
