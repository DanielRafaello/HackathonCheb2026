import type { Pool } from 'pg';

export interface PlaceSourceInfo {
  title: string;
  publisher: string;
  portalUrl: string;
  licenseCode: string;
  licenseUrl: string;
  attributionText: string;
}

/** A playable place with everything its reveal shows. */
export interface Place {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  category: string;
  description: string;
  contentSourceUrl: string | null;
  source: PlaceSourceInfo;
}

export interface PlaceSource {
  /** Up to `count` distinct random places (fewer if the catalog is smaller). */
  randomPlaces(count: number): Promise<Place[]>;
}

export const RANDOM_PLACES_SQL = `
SELECT l.id, l.name, l.latitude, l.longitude, l.description, l.content_source_url, c.name AS category,
       s.title, s.publisher, s.portal_url, s.license_code, s.license_url, s.attribution_text,
       s.retrieved_at, s.source_updated_at
FROM locations l
JOIN categories c ON c.category_id = l.category_id
JOIN sources s ON s.source_id = l.source_id
ORDER BY random()
LIMIT $1`;

interface PlaceRow {
  id: number | string;
  name: string;
  latitude: number | string;
  longitude: number | string;
  description: string | null;
  content_source_url: string | null;
  category: string;
  title: string | null;
  publisher: string | null;
  portal_url: string | null;
  license_code: string | null;
  license_url: string | null;
  attribution_text: string | null;
}

export function placeFromRow(row: PlaceRow): Place {
  return {
    id: Number(row.id),
    name: row.name,
    latitude: Number(row.latitude),
    longitude: Number(row.longitude),
    category: row.category,
    description: row.description ?? '',
    contentSourceUrl: row.content_source_url ?? null,
    source: {
      title: row.title ?? '',
      publisher: row.publisher ?? '',
      portalUrl: row.portal_url ?? '',
      licenseCode: row.license_code ?? '',
      licenseUrl: row.license_url ?? '',
      attributionText: row.attribution_text ?? '',
    },
  };
}

/** Reads places straight from the backend's Postgres (read only). */
export class PgPlaceSource implements PlaceSource {
  constructor(private readonly pool: Pool) {}

  async randomPlaces(count: number): Promise<Place[]> {
    const result = await this.pool.query<PlaceRow>(RANDOM_PLACES_SQL, [count]);
    return result.rows.map(placeFromRow);
  }
}

/** In-memory source for tests and local experiments. */
export class StaticPlaceSource implements PlaceSource {
  constructor(
    private readonly places: Place[],
    private readonly shuffle: boolean = false,
    private readonly random: () => number = Math.random,
  ) {}

  async randomPlaces(count: number): Promise<Place[]> {
    const copy = [...this.places];
    if (this.shuffle) {
      for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(this.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j]!, copy[i]!];
      }
    }
    return copy.slice(0, count);
  }
}
