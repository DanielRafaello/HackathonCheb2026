import { REGION_OUTLINE } from './region.js';

/** Same radius as the backend's `GeoCalculator` so the numbers match. */
export const EARTH_RADIUS_METERS = 6371008.8;

const toRadians = (degrees: number): number => (degrees * Math.PI) / 180;

/** Haversine distance in whole metres (rounded), as `GeoCalculator::distanceMeters`. */
export function distanceMeters(fromLat: number, fromLon: number, toLat: number, toLon: number): number {
  const fromLatRad = toRadians(fromLat);
  const toLatRad = toRadians(toLat);
  const latDelta = toRadians(toLat - fromLat);
  const lonDelta = toRadians(toLon - fromLon);
  const a =
    Math.sin(latDelta / 2) ** 2 + Math.cos(fromLatRad) * Math.cos(toLatRad) * Math.sin(lonDelta / 2) ** 2;
  return Math.round(EARTH_RADIUS_METERS * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

/** Ray casting, the same algorithm as the frontend's `Geo.contains`. */
export function polygonContains(
  ring: ReadonlyArray<readonly [number, number]>,
  latitude: number,
  longitude: number,
): boolean {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [aLat, aLon] = ring[i]!;
    const [bLat, bLon] = ring[j]!;
    const crosses =
      aLat > latitude !== bLat > latitude && longitude < ((bLon - aLon) * (latitude - aLat)) / (bLat - aLat) + aLon;
    if (crosses) inside = !inside;
  }
  return inside;
}

export function isInRegion(latitude: number, longitude: number): boolean {
  return polygonContains(REGION_OUTLINE, latitude, longitude);
}

/** Finite numbers within the WGS84 ranges. */
export function isValidCoordinate(latitude: unknown, longitude: unknown): latitude is number {
  return (
    typeof latitude === 'number' &&
    typeof longitude === 'number' &&
    Number.isFinite(latitude) &&
    Number.isFinite(longitude) &&
    latitude >= -90 &&
    latitude <= 90 &&
    longitude >= -180 &&
    longitude <= 180
  );
}
