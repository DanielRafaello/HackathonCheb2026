export type LogFields = Record<string, unknown>;

export interface Logger {
  info(message: string, fields?: LogFields): void;
  warn(message: string, fields?: LogFields): void;
  error(message: string, fields?: LogFields): void;
}

export const silentLogger: Logger = { info() {}, warn() {}, error() {} };

/** One JSON object per line on stdout/stderr (picked up by the Docker log driver). */
export const jsonLogger: Logger = {
  info: (message, fields) => console.log(JSON.stringify({ level: 'info', time: new Date().toISOString(), message, ...fields })),
  warn: (message, fields) => console.warn(JSON.stringify({ level: 'warn', time: new Date().toISOString(), message, ...fields })),
  error: (message, fields) =>
    console.error(JSON.stringify({ level: 'error', time: new Date().toISOString(), message, ...fields })),
};
