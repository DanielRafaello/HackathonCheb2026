import jwt from 'jsonwebtoken';
import type { Pool } from 'pg';

export interface Account {
  userId: number;
  name: string;
}

/** Turns a backend access token into an account, or null when it is not valid. */
export interface AccountResolver {
  resolve(token: string): Promise<Account | null>;
}

export interface UserDirectory {
  findName(userId: number): Promise<string | null>;
}

export class PgUserDirectory implements UserDirectory {
  constructor(private readonly pool: Pool) {}

  async findName(userId: number): Promise<string | null> {
    const result = await this.pool.query<{ name: string }>('SELECT name FROM users WHERE id = $1', [userId]);
    return result.rows[0]?.name ?? null;
  }
}

/** Verifies the backend's HS256 JWT (`{sub:int, role, iat, exp}`) and looks up `users.name`. */
export class JwtAccountResolver implements AccountResolver {
  constructor(
    private readonly secret: string | null,
    private readonly users: UserDirectory,
  ) {}

  async resolve(token: string): Promise<Account | null> {
    if (!this.secret) return null;
    let payload: string | jwt.JwtPayload;
    try {
      payload = jwt.verify(token, this.secret, { algorithms: ['HS256'] });
    } catch {
      return null;
    }
    if (typeof payload !== 'object' || payload === null) return null;
    const sub = Number(payload.sub);
    if (!Number.isSafeInteger(sub) || sub <= 0) return null;
    const name = await this.users.findName(sub);
    if (name === null) return null;
    const trimmed = name.trim();
    return { userId: sub, name: trimmed.length > 0 ? trimmed : `Hráč ${sub}` };
  }
}
