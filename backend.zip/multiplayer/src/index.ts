import { JwtAccountResolver, PgUserDirectory } from './auth.js';
import { ConfigError, loadConfig } from './config.js';
import { createPool } from './db.js';
import { jsonLogger as logger } from './logger.js';
import { PgPlaceSource } from './places.js';
import { startServer } from './server.js';

async function main(): Promise<void> {
  let config;
  try {
    config = loadConfig();
  } catch (error) {
    if (error instanceof ConfigError) {
      logger.error('invalid configuration', { error: error.message });
      process.exit(1);
    }
    throw error;
  }
  if (!config.jwtSecret) logger.warn('JWT_SECRET is not set: signed-in players cannot join');
  if (config.allowedOrigins.length === 0) logger.warn('FRONTEND_URL is not set: browser origins are rejected');

  const pool = createPool(config.db);
  pool.on('error', (error) => logger.error('database pool error', { error: String(error) }));

  const server = await startServer(
    {
      game: config.game,
      allowedOrigins: config.allowedOrigins,
      places: new PgPlaceSource(pool),
      accounts: new JwtAccountResolver(config.jwtSecret, new PgUserDirectory(pool)),
      logger,
    },
    config.port,
    '0.0.0.0',
  );
  logger.info('multiplayer server listening', { port: server.port, origins: config.allowedOrigins });

  let stopping = false;
  const stop = (signal: string): void => {
    if (stopping) return;
    stopping = true;
    logger.info('shutting down', { signal });
    const force = setTimeout(() => process.exit(1), 10_000);
    force.unref();
    server
      .close()
      .then(() => pool.end())
      .then(() => process.exit(0))
      .catch((error: unknown) => {
        logger.error('shutdown failed', { error: String(error) });
        process.exit(1);
      });
  };
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('SIGINT', () => stop('SIGINT'));
}

main().catch((error: unknown) => {
  logger.error('startup failed', { error: String(error) });
  process.exit(1);
});
