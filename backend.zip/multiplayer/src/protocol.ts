/** Wire protocol: JSON text frames, every message has a `type` (see README.md). */
import type { PlaceSourceInfo } from './places.js';

export type View = 'lobby' | 'game' | 'results';
export type Phase = 'waiting' | 'playing' | 'finished';
export type GameStatus = 'playing' | 'finished';

export const ERROR_CODES = [
  'hello.required',
  'hello.duplicate',
  'auth.invalid_token',
  'nickname.invalid',
  'lobby.not_found',
  'lobby.full',
  'lobby.not_in_lobby',
  'lobby.not_host',
  'lobby.not_enough_players',
  'lobby.in_game',
  'settings.invalid',
  'game.not_playing',
  'game.no_places',
  'guess.invalid',
  'guess.wrong_index',
  'guess.outside_region',
  'resume.invalid',
  'message.invalid',
  'rate_limited',
  'server.error',
] as const;
export type ErrorCode = (typeof ERROR_CODES)[number];

export const CLIENT_MESSAGE_TYPES = [
  'hello',
  'createLobby',
  'joinLobby',
  'leaveLobby',
  'updateSettings',
  'startGame',
  'guess',
  'returnToLobby',
  'ping',
] as const;
export type ClientMessageType = (typeof CLIENT_MESSAGE_TYPES)[number];

/** A parsed client message. Fields are validated by the handler of each type. */
export interface ClientMessage {
  type: ClientMessageType;
  [field: string]: unknown;
}

export interface LatLon {
  latitude: number;
  longitude: number;
}

export interface LobbySettings {
  maxPlayers: number;
  placeCount: number;
  durationSeconds: number;
}

export interface PlaceReveal {
  index: number;
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  category: string;
  description: string;
  contentSourceUrl: string | null;
  source: PlaceSourceInfo;
}

export interface PlayerView {
  id: string;
  nickname: string;
  isGuest: boolean;
  isHost: boolean;
  connected: boolean;
  view: View;
  guessedCount: number;
}

export interface RoundView {
  index: number;
  name: string;
  guess: LatLon | null;
  distanceMeters: number | null;
  place: PlaceReveal | null;
}

export interface SelfGameView {
  currentIndex: number;
  currentPlaceName: string | null;
  rounds: RoundView[];
}

export interface LeaderboardRow {
  rank: number;
  playerId: string;
  nickname: string;
  averageDistanceMeters: number;
  guessedCount: number;
  totalDistanceMeters: number;
  finishedAt: number | null;
}

export interface GuessSummary {
  latitude: number;
  longitude: number;
  distanceMeters: number;
}

export interface GameView {
  status: GameStatus;
  startedAt: number;
  endsAt: number;
  placeCount: number;
  participantIds: string[];
  self: SelfGameView | null;
  leaderboard: LeaderboardRow[] | null;
  places: PlaceReveal[] | null;
  guesses: Record<string, (GuessSummary | null)[]> | null;
}

export interface LobbyView {
  code: string;
  hostId: string;
  selfId: string;
  phase: Phase;
  settings: LobbySettings;
  players: PlayerView[];
  game: GameView | null;
}

export interface Limits {
  maxPlayers: number;
  minPlayers: number;
  maxPlaceCount: number;
  minDurationSeconds: number;
  maxDurationSeconds: number;
  penaltyDistanceMeters: number;
}

export type ServerMessage =
  | {
      type: 'welcome';
      playerId: string;
      resumeToken: string;
      nickname: string;
      isGuest: boolean;
      limits: Limits;
      defaults: LobbySettings;
    }
  | { type: 'state'; serverNow: number; lobby: LobbyView | null }
  | { type: 'guessResult'; index: number; distanceMeters: number; guess: LatLon; place: PlaceReveal }
  | { type: 'error'; code: ErrorCode; message?: string }
  | { type: 'pong' };

export type ParseResult = { ok: true; message: ClientMessage } | { ok: false; reason: string };

/** Parses one text frame. Anything that is not a known message type is rejected. */
export function parseClientMessage(text: string): ParseResult {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return { ok: false, reason: 'Invalid JSON' };
  }
  if (typeof data !== 'object' || data === null || Array.isArray(data)) {
    return { ok: false, reason: 'A message must be a JSON object' };
  }
  const type = (data as Record<string, unknown>).type;
  if (typeof type !== 'string' || !(CLIENT_MESSAGE_TYPES as readonly string[]).includes(type)) {
    return { ok: false, reason: 'Unknown message type' };
  }
  return { ok: true, message: data as ClientMessage };
}
