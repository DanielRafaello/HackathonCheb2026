<?php

declare(strict_types=1);

use App\Middleware\CorsMiddleware;
use App\Repositories\Contracts\LocationRepositoryInterface;
use App\Repositories\Contracts\ProfileRepositoryInterface;
use App\Repositories\Contracts\RefreshTokenRepositoryInterface;
use App\Repositories\Contracts\RoundRepositoryInterface;
use App\Repositories\Contracts\WaferWalletInterface;
use App\Repositories\Contracts\StatisticsRepositoryInterface;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Repositories\LocationRepository;
use App\Repositories\ProfileRepository;
use App\Repositories\RefreshTokenRepository;
use App\Repositories\RoundRepository;
use App\Repositories\StatisticsRepository;
use App\Repositories\UserRepository;
use App\Services\Auth\AuthService;
use App\Services\Contracts\Auth\AuthServiceInterface;
use App\Services\Contracts\Location\LocationServiceInterface;
use App\Services\Contracts\Profile\ProfileServiceInterface;
use App\Services\Contracts\Round\RoundServiceInterface;
use App\Services\Contracts\Statistics\StatisticsServiceInterface;
use App\Services\JWT\JwtService;
use App\Services\Location\LocationService;
use App\Services\Profile\ProfileService;
use App\Services\Round\RoundService;
use App\Services\Statistics\StatisticsService;
use App\Settings\Settings;
use App\Settings\SettingsFactory;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\DriverManager;
use Monolog\Formatter\JsonFormatter;
use Monolog\Handler\RotatingFileHandler;
use Monolog\Handler\StreamHandler;
use Monolog\Handler\WhatFailureGroupHandler;
use Monolog\Level;
use Monolog\Logger;
use Psr\Container\ContainerInterface;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Log\LoggerInterface;
use Slim\Factory\AppFactory;

/*
 * Where to put a class to the container?
 * - when binding an Interface to a specific Class
 * - when class in constructors need primitive values (example: string from env)
 * - we need specific config or calling method after calling constructor
 */


return [
    ResponseFactoryInterface::class => function (): ResponseFactoryInterface {
        return AppFactory::determineResponseFactory();
    },


    Settings::class => function (): Settings {
        return (new SettingsFactory())();
    },

    Connection::class => function (ContainerInterface $c): Connection {
        /** @var Settings $s */
        $s = $c->get(Settings::class);

        return DriverManager::getConnection([
            'driver'   => $s->get('db.driver'),
            'host'     => $s->get('db.host'),
            'port'     => $s->get('db.port'),
            'dbname'   => $s->get('db.dbname'),
            'user'     => $s->get('db.user'),
            'password' => $s->get('db.password'),
        ]);
    },
    // ─── Logging (Monolog, PSR-3) ────────────────────────────────────
    // php://stderr — under Apache+mod_php that lands in the vhost's ErrorLog,
    // which the php:apache image symlinks to /dev/stderr, so the records show
    // up in `docker compose logs backend` as one JSON object per line.
    LoggerInterface::class => function (): LoggerInterface {
        $logger = new Logger('app');

        // Handler for writing to stderr
        $handler = new StreamHandler('php://stderr', Level::Debug);

        // launch JSON formatting
        $formatter = new JsonFormatter();
        $formatter->includeStacktraces(); // logged exceptions keep their trace
        $handler->setFormatter($formatter);

        $logger->pushHandler($handler);

        // Same records into var/log/app-YYYY-MM-DD.log, one file per day, 14 days kept.
        // Development: the project folder on the host. Production: the backend_logs volume.
        $fileHandler = new RotatingFileHandler(__DIR__ . '/../var/log/app.log', 14, Level::Debug);
        $fileHandler->setFormatter($formatter);

        // A log file that cannot be written must never turn an error response into a crash
        $logger->pushHandler(new WhatFailureGroupHandler([$fileHandler]));

        return $logger;
    },

    // ─── CORS (needs the primitive allowed-origin) ───────────────────
    CorsMiddleware::class => function (ContainerInterface $c): CorsMiddleware {
        /** @var Settings $s */
        $s = $c->get(Settings::class);

        return new CorsMiddleware($c->get(ResponseFactoryInterface::class), $s->get('app.frontend_url'));
    },

    // ─── JWT ────────────────────────────────────────────────────────
    JwtService::class => function (ContainerInterface $c): JwtService {
        /** @var Settings $s */
        $s = $c->get(Settings::class);

        return new JwtService($s->get('jwt.secret'), $s->get('jwt.ttl_seconds'));
    },

    AuthServiceInterface::class => function (ContainerInterface $c): AuthServiceInterface {
        /** @var Settings $s */
        $s = $c->get(Settings::class);

        return new AuthService(
            $c->get(Connection::class),
            $c->get(UserRepositoryInterface::class),
            $c->get(RefreshTokenRepositoryInterface::class),
            $c->get(JwtService::class),
            $s->get('jwt.refresh_ttl_seconds'),
        );
    },


    // ─── Repositories ─────────────────────────────────────────────
    UserRepositoryInterface::class         => \DI\autowire(UserRepository::class),
    WaferWalletInterface::class            => \DI\autowire(UserRepository::class),
    RefreshTokenRepositoryInterface::class => \DI\autowire(RefreshTokenRepository::class),
    LocationRepositoryInterface::class     => \DI\autowire(LocationRepository::class),
    RoundRepositoryInterface::class        => \DI\autowire(RoundRepository::class),
    ProfileRepositoryInterface::class      => \DI\autowire(ProfileRepository::class),
    StatisticsRepositoryInterface::class   => \DI\autowire(StatisticsRepository::class),

    // ─── Services ─────────────────────────────────────────────────
    LocationServiceInterface::class => \DI\autowire(LocationService::class),
    RoundServiceInterface::class    => \DI\autowire(RoundService::class),
    ProfileServiceInterface::class  => \DI\autowire(ProfileService::class),
    StatisticsServiceInterface::class => \DI\autowire(StatisticsService::class),



];
