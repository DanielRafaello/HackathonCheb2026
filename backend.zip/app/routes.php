<?php

declare(strict_types=1);


// ─── Routes ───────────────────────────────────────────────────
use App\Action\Admin\GetStatisticsOverviewAction;
use App\Action\Admin\GetVisitStatisticsAction;
use App\Action\Admin\ListLocationStatisticsAction;
use App\Action\Auth\LoginAction;
use App\Action\Auth\LogoutAction;
use App\Action\Auth\RefreshAction;
use App\Action\Auth\RegisterAction;
use App\Action\Location\GetLocationDescriptionAction;
use App\Action\Location\ListLocationsAction;
use App\Action\Location\MarkLocationAction;
use App\Action\Location\RateLocationAction;
use App\Action\Round\GetDailyRoundAction;
use App\Action\Round\GetRoundAction;
use App\Action\Round\SubmitGuessAction;
use App\Action\User\GetProfileAction;
use App\Action\User\MeAction;
use App\Middleware\AdminOnlyMiddleware;
use App\Middleware\JwtAuthMiddleware;
use Slim\App;
use Slim\Routing\RouteCollectorProxy;

return function (App $app): void {

    // ─── Auth ─────────────────────────────────────────────────────
    $app->post('/auth/register', RegisterAction::class);
    $app->post('/auth/login', LoginAction::class);
    $app->post('/auth/refresh', RefreshAction::class);
    $app->post('/auth/logout', LogoutAction::class);


    // JwtAuthMiddleware is added last -> runs first (outermost), so it
    $app->get('/me', MeAction::class)
        //todo
        ->add(JwtAuthMiddleware::class);

    $app->get('/me/profile', GetProfileAction::class)
        ->add(JwtAuthMiddleware::class);

    // ─── Locations ────────────────────────────────────────────────
    $app->get('/locations', ListLocationsAction::class)
        ->add(JwtAuthMiddleware::class);
    $app->post('/locations/{id:[0-9]+}/progress', MarkLocationAction::class)
        ->add(JwtAuthMiddleware::class);
    $app->get('/locations/{id:[0-9]+}/description', GetLocationDescriptionAction::class)
        ->add(JwtAuthMiddleware::class);
    $app->put('/locations/{id:[0-9]+}/rating', RateLocationAction::class)
        ->add(JwtAuthMiddleware::class);

    // ─── Rounds ───────────────────────────────────────────────────
    $app->get('/rounds/daily', GetDailyRoundAction::class)
        ->add(JwtAuthMiddleware::class);
    $app->get('/rounds/{id:[0-9]+}', GetRoundAction::class)
        ->add(JwtAuthMiddleware::class);
    $app->post('/rounds/{id:[0-9]+}/guesses', SubmitGuessAction::class)
        ->add(JwtAuthMiddleware::class);

    // ─── Admin statistics ─────────────────────────────────────────
    // Middleware added last runs first: the JWT is verified, then the admin role.
    $app->group('/admin/statistics', function (RouteCollectorProxy $group): void {
        $group->get('/overview', GetStatisticsOverviewAction::class);
        $group->get('/locations', ListLocationStatisticsAction::class);
        $group->get('/visits', GetVisitStatisticsAction::class);
    });
    //PUBLIC FOR PRESENTATION PURPOSES
    //        ->add(AdminOnlyMiddleware::class)
    //        ->add(JwtAuthMiddleware::class);
};
