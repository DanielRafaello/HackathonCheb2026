<?php

declare(strict_types=1);

namespace App\Domain;

/** The size of one bucket of a statistics time series. */
enum StatisticsGranularity: string
{
    case MONTH = 'month';
    case DAY = 'day';

    /** PHP date() format of a bucket's label, e.g. "2026-03" or "2026-03-14". */
    public function periodFormat(): string
    {
        return match ($this) {
            self::MONTH => 'Y-m',
            self::DAY => 'Y-m-d',
        };
    }

    /** The same label as a PostgreSQL to_char() pattern. */
    public function sqlPeriodFormat(): string
    {
        return match ($this) {
            self::MONTH => 'YYYY-MM',
            self::DAY => 'YYYY-MM-DD',
        };
    }

    /** DateTime::modify() step from one bucket to the next. */
    public function step(): string
    {
        return match ($this) {
            self::MONTH => '+1 month',
            self::DAY => '+1 day',
        };
    }
}
