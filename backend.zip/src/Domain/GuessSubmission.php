<?php

declare(strict_types=1);

namespace App\Domain;

final readonly class GuessSubmission
{
    public function __construct(
        public GameRound $round,
        public GuessResult $guess,
        public int $wafersEarned = 0,
    ) {
    }
}
