<?php

declare(strict_types=1);

namespace App\Domain;

/**
 * A location as seen by one user: the place itself plus that user's progress.
 * A null timestamp means "not yet"; a value says when it happened.
 * The rating is this user's own; the average and count cover every player.
 */
final readonly class UserLocation
{
    public function __construct(
        public int $id,
        public string $name,
        public float $latitude,
        public float $longitude,
        public ?string $guessedAt,
        public ?string $visitedAt,
        public ?int $rating = null,
        public ?string $ratedAt = null,
        public ?float $averageRating = null,
        public int $ratingCount = 0,
    ) {
    }

    /** @param array<string, mixed> $row */
    public static function fromRow(array $row): self
    {
        return new self(
            id:        (int) $row['id'],
            name:      $row['name'],
            latitude:  (float) $row['latitude'],
            longitude: (float) $row['longitude'],
            guessedAt: $row['guessed_at'],
            visitedAt: $row['visited_at'],
            rating:        $row['rating'] !== null ? (int) $row['rating'] : null,
            ratedAt:       $row['rated_at'],
            averageRating: $row['average_rating'] !== null ? (float) $row['average_rating'] : null,
            ratingCount:   (int) $row['rating_count'],
        );
    }

    public function isGuessed(): bool
    {
        return $this->guessedAt !== null;
    }

    public function isVisited(): bool
    {
        return $this->visitedAt !== null;
    }
}
