<?php

declare(strict_types=1);

namespace App\Domain;

/** The outcome of marking a location: its new state and the wafers it earned. */
final readonly class MarkedLocation
{
    public function __construct(
        public UserLocation $location,
        public int $wafersEarned = 0,
    ) {
    }
}
