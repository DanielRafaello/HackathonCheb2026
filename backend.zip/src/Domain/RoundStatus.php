<?php

declare(strict_types=1);

namespace App\Domain;

enum RoundStatus: string
{
    case ACTIVE = 'active';
    case GUESSED = 'guessed';
    case EXPIRED = 'expired';

    public function isComplete(): bool
    {
        return $this !== self::ACTIVE;
    }

    public function revealsTarget(): bool
    {
        return $this === self::GUESSED;
    }
}
