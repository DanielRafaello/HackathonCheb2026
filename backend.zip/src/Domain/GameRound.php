<?php

declare(strict_types=1);

namespace App\Domain;

final readonly class GameRound
{
    public const COMPASS_START_ATTEMPT = 4;

    public function __construct(
        public int $id,
        public int $userId,
        public RoundStatus $status,
        public int $attemptsUsed,
        public ?int $stars,
        public string $dailyDate,
        public ?string $completedAt,
        public RoundTarget $target,
        public ?GuessResult $lastGuess = null,
    ) {
    }

    public function compassActive(): bool
    {
        return $this->status === RoundStatus::ACTIVE
            && $this->attemptsUsed >= self::COMPASS_START_ATTEMPT;
    }

    public static function starsForHit(int $attemptNumber): int
    {
        return max(1, 6 - $attemptNumber);
    }

    /** @return list<array{position: int, type: string, text: string}> */
    public function visibleClues(): array
    {
        $clues = [
            ['position' => 1, 'type' => 'distinctive_fact', 'text' => $this->target->hint1],
            ['position' => 2, 'type' => 'category', 'text' => $this->target->category],
            ['position' => 3, 'type' => 'area_narrowing', 'text' => $this->target->hint2],
            ['position' => 4, 'type' => 'name_edges', 'text' => $this->nameEdgesClue()],
        ];

        $visibleCount = $this->status->revealsTarget()
            ? count($clues)
            : min(count($clues), $this->attemptsUsed + 1);

        return array_slice($clues, 0, $visibleCount);
    }

    private function nameEdgesClue(): string
    {
        $count = preg_match_all('/\p{L}/u', $this->target->name, $matches);
        if ($count === false || $count === 0) {
            return 'Název neobsahuje žádné písmeno.';
        }

        $letters = $matches[0];

        return sprintf(
            'Název začíná písmenem „%s“ a končí písmenem „%s“.',
            $letters[0],
            $letters[array_key_last($letters)],
        );
    }
}
