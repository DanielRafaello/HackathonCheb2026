<?php

declare(strict_types=1);

namespace App\Domain;

final readonly class RoundTarget
{
    public function __construct(
        public int $id,
        public string $name,
        public float $latitude,
        public float $longitude,
        public string $category,
        public string $description,
        public string $hint1,
        public string $hint2,
        public ?string $contentSourceUrl,
        public string $sourceTitle,
        public string $sourcePublisher,
        public string $sourcePortalUrl,
        public string $sourceLicenseCode,
        public string $sourceLicenseUrl,
        public string $sourceAttributionText,
        public ?string $sourceRetrievedAt,
        public ?string $sourceUpdatedAt,
    ) {
    }
}
