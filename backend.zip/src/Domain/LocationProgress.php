<?php

declare(strict_types=1);

namespace App\Domain;

/** What a user can achieve on a location. */
enum LocationProgress: string
{
    case GUESSED = 'guessed';
    case VISITED = 'visited';

    /** Column of user_locations that holds the time this was achieved. */
    public function column(): string
    {
        return match ($this) {
            self::GUESSED => 'guessed_at',
            self::VISITED => 'visited_at',
        };
    }
}
