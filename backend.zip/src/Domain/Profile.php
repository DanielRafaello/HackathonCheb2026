<?php

declare(strict_types=1);

namespace App\Domain;

/** A player's profile: who they are, their points, level and counts. */
final readonly class Profile
{
    public function __construct(
        public User $user,
        public int $pointsFromGuessing,
        public int $pointsFromVisits,
        public LevelProgress $level,
        public int $guessedCount,
        public int $visitedCount,
    ) {
    }

    public function points(): int
    {
        return $this->pointsFromGuessing + $this->pointsFromVisits;
    }
}
