<?php

declare(strict_types=1);

namespace App\Domain;

/** A player's level and how far they are towards the next one. */
final readonly class LevelProgress
{
    /**
     * @param int $level       current level, starting at 1
     * @param int $startsAt    total points at which the current level began
     * @param int $nextLevelAt total points at which the next level begins
     */
    public function __construct(
        public int $level,
        public int $points,
        public int $startsAt,
        public int $nextLevelAt,
    ) {
    }

    /** Points earned since the current level began. */
    public function pointsInLevel(): int
    {
        return $this->points - $this->startsAt;
    }

    /** Points still missing to reach the next level. */
    public function pointsToNextLevel(): int
    {
        return $this->nextLevelAt - $this->points;
    }
}
