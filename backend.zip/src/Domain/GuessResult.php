<?php

declare(strict_types=1);

namespace App\Domain;

final readonly class GuessResult
{
    public function __construct(
        public int $attemptNumber,
        public bool $hit,
        public int $distanceMeters,
        public ?string $direction,
    ) {
    }
}
