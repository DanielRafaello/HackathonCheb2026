<?php

declare(strict_types=1);

namespace App\Domain;

/** How one location is doing across all users. */
final readonly class LocationStatistics
{
    /**
     * @param int        $visitors      users who have visited the location
     * @param int        $guessedBy     users who have guessed the location
     * @param float|null $averageRating average rating (1–5), null when nobody rated it
     */
    public function __construct(
        public int $id,
        public string $name,
        public string $category,
        public int $visitors,
        public int $guessedBy,
        public ?float $averageRating,
        public int $ratingCount,
    ) {
    }
}
