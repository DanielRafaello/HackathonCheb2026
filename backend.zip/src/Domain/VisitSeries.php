<?php

declare(strict_types=1);

namespace App\Domain;

/**
 * Visits over one calendar year, ready for a chart: one point per month or
 * day, including the periods in which nothing happened.
 */
final readonly class VisitSeries
{
    /**
     * @param int|null $locationId the location the series is limited to, null for all locations
     * @param list<array{period: string, visits: int, visitors: int}> $points
     *        in calendar order; "visits" counts user–location pairs first visited in
     *        the period, "visitors" the distinct users among them
     */
    public function __construct(
        public int $year,
        public StatisticsGranularity $granularity,
        public ?int $locationId,
        public array $points,
    ) {
    }

    public function totalVisits(): int
    {
        return array_sum(array_column($this->points, 'visits'));
    }
}
