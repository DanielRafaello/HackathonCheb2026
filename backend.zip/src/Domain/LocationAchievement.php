<?php

declare(strict_types=1);

namespace App\Domain;

/**
 * What one user has achieved on one location — the raw facts points are
 * computed from. Points themselves are never stored.
 */
final readonly class LocationAchievement
{
    /**
     * @param int|null $guessedOnAttempt attempt (1, 2, 3, … no upper limit) of the round that hit the location;
     *                                   null when it was not guessed in a round
     */
    public function __construct(
        public int $locationId,
        public ?int $guessedOnAttempt,
        public bool $guessed,
        public bool $visited,
    ) {
    }
}
