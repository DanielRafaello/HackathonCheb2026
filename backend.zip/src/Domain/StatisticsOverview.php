<?php

declare(strict_types=1);

namespace App\Domain;

/** The headline numbers of the whole game. */
final readonly class StatisticsOverview
{
    /**
     * @param int        $usersTotal       registered accounts
     * @param int        $usersActive      accounts that have guessed or visited at least one location
     * @param int        $locationsTotal   locations in the catalog
     * @param int        $locationsVisited locations visited by at least one user
     * @param int        $visitsTotal      visits; one user visiting one location counts once
     * @param int        $guessesTotal     guessed locations; one user guessing one location counts once
     * @param int        $ratingsTotal     ratings given
     * @param float|null $averageRating    average of all ratings (1–5), null when there are none
     */
    public function __construct(
        public int $usersTotal,
        public int $usersActive,
        public int $locationsTotal,
        public int $locationsVisited,
        public int $visitsTotal,
        public int $guessesTotal,
        public int $ratingsTotal,
        public ?float $averageRating,
    ) {
    }
}
