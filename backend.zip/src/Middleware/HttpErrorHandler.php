<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Exceptions\AbstractException\AppException;
use App\Exceptions\Validation\ValidationException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\Exception\HttpException;
use Slim\Handlers\ErrorHandler;

class HttpErrorHandler extends ErrorHandler
{
    protected function respond(): ResponseInterface
    {
        $exception = $this->exception;

        $errors = $exception instanceof ValidationException ? $exception->getErrors() : null;

        $statusCode = $this->resolveStatusCode();

        $message = match (true) {
            $exception instanceof AppException,
            $exception instanceof HttpException => $exception->getMessage(),
            default                             => $this->displayErrorDetails // display error is turned on in dev mode
                ? $exception->getMessage()
                : 'Server error',
        };

        return $this->buildResponse($this->request, $statusCode, $message, $errors);
    }

    /**
     * Replaces Slim's plain-text dump with one structured record per failed
     * request. Server faults (5xx) are errors and carry the exception; client
     * faults (4xx) are expected traffic, so they are only info.
     */
    protected function writeToErrorLog(): void
    {
        $statusCode = $this->resolveStatusCode();

        $context = [
            'method' => $this->request->getMethod(),
            'path'   => $this->request->getUri()->getPath(),
            'status' => $statusCode,
        ];

        if ($statusCode >= 500) {
            $this->logger->error($this->exception->getMessage(), $context + ['exception' => $this->exception]);

            return;
        }

        $this->logger->info($this->exception->getMessage(), $context);
    }

    private function resolveStatusCode(): int
    {
        $exception = $this->exception;

        return match (true) {
            $exception instanceof AppException  => $exception->httpStatus(),
            $exception instanceof HttpException => $exception->getCode(),
            default                             => 500,
        };
    }

    /** @param array<string, string>|null $errors */
    public function buildResponse(
        ServerRequestInterface $request,
        int $statusCode,
        string $message,
        ?array $errors = null,
    ): ResponseInterface {
        $response = $this->responseFactory->createResponse($statusCode);

        $body = [
            'error'   => true,
            'status'  => $statusCode,
            'message' => $message,
        ];

        if ($errors !== null) {
            $body['errors'] = $errors;
        }

        $response->getBody()->write(json_encode($body));

        return $response->withHeader('Content-Type', 'application/json');
    }
}
