<?php

declare(strict_types=1);

namespace App\Action\Round;

use App\Responder\Round\RoundResponder;
use App\Services\Contracts\Round\RoundServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * GET /rounds/daily — today's round of the caller (created on first call).
 *
 * Auth:     JWT (user id comes from the request attribute "user_id").
 * Body:     none.
 *
 * Steps:
 *   1. RoundService::getDaily takes today's date in Europe/Prague and returns
 *      the caller's round for that date. When there is none yet, it creates
 *      one with a random location the caller has not guessed so far. Calling
 *      again the same day returns the same round, so an unfinished round can
 *      be resumed.
 *   2. The response is marked "Cache-Control: no-store", because it changes
 *      at midnight and after every guess.
 *
 * Response: 200 { "round": { "id", "status", "daily_date", "attempts_used",
 *               "attempts_remaining", "max_attempts", "compass_active", "stars",
 *               "clues", "completed_at", "last_guess" } }
 *           While the round is active, only the unlocked clues are sent
 *           (1 + attempts used, at most 4) and nothing that identifies the
 *           target. Once it is guessed, "location" (name, coordinates,
 *           description, data source) is added.
 * Errors:   409 round.no_eligible_daily_location — the caller has guessed every location.
 *           401 Missing bearer token. / Invalid or expired token.
 */
final readonly class GetDailyRoundAction
{
    public function __construct(
        private RoundServiceInterface $rounds,
        private RoundResponder $responder,
    ) {
    }

    public function __invoke(Request $request, Response $response): Response
    {
        return $this->responder->respond(
            $response,
            $this->rounds->getDaily((int) $request->getAttribute('user_id')),
        )->withHeader('Cache-Control', 'no-store');
    }
}
