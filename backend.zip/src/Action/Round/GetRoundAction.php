<?php

declare(strict_types=1);

namespace App\Action\Round;

use App\Responder\Round\RoundResponder;
use App\Services\Contracts\Round\RoundServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * GET /rounds/{id} — the current state of one round.
 *
 * Auth:     JWT (user id comes from the request attribute "user_id").
 * Path:     {id} — round id from GET /rounds/daily (digits only).
 * Body:     none.
 *
 * Steps:
 *   1. RoundService::get loads the round, but only when it belongs to the
 *      caller. The status is derived on read: guessed, expired (its day has
 *      passed), otherwise active.
 *
 * Response: 200 { "round": { ...same shape as GET /rounds/daily } }
 * Errors:   404 not.found.round — unknown id or a round of another user
 *               (not distinguished, so ids cannot be probed).
 *           401 Missing bearer token. / Invalid or expired token.
 */
final readonly class GetRoundAction
{
    public function __construct(
        private RoundServiceInterface $rounds,
        private RoundResponder $responder,
    ) {
    }

    /** @param array{id: string} $args */
    public function __invoke(Request $request, Response $response, array $args): Response
    {
        return $this->responder->respond(
            $response,
            $this->rounds->get((int) $request->getAttribute('user_id'), (int) $args['id']),
        );
    }
}
