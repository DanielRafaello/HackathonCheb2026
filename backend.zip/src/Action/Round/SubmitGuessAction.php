<?php

declare(strict_types=1);

namespace App\Action\Round;

use App\Exceptions\Validation\ValidationException;
use App\Requests\Round\SubmitGuessRequest;
use App\Responder\Round\RoundResponder;
use App\Services\Contracts\Round\RoundServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * POST /rounds/{id}/guesses — submit one guess (a pin on the map).
 *
 * Auth:     JWT (user id comes from the request attribute "user_id").
 * Path:     {id} — round id (digits only).
 * Body:     { "latitude": -90..90, "longitude": -180..180 }  (WGS 84, numbers
 *           or numeric strings)
 *
 * Steps:
 *   1. Validate the body (SubmitGuessRequest).
 *   2. RoundService::submitGuess, in one transaction with the round row locked:
 *      a. loads the caller's round and refuses it unless it is active;
 *      b. measures the distance from the pin to the target; within 3000 m
 *         it is a hit, otherwise the eight-point direction to the target
 *         (N, NE, … NW) is computed and stored;
 *      c. stores the guess and the new attempt count. A hit ends the round
 *         as guessed (stars = max(1, 6 − attempt number)); every miss leaves
 *         it active. Misses one through three unlock clues without compass
 *         data; the fourth and later misses expose distance and direction.
 *
 * Response: 200 { "guess": { "attempt_number", "hit", "distance_meters",
 *                 "direction", "compass_active" },
 *                 "round": { ...same shape as GET /rounds/daily },
 *                 "wafers_earned": 2 per star of a hit, 0 for a miss }
 *           Distance and direction are null for the first three misses;
 *           "round.location" appears only after a hit.
 * Errors:   422 Validation failed.
 *           404 not.found.round — unknown id or a round of another user.
 *           409 round.not_active — the round is already guessed or expired.
 *           401 Missing bearer token. / Invalid or expired token.
 */
final readonly class SubmitGuessAction
{
    public function __construct(
        private RoundServiceInterface $rounds,
        private RoundResponder $responder,
    ) {
    }

    /** @param array{id: string} $args */
    public function __invoke(Request $request, Response $response, array $args): Response
    {
        $form = new SubmitGuessRequest((array) $request->getParsedBody());
        if ($form->fails()) {
            throw new ValidationException($form->errors());
        }

        $data = $form->safe();
        $submission = $this->rounds->submitGuess(
            (int) $request->getAttribute('user_id'),
            (int) $args['id'],
            (float) $data['latitude'],
            (float) $data['longitude'],
        );

        return $this->responder->guess($response, $submission);
    }
}
