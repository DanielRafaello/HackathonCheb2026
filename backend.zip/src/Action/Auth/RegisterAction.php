<?php

declare(strict_types=1);

namespace App\Action\Auth;

use App\Exceptions\Validation\ValidationException;
use App\Requests\Auth\RegisterRequest;
use App\Responder\Auth\AuthResponder;
use App\Services\Contracts\Auth\AuthServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * POST /auth/register — create an account and sign it in.
 *
 * Auth:     none (public).
 * Body:     { "name", "email", "password", "password_confirm" }
 *
 * Steps:
 *   1. Validate the body (RegisterRequest): name 2–100 characters, a valid
 *      e-mail of at most 255 characters, password of at least 8 characters
 *      that equals password_confirm.
 *   2. AuthService::register refuses an e-mail that is already taken, stores
 *      the user with a bcrypt password hash and the "user" role, and issues a
 *      JWT access token plus a refresh token.
 *
 * Response: 201 { "token", "refresh_token", "user": { "id", "name", "email", "role" } }
 * Errors:   422 Validation failed (errors.email = auth.register.email_taken
 *               when the e-mail is already registered).
 */
final class RegisterAction
{
    public function __construct(
        private readonly AuthServiceInterface $authService,
        private readonly AuthResponder $responder,
    ) {
    }

    public function __invoke(Request $request, Response $response): Response
    {
        $form = new RegisterRequest((array) $request->getParsedBody());

        if ($form->fails()) {
            throw new ValidationException($form->errors());
        }

        $data   = $form->safe();
        $result = $this->authService->register(
            name:        $data['name'],
            email:       $data['email'],
            password:    $data['password'],
        );

        return $this->responder->respond($response, $result['token'], $result['refresh_token'], $result['user'], 201);
    }
}
