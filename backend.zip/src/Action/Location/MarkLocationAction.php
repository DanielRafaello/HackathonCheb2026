<?php

declare(strict_types=1);

namespace App\Action\Location;

use App\Domain\LocationProgress;
use App\Exceptions\Validation\ValidationException;
use App\Requests\Location\MarkLocationRequest;
use App\Responder\Location\LocationResponder;
use App\Services\Contracts\Location\LocationServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * POST /locations/{id}/progress — mark a location as guessed or visited.
 *
 * Auth:     JWT (user id comes from the request attribute "user_id").
 * Path:     {id} — location id (digits only; anything else is a 404 route miss).
 * Body:     { "state": "guessed" | "visited" }
 *
 * Steps:
 *   1. Validate the body (MarkLocationRequest): state is one of the two values.
 *   2. LocationService::mark checks that the location exists and stamps the
 *      chosen state with the server's current time. The first timestamp is
 *      kept, so repeating the call changes nothing; a state cannot be unset.
 *      The two states are independent of each other.
 *
 *   3. The first visit of a location adds wafers to the user's balance.
 *
 * Response: 200 { "location": { ...same shape as one item of GET /locations },
 *                 "wafers_earned": 50 on the first visit, otherwise 0 }
 * Errors:   422 Validation failed.
 *           404 not.found.location.
 *           401 Missing bearer token. / Invalid or expired token.
 */
final class MarkLocationAction
{
    public function __construct(
        private readonly LocationServiceInterface $locationService,
        private readonly LocationResponder $responder,
    ) {
    }

    /** @param array{id: string} $args */
    public function __invoke(Request $request, Response $response, array $args): Response
    {
        $form = new MarkLocationRequest((array) $request->getParsedBody());

        if ($form->fails()) {
            throw new ValidationException($form->errors());
        }

        $marked = $this->locationService->mark(
            (int) $request->getAttribute('user_id'),
            (int) $args['id'],
            LocationProgress::from($form->safe()['state']),
        );

        return $this->responder->respond($response, $marked->location, $marked->wafersEarned);
    }
}
