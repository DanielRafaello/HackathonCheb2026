<?php

declare(strict_types=1);

namespace App\Action\Location;

use App\Exceptions\Validation\ValidationException;
use App\Requests\Location\RateLocationRequest;
use App\Responder\Location\LocationResponder;
use App\Services\Contracts\Location\LocationServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * PUT /locations/{id}/rating — rate a visited location.
 *
 * Auth:     JWT (user id comes from the request attribute "user_id").
 * Path:     {id} — location id (digits only).
 * Body:     { "rating": 1 | 2 | 3 | 4 | 5 }  (whole stars only, 4.5 is rejected)
 *
 * Steps:
 *   1. Validate the body (RateLocationRequest).
 *   2. LocationService::rate checks that the location exists and that the
 *      caller has visited it, then sets the rating or replaces the caller's
 *      earlier one (hence PUT: repeating the call gives the same result).
 *
 * Response: 200 { "location": { ...same shape as one item of GET /locations,
 *               with the caller's "rating"/"rated_at" and the location's
 *               "average_rating"/"rating_count" } }
 * Errors:   422 Validation failed.
 *           422 location.not_visited — only a visited location can be rated.
 *           404 not.found.location.
 *           401 Missing bearer token. / Invalid or expired token.
 */
final class RateLocationAction
{
    public function __construct(
        private readonly LocationServiceInterface $locationService,
        private readonly LocationResponder $responder,
    ) {
    }

    /** @param array{id: string} $args */
    public function __invoke(Request $request, Response $response, array $args): Response
    {
        $form = new RateLocationRequest((array) $request->getParsedBody());

        if ($form->fails()) {
            throw new ValidationException($form->errors());
        }

        $location = $this->locationService->rate(
            (int) $request->getAttribute('user_id'),
            (int) $args['id'],
            (int) $form->safe()['rating'],
        );

        return $this->responder->respond($response, $location);
    }
}
