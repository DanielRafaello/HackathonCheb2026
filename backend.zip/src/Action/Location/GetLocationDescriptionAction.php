<?php

declare(strict_types=1);

namespace App\Action\Location;

use App\Responder\Location\LocationResponder;
use App\Services\Contracts\Location\LocationServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * GET /locations/{id}/description — the texts of a location's card.
 *
 * Auth:     JWT (user id comes from the request attribute "user_id").
 * Path:     {id} — location id (digits only).
 *
 * Steps:
 *   1. LocationService::description checks that the location exists and
 *      that the caller has guessed or visited it. A location in the fog
 *      keeps its texts hidden, so it never spoils a future round.
 *   2. The card has the same shape as "round.location" after a hit.
 *
 * Response: 200 { "location": { "id", "name", "latitude", "longitude",
 *                 "category", "description", "content_source_url",
 *                 "source": { "title", "publisher", "portal_url",
 *                 "license_code", "license_url", "attribution_text",
 *                 "retrieved_at", "source_updated_at" } } }
 * Errors:   403 location.in_fog — neither guessed nor visited by the caller.
 *           404 not.found.location.
 *           401 Missing bearer token. / Invalid or expired token.
 */
final readonly class GetLocationDescriptionAction
{
    public function __construct(
        private LocationServiceInterface $locationService,
        private LocationResponder $responder,
    ) {
    }

    /** @param array{id: string} $args */
    public function __invoke(Request $request, Response $response, array $args): Response
    {
        $card = $this->locationService->description(
            (int) $request->getAttribute('user_id'),
            (int) $args['id'],
        );

        return $this->responder->card($response, $card);
    }
}
