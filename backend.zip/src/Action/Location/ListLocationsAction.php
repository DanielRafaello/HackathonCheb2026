<?php

declare(strict_types=1);

namespace App\Action\Location;

use App\Responder\Location\LocationListResponder;
use App\Services\Contracts\Location\LocationServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * GET /locations — the whole location catalog with the caller's progress.
 *
 * Auth:     JWT (user id comes from the request attribute "user_id").
 * Body:     none.
 *
 * Steps:
 *   1. LocationService::listForUser returns every location, ordered by id,
 *      joined with the caller's guessed/visited timestamps and rating.
 *      A location the caller has no record for is returned as not guessed
 *      and not visited. The list is not paginated.
 *
 * Response: 200 { "locations": [ { "id", "name", "latitude", "longitude",
 *               "guessed", "guessed_at", "visited", "visited_at",
 *               "rating", "rated_at", "average_rating", "rating_count" } ] }
 * Errors:   401 Missing bearer token. / Invalid or expired token.
 */
final class ListLocationsAction
{
    public function __construct(
        private readonly LocationServiceInterface $locationService,
        private readonly LocationListResponder $responder,
    ) {
    }

    public function __invoke(Request $request, Response $response): Response
    {
        $locations = $this->locationService->listForUser((int) $request->getAttribute('user_id'));

        return $this->responder->respond($response, $locations);
    }
}
