<?php

declare(strict_types=1);

namespace App\Action\User;

use App\Responder\User\ProfileResponder;
use App\Services\Contracts\Profile\ProfileServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * GET /me/profile — the caller's profile with points and level.
 *
 * Auth:     JWT (user id comes from the request attribute "user_id").
 * Body:     none.
 *
 * Steps:
 *   1. ProfileService::forUser loads the account and everything the caller
 *      has guessed or visited, and turns it into points with the rules in
 *      Services\Profile\Scoring: a round hit earns 200/150/125/110/100 points
 *      for attempt 1–5 and 50 for any later attempt, a visit earns 400.
 *      Points are computed on every call, never stored. The level follows
 *      from the total: each level needs 250 points more than the previous one.
 *
 * Response: 200 { "profile": { "id", "name", "email", "created_at",
 *               "points": { "total", "guessing", "visits" },
 *               "level": { "number", "starts_at", "next_level_at",
 *                          "points_in_level", "points_to_next_level" },
 *               "locations": { "guessed", "visited" } } }
 * Errors:   401 Missing bearer token. / Invalid or expired token.
 *           404 not.found.user — the account was deleted after the token was issued.
 */
final class GetProfileAction
{
    public function __construct(
        private readonly ProfileServiceInterface $profileService,
        private readonly ProfileResponder $responder,
    ) {
    }

    public function __invoke(Request $request, Response $response): Response
    {
        $profile = $this->profileService->forUser((int) $request->getAttribute('user_id'));

        return $this->responder->respond($response, $profile);
    }
}
