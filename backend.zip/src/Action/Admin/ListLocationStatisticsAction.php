<?php

declare(strict_types=1);

namespace App\Action\Admin;

use App\Responder\Admin\StatisticsResponder;
use App\Services\Contracts\Statistics\StatisticsServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * GET /admin/statistics/locations — how each location is doing.
 *
 * Auth:     JWT of a user with the "admin" role (AdminOnlyMiddleware).
 * Body:     none.
 *
 * Steps:
 *   1. StatisticsService::locations returns every location of the catalog
 *      with the number of users who visited it, the number of users who
 *      guessed it, and its rating. Most visited first, then by name.
 *      Locations nobody has touched are included with zeros.
 *
 * Response: 200 { "locations": [ { "id", "name", "category", "visitors",
 *               "guessed_by", "average_rating", "rating_count" } ] }
 *           "average_rating" (1–5, one decimal) is null when nobody rated it.
 * Errors:   401 Missing bearer token. / Invalid or expired token.
 *           403 auth.forbidden.admin_only — the caller is not an administrator.
 */
final class ListLocationStatisticsAction
{
    public function __construct(
        private readonly StatisticsServiceInterface $statistics,
        private readonly StatisticsResponder $responder,
    ) {
    }

    public function __invoke(Request $request, Response $response): Response
    {
        return $this->responder->locations($response, $this->statistics->locations());
    }
}
