<?php

declare(strict_types=1);

namespace App\Action\Admin;

use App\Domain\StatisticsGranularity;
use App\Exceptions\Validation\ValidationException;
use App\Requests\Admin\VisitStatisticsRequest;
use App\Responder\Admin\StatisticsResponder;
use App\Services\Contracts\Statistics\StatisticsServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * GET /admin/statistics/visits — visits over one year, as data for a chart.
 *
 * Auth:     JWT of a user with the "admin" role (AdminOnlyMiddleware).
 * Query:    year         optional, 2000–2100, default: the current year
 *           granularity  optional, "month" (default) or "day"
 *           location_id  optional, limit the series to one location
 *
 * Steps:
 *   1. Validate the query string (VisitStatisticsRequest).
 *   2. StatisticsService::visits counts the visits first made in each month
 *      (or day) of the year, in Europe/Prague time, and fills the periods
 *      without visits with zeros — so the series always has 12 points, or
 *      365/366 for days, in calendar order.
 *
 * Response: 200 { "visits": { "year", "granularity", "location_id", "total",
 *               "series": [ { "period", "visits", "visitors" } ] } }
 *           "period" is "2026-03" or "2026-03-14". "visits" counts user–location
 *           pairs, "visitors" the distinct users among them.
 * Errors:   422 Validation failed.
 *           404 not.found.location — location_id does not exist.
 *           401 Missing bearer token. / Invalid or expired token.
 *           403 auth.forbidden.admin_only — the caller is not an administrator.
 */
final class GetVisitStatisticsAction
{
    public function __construct(
        private readonly StatisticsServiceInterface $statistics,
        private readonly StatisticsResponder $responder,
    ) {
    }

    public function __invoke(Request $request, Response $response): Response
    {
        $form = new VisitStatisticsRequest($request->getQueryParams());

        if ($form->fails()) {
            throw new ValidationException($form->errors());
        }

        $query = $form->safe();
        $given = static fn (string $key): bool => trim((string) ($query[$key] ?? '')) !== '';

        $series = $this->statistics->visits(
            $given('year') ? (int) $query['year'] : null,
            $given('granularity') ? StatisticsGranularity::from($query['granularity']) : StatisticsGranularity::MONTH,
            $given('location_id') ? (int) $query['location_id'] : null,
        );

        return $this->responder->visits($response, $series);
    }
}
