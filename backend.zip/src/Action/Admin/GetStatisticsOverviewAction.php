<?php

declare(strict_types=1);

namespace App\Action\Admin;

use App\Responder\Admin\StatisticsResponder;
use App\Services\Contracts\Statistics\StatisticsServiceInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * GET /admin/statistics/overview — the headline numbers of the whole game.
 *
 * Auth:     JWT of a user with the "admin" role (AdminOnlyMiddleware).
 * Body:     none.
 *
 * Steps:
 *   1. StatisticsService::overview counts users, locations, visits, guessed
 *      locations and ratings across all users. One user visiting (or
 *      guessing) one location counts once.
 *
 * Response: 200 { "overview": {
 *               "users":     { "total", "active" },
 *               "locations": { "total", "visited" },
 *               "visits":    { "total" },
 *               "guesses":   { "total" },
 *               "ratings":   { "total", "average" } } }
 *           "users.active" have guessed or visited at least one location.
 *           "ratings.average" is null while nobody has rated anything.
 * Errors:   401 Missing bearer token. / Invalid or expired token.
 *           403 auth.forbidden.admin_only — the caller is not an administrator.
 */
final class GetStatisticsOverviewAction
{
    public function __construct(
        private readonly StatisticsServiceInterface $statistics,
        private readonly StatisticsResponder $responder,
    ) {
    }

    public function __invoke(Request $request, Response $response): Response
    {
        return $this->responder->overview($response, $this->statistics->overview());
    }
}
