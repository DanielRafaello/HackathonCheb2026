<?php

declare(strict_types=1);

namespace App\Responder\Admin;

use App\Domain\LocationStatistics;
use App\Domain\StatisticsOverview;
use App\Domain\VisitSeries;
use App\Responder\JsonResponder;
use Psr\Http\Message\ResponseInterface as Response;

final class StatisticsResponder extends JsonResponder
{
    public function overview(Response $response, StatisticsOverview $overview): Response
    {
        return $this->json($response, [
            'overview' => [
                'users' => [
                    'total'  => $overview->usersTotal,
                    'active' => $overview->usersActive,
                ],
                'locations' => [
                    'total'   => $overview->locationsTotal,
                    'visited' => $overview->locationsVisited,
                ],
                'visits'  => ['total' => $overview->visitsTotal],
                'guesses' => ['total' => $overview->guessesTotal],
                'ratings' => [
                    'total'   => $overview->ratingsTotal,
                    'average' => $overview->averageRating,
                ],
            ],
        ]);
    }

    /** @param list<LocationStatistics> $locations */
    public function locations(Response $response, array $locations): Response
    {
        return $this->json($response, [
            'locations' => array_map(
                static fn (LocationStatistics $location): array => [
                    'id'             => $location->id,
                    'name'           => $location->name,
                    'category'       => $location->category,
                    'visitors'       => $location->visitors,
                    'guessed_by'     => $location->guessedBy,
                    'average_rating' => $location->averageRating,
                    'rating_count'   => $location->ratingCount,
                ],
                $locations,
            ),
        ]);
    }

    public function visits(Response $response, VisitSeries $series): Response
    {
        return $this->json($response, [
            'visits' => [
                'year'        => $series->year,
                'granularity' => $series->granularity->value,
                'location_id' => $series->locationId,
                'total'       => $series->totalVisits(),
                'series'      => $series->points,
            ],
        ]);
    }
}
