<?php

declare(strict_types=1);

namespace App\Responder\User;

use App\Domain\Profile;
use App\Responder\JsonResponder;
use Psr\Http\Message\ResponseInterface as Response;

final class ProfileResponder extends JsonResponder
{
    public function respond(Response $response, Profile $profile): Response
    {
        return $this->json($response, [
            'profile' => [
                'id'         => $profile->user->id,
                'name'       => $profile->user->name,
                'email'      => $profile->user->email,
                'created_at' => $profile->user->createdAt,
                'wafers'     => $profile->user->wafers,
                'points'     => [
                    'total'    => $profile->points(),
                    'guessing' => $profile->pointsFromGuessing,
                    'visits'   => $profile->pointsFromVisits,
                ],
                'level' => [
                    'number'               => $profile->level->level,
                    'starts_at'            => $profile->level->startsAt,
                    'next_level_at'        => $profile->level->nextLevelAt,
                    'points_in_level'      => $profile->level->pointsInLevel(),
                    'points_to_next_level' => $profile->level->pointsToNextLevel(),
                ],
                'locations' => [
                    'guessed' => $profile->guessedCount,
                    'visited' => $profile->visitedCount,
                ],
            ],
        ]);
    }
}
