<?php

declare(strict_types=1);

namespace App\Responder\Round;

use App\Domain\GameRound;
use App\Domain\GuessResult;
use App\Domain\GuessSubmission;
use App\Domain\RoundTarget;
use App\Responder\JsonResponder;
use Psr\Http\Message\ResponseInterface as Response;

final class RoundResponder extends JsonResponder
{
    public function respond(Response $response, GameRound $round, int $status = 200): Response
    {
        return $this->json($response, ['round' => self::present($round)], $status);
    }

    public function guess(Response $response, GuessSubmission $submission): Response
    {
        return $this->json($response, [
            'guess' => self::presentGuess($submission->guess),
            'round' => self::present($submission->round),
            'wafers_earned' => $submission->wafersEarned,
        ]);
    }

    /** @return array<string, mixed> */
    public static function present(GameRound $round): array
    {
        $data = [
            'id' => $round->id,
            'status' => $round->status->value,
            'daily_date' => $round->dailyDate,
            'attempts_used' => $round->attemptsUsed,
            'attempts_remaining' => null,
            'max_attempts' => null,
            'compass_active' => $round->compassActive(),
            'stars' => $round->stars,
            'clues' => $round->visibleClues(),
            'completed_at' => $round->completedAt,
            'last_guess' => $round->lastGuess === null ? null : self::presentGuess($round->lastGuess),
        ];

        if ($round->status->revealsTarget()) {
            $data['location'] = self::presentLocation($round->target);
        }

        return $data;
    }

    /**
     * The card of a location: the place, its texts and its primary source.
     * Shared with GET /locations/{id}/description.
     *
     * @return array<string, mixed>
     */
    public static function presentLocation(RoundTarget $target): array
    {
        return [
            'id' => $target->id,
            'name' => $target->name,
            'latitude' => $target->latitude,
            'longitude' => $target->longitude,
            'category' => $target->category,
            'description' => $target->description,
            'content_source_url' => $target->contentSourceUrl,
            'source' => [
                'title' => $target->sourceTitle,
                'publisher' => $target->sourcePublisher,
                'portal_url' => $target->sourcePortalUrl,
                'license_code' => $target->sourceLicenseCode,
                'license_url' => $target->sourceLicenseUrl,
                'attribution_text' => $target->sourceAttributionText,
                'retrieved_at' => $target->sourceRetrievedAt,
                'source_updated_at' => $target->sourceUpdatedAt,
            ],
        ];
    }

    /** @return array<string, mixed> */
    private static function presentGuess(GuessResult $guess): array
    {
        $compassActive = !$guess->hit
            && $guess->attemptNumber >= GameRound::COMPASS_START_ATTEMPT;

        return [
            'attempt_number' => $guess->attemptNumber,
            'hit' => $guess->hit,
            'distance_meters' => $guess->hit || $compassActive ? $guess->distanceMeters : null,
            'direction' => $compassActive ? $guess->direction : null,
            'compass_active' => $compassActive,
        ];
    }
}
