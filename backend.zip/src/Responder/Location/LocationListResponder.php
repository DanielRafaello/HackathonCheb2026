<?php

declare(strict_types=1);

namespace App\Responder\Location;

use App\Domain\UserLocation;
use App\Responder\JsonResponder;
use Psr\Http\Message\ResponseInterface as Response;

final class LocationListResponder extends JsonResponder
{
    /** @param list<UserLocation> $locations */
    public function respond(Response $response, array $locations): Response
    {
        return $this->json($response, [
            'locations' => array_map(LocationResponder::present(...), $locations),
        ]);
    }
}
