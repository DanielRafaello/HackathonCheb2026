<?php

declare(strict_types=1);

namespace App\Responder\Location;

use App\Domain\RoundTarget;
use App\Domain\UserLocation;
use App\Responder\JsonResponder;
use App\Responder\Round\RoundResponder;
use Psr\Http\Message\ResponseInterface as Response;

final class LocationResponder extends JsonResponder
{
    /** With $wafersEarned the body also says how many wafers the request earned. */
    public function respond(Response $response, UserLocation $location, ?int $wafersEarned = null): Response
    {
        $body = ['location' => self::present($location)];
        if ($wafersEarned !== null) {
            $body['wafers_earned'] = $wafersEarned;
        }

        return $this->json($response, $body);
    }

    /** The card of a location with its texts (GET /locations/{id}/description). */
    public function card(Response $response, RoundTarget $card): Response
    {
        return $this->json($response, ['location' => RoundResponder::presentLocation($card)]);
    }

    /**
     * The one JSON shape of a location, shared with the list responder.
     *
     * @return array<string, mixed>
     */
    public static function present(UserLocation $location): array
    {
        return [
            'id'             => $location->id,
            'name'           => $location->name,
            'latitude'       => $location->latitude,
            'longitude'      => $location->longitude,
            'guessed'        => $location->isGuessed(),
            'guessed_at'     => $location->guessedAt,
            'visited'        => $location->isVisited(),
            'visited_at'     => $location->visitedAt,
            'rating'         => $location->rating,
            'rated_at'       => $location->ratedAt,
            'average_rating' => $location->averageRating,
            'rating_count'   => $location->ratingCount,
        ];
    }
}
