<?php

declare(strict_types=1);

namespace App\Services\Profile;

use App\Domain\Profile;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Repositories\Contracts\ProfileRepositoryInterface;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Services\Contracts\Profile\ProfileServiceInterface;

final readonly class ProfileService implements ProfileServiceInterface
{
    public function __construct(
        private UserRepositoryInterface $users,
        private ProfileRepositoryInterface $profiles,
        private Scoring $scoring,
    ) {
    }

    public function forUser(int $userId): Profile
    {
        $user = $this->users->findById($userId) ?? throw new NotFoundException('not.found.user');

        $pointsFromGuessing = 0;
        $pointsFromVisits = 0;
        $guessedCount = 0;
        $visitedCount = 0;

        foreach ($this->profiles->findAchievementsForUser($userId) as $achievement) {
            $pointsFromGuessing += $this->scoring->pointsForGuess($achievement->guessedOnAttempt);
            $pointsFromVisits += $this->scoring->pointsForVisit($achievement->visited);
            $guessedCount += $achievement->guessed ? 1 : 0;
            $visitedCount += $achievement->visited ? 1 : 0;
        }

        return new Profile(
            user: $user,
            pointsFromGuessing: $pointsFromGuessing,
            pointsFromVisits: $pointsFromVisits,
            level: $this->scoring->levelFor($pointsFromGuessing + $pointsFromVisits),
            guessedCount: $guessedCount,
            visitedCount: $visitedCount,
        );
    }
}
