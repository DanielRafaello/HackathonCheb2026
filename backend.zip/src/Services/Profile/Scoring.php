<?php

declare(strict_types=1);

namespace App\Services\Profile;

use App\Domain\LevelProgress;
use App\Domain\LocationAchievement;

/**
 * The scoring rules of the game in one place. Change a number here and every
 * profile follows, because points are computed from achievements on read.
 */
final class Scoring
{
    /**
     * Points for guessing a location, by the attempt that hit it.
     * Any hit is worth 100; fewer attempts earn a growing bonus.
     */
    public const GUESS_POINTS = [
        1 => 200,
        2 => 150,
        3 => 125,
        4 => 110,
        5 => 100,
    ];

    /**
     * Points for a hit on the sixth or any later attempt, when the player
     * keeps guessing with the compass. Finishing a round always earns something.
     */
    public const LATE_GUESS_POINTS = 50;

    /**
     * Points for visiting a location in person — worth far more than any
     * guess, because getting people to the places is the point of the game.
     */
    public const VISIT_POINTS = 400;

    /**
     * Wafers (oplatky, the game's currency) for each star of a round hit:
     * 10 for a first-attempt hit, 2 for a hit with the compass. Every hit
     * earns them, also a later hit of a place guessed before.
     * The migration Version20261010000500 credits existing hits with it.
     */
    public const WAFERS_PER_STAR = 2;

    /**
     * Wafers for visiting a location in person, once per location — more
     * than any hit, like the points.
     */
    public const VISIT_WAFERS = 50;

    /**
     * Each level needs this many points more than the previous one:
     * level 2 at 250, level 3 at 750, level 4 at 1500, level 5 at 2500, …
     */
    public const LEVEL_STEP = 250;

    /**
     * Points for a hit on the given attempt: the bonus table for attempts 1–5,
     * the minimum for any later attempt, 0 for anything that is not a round hit.
     */
    public function pointsForGuess(?int $attempt): int
    {
        if ($attempt === null || $attempt < 1) {
            return 0;
        }

        return self::GUESS_POINTS[$attempt] ?? self::LATE_GUESS_POINTS;
    }

    public function pointsForVisit(bool $visited): int
    {
        return $visited ? self::VISIT_POINTS : 0;
    }

    /** Wafers for a round hit that earned the given stars. */
    public function wafersForHit(int $stars): int
    {
        return self::WAFERS_PER_STAR * max(0, $stars);
    }

    /** Wafers for the first visit of a location. */
    public function wafersForVisit(): int
    {
        return self::VISIT_WAFERS;
    }

    /** Guess points plus visit points of one location. */
    public function pointsFor(LocationAchievement $achievement): int
    {
        return $this->pointsForGuess($achievement->guessedOnAttempt)
            + $this->pointsForVisit($achievement->visited);
    }

    /** Total points at which the given level (1, 2, 3, …) begins. */
    public function levelStartsAt(int $level): int
    {
        return intdiv(self::LEVEL_STEP * $level * ($level - 1), 2);
    }

    public function levelFor(int $points): LevelProgress
    {
        $level = 1;
        while ($this->levelStartsAt($level + 1) <= $points) {
            $level++;
        }

        return new LevelProgress(
            level: $level,
            points: $points,
            startsAt: $this->levelStartsAt($level),
            nextLevelAt: $this->levelStartsAt($level + 1),
        );
    }
}
