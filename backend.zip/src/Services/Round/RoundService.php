<?php

declare(strict_types=1);

namespace App\Services\Round;

use App\Domain\GameRound;
use App\Domain\GuessResult;
use App\Domain\GuessSubmission;
use App\Domain\RoundStatus;
use App\Exceptions\generalExceptions\ConflictException;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Repositories\Contracts\RoundRepositoryInterface;
use App\Repositories\Contracts\WaferWalletInterface;
use App\Services\Contracts\Round\RoundServiceInterface;
use App\Services\Profile\Scoring;

final readonly class RoundService implements RoundServiceInterface
{
    private const HIT_RADIUS_METERS = 3000;

    public function __construct(
        private RoundRepositoryInterface $rounds,
        private GeoCalculator $geo,
        private WaferWalletInterface $wallet,
        private Scoring $scoring,
    ) {
    }

    public function getDaily(int $userId): GameRound
    {
        return $this->rounds->getOrCreateDailyForUser($userId, $this->currentPragueDate())
            ?? throw new ConflictException('round.no_eligible_daily_location');
    }

    public function get(int $userId, int $roundId): GameRound
    {
        return $this->rounds->findForUser($userId, $roundId)
            ?? throw new NotFoundException('not.found.round');
    }

    public function submitGuess(int $userId, int $roundId, float $latitude, float $longitude): GuessSubmission
    {
        return $this->rounds->transactional(function () use ($userId, $roundId, $latitude, $longitude): GuessSubmission {
            $round = $this->rounds->findForUser($userId, $roundId, true)
                ?? throw new NotFoundException('not.found.round');

            if ($round->status !== RoundStatus::ACTIVE) {
                throw new ConflictException('round.not_active');
            }

            $attemptNumber = $round->attemptsUsed + 1;
            $distanceMeters = $this->geo->distanceMeters(
                $latitude,
                $longitude,
                $round->target->latitude,
                $round->target->longitude,
            );
            $hit = $distanceMeters <= self::HIT_RADIUS_METERS;
            $guess = new GuessResult(
                attemptNumber: $attemptNumber,
                hit: $hit,
                distanceMeters: $distanceMeters,
                direction: $hit ? null : $this->geo->direction(
                    $latitude,
                    $longitude,
                    $round->target->latitude,
                    $round->target->longitude,
                ),
            );

            $status = $hit ? RoundStatus::GUESSED : RoundStatus::ACTIVE;
            $this->rounds->addGuess($roundId, $latitude, $longitude, $guess);
            $this->rounds->updateState($roundId, $attemptNumber, $status);

            $updatedRound = $this->rounds->findForUser($userId, $roundId)
                ?? throw new NotFoundException('not.found.round');

            // The round row is locked and only an active round takes a guess,
            // so a round pays out once.
            $wafersEarned = $hit ? $this->scoring->wafersForHit(GameRound::starsForHit($attemptNumber)) : 0;
            $this->wallet->addWafers($userId, $wafersEarned);

            return new GuessSubmission($updatedRound, $guess, $wafersEarned);
        });
    }

    private function currentPragueDate(): string
    {
        return (new \DateTimeImmutable('now', new \DateTimeZone('Europe/Prague')))->format('Y-m-d');
    }
}
