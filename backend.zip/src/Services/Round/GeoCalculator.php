<?php

declare(strict_types=1);

namespace App\Services\Round;

final class GeoCalculator
{
    private const EARTH_RADIUS_METERS = 6371008.8;

    public function distanceMeters(
        float $fromLatitude,
        float $fromLongitude,
        float $toLatitude,
        float $toLongitude,
    ): int {
        $fromLatitudeRadians = deg2rad($fromLatitude);
        $toLatitudeRadians = deg2rad($toLatitude);
        $latitudeDelta = deg2rad($toLatitude - $fromLatitude);
        $longitudeDelta = deg2rad($toLongitude - $fromLongitude);

        $a = sin($latitudeDelta / 2) ** 2
            + cos($fromLatitudeRadians) * cos($toLatitudeRadians) * sin($longitudeDelta / 2) ** 2;

        return (int) round(self::EARTH_RADIUS_METERS * 2 * atan2(sqrt($a), sqrt(1 - $a)));
    }

    /** Returns the eight-point direction from the guess towards the target. */
    public function direction(
        float $fromLatitude,
        float $fromLongitude,
        float $toLatitude,
        float $toLongitude,
    ): string {
        $fromLatitudeRadians = deg2rad($fromLatitude);
        $toLatitudeRadians = deg2rad($toLatitude);
        $longitudeDelta = deg2rad($toLongitude - $fromLongitude);

        $y = sin($longitudeDelta) * cos($toLatitudeRadians);
        $x = cos($fromLatitudeRadians) * sin($toLatitudeRadians)
            - sin($fromLatitudeRadians) * cos($toLatitudeRadians) * cos($longitudeDelta);
        $bearing = fmod(rad2deg(atan2($y, $x)) + 360, 360);
        $directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];

        return $directions[(int) floor(($bearing + 22.5) / 45) % 8];
    }
}
