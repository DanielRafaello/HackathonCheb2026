<?php

declare(strict_types=1);

namespace App\Services\Location;

use App\Domain\LocationProgress;
use App\Domain\MarkedLocation;
use App\Domain\RoundTarget;
use App\Domain\UserLocation;
use App\Exceptions\generalExceptions\ForbiddenException;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Exceptions\generalExceptions\UnprocessableEntityException;
use App\Repositories\Contracts\LocationRepositoryInterface;
use App\Repositories\Contracts\WaferWalletInterface;
use App\Services\Contracts\Location\LocationServiceInterface;
use App\Services\Profile\Scoring;

final readonly class LocationService implements LocationServiceInterface
{
    public function __construct(
        private LocationRepositoryInterface $locations,
        private WaferWalletInterface $wallet,
        private Scoring $scoring,
    ) {
    }

    public function listForUser(int $userId): array
    {
        return $this->locations->findAllForUser($userId);
    }

    public function mark(int $userId, int $locationId, LocationProgress $progress): MarkedLocation
    {
        if ($this->locations->findForUser($userId, $locationId) === null) {
            throw new NotFoundException('not.found.location');
        }

        $stamped = $this->locations->mark($userId, $locationId, $progress);
        $wafersEarned = $stamped && $progress === LocationProgress::VISITED
            ? $this->scoring->wafersForVisit()
            : 0;
        $this->wallet->addWafers($userId, $wafersEarned);

        return new MarkedLocation(
            $this->locations->findForUser($userId, $locationId)
                ?? throw new NotFoundException('not.found.location'),
            $wafersEarned,
        );
    }

    public function description(int $userId, int $locationId): RoundTarget
    {
        $location = $this->locations->findForUser($userId, $locationId)
            ?? throw new NotFoundException('not.found.location');

        // The texts of a place in the fog would spoil a future round
        if (!$location->isGuessed() && !$location->isVisited()) {
            throw new ForbiddenException('location.in_fog');
        }

        return $this->locations->findCard($locationId)
            ?? throw new NotFoundException('not.found.location');
    }

    public function rate(int $userId, int $locationId, int $rating): UserLocation
    {
        if ($this->locations->findForUser($userId, $locationId) === null) {
            throw new NotFoundException('not.found.location');
        }

        if (!$this->locations->rate($userId, $locationId, $rating)) {
            throw new UnprocessableEntityException('location.not_visited');
        }

        return $this->locations->findForUser($userId, $locationId)
            ?? throw new NotFoundException('not.found.location');
    }
}
