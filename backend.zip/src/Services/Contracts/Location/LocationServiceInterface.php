<?php

declare(strict_types=1);

namespace App\Services\Contracts\Location;

use App\Domain\LocationProgress;
use App\Domain\MarkedLocation;
use App\Domain\RoundTarget;
use App\Domain\UserLocation;

interface LocationServiceInterface
{
    /**
     * All locations with the given user's guessed/visited state.
     *
     * @return list<UserLocation>
     */
    public function listForUser(int $userId): array;

    /**
     * Marks a location as guessed or visited by the user, timed by the server.
     * Idempotent — the first timestamp is kept. The first visit of a location
     * earns wafers; guessed through this endpoint earns none (only a round hit
     * does). Returns the location's new state and the wafers earned.
     *
     * @throws \App\Exceptions\generalExceptions\NotFoundException when the location does not exist
     */
    public function mark(int $userId, int $locationId, LocationProgress $progress): MarkedLocation;

    /**
     * The card of a location the user has guessed or visited: its texts,
     * category and primary source. A location in the fog keeps them hidden.
     *
     * @throws \App\Exceptions\generalExceptions\NotFoundException when the location does not exist
     * @throws \App\Exceptions\generalExceptions\ForbiddenException when the user has neither guessed nor visited it
     */
    public function description(int $userId, int $locationId): RoundTarget;

    /**
     * Sets or replaces the user's 1–5 rating of a location. Only a visited
     * location can be rated. Returns the location's new state.
     *
     * @throws \App\Exceptions\generalExceptions\NotFoundException when the location does not exist
     * @throws \App\Exceptions\generalExceptions\UnprocessableEntityException when the user has not visited it
     */
    public function rate(int $userId, int $locationId, int $rating): UserLocation;
}
