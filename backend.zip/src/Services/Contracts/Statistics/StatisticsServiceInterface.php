<?php

declare(strict_types=1);

namespace App\Services\Contracts\Statistics;

use App\Domain\LocationStatistics;
use App\Domain\StatisticsGranularity;
use App\Domain\StatisticsOverview;
use App\Domain\VisitSeries;

/** Game-wide statistics for administrators. */
interface StatisticsServiceInterface
{
    /** The headline numbers: users, locations, visits, guesses, ratings. */
    public function overview(): StatisticsOverview;

    /**
     * Every location with its visitors, guessers and rating, most visited first.
     *
     * @return list<LocationStatistics>
     */
    public function locations(): array;

    /**
     * Visits over one calendar year (Europe/Prague) as a chart-ready series:
     * 12 monthly points or one point per day, with zeros where nothing
     * happened. Without a year, the current one is used.
     *
     * @param int|null $locationId limit the series to one location
     *
     * @throws \App\Exceptions\generalExceptions\NotFoundException when $locationId does not exist
     */
    public function visits(
        ?int $year = null,
        StatisticsGranularity $granularity = StatisticsGranularity::MONTH,
        ?int $locationId = null,
    ): VisitSeries;
}
