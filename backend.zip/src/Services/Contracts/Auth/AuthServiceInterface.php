<?php

declare(strict_types=1);

namespace App\Services\Contracts\Auth;

use App\Domain\User;

interface AuthServiceInterface
{
    /**
     * Creates a new user, and issues an access + refresh token pair.
     *
     * @return array{token: string, refresh_token: string, user: User}
     */
    public function register(string $name, string $email, string $password): array;

    /**
     * Verifies credentials and issues an access + refresh token pair.
     *
     * @return array{token: string, refresh_token: string, user: User}
     */
    public function login(string $email, string $password): array;

    /**
     * Exchanges a valid, non-revoked refresh token for a new access token.
     * Rotates the refresh token (the old one is revoked) so a stolen-but-unused
     * token can't be replayed once the legitimate client has refreshed.
     *
     * @return array{token: string, refresh_token: string, user: User}
     */
    public function refresh(string $refreshToken): array;

    /** Revokes a refresh token. Idempotent — logging out twice isn't an error. */
    public function logout(string $refreshToken): void;

    /**
     * The account behind an already verified access token.
     *
     * @throws \App\Exceptions\generalExceptions\NotFoundException when the account no longer exists
     */
    public function currentUser(int $userId): User;

    /**
     * Issues a fresh access + refresh token pair for an already-resolved user —
     * for flows that authenticate a user outside login/register (e.g. accepting
     * an employee invite) without duplicating token-issuance logic.
     *
     * @return array{token: string, refresh_token: string}
     */
    public function issueTokensFor(User $user): array;
}
