<?php

declare(strict_types=1);

namespace App\Services\Contracts\Profile;

use App\Domain\Profile;

interface ProfileServiceInterface
{
    /**
     * The user's profile: account, points (split into guessing and visits),
     * level with the progress towards the next one, and how many locations
     * they have guessed and visited. Points are computed from the user's
     * achievements on every call — nothing is stored.
     *
     * @throws \App\Exceptions\generalExceptions\NotFoundException when the account no longer exists
     */
    public function forUser(int $userId): Profile;
}
