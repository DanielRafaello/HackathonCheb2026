<?php

declare(strict_types=1);

namespace App\Services\Contracts\Round;

use App\Domain\GameRound;
use App\Domain\GuessSubmission;

/**
 * The game itself: one round a day per user, unlimited guesses until a hit
 * within 3000 m of the target or expiry at Prague midnight.
 */
interface RoundServiceInterface
{
    /**
     * The user's round for today (Europe/Prague). Creates it on the first
     * call of the day with a random location the user has not guessed yet;
     * later calls the same day return the same round.
     *
     * @throws \App\Exceptions\generalExceptions\ConflictException when the user has guessed every location
     */
    public function getDaily(int $userId): GameRound;

    /**
     * One round by id, only if it belongs to the user.
     *
     * @throws \App\Exceptions\generalExceptions\NotFoundException for an unknown round or a round of another user
     */
    public function get(int $userId, int $roundId): GameRound;

    /**
     * Evaluates one pin on the map against the round's target and stores it.
     * A hit ends the round as guessed; every miss leaves it active. The first
     * three misses unlock the remaining clues without exposing compass data.
     * The fourth and later misses expose distance and eight-point direction.
     * Returns the guess together with the round's new state.
     *
     * @throws \App\Exceptions\generalExceptions\NotFoundException for an unknown round or a round of another user
     * @throws \App\Exceptions\generalExceptions\ConflictException when the round is no longer active
     */
    public function submitGuess(int $userId, int $roundId, float $latitude, float $longitude): GuessSubmission;
}
