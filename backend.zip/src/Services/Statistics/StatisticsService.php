<?php

declare(strict_types=1);

namespace App\Services\Statistics;

use App\Domain\StatisticsGranularity;
use App\Domain\StatisticsOverview;
use App\Domain\VisitSeries;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Repositories\Contracts\StatisticsRepositoryInterface;
use App\Services\Contracts\Statistics\StatisticsServiceInterface;

final readonly class StatisticsService implements StatisticsServiceInterface
{
    private const TIME_ZONE = 'Europe/Prague';

    public function __construct(
        private StatisticsRepositoryInterface $statistics,
    ) {
    }

    public function overview(): StatisticsOverview
    {
        return $this->statistics->overview();
    }

    public function locations(): array
    {
        return $this->statistics->locationStatistics();
    }

    public function visits(
        ?int $year = null,
        StatisticsGranularity $granularity = StatisticsGranularity::MONTH,
        ?int $locationId = null,
    ): VisitSeries {
        if ($locationId !== null && !$this->statistics->locationExists($locationId)) {
            throw new NotFoundException('not.found.location');
        }

        $timeZone = new \DateTimeZone(self::TIME_ZONE);
        $year ??= (int) (new \DateTimeImmutable('now', $timeZone))->format('Y');

        $from = (new \DateTimeImmutable('now', $timeZone))->setDate($year, 1, 1)->setTime(0, 0);
        $to = $from->modify('+1 year');

        $counts = $this->statistics->visitCounts(
            $from->format('Y-m-d H:i:s'),
            $to->format('Y-m-d H:i:s'),
            $granularity,
            $locationId,
        );

        // The repository returns only periods with visits; a chart needs every period
        $points = [];
        for ($period = $from; $period < $to; $period = $period->modify($granularity->step())) {
            $label = $period->format($granularity->periodFormat());
            $points[] = [
                'period' => $label,
                'visits' => $counts[$label]['visits'] ?? 0,
                'visitors' => $counts[$label]['visitors'] ?? 0,
            ];
        }

        return new VisitSeries($year, $granularity, $locationId, $points);
    }
}
