<?php

declare(strict_types=1);

namespace App\Requests\Round;

use App\Validation\FormRequest;

final class SubmitGuessRequest extends FormRequest
{
    protected function rules(): array
    {
        return [
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
        ];
    }
}
