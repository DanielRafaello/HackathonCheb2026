<?php

declare(strict_types=1);

namespace App\Requests\Admin;

use App\Validation\FormRequest;

/** Query string of GET /admin/statistics/visits — every parameter is optional. */
class VisitStatisticsRequest extends FormRequest
{
    protected function rules(): array
    {
        return [
            'year' => 'nullable|integer|between:2000,2100',
            'granularity' => 'nullable|in:month,day',
            'location_id' => 'nullable|integer|between:1,2147483647',
        ];
    }
}
