<?php

declare(strict_types=1);

namespace App\Requests\Auth;

use App\Validation\FormRequest;

class LoginRequest extends FormRequest
{
    protected function rules(): array
    {
        return [
            'email'    => 'required|email',
            'password' => 'required',
        ];
    }
}
