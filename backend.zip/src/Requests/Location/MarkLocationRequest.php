<?php

declare(strict_types=1);

namespace App\Requests\Location;

use App\Validation\FormRequest;

class MarkLocationRequest extends FormRequest
{
    protected function rules(): array
    {
        return [
            'state' => 'required|in:guessed,visited',
        ];
    }
}
