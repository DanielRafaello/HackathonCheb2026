<?php

declare(strict_types=1);

namespace App\Requests\Location;

use App\Validation\FormRequest;

class RateLocationRequest extends FormRequest
{
    protected function rules(): array
    {
        return [
            // "in" rather than "between", so 4.5 is rejected
            'rating' => 'required|in:1,2,3,4,5',
        ];
    }
}
