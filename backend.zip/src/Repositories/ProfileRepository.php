<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Domain\LocationAchievement;
use App\Repositories\Contracts\ProfileRepositoryInterface;
use Doctrine\DBAL\Connection;

final readonly class ProfileRepository implements ProfileRepositoryInterface
{
    public function __construct(
        private Connection $connection,
    ) {
    }

    public function findAchievementsForUser(int $userId): array
    {
        // attempts >= 1 means the location was hit in a round (there is no upper
        // limit, guessing continues past the fifth attempt); a location only
        // marked as guessed through POST /locations/{id}/progress has attempts = 0
        $rows = $this->connection->fetchAllAssociative(
            <<<'SQL'
                SELECT location_id,
                       min(attempts) FILTER (WHERE guessed_at IS NOT NULL AND attempts >= 1) AS guessed_on_attempt,
                       bool_or(guessed_at IS NOT NULL) AS guessed,
                       bool_or(visited_at IS NOT NULL) AS visited
                FROM user_locations
                WHERE user_id = :user_id
                GROUP BY location_id
                HAVING bool_or(guessed_at IS NOT NULL) OR bool_or(visited_at IS NOT NULL)
                ORDER BY location_id
                SQL,
            ['user_id' => $userId],
        );

        return array_map(
            static fn (array $row): LocationAchievement => new LocationAchievement(
                locationId: (int) $row['location_id'],
                guessedOnAttempt: $row['guessed_on_attempt'] !== null ? (int) $row['guessed_on_attempt'] : null,
                guessed: filter_var($row['guessed'], FILTER_VALIDATE_BOOL),
                visited: filter_var($row['visited'], FILTER_VALIDATE_BOOL),
            ),
            $rows,
        );
    }
}
