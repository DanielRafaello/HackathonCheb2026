<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Domain\GameRound;
use App\Domain\GuessResult;
use App\Domain\RoundStatus;
use App\Domain\RoundTarget;
use App\Repositories\Contracts\RoundRepositoryInterface;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Types\Types;

final readonly class RoundRepository implements RoundRepositoryInterface
{
    private const SELECT_ROUND = <<<'SQL'
        SELECT
            ul.id,
            ul.user_id,
            ul.attempts,
            ul.daily_date,
            ul.guessed_at,
            l.id AS location_id,
            l.name AS location_name,
            l.latitude,
            l.longitude,
            l.description,
            l.hint1,
            l.hint2,
            l.content_source_url,
            c.name AS category_name,
            s.title AS source_title,
            s.publisher AS source_publisher,
            s.portal_url AS source_portal_url,
            s.license_code AS source_license_code,
            s.license_url AS source_license_url,
            s.attribution_text AS source_attribution_text,
            s.retrieved_at AS source_retrieved_at,
            s.source_updated_at,
            latest_guess.attempt_number AS last_attempt_number,
            latest_guess.distance_meters AS last_distance_meters,
            latest_guess.direction AS last_direction,
            latest_guess.is_hit AS last_is_hit,
            latest_guess.created_at AS last_guess_at
        FROM user_locations ul
        INNER JOIN locations l ON l.id = ul.location_id
        INNER JOIN categories c ON c.category_id = l.category_id
        INNER JOIN sources s ON s.source_id = l.source_id
        LEFT JOIN LATERAL (
            SELECT attempt_number, distance_meters, direction, is_hit, created_at
            FROM user_location_guesses
            WHERE user_location_id = ul.id
            ORDER BY attempt_number DESC
            LIMIT 1
        ) latest_guess ON true
        SQL;

    public function __construct(private Connection $connection)
    {
    }

    public function transactional(callable $callback): mixed
    {
        return $this->connection->transactional($callback);
    }

    public function getOrCreateDailyForUser(int $userId, string $date): ?GameRound
    {
        return $this->connection->transactional(function () use ($userId, $date): ?GameRound {
            // Serialise concurrent daily requests from the same account.
            $this->connection->fetchOne(
                'SELECT id FROM users WHERE id = :user_id FOR UPDATE',
                ['user_id' => $userId],
            );

            $existing = $this->findDailyForUser($userId, $date);
            if ($existing !== null) {
                return $existing;
            }

            $locationId = $this->connection->fetchOne(
                <<<'SQL'
                    SELECT l.id
                    FROM locations l
                    WHERE NOT EXISTS (
                        SELECT 1
                        FROM user_locations progress
                        WHERE progress.user_id = :user_id
                          AND progress.location_id = l.id
                          AND progress.guessed_at IS NOT NULL
                    )
                    ORDER BY random()
                    LIMIT 1
                    SQL,
                ['user_id' => $userId],
            );

            if ($locationId === false) {
                return null;
            }

            $roundId = $this->connection->fetchOne(
                <<<'SQL'
                    INSERT INTO user_locations (user_id, location_id, daily_date, attempts)
                    VALUES (:user_id, :location_id, CAST(:daily_date AS date), 0)
                    RETURNING id
                    SQL,
                ['user_id' => $userId, 'location_id' => $locationId, 'daily_date' => $date],
            );

            return $this->findForUser($userId, (int) $roundId);
        });
    }

    public function findForUser(int $userId, int $roundId, bool $forUpdate = false): ?GameRound
    {
        $sql = self::SELECT_ROUND . ' WHERE ul.id = :round_id AND ul.user_id = :user_id';
        if ($forUpdate) {
            $sql .= ' FOR UPDATE OF ul';
        }

        $row = $this->connection->fetchAssociative(
            $sql,
            ['round_id' => $roundId, 'user_id' => $userId],
        );

        return $row === false ? null : $this->hydrate($row);
    }

    public function addGuess(int $roundId, float $latitude, float $longitude, GuessResult $guess): void
    {
        $this->connection->insert('user_location_guesses', [
            'user_location_id' => $roundId,
            'attempt_number' => $guess->attemptNumber,
            'latitude' => $latitude,
            'longitude' => $longitude,
            'distance_meters' => $guess->distanceMeters,
            'direction' => $guess->direction,
            'is_hit' => $guess->hit,
        ], [
            'is_hit' => Types::BOOLEAN,
        ]);
    }

    public function updateState(int $roundId, int $attemptsUsed, RoundStatus $status): void
    {
        $this->connection->executeStatement(
            <<<'SQL'
                UPDATE user_locations
                SET attempts = :attempts,
                    guessed_at = CASE
                        WHEN :status = 'guessed' THEN COALESCE(guessed_at, now())
                        ELSE guessed_at
                    END
                WHERE id = :round_id
                SQL,
            ['round_id' => $roundId, 'attempts' => $attemptsUsed, 'status' => $status->value],
        );
    }

    private function findDailyForUser(int $userId, string $date): ?GameRound
    {
        $row = $this->connection->fetchAssociative(
            self::SELECT_ROUND . ' WHERE ul.user_id = :user_id AND ul.daily_date = :daily_date',
            ['user_id' => $userId, 'daily_date' => $date],
        );

        return $row === false ? null : $this->hydrate($row);
    }

    /** @param array<string, mixed> $row */
    private function hydrate(array $row): GameRound
    {
        $dailyDate = (string) $row['daily_date'];
        $attempts = (int) $row['attempts'];
        $status = match (true) {
            $row['guessed_at'] !== null => RoundStatus::GUESSED,
            $dailyDate < $this->currentPragueDate() => RoundStatus::EXPIRED,
            default => RoundStatus::ACTIVE,
        };
        $stars = match ($status) {
            RoundStatus::GUESSED => $attempts === 0 ? null : GameRound::starsForHit($attempts),
            RoundStatus::ACTIVE, RoundStatus::EXPIRED => null,
        };
        $completedAt = match ($status) {
            RoundStatus::GUESSED => $row['guessed_at'],
            default => null,
        };

        return new GameRound(
            id: (int) $row['id'],
            userId: (int) $row['user_id'],
            status: $status,
            attemptsUsed: $attempts,
            stars: $stars,
            dailyDate: $dailyDate,
            completedAt: $completedAt,
            target: new RoundTarget(
                id: (int) $row['location_id'],
                name: $row['location_name'],
                latitude: (float) $row['latitude'],
                longitude: (float) $row['longitude'],
                category: $row['category_name'],
                description: $row['description'],
                hint1: $row['hint1'],
                hint2: $row['hint2'],
                contentSourceUrl: $row['content_source_url'],
                sourceTitle: $row['source_title'],
                sourcePublisher: $row['source_publisher'],
                sourcePortalUrl: $row['source_portal_url'],
                sourceLicenseCode: $row['source_license_code'],
                sourceLicenseUrl: $row['source_license_url'],
                sourceAttributionText: $row['source_attribution_text'],
                sourceRetrievedAt: $row['source_retrieved_at'],
                sourceUpdatedAt: $row['source_updated_at'],
            ),
            lastGuess: $row['last_attempt_number'] === null ? null : new GuessResult(
                attemptNumber: (int) $row['last_attempt_number'],
                hit: filter_var($row['last_is_hit'], FILTER_VALIDATE_BOOL),
                distanceMeters: (int) round((float) $row['last_distance_meters']),
                direction: $row['last_direction'],
            ),
        );
    }

    private function currentPragueDate(): string
    {
        return (new \DateTimeImmutable('now', new \DateTimeZone('Europe/Prague')))->format('Y-m-d');
    }
}
