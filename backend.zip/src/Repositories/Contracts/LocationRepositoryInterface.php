<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Domain\LocationProgress;
use App\Domain\RoundTarget;
use App\Domain\UserLocation;

interface LocationRepositoryInterface
{
    /**
     * Every location, each with the given user's guessed/visited state.
     * Locations the user has no record for come back with null timestamps.
     *
     * @return list<UserLocation>
     */
    public function findAllForUser(int $userId): array;

    /** One location with the given user's state, or null when the location does not exist. */
    public function findForUser(int $userId, int $locationId): ?UserLocation;

    /**
     * The card of a location: its texts, category and primary source, or
     * null when the location does not exist. It does not check who may see it.
     */
    public function findCard(int $locationId): ?RoundTarget;

    /**
     * Stamps the progress with the database's current time. The first
     * timestamp wins — marking again never moves it. The location must exist.
     * Returns true when this call set the state, false when it was set before.
     */
    public function mark(int $userId, int $locationId, LocationProgress $progress): bool;

    /**
     * Sets or replaces the user's 1–5 rating of a location they have visited.
     * Returns false, writing nothing, when the user has not visited it.
     */
    public function rate(int $userId, int $locationId, int $rating): bool;
}
