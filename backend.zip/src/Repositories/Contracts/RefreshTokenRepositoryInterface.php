<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

/**
 * Storage of refresh tokens. Only the sha256 hash of a token is ever stored
 * or looked up — the raw token exists only on the client.
 */
interface RefreshTokenRepositoryInterface
{
    /** Stores a new, not revoked token of the user that expires at the given time (ISO 8601). */
    public function create(int $userId, string $tokenHash, string $expiresAt): void;

    /**
     * The owner of a token that is neither revoked nor expired, or null.
     *
     * @deprecated use findByHash — it also tells a revoked token from an unknown one
     */
    public function findValidUserId(string $tokenHash): ?int;

    /**
     * Marks one token as revoked now (logout, or rotation on refresh).
     * Does nothing for an unknown or already revoked token.
     */
    public function revoke(string $tokenHash): void;

    /**
     * Housekeeping: deletes every token that is expired or revoked.
     * Returns the number of deleted tokens.
     */
    public function deleteExpiredAndRevoked(): int;

    /**
     * The token's row whatever its state, or null when the hash is unknown.
     * The caller decides what a revoked or expired token means.
     *
     * @return array{user_id: int|string, revoked_at: ?string, expires_at: string}|null
     */
    public function findByHash(string $tokenHash): ?array;

    /**
     * Revokes every active token of the user, signing them out on all devices.
     * Used when an already revoked refresh token is presented again — a sign
     * that the token was stolen and someone is replaying it.
     */
    public function revokeAllForUser(int $userId): void;
}
