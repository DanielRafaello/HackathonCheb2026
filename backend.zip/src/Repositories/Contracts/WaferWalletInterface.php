<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

/**
 * The wafers balance of a user (users.wafers), the game's currency. Wafers
 * are only ever added for now; spending them is a future feature.
 */
interface WaferWalletInterface
{
    /** Adds a positive amount to the user's balance; 0 does nothing. */
    public function addWafers(int $userId, int $wafers): void;
}
