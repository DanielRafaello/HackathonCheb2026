<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Domain\LocationStatistics;
use App\Domain\StatisticsGranularity;
use App\Domain\StatisticsOverview;

/**
 * Aggregated numbers across all users, for the admin statistics.
 *
 * Everywhere here a "visit" is one user having visited one location, counted
 * once and dated by the first time it happened — however many records the
 * user has for that location.
 */
interface StatisticsRepositoryInterface
{
    /** The headline numbers of the whole game. */
    public function overview(): StatisticsOverview;

    /**
     * Every location with its number of visitors, number of users who guessed
     * it, and its rating. Ordered by visitors (most first), then by name.
     *
     * @return list<LocationStatistics>
     */
    public function locationStatistics(): array;

    /** Whether a location with this id exists. */
    public function locationExists(int $locationId): bool;

    /**
     * Visits first made in [$from, $to), grouped into periods. $from and $to
     * are Europe/Prague local times ("Y-m-d H:i:s"); periods are cut in the
     * same time zone. Only periods with at least one visit are returned —
     * filling the gaps is the caller's job.
     *
     * @param int|null $locationId limit to one location, null for all
     *
     * @return array<string, array{visits: int, visitors: int}> keyed by period label
     *         ("2026-03" or "2026-03-14", see StatisticsGranularity)
     */
    public function visitCounts(
        string $from,
        string $to,
        StatisticsGranularity $granularity,
        ?int $locationId = null,
    ): array;
}
