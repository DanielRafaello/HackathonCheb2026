<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Domain\GameRound;
use App\Domain\GuessResult;
use App\Domain\RoundStatus;

/**
 * Storage of rounds. A round is a user_locations row with a daily_date; its
 * guesses are user_location_guesses rows. The round's status and stars are
 * not stored — they are derived from the attempts, guessed_at and the date
 * every time a round is read.
 */
interface RoundRepositoryInterface
{
    /**
     * Runs the callback in one database transaction and returns its result.
     * Any exception rolls everything back.
     */
    public function transactional(callable $callback): mixed;

    /**
     * The user's round for the given date (Y-m-d). When there is none, creates
     * one with a random location the user has not guessed yet. Returns null
     * when no such location is left. Safe against concurrent calls of the
     * same user — both get the same round.
     */
    public function getOrCreateDailyForUser(int $userId, string $date): ?GameRound;

    /**
     * One round with its target and last guess, or null when the id is
     * unknown or the round belongs to another user. With $forUpdate the row
     * is locked until the surrounding transaction ends, so two guesses of
     * the same round cannot be evaluated at once.
     */
    public function findForUser(int $userId, int $roundId, bool $forUpdate = false): ?GameRound;

    /**
     * Stores one evaluated guess of a round: the pin and its result
     * (attempt number, distance, direction, hit).
     */
    public function addGuess(int $roundId, float $latitude, float $longitude, GuessResult $guess): void;

    /**
     * Saves the number of attempts used. When the status is GUESSED it also
     * stamps guessed_at with the current time (the first stamp is kept),
     * which marks the location as guessed for the user.
     */
    public function updateState(
        int $roundId,
        int $attemptsUsed,
        RoundStatus $status,
    ): void;
}
