<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Domain\Role;
use App\Domain\User;

/** Storage of user accounts. */
interface UserRepositoryInterface
{
    /** The user with this id (without the password hash), or null. */
    public function findById(int $id): ?User;

    /** Whether an account with this e-mail already exists. */
    public function existsByEmail(string $email): bool;

    /**
     * Raw row incl. password_hash — for authentication only. Never expose
     * the hash outside the service method that verifies it.
     *
     * @return array<string, mixed>|null
     */
    public function findAuthRecordByEmail(string $email): ?array;

    /**
     * Inserts a new account and returns it with its generated id and
     * creation time. The password must already be hashed; the e-mail must
     * be unique (check existsByEmail first).
     */
    public function create(string $name, string $email, string $passwordHash, Role $role): User;
}
