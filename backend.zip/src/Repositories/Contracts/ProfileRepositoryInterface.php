<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Domain\LocationAchievement;

/** Reads what a user has achieved, as the basis for points and levels. */
interface ProfileRepositoryInterface
{
    /**
     * One entry per location the user has guessed or visited, ordered by
     * location id. A location with several records (for example an expired
     * round and a later successful one) is merged into a single entry:
     * the best hit and whether it was ever visited.
     *
     * @return list<LocationAchievement>
     */
    public function findAchievementsForUser(int $userId): array;
}
