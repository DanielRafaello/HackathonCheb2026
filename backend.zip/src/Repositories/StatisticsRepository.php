<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Domain\LocationStatistics;
use App\Domain\StatisticsGranularity;
use App\Domain\StatisticsOverview;
use App\Repositories\Contracts\StatisticsRepositoryInterface;
use Doctrine\DBAL\Connection;

final readonly class StatisticsRepository implements StatisticsRepositoryInterface
{
    /**
     * One row per user and location with the first time it was visited and
     * guessed. A user can have several user_locations rows for one location
     * (a failed round and a later one), so everything is counted from here.
     */
    private const PROGRESS = <<<'SQL'
        SELECT user_id,
               location_id,
               min(visited_at) AS visited_at,
               min(guessed_at) AS guessed_at
        FROM user_locations
        GROUP BY user_id, location_id
        SQL;

    public function __construct(
        private Connection $connection,
    ) {
    }

    public function overview(): StatisticsOverview
    {
        $progress = self::PROGRESS;

        /** @var array<string, mixed> $row */
        $row = $this->connection->fetchAssociative(
            <<<SQL
                WITH progress AS ({$progress})
                SELECT
                    (SELECT count(*) FROM users) AS users_total,
                    (SELECT count(DISTINCT user_id) FROM progress
                      WHERE visited_at IS NOT NULL OR guessed_at IS NOT NULL) AS users_active,
                    (SELECT count(*) FROM locations) AS locations_total,
                    (SELECT count(DISTINCT location_id) FROM progress WHERE visited_at IS NOT NULL) AS locations_visited,
                    (SELECT count(*) FROM progress WHERE visited_at IS NOT NULL) AS visits_total,
                    (SELECT count(*) FROM progress WHERE guessed_at IS NOT NULL) AS guesses_total,
                    (SELECT count(*) FROM location_ratings) AS ratings_total,
                    (SELECT round(avg(rating), 1) FROM location_ratings) AS average_rating
                SQL,
        );

        return new StatisticsOverview(
            usersTotal: (int) $row['users_total'],
            usersActive: (int) $row['users_active'],
            locationsTotal: (int) $row['locations_total'],
            locationsVisited: (int) $row['locations_visited'],
            visitsTotal: (int) $row['visits_total'],
            guessesTotal: (int) $row['guesses_total'],
            ratingsTotal: (int) $row['ratings_total'],
            averageRating: $row['average_rating'] !== null ? (float) $row['average_rating'] : null,
        );
    }

    public function locationStatistics(): array
    {
        $progress = self::PROGRESS;

        $rows = $this->connection->fetchAllAssociative(
            <<<SQL
                WITH progress AS ({$progress})
                SELECT l.id,
                       l.name,
                       c.name AS category,
                       COALESCE(p.visitors, 0) AS visitors,
                       COALESCE(p.guessed_by, 0) AS guessed_by,
                       r.average_rating,
                       COALESCE(r.rating_count, 0) AS rating_count
                FROM locations l
                INNER JOIN categories c ON c.category_id = l.category_id
                LEFT JOIN (
                    SELECT location_id,
                           count(*) FILTER (WHERE visited_at IS NOT NULL) AS visitors,
                           count(*) FILTER (WHERE guessed_at IS NOT NULL) AS guessed_by
                    FROM progress
                    GROUP BY location_id
                ) p ON p.location_id = l.id
                LEFT JOIN (
                    SELECT location_id, round(avg(rating), 1) AS average_rating, count(*) AS rating_count
                    FROM location_ratings
                    GROUP BY location_id
                ) r ON r.location_id = l.id
                ORDER BY visitors DESC, l.name, l.id
                SQL,
        );

        return array_map(
            static fn (array $row): LocationStatistics => new LocationStatistics(
                id: (int) $row['id'],
                name: $row['name'],
                category: $row['category'],
                visitors: (int) $row['visitors'],
                guessedBy: (int) $row['guessed_by'],
                averageRating: $row['average_rating'] !== null ? (float) $row['average_rating'] : null,
                ratingCount: (int) $row['rating_count'],
            ),
            $rows,
        );
    }

    public function locationExists(int $locationId): bool
    {
        return $this->connection->fetchOne(
            'SELECT 1 FROM locations WHERE id = :id',
            ['id' => $locationId],
        ) !== false;
    }

    public function visitCounts(
        string $from,
        string $to,
        StatisticsGranularity $granularity,
        ?int $locationId = null,
    ): array {
        $progress = self::PROGRESS;

        // The to_char pattern comes from the enum, never from user input
        $pattern = $granularity->sqlPeriodFormat();

        $params = ['from' => $from, 'to' => $to];
        $locationFilter = '';
        if ($locationId !== null) {
            $locationFilter = 'AND location_id = :location_id';
            $params['location_id'] = $locationId;
        }

        $rows = $this->connection->fetchAllAssociative(
            <<<SQL
                WITH progress AS ({$progress})
                SELECT to_char(visited_at AT TIME ZONE 'Europe/Prague', '{$pattern}') AS period,
                       count(*) AS visits,
                       count(DISTINCT user_id) AS visitors
                FROM progress
                WHERE visited_at >= CAST(:from AS timestamp) AT TIME ZONE 'Europe/Prague'
                  AND visited_at <  CAST(:to AS timestamp) AT TIME ZONE 'Europe/Prague'
                  {$locationFilter}
                GROUP BY period
                ORDER BY period
                SQL,
            $params,
        );

        $counts = [];
        foreach ($rows as $row) {
            $counts[(string) $row['period']] = [
                'visits' => (int) $row['visits'],
                'visitors' => (int) $row['visitors'],
            ];
        }

        return $counts;
    }
}
