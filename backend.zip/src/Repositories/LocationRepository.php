<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Domain\LocationProgress;
use App\Domain\RoundTarget;
use App\Domain\UserLocation;
use App\Repositories\Contracts\LocationRepositoryInterface;
use Doctrine\DBAL\Connection;

final readonly class LocationRepository implements LocationRepositoryInterface
{
    // Timestamps are formatted as ISO 8601 UTC here so every client gets the same shape
    private const SELECT_FOR_USER = <<<'SQL'
        SELECT l.id, l.name, l.latitude, l.longitude,
               to_char(ul.guessed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS guessed_at,
               to_char(ul.visited_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS visited_at,
               r.rating,
               to_char(r.updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS rated_at,
               ra.average_rating,
               COALESCE(ra.rating_count, 0) AS rating_count
        FROM locations l
        LEFT JOIN (
            SELECT location_id, min(guessed_at) AS guessed_at, min(visited_at) AS visited_at
            FROM user_locations
            WHERE user_id = :user_id
            GROUP BY location_id
        ) ul ON ul.location_id = l.id
        LEFT JOIN location_ratings r ON r.location_id = l.id AND r.user_id = :user_id
        LEFT JOIN (
            SELECT location_id, round(avg(rating), 1) AS average_rating, count(*) AS rating_count
            FROM location_ratings
            GROUP BY location_id
        ) ra ON ra.location_id = l.id
        SQL;

    public function __construct(
        private Connection $connection,
    ) {
    }

    public function findAllForUser(int $userId): array
    {
        $rows = $this->connection->fetchAllAssociative(
            self::SELECT_FOR_USER . ' ORDER BY l.id',
            ['user_id' => $userId],
        );

        return array_map(UserLocation::fromRow(...), $rows);
    }

    public function findForUser(int $userId, int $locationId): ?UserLocation
    {
        $row = $this->connection->fetchAssociative(
            self::SELECT_FOR_USER . ' WHERE l.id = :location_id',
            ['user_id' => $userId, 'location_id' => $locationId],
        );

        return $row !== false ? UserLocation::fromRow($row) : null;
    }

    public function findCard(int $locationId): ?RoundTarget
    {
        $row = $this->connection->fetchAssociative(
            <<<'SQL'
                SELECT l.id, l.name, l.latitude, l.longitude, l.description,
                       l.hint1, l.hint2, l.content_source_url,
                       c.name AS category_name,
                       s.title, s.publisher, s.portal_url, s.license_code,
                       s.license_url, s.attribution_text, s.retrieved_at,
                       s.source_updated_at
                FROM locations l
                INNER JOIN categories c ON c.category_id = l.category_id
                INNER JOIN sources s ON s.source_id = l.source_id
                WHERE l.id = :id
                SQL,
            ['id' => $locationId],
        );

        if ($row === false) {
            return null;
        }

        return new RoundTarget(
            id: (int) $row['id'],
            name: $row['name'],
            latitude: (float) $row['latitude'],
            longitude: (float) $row['longitude'],
            category: $row['category_name'],
            description: $row['description'],
            hint1: $row['hint1'],
            hint2: $row['hint2'],
            contentSourceUrl: $row['content_source_url'],
            sourceTitle: $row['title'],
            sourcePublisher: $row['publisher'],
            sourcePortalUrl: $row['portal_url'],
            sourceLicenseCode: $row['license_code'],
            sourceLicenseUrl: $row['license_url'],
            sourceAttributionText: $row['attribution_text'],
            sourceRetrievedAt: $row['retrieved_at'],
            sourceUpdatedAt: $row['source_updated_at'],
        );
    }

    public function mark(int $userId, int $locationId, LocationProgress $progress): bool
    {
        return $this->connection->transactional(
            fn (): bool => $this->stamp($userId, $locationId, $progress),
        );
    }

    private function stamp(int $userId, int $locationId, LocationProgress $progress): bool
    {
        // The column name comes from the enum, never from user input
        $column = $progress->column();

        // Locking the user serialises marks of one user, so two parallel
        // visits cannot both see the location as not visited yet
        $this->connection->executeStatement(
            'SELECT id FROM users WHERE id = :user_id FOR UPDATE',
            ['user_id' => $userId],
        );
        $alreadySet = $this->connection->fetchOne(
            <<<SQL
                SELECT 1 FROM user_locations
                WHERE user_id = :user_id AND location_id = :location_id
                  AND {$column} IS NOT NULL
                LIMIT 1
                SQL,
            ['user_id' => $userId, 'location_id' => $locationId],
        ) !== false;

        $updated = $this->connection->executeStatement(
            <<<SQL
                UPDATE user_locations
                SET {$column} = COALESCE({$column}, now())
                WHERE user_id = :user_id AND location_id = :location_id
                SQL,
            ['user_id' => $userId, 'location_id' => $locationId],
        );

        if ($updated === 0) {
            $this->connection->executeStatement(
                <<<SQL
                    INSERT INTO user_locations (user_id, location_id, {$column})
                    VALUES (:user_id, :location_id, now())
                    SQL,
                ['user_id' => $userId, 'location_id' => $locationId],
            );
        }

        return !$alreadySet;
    }

    public function rate(int $userId, int $locationId, int $rating): bool
    {
        // The visit check and the write are one statement, so no visit can be missed in between
        $written = $this->connection->executeStatement(
            <<<'SQL'
                INSERT INTO location_ratings (user_id, location_id, rating)
                SELECT :user_id, :location_id, :rating
                WHERE EXISTS (
                    SELECT 1
                    FROM user_locations
                    WHERE user_id = :user_id
                      AND location_id = :location_id
                      AND visited_at IS NOT NULL
                )
                ON CONFLICT (user_id, location_id) DO UPDATE SET
                    rating     = EXCLUDED.rating,
                    updated_at = now()
                SQL,
            ['user_id' => $userId, 'location_id' => $locationId, 'rating' => $rating],
        );

        return $written > 0;
    }
}
