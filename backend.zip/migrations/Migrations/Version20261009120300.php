<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * SOURCES
 */
final class Version20261009120300 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Create sources table';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            CREATE TABLE sources (
                source_id INTEGER PRIMARY KEY,
                file_name TEXT    NOT NULL UNIQUE
            )
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE sources');
    }
}
