<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * USER LOCATIONS
 *
 * Per-user progress on a location. The timestamps double as flags:
 * NULL = not guessed / not visited, a value = when it happened.
 */
final class Version20261009120600 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Create user_locations table';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            CREATE TABLE user_locations (
                user_id     BIGINT      NOT NULL REFERENCES users (id) ON DELETE CASCADE,
                location_id INTEGER     NOT NULL REFERENCES locations (id) ON DELETE CASCADE,
                guessed_at  TIMESTAMPTZ NULL,
                visited_at  TIMESTAMPTZ NULL,
                PRIMARY KEY (user_id, location_id)
            )
            SQL);

        $this->addSql('CREATE INDEX idx_user_locations_location_id ON user_locations (location_id)');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE user_locations');
    }
}
