<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * LOCATION DISTANCE CLUE
 */
final class Version20261010000000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Describe hint2 as the distance-from-district-capital clue';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            COMMENT ON COLUMN locations.hint2 IS 'Distance band from the location to its district capital.'
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            COMMENT ON COLUMN locations.hint2 IS 'Numeric clue; normally the municipality population band as of 1 January 2026.'
            SQL);
    }
}
