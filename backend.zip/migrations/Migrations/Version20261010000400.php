<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261010000400 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Allow unlimited guesses after clue-only attempts activate the compass';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            ALTER TABLE user_locations
                DROP CONSTRAINT user_locations_attempts_check,
                ALTER COLUMN attempts TYPE INTEGER,
                ADD CONSTRAINT user_locations_attempts_check CHECK (attempts >= 0)
            SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user_location_guesses
                DROP CONSTRAINT user_location_guesses_attempt_number_check,
                ALTER COLUMN attempt_number TYPE INTEGER,
                ADD CONSTRAINT user_location_guesses_attempt_number_check CHECK (attempt_number >= 1)
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->abortIf(
            (int) $this->connection->fetchOne(
                'SELECT COUNT(*) FROM user_locations WHERE attempts > 5',
            ) > 0,
            'Cannot restore the five-attempt constraint while rounds with more than five attempts exist.',
        );

        $this->addSql(<<<'SQL'
            ALTER TABLE user_location_guesses
                DROP CONSTRAINT user_location_guesses_attempt_number_check,
                ALTER COLUMN attempt_number TYPE SMALLINT,
                ADD CONSTRAINT user_location_guesses_attempt_number_check
                    CHECK (attempt_number BETWEEN 1 AND 5)
            SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user_locations
                DROP CONSTRAINT user_locations_attempts_check,
                ALTER COLUMN attempts TYPE SMALLINT,
                ADD CONSTRAINT user_locations_attempts_check CHECK (attempts BETWEEN 0 AND 5)
            SQL);
    }
}
