<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * RENAME MUNICIPALITIES TO ORPS
 */
final class Version20261009120800 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Rename the ORP lookup table and foreign key to match their actual meaning';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('ALTER TABLE municipalities RENAME TO orps');
        $this->addSql('ALTER TABLE orps RENAME COLUMN municipality_id TO orp_id');
        $this->addSql('ALTER TABLE orps RENAME COLUMN municipality_code TO orp_code');
        $this->addSql('ALTER TABLE locations RENAME COLUMN municipality_id TO orp_id');

        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT municipalities_municipality_id_not_null TO orps_orp_id_not_null');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT municipalities_district_id_not_null TO orps_district_id_not_null');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT municipalities_name_not_null TO orps_name_not_null');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT municipalities_municipality_code_not_null TO orps_orp_code_not_null');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT municipalities_pkey TO orps_pkey');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT municipalities_district_id_fkey TO orps_district_id_fkey');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT municipalities_municipality_code_key TO orps_orp_code_key');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT municipalities_municipality_id_district_id_key TO orps_orp_id_district_id_key');
        $this->addSql('ALTER TABLE locations RENAME CONSTRAINT locations_municipality_id_district_id_fkey TO locations_orp_id_district_id_fkey');
        $this->addSql('ALTER TABLE locations RENAME CONSTRAINT locations_municipality_id_not_null TO locations_orp_id_not_null');
        $this->addSql('ALTER INDEX locations_municipality_id_idx RENAME TO locations_orp_id_idx');

        $this->addSql("COMMENT ON TABLE orps IS 'Municipalities with extended powers (ORPs), mapped from the source CSV fields.'");
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER INDEX locations_orp_id_idx RENAME TO locations_municipality_id_idx');
        $this->addSql('ALTER TABLE locations RENAME CONSTRAINT locations_orp_id_not_null TO locations_municipality_id_not_null');
        $this->addSql('ALTER TABLE locations RENAME CONSTRAINT locations_orp_id_district_id_fkey TO locations_municipality_id_district_id_fkey');
        $this->addSql('ALTER TABLE locations RENAME COLUMN orp_id TO municipality_id');

        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT orps_orp_id_district_id_key TO municipalities_municipality_id_district_id_key');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT orps_orp_code_key TO municipalities_municipality_code_key');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT orps_district_id_fkey TO municipalities_district_id_fkey');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT orps_pkey TO municipalities_pkey');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT orps_orp_code_not_null TO municipalities_municipality_code_not_null');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT orps_name_not_null TO municipalities_name_not_null');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT orps_district_id_not_null TO municipalities_district_id_not_null');
        $this->addSql('ALTER TABLE orps RENAME CONSTRAINT orps_orp_id_not_null TO municipalities_municipality_id_not_null');
        $this->addSql('ALTER TABLE orps RENAME COLUMN orp_code TO municipality_code');
        $this->addSql('ALTER TABLE orps RENAME COLUMN orp_id TO municipality_id');
        $this->addSql('ALTER TABLE orps RENAME TO municipalities');

        $this->addSql("COMMENT ON TABLE municipalities IS 'Municipalities with extended powers (ORP), mapped from the available CSV fields.'");
    }
}
