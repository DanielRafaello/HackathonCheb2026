<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * LOCATION RATINGS
 *
 * One 1–5 rating per user and location. Separate from user_locations because
 * that table now holds one row per round, so a user can have several rows for
 * the same location. The "only after a visit" rule is enforced by the service.
 */
final class Version20261010000300 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Create location_ratings for 1–5 ratings of visited locations';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            CREATE TABLE location_ratings (
                user_id     BIGINT      NOT NULL REFERENCES users (id) ON DELETE CASCADE,
                location_id INTEGER     NOT NULL REFERENCES locations (id) ON DELETE CASCADE,
                rating      SMALLINT    NOT NULL CHECK (rating BETWEEN 1 AND 5),
                created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
                updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
                PRIMARY KEY (user_id, location_id)
            )
            SQL);

        $this->addSql('CREATE INDEX location_ratings_location_id_idx ON location_ratings (location_id)');

        $this->addSql(<<<'SQL'
            COMMENT ON TABLE location_ratings IS 'Player ratings (1–5) of locations they have visited; distinct from round stars.'
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE location_ratings');
    }
}
