<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * LOCATION CLUE PROVENANCE
 */
final class Version20261009120700 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Store the public source URL used to prepare each location description and clue';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('ALTER TABLE locations ADD content_source_url TEXT DEFAULT NULL');
        $this->addSql(<<<'SQL'
            COMMENT ON COLUMN locations.content_source_url IS 'Public page used to prepare the description and hint1; null means the source dataset itself.'
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE locations DROP COLUMN content_source_url');
    }
}
