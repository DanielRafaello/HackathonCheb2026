<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * DISTRICTS
 */
final class Version20261009120100 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Create districts table';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            CREATE TABLE districts (
                district_id   INTEGER PRIMARY KEY,
                name          TEXT    NOT NULL,
                district_code TEXT    NOT NULL UNIQUE
            )
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE districts');
    }
}
