<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * MUNICIPALITIES
 *
 * Czech ORP (obce s rozšířenou působností) — the municipality-level fields
 * available in the source CSV.
 */
final class Version20261009120200 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Create municipalities table';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            CREATE TABLE municipalities (
                municipality_id   INTEGER PRIMARY KEY,
                district_id       INTEGER NOT NULL REFERENCES districts (district_id)
                    ON UPDATE CASCADE ON DELETE RESTRICT,
                name              TEXT    NOT NULL,
                municipality_code TEXT    NOT NULL UNIQUE,
                UNIQUE (municipality_id, district_id)
            )
            SQL);

        $this->addSql(<<<'SQL'
            COMMENT ON TABLE municipalities IS 'Municipalities with extended powers (ORP), mapped from the available CSV fields.'
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE municipalities');
    }
}
