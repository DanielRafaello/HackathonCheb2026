<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * LOCATION CLUES
 */
final class Version20261009120500 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Replace location keywords with two clue columns';
    }

    public function up(Schema $schema): void
    {
        $this->addSql('DROP INDEX locations_keywords_gin_idx');
        $this->addSql("ALTER TABLE locations ADD hint1 TEXT NOT NULL DEFAULT '', ADD hint2 TEXT NOT NULL DEFAULT ''");
        $this->addSql('ALTER TABLE locations ALTER COLUMN hint1 DROP DEFAULT, ALTER COLUMN hint2 DROP DEFAULT');
        $this->addSql('ALTER TABLE locations DROP COLUMN keywords');

        $this->addSql(<<<'SQL'
            COMMENT ON COLUMN locations.hint1 IS 'Short clue derived from the location description without naming the location.'
            SQL);
        $this->addSql(<<<'SQL'
            COMMENT ON COLUMN locations.hint2 IS 'Numeric clue; normally the municipality population band as of 1 January 2026.'
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            ALTER TABLE locations
                ADD keywords JSONB NOT NULL DEFAULT '[]'::jsonb
                    CHECK (jsonb_typeof(keywords) = 'array')
            SQL);
        $this->addSql('CREATE INDEX locations_keywords_gin_idx ON locations USING GIN (keywords)');
        $this->addSql('ALTER TABLE locations DROP COLUMN hint2, DROP COLUMN hint1');
    }
}
