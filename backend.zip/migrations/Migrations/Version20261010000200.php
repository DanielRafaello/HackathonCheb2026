<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261010000200 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Store daily guessing state and guesses in user_locations';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            ALTER TABLE user_locations
                DROP CONSTRAINT user_locations_pkey,
                ADD id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                ADD daily_date DATE NULL,
                ADD attempts SMALLINT NOT NULL DEFAULT 0
                    CHECK (attempts BETWEEN 0 AND 5)
            SQL);
        $this->addSql('CREATE INDEX user_locations_user_location_idx ON user_locations (user_id, location_id)');
        $this->addSql(<<<'SQL'
            CREATE UNIQUE INDEX user_locations_user_daily_date_uidx
                ON user_locations (user_id, daily_date)
                WHERE daily_date IS NOT NULL
            SQL);

        $this->addSql(<<<'SQL'
            CREATE TABLE user_location_guesses (
                id               BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                user_location_id BIGINT           NOT NULL REFERENCES user_locations (id) ON DELETE CASCADE,
                attempt_number   SMALLINT         NOT NULL CHECK (attempt_number BETWEEN 1 AND 5),
                latitude         DOUBLE PRECISION NOT NULL CHECK (latitude BETWEEN -90 AND 90),
                longitude        DOUBLE PRECISION NOT NULL CHECK (longitude BETWEEN -180 AND 180),
                distance_meters  DOUBLE PRECISION NOT NULL CHECK (distance_meters >= 0),
                direction        VARCHAR(2)       NULL CHECK (direction IN ('N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW')),
                is_hit           BOOLEAN          NOT NULL,
                created_at       TIMESTAMPTZ      NOT NULL DEFAULT now(),
                UNIQUE (user_location_id, attempt_number),
                CHECK ((is_hit AND direction IS NULL) OR (NOT is_hit AND direction IS NOT NULL))
            )
            SQL);
        $this->addSql(<<<'SQL'
            CREATE INDEX user_location_guesses_user_location_id_idx
                ON user_location_guesses (user_location_id)
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE user_location_guesses');
        $this->addSql('DROP INDEX user_locations_user_daily_date_uidx');
        $this->addSql('DROP INDEX user_locations_user_location_idx');
        $this->addSql(<<<'SQL'
            ALTER TABLE user_locations
                DROP COLUMN attempts,
                DROP COLUMN daily_date,
                DROP COLUMN id,
                ADD PRIMARY KEY (user_id, location_id)
            SQL);
    }
}
