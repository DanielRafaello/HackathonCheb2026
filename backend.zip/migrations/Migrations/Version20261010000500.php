<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261010000500 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Add the wafers balance to users and credit existing hits and visits';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            ALTER TABLE users
                ADD COLUMN wafers INTEGER NOT NULL DEFAULT 0,
                ADD CONSTRAINT users_wafers_check CHECK (wafers >= 0)
            SQL);

        // Keep in sync with Scoring::WAFERS_PER_STAR and Scoring::VISIT_WAFERS:
        // every round hit earns 2 wafers per star (stars = max(1, 6 - attempts)),
        // every visited location 50 wafers once.
        $this->addSql(<<<'SQL'
            UPDATE users u
            SET wafers = COALESCE((
                    SELECT SUM(2 * GREATEST(1, 6 - ul.attempts))
                    FROM user_locations ul
                    WHERE ul.user_id = u.id
                      AND ul.daily_date IS NOT NULL
                      AND ul.guessed_at IS NOT NULL
                      AND ul.attempts >= 1
                ), 0)
                + 50 * (
                    SELECT COUNT(DISTINCT ul.location_id)
                    FROM user_locations ul
                    WHERE ul.user_id = u.id
                      AND ul.visited_at IS NOT NULL
                )
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->addSql('ALTER TABLE users DROP COLUMN wafers');
    }
}
