<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * LOCATIONS
 */
final class Version20261009120400 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Create locations table';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            CREATE TABLE locations (
                id               INTEGER          PRIMARY KEY,
                source_id        INTEGER          NOT NULL REFERENCES sources (source_id)
                    ON UPDATE CASCADE ON DELETE RESTRICT,
                source_record_id TEXT             NOT NULL,
                name             TEXT             NOT NULL,
                district_id      INTEGER          NOT NULL REFERENCES districts (district_id)
                    ON UPDATE CASCADE ON DELETE RESTRICT,
                municipality_id  INTEGER          NOT NULL,
                category_id      INTEGER          NOT NULL REFERENCES categories (category_id)
                    ON UPDATE CASCADE ON DELETE RESTRICT,
                longitude        DOUBLE PRECISION NOT NULL CHECK (longitude BETWEEN -180 AND 180),
                latitude         DOUBLE PRECISION NOT NULL CHECK (latitude BETWEEN -90 AND 90),
                description      TEXT             NOT NULL,
                keywords         JSONB            NOT NULL DEFAULT '[]'::jsonb
                    CHECK (jsonb_typeof(keywords) = 'array'),
                UNIQUE (source_id, source_record_id),
                FOREIGN KEY (municipality_id, district_id)
                    REFERENCES municipalities (municipality_id, district_id)
                    ON UPDATE CASCADE ON DELETE RESTRICT
            )
            SQL);

        $this->addSql(<<<'SQL'
            COMMENT ON COLUMN locations.source_record_id IS 'Record identifier in the referenced source file.'
            SQL);

        $this->addSql('CREATE INDEX locations_category_id_idx ON locations (category_id)');
        $this->addSql('CREATE INDEX locations_district_id_idx ON locations (district_id)');
        $this->addSql('CREATE INDEX locations_municipality_id_idx ON locations (municipality_id)');
        $this->addSql('CREATE INDEX locations_source_id_idx ON locations (source_id)');
        $this->addSql('CREATE INDEX locations_coordinates_idx ON locations (latitude, longitude)');
        $this->addSql('CREATE INDEX locations_keywords_gin_idx ON locations USING GIN (keywords)');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE locations');
    }
}
