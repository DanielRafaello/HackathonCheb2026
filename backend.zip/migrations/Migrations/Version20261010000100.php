<?php

declare(strict_types=1);

namespace App\Migrations\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * SOURCE PROVENANCE
 */
final class Version20261010000100 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Add provenance, licence, retrieval, and version metadata to sources';
    }

    public function up(Schema $schema): void
    {
        $this->addSql(<<<'SQL'
            ALTER TABLE sources
                ADD external_id TEXT NULL,
                ADD title TEXT NULL,
                ADD portal_url TEXT NULL,
                ADD publisher TEXT NULL,
                ADD license_code TEXT NULL,
                ADD license_url TEXT NULL,
                ADD attribution_text TEXT NULL,
                ADD retrieved_at TIMESTAMP(0) WITH TIME ZONE NULL,
                ADD source_updated_at TIMESTAMP(0) WITH TIME ZONE NULL
            SQL);

        $this->addSql('CREATE UNIQUE INDEX sources_external_id_uidx ON sources (external_id) WHERE external_id IS NOT NULL');
        $this->addSql('CREATE UNIQUE INDEX sources_portal_url_uidx ON sources (portal_url) WHERE portal_url IS NOT NULL');

        $this->addSql(<<<'SQL'
            COMMENT ON COLUMN sources.external_id IS 'Stable item identifier assigned by the source portal.'
            SQL);
        $this->addSql(<<<'SQL'
            COMMENT ON COLUMN sources.portal_url IS 'Canonical public metadata page for the source dataset.'
            SQL);
        $this->addSql(<<<'SQL'
            COMMENT ON COLUMN sources.retrieved_at IS 'Time at which the imported source file was downloaded.'
            SQL);
        $this->addSql(<<<'SQL'
            COMMENT ON COLUMN sources.source_updated_at IS 'Last-modified timestamp reported by the source portal; used as the source version.'
            SQL);
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP INDEX sources_portal_url_uidx');
        $this->addSql('DROP INDEX sources_external_id_uidx');
        $this->addSql(<<<'SQL'
            ALTER TABLE sources
                DROP COLUMN source_updated_at,
                DROP COLUMN retrieved_at,
                DROP COLUMN attribution_text,
                DROP COLUMN license_url,
                DROP COLUMN license_code,
                DROP COLUMN publisher,
                DROP COLUMN portal_url,
                DROP COLUMN title,
                DROP COLUMN external_id
            SQL);
    }
}
