<?php

declare(strict_types=1);

namespace App\Migrations\Seeders;

use Doctrine\DBAL\Connection;

class SourceSeeder
{
    public function __construct(private Connection $db)
    {
    }

    public function run(): void
    {
        $json = file_get_contents(__DIR__ . '/data/sources.json');
        if ($json === false) {
            throw new \RuntimeException('Cannot read data/sources.json');
        }

        $sources = json_decode($json, true, flags: JSON_THROW_ON_ERROR);

        foreach ($sources as $source) {
            $this->db->executeStatement(<<<'SQL'
                INSERT INTO sources (
                    source_id,
                    external_id,
                    title,
                    file_name,
                    portal_url,
                    publisher,
                    license_code,
                    license_url,
                    attribution_text,
                    retrieved_at,
                    source_updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (source_id) DO UPDATE SET
                    external_id = EXCLUDED.external_id,
                    title = EXCLUDED.title,
                    file_name = EXCLUDED.file_name,
                    portal_url = EXCLUDED.portal_url,
                    publisher = EXCLUDED.publisher,
                    license_code = EXCLUDED.license_code,
                    license_url = EXCLUDED.license_url,
                    attribution_text = EXCLUDED.attribution_text,
                    retrieved_at = EXCLUDED.retrieved_at,
                    source_updated_at = EXCLUDED.source_updated_at
                SQL, [
                    $source['source_id'],
                    $source['external_id'],
                    $source['title'],
                    $source['file_name'],
                    $source['portal_url'],
                    $source['publisher'],
                    $source['license_code'],
                    $source['license_url'],
                    $source['attribution_text'],
                    $source['retrieved_at'],
                    $source['source_updated_at'],
                ]);
        }
    }
}
