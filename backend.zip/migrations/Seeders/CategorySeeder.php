<?php

declare(strict_types=1);

namespace App\Migrations\Seeders;

use Doctrine\DBAL\Connection;

class CategorySeeder
{
    public function __construct(private Connection $db)
    {
    }

    public function run(): void
    {
        // [category_id, name]
        $categories = [
            [1, 'Hrady, tvrze a zříceniny'],
            [2, 'Koupací místa'],
            [3, 'Lanová a zábavní centra'],
            [4, 'Letiště'],
            [5, 'Památkově chráněná území'],
        ];

        foreach ($categories as $category) {
            $this->db->executeStatement(<<<'SQL'
                INSERT INTO categories (category_id, name) VALUES (?, ?)
                ON CONFLICT (category_id) DO UPDATE SET
                    name = EXCLUDED.name
                SQL, $category);
        }
    }
}
