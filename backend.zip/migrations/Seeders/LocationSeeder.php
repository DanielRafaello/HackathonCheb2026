<?php

declare(strict_types=1);

namespace App\Migrations\Seeders;

use Doctrine\DBAL\Connection;

class LocationSeeder
{
    public function __construct(private Connection $db)
    {
    }

    public function run(): void
    {
        // 112 locations from five regional datasets. hint1 is a distinctive
        // category-free fact and hint2 narrows the area by distance from the
        // district capital. The JSON is handed to PostgreSQL as-is, so
        // coordinates are parsed by the database and never pass through PHP floats.
        $json = file_get_contents(__DIR__ . '/data/locations.json');
        if ($json === false) {
            throw new \RuntimeException('Cannot read data/locations.json');
        }

        $this->db->executeStatement(<<<'SQL'
            INSERT INTO locations (id, source_id, source_record_id, name, district_id, orp_id, category_id, longitude, latitude, description, hint1, hint2, content_source_url)
            SELECT id, source_id, source_record_id, name, district_id, orp_id, category_id, longitude, latitude, description, hint1, hint2, content_source_url
            FROM jsonb_to_recordset(CAST(? AS jsonb)) AS l (
                id               INTEGER,
                source_id        INTEGER,
                source_record_id TEXT,
                name             TEXT,
                district_id      INTEGER,
                orp_id           INTEGER,
                category_id      INTEGER,
                longitude        DOUBLE PRECISION,
                latitude         DOUBLE PRECISION,
                description      TEXT,
                hint1            TEXT,
                hint2            TEXT,
                content_source_url TEXT
            )
            ON CONFLICT (id) DO UPDATE SET
                source_id = EXCLUDED.source_id,
                source_record_id = EXCLUDED.source_record_id,
                name = EXCLUDED.name,
                district_id = EXCLUDED.district_id,
                orp_id = EXCLUDED.orp_id,
                category_id = EXCLUDED.category_id,
                longitude = EXCLUDED.longitude,
                latitude = EXCLUDED.latitude,
                description = EXCLUDED.description,
                hint1 = EXCLUDED.hint1,
                hint2 = EXCLUDED.hint2,
                content_source_url = EXCLUDED.content_source_url
            SQL, [$json]);

        // Schools are deliberately outside the playable catalog. These targeted
        // deletes also clean up installations seeded before they were removed.
        $this->db->executeStatement('DELETE FROM locations WHERE category_id = 6');
        $this->db->executeStatement('DELETE FROM categories WHERE category_id = 6');
        $this->db->executeStatement('DELETE FROM sources WHERE source_id = 6');
    }
}
