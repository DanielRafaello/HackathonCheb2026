<?php

declare(strict_types=1);

namespace App\Migrations\Seeders;

use Doctrine\DBAL\Connection;

class DistrictSeeder
{
    public function __construct(private Connection $db)
    {
    }

    public function run(): void
    {
        // [district_id, name, district_code]
        $districts = [
            [1, 'Cheb', 'CZ0411'],
            [2, 'Karlovy Vary', 'CZ0412'],
            [3, 'Sokolov', 'CZ0413'],
        ];

        foreach ($districts as $district) {
            $this->db->executeStatement(<<<'SQL'
                INSERT INTO districts (district_id, name, district_code) VALUES (?, ?, ?)
                ON CONFLICT (district_id) DO UPDATE SET
                    name = EXCLUDED.name,
                    district_code = EXCLUDED.district_code
                SQL, $district);
        }
    }
}
