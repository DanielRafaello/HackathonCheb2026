<?php

declare(strict_types=1);

namespace App\Migrations\Seeders;

use Doctrine\DBAL\Connection;

class OrpSeeder
{
    public function __construct(private Connection $db)
    {
    }

    public function run(): void
    {
        // Czech ORPs (obce s rozšířenou působností)
        // [orp_id, district_id, name, orp_code]
        $orps = [
            [1, 1, 'Aš', '4101'],
            [2, 1, 'Cheb', '4102'],
            [3, 2, 'Karlovy Vary', '4103'],
            [4, 3, 'Kraslice', '4104'],
            [5, 1, 'Mariánské Lázně', '4105'],
            [6, 2, 'Ostrov', '4106'],
            [7, 3, 'Sokolov', '4107'],
        ];

        foreach ($orps as $orp) {
            $this->db->executeStatement(<<<'SQL'
                INSERT INTO orps (orp_id, district_id, name, orp_code) VALUES (?, ?, ?, ?)
                ON CONFLICT (orp_id) DO UPDATE SET
                    district_id = EXCLUDED.district_id,
                    name = EXCLUDED.name,
                    orp_code = EXCLUDED.orp_code
                SQL, $orp);
        }
    }
}
