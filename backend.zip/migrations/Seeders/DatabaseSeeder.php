<?php

declare(strict_types=1);

namespace App\Migrations\Seeders;

use Doctrine\DBAL\Connection;

class DatabaseSeeder
{
    public function __construct(private Connection $db)
    {
    }

    public function run(): void
    {
        // Calling seeders in one transaction, lookup tables first (locations reference them)
        $this->db->transactional(function (): void {
            $this->call(CategorySeeder::class);
            $this->call(DistrictSeeder::class);
            $this->call(OrpSeeder::class);
            $this->call(SourceSeeder::class);
            $this->call(LocationSeeder::class);
            // $this->call(AnotherSeeder::class);
        });
    }

    /**
     * Helping method for purer calling and log
     */
    private function call(string $seederClass): void
    {
        // Getting pure name of class without namespace
        $className = substr(strrchr($seederClass, '\\'), 1) ?: $seederClass;
        echo " -> Launching {$className}...\n";

        // Create insance of seeder and run it with database connection
        $seeder = new $seederClass($this->db);
        $seeder->run();
    }
}
