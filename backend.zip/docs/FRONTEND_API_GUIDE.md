# Frontend API guide

This guide describes how the frontend should use the current backend API. For the complete request and response schemas, see [API_SPECIFICATION.md](API_SPECIFICATION.md).

## Client configuration

- Development base URL: `http://localhost:8080`
- Development multiplayer socket URL: `ws://localhost:8090/ws` (see [Multiplayer client flow](#multiplayer-client-flow))
- Send and accept JSON with `Content-Type: application/json` and `Accept: application/json`.
- Store the base URL in environment configuration rather than hard-coding it.
- Protected gameplay and account endpoints require an access token:

```http
Authorization: Bearer <access-token>
```

The access token expires after one hour. The refresh token expires after 30 days and is rotated every time it is used.

Registration and login need no token. Refresh and logout receive the refresh token in their JSON body rather than the access-token header.

## Recommended application flow

```mermaid
sequenceDiagram
    participant UI as Frontend
    participant API as Backend API

    UI->>API: POST /auth/login
    API-->>UI: Access token, refresh token, user
    UI->>API: GET /rounds/daily
    API-->>UI: Today's round

    loop While the round is active
        UI->>API: POST /rounds/{roundId}/guesses
        API-->>UI: Guess result and updated round
    end

    UI->>API: GET /locations
    API-->>UI: Locations with guessed/visited state
```

On application startup:

1. Restore the saved tokens, if present.
2. Load the current user with `GET /me` if the frontend needs to validate the session or refresh the user profile.
3. Request `GET /rounds/daily` when the player opens the daily game.
4. Render the returned round based on its `status`.
5. Submit each placed pin to `POST /rounds/{id}/guesses`.
6. Use `GET /locations` only for the player's map or progress screens.

Do not cache the daily-round response across accounts or calendar days. The backend uses the `Europe/Prague` date when deciding which round is today's round.

## Authentication

### Register

```http
POST /auth/register
```

```json
{
  "name": "Player",
  "email": "player@example.com",
  "password": "secret-password",
  "password_confirm": "secret-password"
}
```

### Log in

```http
POST /auth/login
```

```json
{
  "email": "player@example.com",
  "password": "secret-password"
}
```

Registration and login return both tokens and the user:

```json
{
  "token": "<access-token>",
  "refresh_token": "<refresh-token>",
  "user": {
    "id": 7,
    "name": "Player",
    "email": "player@example.com",
    "role": "user"
  }
}
```

Store both tokens securely. Do not store them in application logs or error reports.

### Refresh an expired access token

```http
POST /auth/refresh
```

```json
{
  "refreshToken": "<current-refresh-token>"
}
```

The response contains a new access token and a new refresh token. Replace both stored tokens together because the previous refresh token becomes invalid.

The HTTP client should handle `401 Unauthorized` as follows:

1. Allow only one refresh request at a time, even if several API calls fail together.
2. Replace both tokens after a successful refresh.
3. Retry each failed request once with the new access token.
4. If refresh fails, clear the local session and show the login screen.

Never keep retrying a request after a second `401` response.

### Log out

```http
POST /auth/logout
```

```json
{
  "refreshToken": "<current-refresh-token>"
}
```

After the request, clear both tokens locally even if the session has already expired.

## Daily round

### Obtain or create today's round

```http
GET /rounds/daily
```

The backend randomly selects a location that the user has not guessed before and creates a `user_locations` row for today's date. Repeated calls on the same date return the same round. After midnight, the endpoint selects a new daily location even if the previous round was not completed.

An active response has this shape:

```json
{
  "round": {
    "id": 15,
    "status": "active",
    "daily_date": "2026-10-10",
    "attempts_used": 0,
    "attempts_remaining": null,
    "max_attempts": null,
    "compass_active": false,
    "stars": null,
    "clues": [
      {
        "position": 1,
        "type": "distinctive_fact",
        "text": "A treasure remained hidden beneath a chapel floor for decades."
      }
    ],
    "completed_at": null,
    "last_guess": null
  }
}
```

The backend exposes only the clues currently unlocked by the number of attempts. The frontend should render `clues` exactly as returned rather than unlocking clues locally.

The location identity and its coordinates are intentionally absent while the round is active. They are included only after the round is guessed.

### Round ID versus location ID

These IDs represent different resources:

- `round.id` is the `user_locations` row ID. Use it in `/rounds/{id}` and `/rounds/{id}/guesses`.
- `location.id` identifies the actual place. Use it in `/locations/{id}/progress`.

Do not submit a location ID to a round endpoint.

### Resume a known round

```http
GET /rounds/{roundId}
```

Use this endpoint when the frontend already has a round ID and needs its latest state, for example after returning from the background. On a fresh game-screen load, prefer `GET /rounds/daily`, because it is authoritative after midnight.

An unfinished round from an earlier date is returned as `expired`. The frontend must disable guessing for it and request `/rounds/daily` to obtain the new daily round.

### Submit a guess

```http
POST /rounds/{roundId}/guesses
```

Send the WGS 84 coordinates of the pin placed by the player:

```json
{
  "latitude": 50.2319,
  "longitude": 12.8710
}
```

The backend validates the coordinate ranges, calculates the distance and direction, increments the attempt count, and decides whether the guess is a hit. It withholds the distance and direction for the first three misses. The third miss reveals the generated fourth clue with the first and last letter of the location name. The fourth miss activates the compass, and every later miss returns compass feedback.

```json
{
  "guess": {
    "attempt_number": 1,
    "hit": false,
    "distance_meters": null,
    "direction": null,
    "compass_active": false
  },
  "round": {
    "id": 15,
    "status": "active",
    "daily_date": "2026-10-10",
    "attempts_used": 1,
    "attempts_remaining": null,
    "max_attempts": null,
    "compass_active": false,
    "stars": null,
    "clues": [
      {
        "position": 1,
        "type": "distinctive_fact",
        "text": "A treasure remained hidden beneath a chapel floor for decades."
      },
      {
        "position": 2,
        "type": "category",
        "text": "Hrady, tvrze a zříceniny"
      }
    ],
    "completed_at": null,
    "last_guess": {
      "attempt_number": 1,
      "hit": false,
      "distance_meters": null,
      "direction": null,
      "compass_active": false
    }
  }
}
```

Always replace the frontend's round state with the returned `round` object. Do not calculate attempts, stars, clue visibility, distance, direction, compass activation, or success locally. A guess is successful when the backend calculates a distance of at most 3,000 metres. The response carries `wafers_earned` (2 per star of a hit, otherwise 0); show it, do not compute it. The balance is `wafers` in `GET /me` and `GET /me/profile`, and a first visit through `POST /locations/{id}/progress` also returns `wafers_earned` (50). `attempts_remaining` and `max_attempts` are `null` because there is no attempt limit. Render compass feedback only when `guess.compass_active` is `true`.

The first three misses unlock the remaining clues. After the third miss, render the returned `name_edges` clue; do not derive it in the client. A fourth miss sets `round.compass_active` and `guess.compass_active` to `true`. Further misses leave the round active indefinitely. The location is never revealed because of the number of misses. A hit on attempts 1–5 awards 5–1 stars; every later hit awards the minimum of 1 star.

Do not automatically retry a guess after a network timeout. The first request may have reached the server and consumed an attempt even if its response was lost. Fetch `GET /rounds/{roundId}` first and let the player decide whether another guess is needed.

### Render round states

- `active`: show the returned clues and map, allow another guess, and show distance/direction only when `compass_active` is true.
- `guessed`: show the result, stars, and revealed `location`; disable guessing.
- `expired`: explain that the date changed, disable guessing, and load `/rounds/daily` for the current day.

After a round is `guessed`, the response includes the location and source attribution:

```json
{
  "location": {
    "id": 42,
    "name": "Location name",
    "latitude": 50.0,
    "longitude": 12.0,
    "category": "Hrady, tvrze a zříceniny",
    "description": "Location description",
    "content_source_url": "https://example.com/source",
    "source": {
      "title": "Dataset title",
      "publisher": "Publisher",
      "portal_url": "https://example.com/dataset",
      "license_code": "CC BY 4.0",
      "license_url": "https://creativecommons.org/licenses/by/4.0/",
      "attribution_text": "Required attribution",
      "retrieved_at": "2026-10-09T00:00:00+00:00",
      "source_updated_at": null
    }
  }
}
```

Use the attribution fields wherever the product displays the source of the revealed location.

## Locations and player progress

### Load the player's map

```http
GET /locations
```

This returns the location catalogue together with the current user's guessed and visited states and timestamps. Use it for the player's progress/map screen.

This endpoint exposes location names and coordinates, so do not call it from the active guessing screen or keep its response in state available to game-screen code. Doing so could reveal the answer before the round is complete.

### Load a place card

```http
GET /locations/{locationId}/description
```

Returns the description, category, and primary data source of a location the player has guessed or visited, in the same shape as `round.location` after a hit. Call it when the player opens the card of such a location and the client has not kept the card from the hit, for example after a hit on another device. A location in the fog answers `403 location.in_fog`; show its name and position from `GET /locations` only.

### Mark progress

```http
POST /locations/{locationId}/progress
```

```json
{
  "state": "visited"
}
```

`state` accepts `guessed` or `visited`. The operation is idempotent, and the backend supplies the timestamp.

A successful round already marks its location as guessed. Do not make a second progress request after a successful guess. Use this endpoint for explicit progress actions, such as marking a place as visited. The current endpoint records the user's action; it does not verify their physical GPS position.

## Multiplayer client flow

The multiplayer game uses a WebSocket to the socket server, not the HTTP API. The full message reference is [API_SPECIFICATION.md](API_SPECIFICATION.md) §7.

### Connect and say hello

1. Open `ws://localhost:8090/ws` in development or `wss://aether217.zcu.cz/ws` in production. Read the URL from configuration (`MULTIPLAYER_URL`), not from code.
2. Send `hello` as the first message:
   - a signed-in player sends the access token. Refresh an expired token before you connect;
   - a guest sends a nickname of 2–24 characters;
   - after a reconnect, also send the `resumeToken` from the last `welcome`.
3. Wait for `welcome`. Keep `playerId`, `resumeToken`, `limits`, and `defaults`. Use `limits` and `defaults` for the settings controls instead of constants in the client.

```json
{ "type": "hello", "token": "<access-token>" }
```

If the answer is `error` with `auth.invalid_token`, refresh the access token once and send `hello` again. If the refresh fails, offer to play as a guest.

### Lobby and game

```mermaid
sequenceDiagram
    participant UI as Frontend
    participant WS as Socket server

    UI->>WS: hello
    WS-->>UI: welcome
    WS-->>UI: state (lobby null)
    UI->>WS: createLobby or joinLobby {code}
    WS-->>UI: state (lobby)
    UI->>WS: startGame (host)
    WS-->>UI: state (game, currentPlaceName)

    loop For each place, until the game ends
        UI->>WS: guess {index, latitude, longitude}
        WS-->>UI: guessResult (offset and place)
        WS-->>UI: state (next place name)
    end

    WS-->>UI: state (finished: leaderboard, places, guesses)
    UI->>WS: returnToLobby or leaveLobby
```

- Render every screen from the latest `state`. Each `state` is a complete snapshot of the lobby for this player, so replace the previous one instead of merging.
- Choose the screen from `lobby.players[self].view`: `lobby`, `game`, or `results`. `lobby` is `null` when the player is in no lobby, which includes the `state` right after `welcome`. Do not treat that first `state` as being removed from a lobby while a `createLobby` or `joinLobby` is still unanswered.
- Build the lobby link from `lobby.code` and the app route `/multiplayer/<code>`.
- Show only the host the settings controls and the start button (`lobby.hostId == lobby.selfId`).
- During the game, show `game.self.currentPlaceName` and `currentIndex + 1` of `placeCount`. When `currentIndex == placeCount`, the player has finished and waits for the others.
- Send one `guess` per place, with `index` equal to `currentIndex`, and disable the confirm button until the answer arrives. On `guess.outside_region`, let the player move the pin and confirm again.
- Show the `guessResult` (offset and place) before you move on to the next place name.
- For the countdown, compute the offset between the device clock and `serverNow` when a `state` arrives, and count down to `endsAt` with that correction. The server ends the game; do not end it in the client.
- At the end, show `game.leaderboard`, and use `game.places` and `game.guesses` for the full results.

### Reconnect

- When the connection drops, reconnect automatically and send `hello` with the `resumeToken`. The server keeps the seat for about a minute, so the player returns to the same lobby and game.
- Send the token or nickname again with the `resumeToken`, as on the first `hello`.
- If the answer includes `error` with `resume.invalid`, the seat is gone. The `hello` still succeeds as a new player. The Flutter client then sends `joinLobby` with the same code after `welcome`, so the player is back in the lobby as a new player; it shows the entry screen only when that join fails (`lobby.not_found`, `lobby.full`).
- Send `ping` to keep an idle connection alive through a proxy, and to find a connection that died without closing. The server answers `pong`. The Flutter client pings every 15 seconds and when the app returns to the foreground, and reconnects when nothing arrives within 10 seconds.
- When the server closes the connection with code `4001`, another connection resumed the same seat, for example the same player in another browser tab. Do not reconnect automatically: the two connections would keep taking the seat from each other. Tell the player that the game is open elsewhere, and resume only when they ask. When they leave instead, forget the seat stored in this tab, or entering multiplayer again there takes the seat back from the other tab.
- Keep a stored `resumeToken` per browser tab (`sessionStorage`), not in storage that all tabs share, and resume it only for the identity (account or guest) that took the seat.

### What the client must not do

- Do not compute offsets or rankings. The server does that.
- Do not cache or log place data. Before the player's own guess on a place, the client receives only its name.
- Do not record multiplayer guesses in progress or call `POST /locations/{id}/progress` for them.

## Error handling

Errors use a consistent shape:

```json
{
  "error": true,
  "status": 422,
  "message": "Validation failed.",
  "errors": {
    "latitude": "The latitude field is required."
  }
}
```

The `errors` object is present for field validation failures. Recommended frontend handling:

- `401`: refresh once, retry once, then sign out if refresh fails.
- `404`: show a generic not-found message. A round may also be inaccessible because it belongs to another user.
- `409 round.not_active`: refresh the round and disable the guess controls.
- `409 round.no_eligible_daily_location`: explain that the player has already guessed all available locations.
- `422`: attach validation messages to the relevant input or map action.
- `429`: respect the `Retry-After` header and temporarily disable repeated submission.
- `5xx` or network failure: keep the current UI state and offer a safe retry. For a guess, fetch the round state before submitting again.

## Endpoint summary

- `POST /auth/register` — create an account and receive tokens.
- `POST /auth/login` — authenticate and receive tokens.
- `POST /auth/refresh` — rotate both tokens.
- `POST /auth/logout` — revoke the refresh token.
- `GET /me` — load the authenticated user.
- `GET /rounds/daily` — obtain or create today's per-user daily round.
- `GET /rounds/{roundId}` — retrieve the latest state of a known round.
- `POST /rounds/{roundId}/guesses` — submit one pin and receive the result plus updated round.
- `GET /locations` — load all locations with the player's progress state.
- `POST /locations/{locationId}/progress` — mark a location as guessed or visited.
- `GET /locations/{locationId}/description` — the texts and source of a guessed or visited location.
- `ws://…/ws` — the multiplayer socket server (WebSocket, not HTTP); see [API_SPECIFICATION.md](API_SPECIFICATION.md) §7.

There are no free-play or skip endpoints in the current API.
