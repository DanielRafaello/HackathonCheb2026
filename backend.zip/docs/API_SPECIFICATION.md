# Kde na západě – API Specification

**Owner:** backend team.

This document is the reference for the Game API introduced in [BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md) §4. It documents the endpoints that are implemented and routed in `/app/routes.php`. The machine-readable version is [openapi.yaml](openapi.yaml). Section 7 documents the WebSocket protocol of the multiplayer socket server ([BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md) §5), which is not part of `openapi.yaml`.

| # | Endpoint              | Group     | Auth          | Purpose                                             |
|---|-----------------------|-----------|---------------|-----------------------------------------------------|
| 1 | `POST /auth/register` | Auth      | –             | Register and start a session.                       |
| 2 | `POST /auth/login`    | Auth      | –             | Sign in and start a session.                        |
| 3 | `POST /auth/refresh`  | Auth      | refresh token | Exchange a refresh token for a new token pair.      |
| 4 | `POST /auth/logout`   | Auth      | refresh token | Revoke a refresh token.                             |
| 5 | `GET /me`             | Account   | access token  | The signed-in account.                              |
| 5a | `GET /me/profile`    | Account   | access token  | The caller's profile with points and level.         |
| 6 | `GET /locations`      | Locations | access token  | All locations with the caller's guessed/visited state. |
| 7 | `POST /locations/{id}/progress` | Locations | access token | Mark a location as guessed or visited. |
| 8 | `PUT /locations/{id}/rating` | Locations | access token | Rate a visited location 1–5. |
| 8a | `GET /locations/{id}/description` | Locations | access token | The description, category and source of a guessed or visited location. |
| 9 | `GET /rounds/daily` | Rounds | access token | Obtain or resume today's daily round. |
| 10 | `GET /rounds/{id}` | Rounds | access token | Obtain a daily round's current state. |
| 11 | `POST /rounds/{id}/guesses` | Rounds | access token | Submit a WGS 84 pin guess. |
| 12 | `GET /admin/statistics/overview` | Admin | – (temporarily public) | Headline numbers of the whole game. |
| 13 | `GET /admin/statistics/locations` | Admin | – (temporarily public) | Visitors, guessers and rating of every location. |
| 14 | `GET /admin/statistics/visits` | Admin | – (temporarily public) | Visits over a year as chart data. |
| 15 | `GET /ws` (WebSocket upgrade) | Multiplayer | access token in `hello`, or a guest nickname | The multiplayer socket server; see §7. |
| 16 | `GET /ws/health` | Multiplayer | – | Health check of the socket server. |

## 1. Conventions

- **Base URL (development):** `http://localhost:8080`
- **Multiplayer socket (development):** `ws://localhost:8090/ws`; production `wss://aether217.zcu.cz/ws`. See section 7.
- **Format:** requests and responses are JSON (`Content-Type: application/json`).
- **Coordinates:** WGS 84, as `latitude` and `longitude` in decimal degrees.
- **Rate limit:** 50 requests per 60 seconds per IP address, across all endpoints.

### 1.1 Authentication

The API uses a short-lived JWT access token and a long-lived refresh token.

| Token         | Lifetime                        | How it is sent                                          |
|---------------|---------------------------------|---------------------------------------------------------|
| Access token  | 1 hour (`JWT_TTL_SECONDS`)      | `Authorization: Bearer <token>` header                  |
| Refresh token | 30 days (`REFRESH_TTL_SECONDS`) | In the JSON body of `/auth/refresh` and `/auth/logout`  |

- Refresh tokens **rotate**: every `/auth/refresh` call revokes the token it received and returns a new pair.
- **Reuse detection:** sending a refresh token that was already revoked revokes every refresh token of that account, so the player must sign in again on all devices.
- The JWT carries the claims `sub` (user id) and `role` (`user` or `admin`).

### 1.2 Errors

Every error has the same body:

```json
{
  "error": true,
  "status": 422,
  "message": "Validation failed.",
  "errors": {
    "email": "Email must be a valid email address."
  }
}
```

`errors` is present only for validation errors. It maps a field name to the first error of that field.

| Status | When                                                                  |
|--------|-----------------------------------------------------------------------|
| `401`  | Missing, invalid, or expired token; wrong credentials.                |
| `404`  | Unknown route or resource.                                            |
| `422`  | Validation failed.                                                    |
| `429`  | Rate limit exceeded. The `Retry-After` header gives the seconds to wait. |
| `500`  | Unexpected server error.                                              |

For business errors, `message` is a stable key (for example `not.found.user.invalid.credentials`) that the frontend translates. Messages from the generic validator are English sentences.

## 2. Auth

### 2.1 `POST /auth/register`

Creates an account and starts a session.

Request:

```json
{
  "name": "Dan",
  "email": "dan@example.com",
  "password": "secret-password",
  "password_confirm": "secret-password"
}
```

| Field              | Rules                                              |
|--------------------|----------------------------------------------------|
| `name`             | required, 2–100 characters                         |
| `email`            | required, valid e-mail, max 255 characters, unique |
| `password`         | required, at least 8 characters                    |
| `password_confirm` | must equal `password`                              |

Response `201`:

```json
{
  "token": "<jwt>",
  "refresh_token": "<64 hex characters>",
  "user": {
    "id": 1,
    "name": "Dan",
    "email": "dan@example.com",
    "role": "user"
  }
}
```

Errors:

| Status | `message`            | Meaning                                                                    |
|--------|----------------------|----------------------------------------------------------------------------|
| `422`  | `Validation failed.` | A field broke its rules; see `errors`.                                     |
| `422`  | `Validation failed.` | The e-mail is already registered: `errors.email` is `auth.register.email_taken`. |

### 2.2 `POST /auth/login`

Signs in and starts a session.

Request:

```json
{
  "email": "dan@example.com",
  "password": "secret-password"
}
```

Response `200`: the same body as `POST /auth/register`.

Errors:

| Status | `message`                            | Meaning                                                              |
|--------|--------------------------------------|----------------------------------------------------------------------|
| `422`  | `Validation failed.`                 | `email` or `password` is missing, or `email` is not an e-mail.       |
| `401`  | `not.found.user.invalid.credentials` | Unknown e-mail or wrong password. The two cases are not distinguished on purpose. |

### 2.3 `POST /auth/refresh`

Exchanges a refresh token for a new access token and a new refresh token. The old refresh token stops working.

Request:

```json
{
  "refreshToken": "<64 hex characters>"
}
```

Response `200`: the same body as `POST /auth/register`.

Errors:

| Status | `message`                                     | Meaning                                                               |
|--------|-----------------------------------------------|-----------------------------------------------------------------------|
| `422`  | `Validation failed.`                          | `refreshToken` is missing.                                            |
| `401`  | `invalid.refresh.token`                       | The token does not exist.                                             |
| `401`  | `invalid.expired.refresh.token`               | The token expired.                                                    |
| `401`  | `security.token_compromised.relogin_required` | The token was already used or revoked. All sessions of the account were revoked. |
| `401`  | `not.found.user`                              | The account no longer exists.                                         |

### 2.4 `POST /auth/logout`

Revokes one refresh token. Does not need an access token. An unknown token is ignored, so the call is safe to repeat.

Request:

```json
{
  "refreshToken": "<64 hex characters>"
}
```

Response `200`:

```json
{
  "logged_out": true
}
```

Errors: `422` `Validation failed.` when `refreshToken` is missing.

The access token stays valid until it expires (at most 1 hour); the client must discard it.

## 3. Account

### 3.1 `GET /me`

Returns the signed-in account. Requires `Authorization: Bearer <token>`.

Response `200`:

```json
{
  "user": {
    "id": 1,
    "name": "Dan",
    "email": "dan@example.com",
    "role": "user",
    "created_at": "2026-10-09 21:13:42.497845+00",
    "wafers": 112
  }
}
```

`created_at` is the raw database timestamp. `wafers` is the balance of the game's currency (see [Wafers](#wafers)).

Errors:

| Status | `message`                   | Meaning                                     |
|--------|-----------------------------|---------------------------------------------|
| `401`  | `Missing bearer token.`     | No `Authorization: Bearer` header.          |
| `401`  | `Invalid or expired token.` | The access token is malformed or expired.   |

### 3.2 `GET /me/profile`

Returns the caller's profile: account, points, level, and location counts. Requires `Authorization: Bearer <token>`.

Response `200`:

```json
{
  "profile": {
    "id": 1,
    "name": "Dan",
    "email": "dan@example.com",
    "created_at": "2026-10-09 21:13:42.497845+00",
    "wafers": 112,
    "points": {
      "total": 825,
      "guessing": 425,
      "visits": 400
    },
    "level": {
      "number": 3,
      "starts_at": 750,
      "next_level_at": 1500,
      "points_in_level": 75,
      "points_to_next_level": 675
    },
    "locations": {
      "guessed": 3,
      "visited": 1
    }
  }
}
```

| Field                        | Meaning                                                              |
|------------------------------|----------------------------------------------------------------------|
| `wafers`                     | The balance of wafers, the game's currency (see [Wafers](#wafers)).  |
| `points.total`               | `points.guessing` + `points.visits`.                                 |
| `level.number`               | Current level, starting at 1.                                        |
| `level.starts_at`            | Total points at which the current level began.                       |
| `level.next_level_at`        | Total points at which the next level begins.                         |
| `level.points_in_level`      | Points earned since the current level began.                         |
| `level.points_to_next_level` | Points still missing to the next level.                              |
| `locations.guessed`          | Locations the caller has guessed (including ones marked without a round). |
| `locations.visited`          | Locations the caller has visited.                                    |

A progress bar is `points_in_level / (next_level_at − starts_at)`.

#### Points

Points are **not stored**. They are computed on every call from what the caller has guessed and visited, with the rules in `App\Services\Profile\Scoring`. Changing a rule changes every profile at once.

| Achievement                         | Points |
|-------------------------------------|--------|
| Round hit on the 1st attempt        | 200    |
| Round hit on the 2nd attempt        | 150    |
| Round hit on the 3rd attempt        | 125    |
| Round hit on the 4th attempt        | 110    |
| Round hit on the 5th attempt        | 100    |
| Round hit on the 6th or any later attempt | 50 |
| Expired round (not hit by midnight) | 0      |
| Visit of a location                 | 400    |

- A round never fails. After the fifth miss the player keeps guessing with the compass, and a hit then still earns the minimum of 50 points.
- A visit is worth twice the best possible guess, because getting people to the places is the point of the game.
- Each location counts once: at most one hit and one visit, so a location is worth at most 600 points.
- A location marked as guessed through `POST /locations/{id}/progress` without playing a round earns no guess points, but counts in `locations.guessed`.
- A visit earns points whether or not the location was guessed.

#### Wafers

Wafers (UI: „oplatky“, after the Karlovy Vary spa wafers) are the game's currency. Unlike points they are **stored**, in `users.wafers`, because a later version will let players spend them; nothing spends them yet. The amounts are constants in `App\Services\Profile\Scoring`.

| Event                                   | Wafers                         |
|-----------------------------------------|--------------------------------|
| Round hit                               | 2 per star: 10, 8, 6, 4, or 2  |
| First visit of a location               | 50                             |
| Miss, repeated visit, or `guessed` through `POST /locations/{id}/progress` | 0 |

- Every round hit pays, also a later hit of a place the player guessed before. A round takes only one hit, so it pays once.
- A visit pays once per location, whether or not the location was guessed.
- `POST /rounds/{id}/guesses` and `POST /locations/{id}/progress` return `wafers_earned`, the wafers that request added.
- The migration `Version20261010000500` added the column and credited every existing hit and visit with these amounts.

#### Levels

Each level needs 250 points more than the previous one:

| Level | Starts at | Points needed for this step |
|-------|-----------|-----------------------------|
| 1     | 0         | –                           |
| 2     | 250       | 250                         |
| 3     | 750       | 500                         |
| 4     | 1 500     | 750                         |
| 5     | 2 500     | 1 000                       |
| 10    | 11 250    | 2 250                       |
| 23    | 63 250    | 5 500                       |

Level *n* starts at `125 × n × (n − 1)` points. With today's 112 locations the maximum is 67 200 points, which is level 23.

Errors: the same `401` responses as `GET /me`, and `404` `not.found.user` when the account was deleted after the token was issued.

## 4. Locations

### 4.1 `GET /locations`

Returns every location in the catalog together with the caller's progress on it. Requires `Authorization: Bearer <token>`.

The list is not paginated (currently 112 seeded locations) and is ordered by `id`.

Response `200`:

```json
{
  "locations": [
    {
      "id": 1,
      "name": "Hrad Cheb",
      "latitude": 50.081137,
      "longitude": 12.366035,
      "guessed": true,
      "guessed_at": "2026-10-09T21:13:43Z",
      "visited": false,
      "visited_at": null,
      "rating": null,
      "rated_at": null,
      "average_rating": 4.3,
      "rating_count": 12
    }
  ]
}
```

| Field        | Type            | Meaning                                                        |
|--------------|-----------------|----------------------------------------------------------------|
| `id`         | integer         | Location id.                                                   |
| `name`       | string          | Location name.                                                 |
| `latitude`   | number          | WGS 84 latitude.                                               |
| `longitude`  | number          | WGS 84 longitude.                                              |
| `guessed`    | boolean         | Whether the caller has guessed the location.                   |
| `guessed_at` | string or null  | When it was guessed (ISO 8601, UTC); `null` when not guessed.  |
| `visited`    | boolean         | Whether the caller has visited the location.                   |
| `visited_at` | string or null  | When it was visited (ISO 8601, UTC); `null` when not visited.  |
| `rating`     | integer or null | The caller's own rating, 1–5; `null` when not rated.           |
| `rated_at`   | string or null  | When the caller last set the rating (ISO 8601, UTC).           |
| `average_rating` | number or null | Average of all players' ratings, rounded to one decimal; `null` when nobody has rated it. Shown for every location, visited or not, so a player can judge whether a place is worth the trip. |
| `rating_count` | integer       | Number of players who rated the location.                      |

Progress and daily assignments are stored in `user_locations`. `guessed` and `visited` are derived from the earliest non-null `guessed_at` and `visited_at` values across the caller's rows for a location. A location with no row for the caller is returned as not guessed and not visited.

Primary dataset provenance is stored in `sources` but is not exposed by this catalog/progress endpoint. A future place-card response should return the source title, publisher, portal URL, licence code and URL, and attribution text after the round ends.

Errors: the same `401` responses as `GET /me`.

### 4.2 `POST /locations/{id}/progress`

Marks the location as guessed or visited by the caller. Requires `Authorization: Bearer <token>`.

The server sets the time; the client cannot send one. The call is idempotent: the first timestamp is kept, so marking the same state again changes nothing. A state cannot be unset.

`{id}` is the location id from `GET /locations`.

Request:

```json
{
  "state": "guessed"
}
```

| Field   | Rules                                  |
|---------|----------------------------------------|
| `state` | required, `guessed` or `visited`       |

Response `200`: the location in the same shape as in `GET /locations`, with its new state, and the wafers the call earned: 50 for the first visit of the location, otherwise 0.

```json
{
  "location": {
    "id": 12,
    "name": "Hrad Loket",
    "latitude": 50.187104,
    "longitude": 12.754285,
    "guessed": true,
    "guessed_at": "2026-10-09T21:42:14Z",
    "visited": false,
    "visited_at": null,
    "rating": null,
    "rated_at": null,
    "average_rating": null,
    "rating_count": 0
  },
  "wafers_earned": 0
}
```

The two states are independent: `visited` can be set without `guessed`.

Errors:

| Status | `message`                   | Meaning                                         |
|--------|-----------------------------|-------------------------------------------------|
| `422`  | `Validation failed.`        | `state` is missing or not one of the two values. |
| `404`  | `not.found.location`        | No location has this id.                        |
| `404`  | `Not found.`                | `{id}` is not a number.                         |
| `401`  | `Missing bearer token.`     | No `Authorization: Bearer` header.              |
| `401`  | `Invalid or expired token.` | The access token is malformed or expired.       |

### 4.3 `PUT /locations/{id}/rating`

Sets or replaces the caller's rating of a location, from 1 to 5 stars. Requires `Authorization: Bearer <token>`.

Only a location the caller has **visited** can be rated. Calling again with another value changes the rating; there is one rating per player and location. The rating is unrelated to the stars a round awards. Ratings are stored in `location_ratings`.

Request:

```json
{
  "rating": 4
}
```

| Field    | Rules                                 |
|----------|---------------------------------------|
| `rating` | required, a whole number from 1 to 5  |

Response `200`: the location in the same shape as in `GET /locations`, with the caller's rating and the updated average.

```json
{
  "location": {
    "id": 12,
    "name": "Hrad Loket",
    "latitude": 50.187104,
    "longitude": 12.754285,
    "guessed": true,
    "guessed_at": "2026-10-09T21:42:14Z",
    "visited": true,
    "visited_at": "2026-10-10T08:05:31Z",
    "rating": 4,
    "rated_at": "2026-10-10T08:06:02Z",
    "average_rating": 4.3,
    "rating_count": 12
  }
}
```

Errors:

| Status | `message`                   | Meaning                                         |
|--------|-----------------------------|-------------------------------------------------|
| `422`  | `Validation failed.`        | `rating` is missing or not a whole number from 1 to 5. |
| `422`  | `location.not_visited`      | The caller has not visited the location.        |
| `404`  | `not.found.location`        | No location has this id.                        |
| `404`  | `Not found.`                | `{id}` is not a number.                         |
| `401`  | `Missing bearer token.`     | No `Authorization: Bearer` header.              |
| `401`  | `Invalid or expired token.` | The access token is malformed or expired.       |

### 4.4 `GET /locations/{id}/description`

Returns the texts of a location's card: its description, category, and primary data source. Requires `Authorization: Bearer <token>`.

Only a location the caller has guessed or visited has its texts shown. A location in the fog (neither guessed nor visited) answers `403`, so its description cannot spoil a future round. The name and position of every location are already in `GET /locations`.

Response `200`: the same shape as `round.location` after a hit (5.3). The clues (`hint1`, `hint2`) are not part of it.

```json
{
  "location": {
    "id": 12,
    "name": "Hrad Loket",
    "latitude": 50.187104,
    "longitude": 12.754285,
    "category": "Hrady, tvrze a zříceniny",
    "description": "Gotický hrad na skále v ohbí Ohře.",
    "content_source_url": "https://example.com/hrad-loket",
    "source": {
      "title": "Hrady, tvrze a zříceniny",
      "publisher": "Karlovarský kraj",
      "portal_url": "https://datazapad.cz/…",
      "license_code": "CC BY 4.0",
      "license_url": "https://creativecommons.org/licenses/by/4.0/",
      "attribution_text": "Zdroj: datazapad.cz",
      "retrieved_at": "2026-10-09T00:00:00+00:00",
      "source_updated_at": "2026-10-08T00:00:00+00:00"
    }
  }
}
```

Errors:

| Status | `message`                   | Meaning                                              |
|--------|-----------------------------|------------------------------------------------------|
| `403`  | `location.in_fog`           | The caller has neither guessed nor visited the location. |
| `404`  | `not.found.location`        | No location has this id.                             |
| `404`  | `Not found.`                | `{id}` is not a number.                              |
| `401`  | `Missing bearer token.`     | No `Authorization: Bearer` header.                   |
| `401`  | `Invalid or expired token.` | The access token is malformed or expired.            |

## 5. Rounds

All round endpoints require `Authorization: Bearer <token>`. A round belongs to the caller; requesting another caller's id returns `404` without revealing whether it exists.

An active or expired round returns only gameplay state and unlocked clues. The hidden location is included only after the status changes to `guessed`.

### 5.1 `GET /rounds/daily`

Returns the caller's assignment for the current `Europe/Prague` date. If none exists, the backend randomly selects a location that the caller has not successfully guessed and inserts a `user_locations` row. Different callers receive independent random selections. Repeated calls on the same date return the same row and do not consume an attempt. After midnight, a new row is created even when the previous day was unfinished.

Response `200`:

```json
{
  "round": {
    "id": 15,
    "status": "active",
    "daily_date": "2026-10-10",
    "attempts_used": 0,
    "attempts_remaining": null,
    "max_attempts": null,
    "compass_active": false,
    "stars": null,
    "clues": [
      {
        "position": 1,
        "type": "distinctive_fact",
        "text": "Vzácný relikviář zde zůstal ukrytý čtyřicet let."
      }
    ],
    "completed_at": null,
    "last_guess": null
  }
}
```

Error `409` with `message: round.no_eligible_daily_location` means the caller has already guessed every catalog location.

### 5.2 `GET /rounds/{id}`

Returns the current state of the caller's daily assignment. An unfinished assignment from an earlier Prague date has status `expired` and cannot accept more guesses.

Response `200`: the same round representation as `GET /rounds/daily`.

Error `404` with `message: not.found.round` means the round does not exist or belongs to somebody else.

### 5.3 `POST /rounds/{id}/guesses`

Stores a placed map pin and evaluates it against the hidden target.

Request:

```json
{
  "latitude": 50.123456,
  "longitude": 12.654321
}
```

Both coordinates are required numbers in the WGS 84 ranges `-90…90` and `-180…180`.

Response `200` after the first miss:

```json
{
  "guess": {
    "attempt_number": 1,
    "hit": false,
    "distance_meters": null,
    "direction": null,
    "compass_active": false
  },
  "round": {
    "id": 15,
    "status": "active",
    "daily_date": "2026-10-10",
    "attempts_used": 1,
    "attempts_remaining": null,
    "max_attempts": null,
    "compass_active": false,
    "stars": null,
    "clues": [
      {"position": 1, "type": "distinctive_fact", "text": "…"},
      {"position": 2, "type": "category", "text": "Hrady, tvrze a zříceniny"}
    ],
    "completed_at": null,
    "last_guess": {
      "attempt_number": 1,
      "hit": false,
      "distance_meters": null,
      "direction": null,
      "compass_active": false
    }
  },
  "wafers_earned": 0
}
```

`wafers_earned` is 2 per star for a hit (10 for a first-attempt hit, 2 with the compass) and 0 for a miss.

A guess at most 3,000 metres away is a hit. Its direction is `null`, the round becomes `guessed`, and stars are `max(1, 6 - attempt_number)`. The first three misses deliberately return `distance_meters: null`, `direction: null`, and `compass_active: false`; they progressively reveal the category, area-narrowing, and generated name-edge clues. The fourth miss activates the compass; that miss and every later miss return the calculated distance and direction with `compass_active: true`.

There is no maximum attempt count. A miss always leaves the round `active`, does not reveal the location, and allows another guess until the player hits the target or the daily round expires at Prague midnight. Only a hit adds `location` to the round:

```json
{
  "location": {
    "id": 12,
    "name": "Hrad Loket",
    "latitude": 50.187104,
    "longitude": 12.754285,
    "category": "Hrady, tvrze a zříceniny",
    "description": "…",
    "content_source_url": "https://example.test/place",
    "source": {
      "title": "…",
      "publisher": "…",
      "portal_url": "…",
      "license_code": "CC BY 4.0",
      "license_url": "…",
      "attribution_text": "…",
      "retrieved_at": "2026-10-09T00:00:00+00:00",
      "source_updated_at": "2026-10-08T00:00:00+00:00"
    }
  }
}
```

A hit automatically records the location as guessed in the same `user_locations` row. Errors are `404 not.found.round`, `409 round.not_active`, or `422 Validation failed.`.

## 6. Admin statistics

> **Temporarily public.** For the presentation the three endpoints of this section need no token: `AdminOnlyMiddleware` and `JwtAuthMiddleware` are commented out on the `/admin/statistics` group in `app/routes.php`. The access rules below describe the intended state and apply again once the two middlewares are restored.

Game-wide statistics for administrators. Every endpoint in this section requires `Authorization: Bearer <token>` of a user whose role is `admin`.

- The role is read from the access token. After a role change in the database, the user must sign in again (or refresh the token) for it to take effect.
- There is no endpoint for granting the role. An administrator is made in the database: `UPDATE users SET role = 'admin' WHERE email = '…'`.
- Everywhere below, a **visit** is one user having visited one location. It counts once and is dated by the first time it happened, however many rounds the user played on that location.

Errors shared by all three endpoints:

| Status | `message`                   | Meaning                                    |
|--------|-----------------------------|--------------------------------------------|
| `401`  | `Missing bearer token.`     | No `Authorization: Bearer` header.         |
| `401`  | `Invalid or expired token.` | The access token is malformed or expired.  |
| `403`  | `auth.forbidden.admin_only` | The caller is signed in but is not an administrator. |

### 6.1 `GET /admin/statistics/overview`

The headline numbers of the whole game.

Response `200`:

```json
{
  "overview": {
    "users": { "total": 10, "active": 6 },
    "locations": { "total": 112, "visited": 20 },
    "visits": { "total": 45 },
    "guesses": { "total": 80 },
    "ratings": { "total": 30, "average": 4.2 }
  }
}
```

| Field               | Meaning                                                              |
|---------------------|----------------------------------------------------------------------|
| `users.total`       | Registered accounts.                                                 |
| `users.active`      | Accounts that have guessed or visited at least one location.         |
| `locations.total`   | Locations in the catalog.                                            |
| `locations.visited` | Locations visited by at least one user.                              |
| `visits.total`      | Visits (user–location pairs).                                        |
| `guesses.total`     | Guessed locations (user–location pairs).                             |
| `ratings.total`     | Ratings given.                                                       |
| `ratings.average`   | Average of all ratings, 1–5 with one decimal; `null` when there are none. |

### 6.2 `GET /admin/statistics/locations`

Every location of the catalog with its popularity and rating. Ordered by `visitors` (most first), then by name. Locations nobody has touched are included with zeros. Not paginated.

Response `200`:

```json
{
  "locations": [
    {
      "id": 12,
      "name": "Hrad Loket",
      "category": "Hrady, tvrze a zříceniny",
      "visitors": 9,
      "guessed_by": 14,
      "average_rating": 4.6,
      "rating_count": 7
    }
  ]
}
```

| Field            | Meaning                                                           |
|------------------|-------------------------------------------------------------------|
| `visitors`       | Users who have visited the location.                              |
| `guessed_by`     | Users who have guessed the location.                              |
| `average_rating` | Average rating, 1–5 with one decimal; `null` when nobody rated it. |
| `rating_count`   | Number of ratings.                                                |

### 6.3 `GET /admin/statistics/visits`

Visits over one calendar year as data for a chart. The year and its periods are cut in Europe/Prague time.

Query parameters, all optional:

| Parameter     | Values              | Default          | Meaning                              |
|---------------|---------------------|------------------|--------------------------------------|
| `year`        | `2000`–`2100`       | the current year | The calendar year of the series.     |
| `granularity` | `month`, `day`      | `month`          | The size of one point of the series. |
| `location_id` | a location id       | all locations    | Limit the series to one location.    |

Response `200` for `GET /admin/statistics/visits?year=2026`:

```json
{
  "visits": {
    "year": 2026,
    "granularity": "month",
    "location_id": null,
    "total": 4,
    "series": [
      { "period": "2026-01", "visits": 0, "visitors": 0 },
      { "period": "2026-02", "visits": 0, "visitors": 0 },
      { "period": "2026-03", "visits": 2, "visitors": 1 }
    ]
  }
}
```

- `series` always covers the whole year in calendar order: 12 points for `month`, 365 or 366 for `day`. Periods without visits are present with zeros, so the array can be passed to a chart as it is.
- `period` is `YYYY-MM` for months and `YYYY-MM-DD` for days.
- `visits` counts the visits first made in the period; `visitors` the distinct users among them.
- `total` is the sum of `visits` over the series.

Additional errors:

| Status | `message`            | Meaning                                                       |
|--------|----------------------|---------------------------------------------------------------|
| `422`  | `Validation failed.` | `year` is not a whole number in range, `granularity` is unknown, or `location_id` is not a positive whole number. |
| `404`  | `not.found.location` | No location has the given `location_id`.                      |

## 7. Multiplayer protocol

The multiplayer game is not part of the HTTP Game API. It runs on the socket server described in [BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md) §5, and the client talks to it over one WebSocket connection. The rules of the game are in [PRODUCT_SPECIFICATION.md](PRODUCT_SPECIFICATION.md), Multiplayer rules. `openapi.yaml` does not describe this protocol.

### 7.1 Connection

| Environment | WebSocket URL | Health check |
|-------------|---------------|--------------|
| Development | `ws://localhost:8090/ws` | `GET http://localhost:8090/ws/health` |
| Production  | `wss://aether217.zcu.cz/ws` | `GET https://aether217.zcu.cz/ws/health` |

- The health check answers `200` with `{"status":"ok"}`. Every other HTTP request to the server answers `404`.
- When the upgrade request has an `Origin` header, it must equal one of the origins in `FRONTEND_URL`. Otherwise the server refuses the upgrade with `403`. A request without `Origin`, as sent by the mobile apps, is allowed.
- Each message is one JSON object in a text frame, at most 4 KiB. Every message has a `type` field.
- Field names are camelCase, unlike the snake_case of the HTTP API. Coordinates are WGS 84 decimal degrees. Times are epoch milliseconds on the server clock.
- One connection is one player. The first client message must be `hello`.
- When a `hello` resumes a seat that another connection holds, the server moves the seat to the new connection and closes the old one with code `4001`.
- The server pings every connection every 30 seconds and terminates a connection that does not answer with a pong. Other messages do not count as an answer; browsers and WebSocket libraries answer pings automatically.
- Each connection may send about 20 messages per 5 seconds. The server drops excess messages and answers only the first of them with `error` `rate_limited`. When the connection keeps sending until another 20 messages are dropped, the server closes it with code `1008`.
- The server terminates a connection whose unsent output grows past 2 MiB, because its client does not read.

### 7.2 Client messages

| `type` | Fields | Notes |
|--------|--------|-------|
| `hello` | `token?: string`, `nickname?: string`, `resumeToken?: string` | Must be the first message. With `token`, the player is an account: the server verifies the access token and uses `users.name` as the nickname. Without `token`, `nickname` is required: trimmed, 2–24 characters, no control characters, else `nickname.invalid`. With the `resumeToken` of a seat that is still held, the player gets that seat and its lobby back. |
| `createLobby` | – | Creates a lobby. The sender becomes its host. |
| `joinLobby` | `code: string` | Joins the lobby with this code; the code is not case-sensitive. A player in another lobby leaves it first. Joining while a game is running is allowed: the player waits in the lobby. |
| `leaveLobby` | – | Leaves the lobby and frees the seat. The `resumeToken` no longer returns the player to that lobby. |
| `updateSettings` | `settings: {maxPlayers?, placeCount?, durationSeconds?}` | Host only, not while a game is running (phase `waiting` or `finished`), within the limits from `welcome`. `maxPlayers` cannot go below the current number of players. |
| `startGame` | – | Host only. The host must be in the `lobby` view, and at least `limits.minPlayers` connected players must be in the `lobby` view. Allowed from phase `waiting` or `finished`. |
| `guess` | `index: int`, `latitude: number`, `longitude: number` | `index` must equal the sender's `currentIndex`. One guess per place. |
| `returnToLobby` | – | Moves the sender from the `results` view back to the `lobby` view. |
| `ping` | – | The server answers `pong`. |

Examples, one message per line:

```text
{ "type": "hello", "nickname": "Bára" }
{ "type": "joinLobby", "code": "k7m2qx" }
{ "type": "guess", "index": 2, "latitude": 50.187, "longitude": 12.754 }
```

### 7.3 Server messages

| `type` | Fields | When |
|--------|--------|------|
| `welcome` | `playerId: string`, `resumeToken: string`, `nickname: string`, `isGuest: bool`, `limits: {maxPlayers, minPlayers, maxPlaceCount, minDurationSeconds, maxDurationSeconds, penaltyDistanceMeters}`, `defaults: {maxPlayers, placeCount, durationSeconds}` | Answer to a successful `hello`. |
| `state` | `serverNow: number`, `lobby: LobbyView \| null` | A personalized snapshot, sent to every lobby member after every change, and right after hello, create, join, and resume. `lobby` is `null` when the player is in no lobby, for example in the `state` that follows `welcome` after a `hello` without a held seat. |
| `guessResult` | `index`, `distanceMeters`, `guess: {latitude, longitude}`, `place: PlaceReveal` | Only to the player who guessed, immediately before the next `state`. |
| `error` | `code: string`, `message?: string` | A rejected message. `code` is a stable key (section 7.5); `message` is an English hint for logs, not for the UI. |
| `pong` | – | Answer to `ping`. |

The snapshot types:

```
LobbyView {
  code: string                    // for example "K7M2QX"; the alphabet leaves out 0 O 1 I L
  hostId: string
  selfId: string
  phase: "waiting" | "playing" | "finished"   // finished = a game ended and no new game has started
  settings: { maxPlayers, placeCount, durationSeconds }
  players: [{ id, nickname, isGuest, isHost, connected, view: "lobby" | "game" | "results", guessedCount }]
  game: GameView | null           // the running game, or the last finished game until the next start
}

GameView {
  status: "playing" | "finished"
  startedAt: number, endsAt: number   // epoch ms on the server clock; correct the skew with serverNow
  placeCount: number
  participantIds: string[]
  self: {                         // null when this player is not a participant
    currentIndex: number          // = guesses made; == placeCount when done
    currentPlaceName: string | null   // name of the place at currentIndex while playing, else null
    rounds: [{ index, name, guess: {latitude, longitude} | null, distanceMeters: number | null, place: PlaceReveal | null }]
                                  // only rounds < currentIndex while playing; all rounds when finished
  } | null
  leaderboard: LeaderboardRow[] | null    // only when status == "finished"
  places: PlaceReveal[] | null            // only when finished, in game order
  guesses: { [playerId]: ({latitude, longitude, distanceMeters} | null)[] } | null   // only when finished
}

LeaderboardRow { rank, playerId, nickname, averageDistanceMeters, guessedCount, totalDistanceMeters, finishedAt: number | null }

PlaceReveal { index, id, name, latitude, longitude, category, description, contentSourceUrl: string | null,
              source: { title, publisher, portalUrl, licenseCode, licenseUrl, attributionText } }
```

- While a game is running, a snapshot never holds the coordinates or texts of a place that the player has not guessed, and never holds the guesses of other players. Other players' progress is only their `guessedCount`.
- `averageDistanceMeters` is an integer, rounded. Unguessed places count with `limits.penaltyDistanceMeters`.
- Ranks are `1…n` and unique. Ties in `averageDistanceMeters` are broken by more `guessedCount`, then the earlier `finishedAt` (the time of the last guess), then `nickname`.

### 7.4 Lifecycle

- **Views.** A player's `view` is `lobby` after create, join, or `returnToLobby`; `game` while playing as a participant; and `results` after the game ends, for its participants.
- **Start.** The participants are the connected players in the `lobby` view. A player who is still in the `results` view of the previous game stays out of the new game. If they send `returnToLobby` while it runs, they wait in the `lobby` view for the next one.
- **End.** The game ends at `endsAt` (server timer) or when every participant still in the lobby has guessed every place. Then the game `status` and the lobby `phase` become `finished`, and the participants' view becomes `results`.
- **Disconnect.** A disconnected player has `connected: false` and keeps the seat for `MP_RECONNECT_GRACE_SECONDS`. After that, the server removes them, and the host role moves to the longest-present player if needed. A participant removed during a game keeps their row in the results.
- **Empty lobby.** A lobby without players is deleted. A lobby idle for `MP_LOBBY_IDLE_TTL_SECONDS` while no game is running is deleted too.

A typical game:

```mermaid
sequenceDiagram
    participant H as Host
    participant S as Socket server
    participant P as Player

    H->>S: hello {token}
    S-->>H: welcome
    S-->>H: state (lobby null)
    H->>S: createLobby
    S-->>H: state (phase waiting)
    P->>S: hello {nickname}
    S-->>P: welcome
    S-->>P: state (lobby null)
    P->>S: joinLobby {code}
    S-->>H: state
    S-->>P: state
    H->>S: startGame
    S-->>H: state (phase playing, currentPlaceName)
    S-->>P: state (phase playing, currentPlaceName)
    P->>S: guess {index 0, latitude, longitude}
    S-->>P: guessResult (offset and place)
    S-->>P: state (next place name)
    S-->>H: state (P's guessedCount)
    Note over H,P: … until endsAt or everyone has guessed every place
    S-->>H: state (phase finished, leaderboard, places, guesses)
    S-->>P: state (phase finished, leaderboard, places, guesses)
    P->>S: returnToLobby
```

### 7.5 Errors

The server answers a rejected message with `error`. The `code` values are stable keys that the client translates, like the `message` keys of the HTTP API (section 1.2).

| `code` | Meaning |
|--------|---------|
| `hello.required` | A message other than `hello` arrived before `hello`. |
| `hello.duplicate` | A second `hello` on the same connection. |
| `auth.invalid_token` | The access token is invalid or expired, or its account does not exist. Refresh the token once and send `hello` again. |
| `nickname.invalid` | A guest `hello` without a valid nickname: 2–24 characters after trimming, no control characters. |
| `lobby.not_found` | No lobby has this code. |
| `lobby.full` | The lobby has reached its `maxPlayers`. |
| `lobby.not_in_lobby` | The message needs a lobby, but the sender is in none. Also `startGame` from a host who is still in the `results` view; send `returnToLobby` first. |
| `lobby.not_host` | Only the host may send this message. |
| `lobby.not_enough_players` | Fewer than `limits.minPlayers` connected players wait in the `lobby` view. |
| `lobby.in_game` | A game is running and does not allow the message: `startGame` or `updateSettings` while a game runs, or `returnToLobby` from a participant who is still playing. |
| `settings.invalid` | A setting is not a whole number, is outside the limits, or `maxPlayers` is below the current number of players. |
| `game.not_playing` | No game is running, or the sender is not its participant. |
| `game.no_places` | The place catalog cannot supply the places for the game. |
| `guess.invalid` | The coordinates are missing, not finite, or outside `-90…90` / `-180…180`, or `index` is not a whole number. |
| `guess.wrong_index` | `index` is not the sender's `currentIndex`, for example a second guess on the same place. |
| `guess.outside_region` | The guess lies outside the Karlovy Vary Region. It does not count; guess again. |
| `resume.invalid` | `hello` carried a `resumeToken`, but no seat is held for it. Not fatal: the `hello` still succeeds as a new player. |
| `message.invalid` | The frame is binary or not valid JSON, has an unknown `type`, or has fields of the wrong type. |
| `rate_limited` | Too many messages in a short time. The server drops them and sends this once per burst; a client that keeps sending is closed with code `1008`. |
| `server.error` | An unexpected server error, for example the database is unreachable. |
