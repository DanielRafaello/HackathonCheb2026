<?php

declare(strict_types=1);

/*
 * Pest bootstrap soubor — spouští se před každým testem.
 *
 * Tady se definují:
 *  - globální `uses()` (aby ses nemusel opakovat v každém souboru)
 *  - globální helpery (funkce dostupné v každém testu)
 *
 * Spuštění všech testů:       ./vendor/bin/pest
 * Pouze unit testy:           ./vendor/bin/pest tests/Unit
 * Pouze integrační:           ./vendor/bin/pest tests/Integration
 * Filtr podle názvu:          ./vendor/bin/pest --filter "creates domain"
 * S pokrytím kódu:            ./vendor/bin/pest --coverage
 */

// Pokud budeš mít TestCase bázovou třídu, přidej ji sem:
// uses(Tests\TestCase::class)->in('Unit', 'Integration');

use App\Domain\GameRound;
use App\Domain\GuessResult;
use App\Domain\RoundStatus;
use App\Domain\RoundTarget;
use App\Repositories\Contracts\WaferWalletInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Slim\Psr7\Factory\ServerRequestFactory;
use Slim\Psr7\Response;

// ─── Globální helpery pro HTTP vrstvu (Action, Middleware, Responder) ───

/**
 * PSR-7 request tak, jak ho dostane Action: tělo už je naparsované.
 *
 * @param array<string, mixed>|null $body
 * @param array<string, string>     $headers
 * @param array<string, mixed>      $serverParams
 */
function apiRequest(
    string $method = 'GET',
    string $path = '/',
    ?array $body = null,
    array $headers = [],
    array $serverParams = [],
): ServerRequestInterface {
    $request = (new ServerRequestFactory())->createServerRequest($method, $path, $serverParams);

    foreach ($headers as $name => $value) {
        $request = $request->withHeader($name, $value);
    }

    return $body === null ? $request : $request->withParsedBody($body);
}

/** @return array<string, mixed> */
function jsonOf(ResponseInterface $response): array
{
    return json_decode((string) $response->getBody(), true, flags: JSON_THROW_ON_ERROR);
}

/**
 * Handler na konci middleware řetězce: pamatuje si, kolikrát a s jakým
 * requestem byl zavolán, a vrací předanou (nebo prázdnou 200) odpověď.
 */
function spyHandler(?ResponseInterface $response = null): RequestHandlerInterface
{
    return new class ($response ?? new Response()) implements RequestHandlerInterface {
        public int $calls = 0;

        public ?ServerRequestInterface $request = null;

        public function __construct(private readonly ResponseInterface $response)
        {
        }

        public function handle(ServerRequestInterface $request): ResponseInterface
        {
            $this->calls++;
            $this->request = $request;

            return $this->response;
        }
    };
}

/** Kolo s tajným cílem „Tajné místo“ na 50.0, 12.0 pro uživatele 7. */
function roundFixture(
    RoundStatus $status = RoundStatus::ACTIVE,
    int $attemptsUsed = 0,
    ?int $stars = null,
    ?GuessResult $lastGuess = null,
): GameRound {
    return new GameRound(
        id: 3,
        userId: 7,
        status: $status,
        attemptsUsed: $attemptsUsed,
        stars: $stars,
        dailyDate: '2026-10-10',
        completedAt: $status->isComplete() ? '2026-10-10T12:00:00Z' : null,
        target: new RoundTarget(
            id: 42,
            name: 'Tajné místo',
            latitude: 50.0,
            longitude: 12.0,
            category: 'Hrady, tvrze a zříceniny',
            description: 'Popis místa.',
            hint1: 'První nápověda.',
            hint2: 'Třetí nápověda.',
            contentSourceUrl: 'https://example.com/place',
            sourceTitle: 'Dataset',
            sourcePublisher: 'Publisher',
            sourcePortalUrl: 'https://example.com/dataset',
            sourceLicenseCode: 'CC BY 4.0',
            sourceLicenseUrl: 'https://creativecommons.org/licenses/by/4.0/',
            sourceAttributionText: 'Attribution',
            sourceRetrievedAt: '2026-10-09T00:00:00+00:00',
            sourceUpdatedAt: '2026-10-08T00:00:00+00:00',
        ),
        lastGuess: $lastGuess,
    );
}

/** Collects the wafers a service adds, by user. */
final class InMemoryWaferWallet implements WaferWalletInterface
{
    /** @var array<int, int> */
    public array $balances = [];

    public function addWafers(int $userId, int $wafers): void
    {
        if ($wafers > 0) {
            $this->balances[$userId] = ($this->balances[$userId] ?? 0) + $wafers;
        }
    }

    public function of(int $userId): int
    {
        return $this->balances[$userId] ?? 0;
    }
}
