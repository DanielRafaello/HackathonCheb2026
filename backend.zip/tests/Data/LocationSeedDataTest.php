<?php

declare(strict_types=1);

function locationSeedRows(): array
{
    $json = file_get_contents(__DIR__ . '/../../migrations/Seeders/data/locations.json');
    if ($json === false) {
        throw new RuntimeException('Cannot read location seed data');
    }

    return json_decode($json, true, flags: JSON_THROW_ON_ERROR);
}

function sourceSeedRows(): array
{
    $json = file_get_contents(__DIR__ . '/../../migrations/Seeders/data/sources.json');
    if ($json === false) {
        throw new RuntimeException('Cannot read source seed data');
    }

    return json_decode($json, true, flags: JSON_THROW_ON_ERROR);
}

function districtCapitalReferences(): array
{
    return [
        1 => ['name' => 'Chebu', 'latitude' => 50.07935, 'longitude' => 12.370353],
        2 => ['name' => 'Karlových Varů', 'latitude' => 50.22768, 'longitude' => 12.879553],
        3 => ['name' => 'Sokolova', 'latitude' => 50.1813, 'longitude' => 12.6401],
    ];
}

function distanceInKilometres(float $latitude1, float $longitude1, float $latitude2, float $longitude2): float
{
    $earthRadius = 6371.0088;
    $latitude1Radians = deg2rad($latitude1);
    $latitude2Radians = deg2rad($latitude2);
    $latitudeDelta = deg2rad($latitude2 - $latitude1);
    $longitudeDelta = deg2rad($longitude2 - $longitude1);

    $a = sin($latitudeDelta / 2) ** 2
        + cos($latitude1Radians) * cos($latitude2Radians) * sin($longitudeDelta / 2) ** 2;

    return $earthRadius * 2 * atan2(sqrt($a), sqrt(1 - $a));
}

function expectedDistanceClue(array $row): string
{
    $reference = districtCapitalReferences()[$row['district_id']];
    $distance = distanceInKilometres(
        (float) $row['latitude'],
        (float) $row['longitude'],
        $reference['latitude'],
        $reference['longitude'],
    );

    $range = match (true) {
        $distance < 5 => 'Méně než 5 km',
        $distance < 10 => 'Přibližně 5–10 km',
        $distance < 20 => 'Přibližně 10–20 km',
        $distance < 30 => 'Přibližně 20–30 km',
        $distance < 40 => 'Přibližně 30–40 km',
        default => 'Nejméně 40 km',
    };

    return "{$range} vzdušnou čarou od centra {$reference['name']}.";
}

function categoryTermsForbiddenInHint1(): array
{
    return [
        1 => '/hrad|tvrz|zřícenin/iu',
        2 => '/koupališt|koupací|koupán/iu',
        3 => '/lanov|zábavní\s+centrum/iu',
        4 => '/letišt|dráh|létán/iu',
        5 => '/památkově\s+chráněn|chráněné\s+území/iu',
    ];
}

it('contains complete location clues without legacy keywords', function (): void {
    $rows = locationSeedRows();

    expect($rows)->toHaveCount(112);
    expect(array_column($rows, 'id'))->toBe(range(1, 112));

    foreach ($rows as $row) {
        expect($row)->not->toHaveKey('keywords');
        expect($row)->toHaveKeys(['orp_id', 'description', 'hint1', 'hint2', 'content_source_url']);
        expect($row)->not->toHaveKey('municipality_id');
        expect($row['orp_id'])->toBeInt()->toBeGreaterThanOrEqual(1)->toBeLessThanOrEqual(7);
        expect($row['description'])->not->toBeEmpty();
        expect($row['hint1'])->not->toBeEmpty();
        expect($row['hint2'])->not->toBeEmpty();

        preg_match_all('/./u', $row['hint1'], $characters);
        expect(count($characters[0]))->toBeLessThanOrEqual(100);
        expect(preg_match('/' . preg_quote($row['name'], '/') . '/iu', $row['hint1']))->toBe(0);
    }
});

it('excludes schools and records clue provenance', function (): void {
    foreach (locationSeedRows() as $row) {
        expect($row['category_id'])->not->toBe(6);
        expect($row['source_id'])->not->toBe(6);

        if (in_array($row['category_id'], [1, 2, 3, 4], true)) {
            expect(filter_var($row['content_source_url'], FILTER_VALIDATE_URL))->not->toBeFalse();
        } else {
            expect($row['content_source_url'])->toBeNull();
        }
    }
});

it('stores complete provenance for every source dataset', function (): void {
    $sources = sourceSeedRows();

    expect($sources)->toHaveCount(5);
    expect(array_column($sources, 'source_id'))->toBe(range(1, 5));
    expect(array_values(array_unique(array_column($sources, 'source_id'))))->toHaveCount(5);
    expect(array_values(array_unique(array_column($sources, 'external_id'))))->toHaveCount(5);
    expect(array_values(array_unique(array_column($sources, 'portal_url'))))->toHaveCount(5);

    $sourceIds = array_column($sources, 'source_id');
    expect(array_values(array_unique(array_column(locationSeedRows(), 'source_id'))))->toBe($sourceIds);

    foreach ($sources as $source) {
        expect($source)->toHaveKeys([
            'source_id',
            'external_id',
            'title',
            'file_name',
            'portal_url',
            'publisher',
            'license_code',
            'license_url',
            'attribution_text',
            'retrieved_at',
            'source_updated_at',
        ]);
        expect($source['external_id'])->toMatch('/^[a-f0-9]{32}$/');
        expect(filter_var($source['portal_url'], FILTER_VALIDATE_URL))->not->toBeFalse();
        expect($source['portal_url'])->toContain($source['external_id']);
        expect(filter_var($source['license_url'], FILTER_VALIDATE_URL))->not->toBeFalse();
        expect($source['license_code'])->toBeIn(['CC BY 4.0', 'CC0 1.0']);
        expect($source['attribution_text'])->toContain($source['license_code']);
        if ($source['license_code'] === 'CC BY 4.0') {
            expect($source['attribution_text'])->toContain('Data byla upravena');
        }
        expect(new DateTimeImmutable($source['retrieved_at']))
            ->toBeGreaterThan(new DateTimeImmutable($source['source_updated_at']));
    }
});

it('keeps the distinctive fact, category, and distance clue distinct', function (): void {
    foreach (locationSeedRows() as $row) {
        expect($row['hint2'])->toBe(expectedDistanceClue($row));
        expect($row['hint1'])->not->toBe($row['hint2']);
        expect(preg_match(categoryTermsForbiddenInHint1()[$row['category_id']], $row['hint1']))->toBe(0);
        expect(preg_match('/vzdušnou čarou|od centra|od města|půl kilometru od/iu', $row['hint1']))->toBe(0);
    }
});
