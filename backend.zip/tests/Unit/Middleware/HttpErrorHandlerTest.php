<?php

declare(strict_types=1);

use App\Exceptions\generalExceptions\ConflictException;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Exceptions\generalExceptions\UnauthorizedException;
use App\Exceptions\Validation\ValidationException;
use App\Middleware\HttpErrorHandler;
use Monolog\Handler\TestHandler;
use Monolog\Level;
use Monolog\Logger;
use Slim\CallableResolver;
use Slim\Exception\HttpMethodNotAllowedException;
use Slim\Exception\HttpNotFoundException;
use Slim\Psr7\Factory\ResponseFactory;

beforeEach(function (): void {
    $this->log = new TestHandler();
    $this->handler = new HttpErrorHandler(
        new CallableResolver(),
        new ResponseFactory(),
        new Logger('test', [$this->log]),
    );
});

it('turns an application exception into its status and message', function (Throwable $exception, int $status): void {
    $response = ($this->handler)(apiRequest('GET', '/me'), $exception, false, true, true);

    expect($response->getStatusCode())->toBe($status);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect(jsonOf($response))->toBe([
        'error' => true,
        'status' => $status,
        'message' => $exception->getMessage(),
    ]);
})->with([
    'unauthorized' => [new UnauthorizedException('Missing bearer token.'), 401],
    'not found' => [new NotFoundException('not.found.location'), 404],
    'conflict' => [new ConflictException('round.not_active'), 409],
]);

it('adds the field errors of a validation exception', function (): void {
    $exception = new ValidationException(['email' => 'Email is required.']);

    $response = ($this->handler)(apiRequest('POST', '/auth/login'), $exception, false, true, true);

    expect($response->getStatusCode())->toBe(422);
    expect(jsonOf($response))->toBe([
        'error' => true,
        'status' => 422,
        'message' => 'Validation failed.',
        'errors' => ['email' => 'Email is required.'],
    ]);
});

it('keeps the status of a Slim HTTP exception', function (): void {
    $request = apiRequest('GET', '/nope');

    $notFound = ($this->handler)($request, new HttpNotFoundException($request), false, true, true);
    $notAllowed = ($this->handler)($request, new HttpMethodNotAllowedException($request), false, true, true);

    expect($notFound->getStatusCode())->toBe(404);
    expect(jsonOf($notFound)['message'])->toBe('Not found.');
    expect($notAllowed->getStatusCode())->toBe(405);
});

it('hides the message of an unexpected exception in production', function (): void {
    $exception = new RuntimeException('SQLSTATE[42P01]: relation "users" does not exist');

    $response = ($this->handler)(apiRequest('GET', '/me'), $exception, false, true, true);

    expect($response->getStatusCode())->toBe(500);
    expect(jsonOf($response))->toBe(['error' => true, 'status' => 500, 'message' => 'Server error']);
});

it('shows the message of an unexpected exception when error details are on', function (): void {
    $exception = new RuntimeException('SQLSTATE[42P01]: relation "users" does not exist');

    $response = ($this->handler)(apiRequest('GET', '/me'), $exception, true, true, true);

    expect($response->getStatusCode())->toBe(500);
    expect(jsonOf($response)['message'])->toBe('SQLSTATE[42P01]: relation "users" does not exist');
});

it('logs a client error as one info record without the exception', function (): void {
    ($this->handler)(apiRequest('POST', '/auth/login'), new ValidationException(['email' => 'x']), false, true, true);

    $records = $this->log->getRecords();

    expect($records)->toHaveCount(1);
    expect($records[0]->level)->toBe(Level::Info);
    expect($records[0]->message)->toBe('Validation failed.');
    expect($records[0]->context)->toBe(['method' => 'POST', 'path' => '/auth/login', 'status' => 422]);
});

it('logs a server error as an error record with the exception', function (): void {
    $exception = new RuntimeException('database is down');

    ($this->handler)(apiRequest('GET', '/locations'), $exception, false, true, true);

    $records = $this->log->getRecords();

    expect($records)->toHaveCount(1);
    expect($records[0]->level)->toBe(Level::Error);
    expect($records[0]->message)->toBe('database is down');
    expect($records[0]->context['method'])->toBe('GET');
    expect($records[0]->context['path'])->toBe('/locations');
    expect($records[0]->context['status'])->toBe(500);
    expect($records[0]->context['exception'])->toBe($exception);
});

it('logs the real message even when the response hides it', function (): void {
    $response = ($this->handler)(apiRequest(), new RuntimeException('secret detail'), false, true, true);

    expect(jsonOf($response)['message'])->toBe('Server error');
    expect($this->log->getRecords()[0]->message)->toBe('secret detail');
});

it('logs nothing when error logging is off', function (): void {
    ($this->handler)(apiRequest(), new RuntimeException('boom'), false, false, false);

    expect($this->log->getRecords())->toBe([]);
});

it('builds an error response directly for other middleware', function (): void {
    $response = $this->handler->buildResponse(apiRequest(), 429, 'Too many requests. Please slow down.');

    expect($response->getStatusCode())->toBe(429);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect(jsonOf($response))->toBe([
        'error' => true,
        'status' => 429,
        'message' => 'Too many requests. Please slow down.',
    ]);
});
