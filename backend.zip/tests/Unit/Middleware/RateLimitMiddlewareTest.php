<?php

declare(strict_types=1);

use App\Middleware\HttpErrorHandler;
use App\Middleware\RateLimitMiddleware;
use Doctrine\DBAL\Connection;
use Psr\Log\NullLogger;
use Slim\CallableResolver;
use Slim\Psr7\Factory\ResponseFactory;

/**
 * The connection is a stub: $this->window is what the lookup of the caller's
 * current window returns (false = no window yet), and every write is recorded
 * in $this->statements as [first SQL keyword, params].
 */
beforeEach(function (): void {
    $this->window = false;
    $this->statements = [];
    $this->lookups = [];

    $connection = $this->createStub(Connection::class);
    $connection->method('fetchAssociative')->willReturnCallback(
        function (string $sql, array $params): array|false {
            $this->lookups[] = $params;

            return $this->window;
        },
    );
    $connection->method('executeStatement')->willReturnCallback(
        function (string $sql, array $params = []): int {
            $this->statements[] = [strtok(trim($sql), ' '), $params];

            return 1;
        },
    );

    $this->limiter = new RateLimitMiddleware(
        connection: $connection,
        maxRequests: 50,
        windowSeconds: 60,
        httpErrorHandler: new HttpErrorHandler(new CallableResolver(), new ResponseFactory(), new NullLogger()),
    );

    // The occasional (1 %) cleanup DELETE is not part of what a test asserts
    $this->writes = fn (): array => array_values(
        array_filter($this->statements, fn (array $statement): bool => $statement[0] !== 'DELETE'),
    );
});

it('opens a window for the first request of an IP address', function (): void {
    $handler = spyHandler();

    $response = $this->limiter->process(
        apiRequest('GET', '/me', serverParams: ['REMOTE_ADDR' => '203.0.113.9']),
        $handler,
    );

    $writes = ($this->writes)();

    expect($handler->calls)->toBe(1);
    expect($response->getStatusCode())->toBe(200);
    expect($writes)->toHaveCount(1);
    expect($writes[0][0])->toBe('INSERT');
});

it('counts a further request inside the window', function (): void {
    $handler = spyHandler();

    $this->window = ['id' => 5, 'requests' => 3];

    $this->limiter->process(
        apiRequest('GET', '/me', serverParams: ['REMOTE_ADDR' => '203.0.113.9']),
        $handler,
    );

    expect($handler->calls)->toBe(1);
    expect(($this->writes)())->toBe([['UPDATE', [5]]]);
});

it('lets the last allowed request through', function (): void {
    $handler = spyHandler();

    $this->window = ['id' => 5, 'requests' => 49];

    $this->limiter->process(apiRequest(), $handler);

    expect($handler->calls)->toBe(1);
});

it('blocks a request over the limit with 429 and Retry-After', function (int $requests): void {
    $handler = spyHandler();

    $this->window = ['id' => 5, 'requests' => $requests];

    $response = $this->limiter->process(apiRequest('POST', '/auth/login'), $handler);

    expect($handler->calls)->toBe(0);
    expect($response->getStatusCode())->toBe(429);
    expect($response->getHeaderLine('Retry-After'))->toBe('60');
    expect(jsonOf($response))->toBe([
        'error' => true,
        'status' => 429,
        'message' => 'Too many requests. Please slow down.',
    ]);
    expect($this->statements)->toBe([]);
})->with([
    'exactly at the limit' => [50],
    'above the limit' => [75],
]);

it('stores only a hash of the IP address', function (): void {
    $this->limiter->process(
        apiRequest('GET', '/me', serverParams: ['REMOTE_ADDR' => '203.0.113.9']),
        spyHandler(),
    );

    $hash = hash('sha256', '203.0.113.9');

    expect($this->lookups[0][0])->toBe($hash);
    expect(($this->writes)()[0][1][0])->toBe($hash);
    expect(json_encode([$this->lookups, $this->statements]))->not->toContain('203.0.113.9');
});

it('still limits a request with no known address', function (): void {
    $this->limiter->process(apiRequest(), spyHandler());

    expect($this->lookups[0][0])->toBe(hash('sha256', 'unknown'));
});
