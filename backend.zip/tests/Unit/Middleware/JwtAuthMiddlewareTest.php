<?php

declare(strict_types=1);

use App\Domain\Role;
use App\Domain\User;
use App\Exceptions\generalExceptions\UnauthorizedException;
use App\Middleware\JwtAuthMiddleware;
use App\Services\JWT\JwtService;

beforeEach(function (): void {
    $this->jwt = new JwtService('unit-test-secret-that-is-long-enough-for-hs256', 3600);
    $this->middleware = new JwtAuthMiddleware($this->jwt);
    $this->token = $this->jwt->issue(new User(7, 'dan@example.com', 'Dan', Role::ADMIN, '2026-10-10 12:00:00+00'));
});

it('passes the user id and role of a valid token to the action', function (): void {
    $handler = spyHandler();

    $this->middleware->process(
        apiRequest('GET', '/me', headers: ['Authorization' => "Bearer {$this->token}"]),
        $handler,
    );

    expect($handler->calls)->toBe(1);
    expect($handler->request->getAttribute('user_id'))->toBe(7);
    expect($handler->request->getAttribute('role'))->toBe('admin');
});

it('returns the response of the action', function (): void {
    $inner = new Slim\Psr7\Response(204);

    $response = $this->middleware->process(
        apiRequest('GET', '/me', headers: ['Authorization' => "Bearer {$this->token}"]),
        spyHandler($inner),
    );

    expect($response)->toBe($inner);
});

it('rejects a request without a bearer token', function (array $headers): void {
    $handler = spyHandler();

    expect(fn () => $this->middleware->process(apiRequest('GET', '/me', headers: $headers), $handler))
        ->toThrow(UnauthorizedException::class, 'Missing bearer token.');
    expect($handler->calls)->toBe(0);
})->with([
    'no header' => [[]],
    'empty header' => [['Authorization' => '']],
    'basic auth' => [['Authorization' => 'Basic ZGFuOnNlY3JldA==']],
    'lower-case scheme' => [['Authorization' => 'bearer some-token']],
    'token without a scheme' => [['Authorization' => 'some-token']],
    'scheme without a token' => [['Authorization' => 'Bearer ']],
]);

it('rejects an invalid token', function (string $token): void {
    $handler = spyHandler();

    expect(fn () => $this->middleware->process(
        apiRequest('GET', '/me', headers: ['Authorization' => "Bearer {$token}"]),
        $handler,
    ))->toThrow(UnauthorizedException::class, 'Invalid or expired token.');
    expect($handler->calls)->toBe(0);
})->with([
    'garbage' => ['not-a-token'],
    'three empty parts' => ['..'],
]);

it('rejects a token signed with another secret', function (): void {
    $foreign = (new JwtService('another-secret-that-is-also-long-enough-123', 3600))
        ->issue(new User(7, 'dan@example.com', 'Dan', Role::ADMIN, '2026-10-10 12:00:00+00'));

    $this->middleware->process(
        apiRequest('GET', '/me', headers: ['Authorization' => "Bearer {$foreign}"]),
        spyHandler(),
    );
})->throws(UnauthorizedException::class, 'Invalid or expired token.');
