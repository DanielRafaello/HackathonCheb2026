<?php

declare(strict_types=1);

use App\Middleware\CorsMiddleware;
use Slim\Psr7\Factory\ResponseFactory;
use Slim\Psr7\Response;

function corsMiddleware(): CorsMiddleware
{
    return new CorsMiddleware(new ResponseFactory(), 'http://localhost:5173');
}

it('answers the preflight itself without reaching the application', function (): void {
    $handler = spyHandler();

    $response = corsMiddleware()->process(apiRequest('OPTIONS', '/auth/login'), $handler);

    expect($response->getStatusCode())->toBe(204);
    expect($handler->calls)->toBe(0);
    expect($response->getHeaderLine('Access-Control-Allow-Origin'))->toBe('http://localhost:5173');
});

it('recognises a lower-case options method', function (): void {
    $handler = spyHandler();

    $response = corsMiddleware()->process(apiRequest('options', '/me'), $handler);

    expect($response->getStatusCode())->toBe(204);
    expect($handler->calls)->toBe(0);
});

it('stamps the CORS headers onto the application response', function (): void {
    $handler = spyHandler((new Response(201))->withHeader('Content-Type', 'application/json'));

    $response = corsMiddleware()->process(apiRequest('POST', '/auth/register'), $handler);

    expect($handler->calls)->toBe(1);
    expect($response->getStatusCode())->toBe(201);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect($response->getHeaderLine('Access-Control-Allow-Origin'))->toBe('http://localhost:5173');
    expect($response->getHeaderLine('Access-Control-Allow-Methods'))->toBe('GET, POST, PUT, DELETE, OPTIONS');
    expect($response->getHeaderLine('Access-Control-Allow-Headers'))->toBe('Content-Type, Authorization');
    expect($response->getHeaderLine('Access-Control-Allow-Credentials'))->toBe('true');
});

it('allows only the configured origin, never a wildcard', function (): void {
    $response = corsMiddleware()->process(
        apiRequest('GET', '/me', headers: ['Origin' => 'https://evil.example']),
        spyHandler(),
    );

    expect($response->getHeaderLine('Access-Control-Allow-Origin'))->toBe('http://localhost:5173');
});

it('adds the headers to error responses too', function (): void {
    $response = corsMiddleware()->process(apiRequest('GET', '/me'), spyHandler(new Response(401)));

    expect($response->getStatusCode())->toBe(401);
    expect($response->hasHeader('Access-Control-Allow-Origin'))->toBeTrue();
});
