<?php

declare(strict_types=1);

use App\Exceptions\generalExceptions\ForbiddenException;
use App\Middleware\AdminOnlyMiddleware;
use Slim\Psr7\Response;

it('lets an administrator through to the action', function (): void {
    $inner = new Response(200);
    $handler = spyHandler($inner);

    $response = (new AdminOnlyMiddleware())->process(
        apiRequest('GET', '/admin/statistics/overview')->withAttribute('role', 'admin'),
        $handler,
    );

    expect($handler->calls)->toBe(1);
    expect($response)->toBe($inner);
});

it('stops everyone else with 403 before the action runs', function (mixed $role): void {
    $handler = spyHandler();
    $request = apiRequest('GET', '/admin/statistics/overview');
    if ($role !== 'missing') {
        $request = $request->withAttribute('role', $role);
    }

    try {
        (new AdminOnlyMiddleware())->process($request, $handler);
    } catch (ForbiddenException $exception) {
        expect($exception->getMessage())->toBe('auth.forbidden.admin_only');
        expect($exception->httpStatus())->toBe(403);
        expect($handler->calls)->toBe(0);

        return;
    }

    $this->fail('A non-admin request was let through.');
})->with([
    'ordinary user' => ['user'],
    'no role attribute at all' => ['missing'],
    'null role' => [null],
    'empty role' => [''],
    'wrong case' => ['Admin'],
    'boolean true' => [true],
]);
