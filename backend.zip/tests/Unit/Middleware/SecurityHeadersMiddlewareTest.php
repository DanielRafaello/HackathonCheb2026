<?php

declare(strict_types=1);

use App\Middleware\SecurityHeadersMiddleware;
use Slim\Psr7\Response;

it('adds the security headers to the response', function (): void {
    $response = (new SecurityHeadersMiddleware())->process(apiRequest(), spyHandler());

    expect($response->getHeaderLine('X-Content-Type-Options'))->toBe('nosniff');
    expect($response->getHeaderLine('Referrer-Policy'))->toBe('strict-origin-when-cross-origin');
    expect($response->getHeaderLine('Permissions-Policy'))->toBe('camera=(), microphone=(), geolocation=()');
    expect($response->getHeaderLine('Content-Security-Policy'))->toBe("default-src 'none'; frame-ancestors 'none';");
});

it('keeps the status, headers, and body of the application response', function (): void {
    $inner = (new Response(201))->withHeader('Content-Type', 'application/json');
    $inner->getBody()->write('{"ok":true}');
    $handler = spyHandler($inner);

    $response = (new SecurityHeadersMiddleware())->process(apiRequest('POST', '/auth/register'), $handler);

    expect($handler->calls)->toBe(1);
    expect($response->getStatusCode())->toBe(201);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect((string) $response->getBody())->toBe('{"ok":true}');
});
