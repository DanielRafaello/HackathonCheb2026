<?php

declare(strict_types=1);

use App\Requests\Round\SubmitGuessRequest;

it('accepts valid WGS 84 pin coordinates', function (): void {
    $request = new SubmitGuessRequest(['latitude' => 50.123, 'longitude' => 12.456]);

    expect($request->passes())->toBeTrue();
});

it('rejects missing, non-numeric, and out-of-range coordinates', function (array $data): void {
    expect((new SubmitGuessRequest($data))->fails())->toBeTrue();
})->with([
    'missing longitude' => [['latitude' => 50.123]],
    'non-numeric latitude' => [['latitude' => 'north', 'longitude' => 12.456]],
    'latitude outside WGS 84' => [['latitude' => 91, 'longitude' => 12.456]],
    'longitude outside WGS 84' => [['latitude' => 50.123, 'longitude' => -181]],
]);
