<?php

declare(strict_types=1);

use App\Requests\Auth\RefreshRequest;

it('accepts a refresh token', function (): void {
    $request = new RefreshRequest(['refreshToken' => str_repeat('a', 64)]);

    expect($request->passes())->toBeTrue();
    expect($request->safe())->toBe(['refreshToken' => str_repeat('a', 64)]);
});

it('rejects a request without a usable refresh token', function (array $data): void {
    $request = new RefreshRequest($data);

    expect($request->fails())->toBeTrue();
    expect($request->errors())->toHaveKey('refreshToken');
})->with([
    'missing' => [[]],
    'empty' => [['refreshToken' => '']],
    'snake_case field name' => [['refresh_token' => str_repeat('a', 64)]],
]);
