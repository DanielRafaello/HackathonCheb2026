<?php

declare(strict_types=1);

use App\Requests\Auth\RegisterRequest;

function validRegistration(array $overrides = []): array
{
    return array_merge([
        'name' => 'Dan',
        'email' => 'dan@example.com',
        'password' => 'secret-password',
        'password_confirm' => 'secret-password',
    ], $overrides);
}

it('accepts a complete registration', function (): void {
    $request = new RegisterRequest(validRegistration());

    expect($request->passes())->toBeTrue();
    expect($request->errors())->toBe([]);
});

it('accepts the shortest and longest allowed values', function (array $overrides): void {
    expect((new RegisterRequest(validRegistration($overrides)))->passes())->toBeTrue();
})->with([
    'two-character name' => [['name' => 'Al']],
    'hundred-character name' => [['name' => str_repeat('a', 100)]],
    'eight-character password' => [['password' => '12345678', 'password_confirm' => '12345678']],
]);

it('rejects a registration that breaks a rule', function (array $overrides, string $field): void {
    $request = new RegisterRequest(validRegistration($overrides));

    expect($request->fails())->toBeTrue();
    expect(array_keys($request->errors()))->toBe([$field]);
})->with([
    'missing name' => [['name' => ''], 'name'],
    'one-character name' => [['name' => 'A'], 'name'],
    'name over 100 characters' => [['name' => str_repeat('a', 101)], 'name'],
    'missing e-mail' => [['email' => ''], 'email'],
    'malformed e-mail' => [['email' => 'dan@'], 'email'],
    'e-mail over 255 characters' => [['email' => str_repeat('a', 250) . '@example.com'], 'email'],
    'missing password' => [['password' => '', 'password_confirm' => ''], 'password'],
    'password under 8 characters' => [['password' => '1234567', 'password_confirm' => '1234567'], 'password'],
    'confirmation differs' => [['password_confirm' => 'another-password'], 'password'],
]);

it('requires the confirmation in the password_confirm field', function (): void {
    $data = validRegistration();
    unset($data['password_confirm']);

    $request = new RegisterRequest($data);

    expect($request->errors())->toBe(['password' => 'Password confirmation does not match.']);
});

it('passes only the validated fields on', function (): void {
    $request = new RegisterRequest(validRegistration(['role' => 'admin']));

    expect($request->safe())->toBe([
        'name' => 'Dan',
        'email' => 'dan@example.com',
        'password' => 'secret-password',
    ]);
});
