<?php

declare(strict_types=1);

use App\Requests\Auth\LoginRequest;

it('accepts an e-mail and a password', function (): void {
    $request = new LoginRequest(['email' => 'dan@example.com', 'password' => 'secret-password']);

    expect($request->passes())->toBeTrue();
    expect($request->errors())->toBe([]);
});

it('rejects incomplete or malformed credentials', function (array $data, string $field): void {
    $request = new LoginRequest($data);

    expect($request->fails())->toBeTrue();
    expect($request->errors())->toHaveKey($field);
})->with([
    'missing e-mail' => [['password' => 'secret-password'], 'email'],
    'empty e-mail' => [['email' => '   ', 'password' => 'secret-password'], 'email'],
    'malformed e-mail' => [['email' => 'not-an-email', 'password' => 'secret-password'], 'email'],
    'missing password' => [['email' => 'dan@example.com'], 'password'],
]);

it('reports every failing field at once', function (): void {
    $request = new LoginRequest([]);

    expect($request->errors())->toBe([
        'email' => 'Email is required.',
        'password' => 'Password is required.',
    ]);
});

it('does not enforce a password length on login', function (): void {
    expect((new LoginRequest(['email' => 'dan@example.com', 'password' => 'x']))->passes())->toBeTrue();
});

it('passes only the validated fields on', function (): void {
    $request = new LoginRequest([
        'email' => 'dan@example.com',
        'password' => 'secret-password',
        'role' => 'admin',
    ]);

    expect($request->safe())->toBe(['email' => 'dan@example.com', 'password' => 'secret-password']);
});
