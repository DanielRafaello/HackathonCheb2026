<?php

declare(strict_types=1);

use App\Requests\Admin\VisitStatisticsRequest;

it('accepts an empty query, because every parameter is optional', function (): void {
    $request = new VisitStatisticsRequest([]);

    expect($request->passes())->toBeTrue();
    expect($request->safe())->toBe(['year' => null, 'granularity' => null, 'location_id' => null]);
});

it('accepts valid parameters', function (array $query): void {
    expect((new VisitStatisticsRequest($query))->passes())->toBeTrue();
})->with([
    'year only' => [['year' => '2026']],
    'earliest year' => [['year' => '2000']],
    'latest year' => [['year' => '2100']],
    'monthly' => [['granularity' => 'month']],
    'daily' => [['granularity' => 'day']],
    'one location' => [['location_id' => '12']],
    'everything' => [['year' => '2026', 'granularity' => 'day', 'location_id' => '1']],
    'empty values are treated as not given' => [['year' => '', 'granularity' => '', 'location_id' => '']],
]);

it('rejects an invalid parameter', function (array $query, string $field): void {
    $request = new VisitStatisticsRequest($query);

    expect($request->fails())->toBeTrue();
    expect(array_keys($request->errors()))->toBe([$field]);
})->with([
    'year as text' => [['year' => 'this year'], 'year'],
    'fractional year' => [['year' => '2026.5'], 'year'],
    'year before 2000' => [['year' => '1999'], 'year'],
    'year after 2100' => [['year' => '2101'], 'year'],
    'unknown granularity' => [['granularity' => 'week'], 'granularity'],
    'granularity in the wrong case' => [['granularity' => 'Month'], 'granularity'],
    'location id as text' => [['location_id' => 'loket'], 'location_id'],
    'location id zero' => [['location_id' => '0'], 'location_id'],
    'negative location id' => [['location_id' => '-3'], 'location_id'],
]);

it('ignores query parameters it does not know', function (): void {
    $request = new VisitStatisticsRequest(['year' => '2026', 'sort' => 'visits']);

    expect($request->passes())->toBeTrue();
    expect($request->safe())->not->toHaveKey('sort');
});
