<?php

declare(strict_types=1);

use App\Domain\LocationProgress;
use App\Requests\Location\MarkLocationRequest;

it('accepts both progress states', function (string $state): void {
    $request = new MarkLocationRequest(['state' => $state]);

    expect($request->passes())->toBeTrue();
    expect($request->safe())->toBe(['state' => $state]);
})->with(['guessed', 'visited']);

it('accepts exactly the states the domain knows', function (): void {
    foreach (LocationProgress::cases() as $progress) {
        expect((new MarkLocationRequest(['state' => $progress->value]))->passes())->toBeTrue();
    }
});

it('rejects a missing or unknown state', function (array $data): void {
    $request = new MarkLocationRequest($data);

    expect($request->fails())->toBeTrue();
    expect($request->errors())->toHaveKey('state');
})->with([
    'missing' => [[]],
    'empty' => [['state' => '']],
    'unknown value' => [['state' => 'skipped']],
    'wrong case' => [['state' => 'Guessed']],
    'boolean instead of a state' => [['state' => true]],
]);
