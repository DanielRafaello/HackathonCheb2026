<?php

declare(strict_types=1);

use App\Validation\FormRequest;

/** @param array<string, mixed> $data */
function profileRequest(array $data): FormRequest
{
    return new class ($data) extends FormRequest {
        protected function rules(): array
        {
            return [
                'name' => 'required|min:2',
                'website' => 'nullable|url',
            ];
        }

        protected function messages(): array
        {
            return ['name.required' => 'Tell us your name.'];
        }
    };
}

it('validates itself on construction', function (): void {
    $valid = profileRequest(['name' => 'Dan']);
    $invalid = profileRequest(['name' => 'D', 'website' => 'nope']);

    expect($valid->passes())->toBeTrue();
    expect($valid->fails())->toBeFalse();
    expect($invalid->fails())->toBeTrue();
    expect($invalid->passes())->toBeFalse();
    expect($invalid->errors())->toBe([
        'name' => 'Name must be at least 2 characters.',
        'website' => 'Website must be a valid URL.',
    ]);
});

it('uses the custom messages of the request', function (): void {
    expect(profileRequest([])->errors())->toBe(['name' => 'Tell us your name.']);
});

it('returns only the fields that have rules as safe data', function (): void {
    $request = profileRequest(['name' => 'Dan', 'website' => 'https://example.com', 'role' => 'admin']);

    expect($request->safe())->toBe(['name' => 'Dan', 'website' => 'https://example.com']);
});

it('fills a missing ruled field with null in the safe data', function (): void {
    expect(profileRequest(['name' => 'Dan'])->safe())->toBe(['name' => 'Dan', 'website' => null]);
});

it('exposes the raw input', function (): void {
    $data = ['name' => 'Dan', 'role' => 'admin'];
    $request = profileRequest($data);

    expect($request->all())->toBe($data);
    expect($request->input('role'))->toBe('admin');
    expect($request->input('missing'))->toBeNull();
    expect($request->input('missing', 'fallback'))->toBe('fallback');
    expect($request->name)->toBe('Dan');
    expect($request->missing)->toBeNull();
});
