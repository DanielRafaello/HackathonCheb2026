<?php

declare(strict_types=1);

use App\Validation\Validator;

it('passes when every rule holds', function (): void {
    $validator = Validator::make(
        ['name' => 'Dan', 'email' => 'dan@example.com'],
        ['name' => 'required|min:2', 'email' => 'required|email'],
    );

    expect($validator->passes())->toBeTrue();
    expect($validator->fails())->toBeFalse();
    expect($validator->errors())->toBe([]);
});

it('checks a single rule', function (string $rule, mixed $value, bool $passes): void {
    $validator = Validator::make(['field' => $value], ['field' => $rule]);

    expect($validator->passes())->toBe($passes);
})->with([
    'required: text' => ['required', 'x', true],
    'required: zero is a value' => ['required', 0, true],
    'required: empty string' => ['required', '', false],
    'required: only spaces' => ['required', '   ', false],
    'required: null' => ['required', null, false],
    'email: valid' => ['email', 'dan@example.com', true],
    'email: no domain' => ['email', 'dan@', false],
    'email: empty is left to required' => ['email', '', true],
    'url: valid' => ['url', 'https://example.com/a?b=1', true],
    'url: no scheme' => ['url', 'example.com', false],
    'min: exactly at the limit' => ['min:3', 'abc', true],
    'min: below the limit' => ['min:3', 'ab', false],
    'max: exactly at the limit' => ['max:3', 'abc', true],
    'max: above the limit' => ['max:3', 'abcd', false],
    'numeric: integer' => ['numeric', '42', true],
    'numeric: decimal' => ['numeric', 12.5, true],
    'numeric: negative' => ['numeric', '-3.2', true],
    'numeric: text' => ['numeric', 'north', false],
    'integer: whole number' => ['integer', '2026', true],
    'integer: negative' => ['integer', '-3', true],
    'integer: PHP int' => ['integer', 12, true],
    'integer: fraction' => ['integer', '4.5', false],
    'integer: text' => ['integer', 'twelve', false],
    'integer: empty is left to required' => ['integer', '', true],
    'between: inside' => ['between:-90,90', 50.1, true],
    'between: lower bound' => ['between:-90,90', -90, true],
    'between: upper bound' => ['between:-90,90', '90', true],
    'between: outside' => ['between:-90,90', 90.0001, false],
    'between: not a number' => ['between:-90,90', 'north', false],
    'between: malformed parameters' => ['between:1', 5, false],
    'in: listed' => ['in:guessed,visited', 'visited', true],
    'in: not listed' => ['in:guessed,visited', 'skipped', false],
    'in: case-sensitive' => ['in:guessed,visited', 'Visited', false],
    'date: ISO date' => ['date', '2026-10-10', true],
    'date: ISO date-time with offset' => ['date', '2026-10-10T12:00:00+02:00', true],
    'date: nonsense' => ['date', 'not a date', false],
    'date: empty is left to required' => ['date', '', true],
    'unknown rule is ignored' => ['made_up_rule', 'x', true],
]);

it('ignores surrounding whitespace when measuring length', function (): void {
    expect(Validator::make(['name' => '  ab  '], ['name' => 'max:2'])->passes())->toBeTrue();
});

it('compares a field with another field', function (array $data, bool $passes): void {
    expect(Validator::make($data, ['password' => 'same:repeat'])->passes())->toBe($passes);
})->with([
    'equal' => [['password' => 'secret', 'repeat' => 'secret'], true],
    'different' => [['password' => 'secret', 'repeat' => 'other'], false],
    'other field missing' => [['password' => 'secret'], false],
]);

it('expects the confirmation in the <field>_confirm field', function (array $data, bool $passes): void {
    expect(Validator::make($data, ['password' => 'confirmed'])->passes())->toBe($passes);
})->with([
    'matching' => [['password' => 'secret', 'password_confirm' => 'secret'], true],
    'different' => [['password' => 'secret', 'password_confirm' => 'other'], false],
    'missing' => [['password' => 'secret'], false],
    'Laravel-style name is not accepted' => [['password' => 'secret', 'password_confirmation' => 'secret'], false],
]);

it('skips the other rules of an empty nullable field', function (): void {
    $rules = ['website' => 'nullable|url'];

    expect(Validator::make([], $rules)->passes())->toBeTrue();
    expect(Validator::make(['website' => ''], $rules)->passes())->toBeTrue();
    expect(Validator::make(['website' => 'https://example.com'], $rules)->passes())->toBeTrue();
    expect(Validator::make(['website' => 'nope'], $rules)->fails())->toBeTrue();
});

it('stops at the first failing rule of a field', function (): void {
    $validator = Validator::make(['email' => ''], ['email' => 'required|email|min:5']);

    expect($validator->allErrors())->toBe(['email' => ['Email is required.']]);
});

it('reports the first error of every failing field', function (): void {
    $validator = Validator::make(
        ['name' => 'A', 'email' => 'nope', 'age' => '30'],
        ['name' => 'required|min:2', 'email' => 'required|email', 'age' => 'numeric'],
    );

    expect($validator->errors())->toBe([
        'name' => 'Name must be at least 2 characters.',
        'email' => 'Email must be a valid email address.',
    ]);
});

it('words the default message of each rule', function (string $rule, mixed $value, string $message): void {
    $validator = Validator::make(['home_page' => $value], ['home_page' => $rule]);

    expect($validator->errors())->toBe(['home_page' => $message]);
})->with([
    'required' => ['required', '', 'Home page is required.'],
    'email' => ['email', 'x', 'Home page must be a valid email address.'],
    'url' => ['url', 'x', 'Home page must be a valid URL.'],
    'min' => ['min:5', 'x', 'Home page must be at least 5 characters.'],
    'max' => ['max:2', 'xyz', 'Home page may not exceed 2 characters.'],
    'numeric' => ['numeric', 'x', 'Home page must be a number.'],
    'integer' => ['integer', '4.5', 'Home page must be a whole number.'],
    'between' => ['between:1,5', 9, 'Home page must be between 1 and 5.'],
    'in' => ['in:a,b', 'x', 'Home page must be one of: a,b.'],
    'same' => ['same:other', 'x', 'Home page must match other.'],
    'confirmed' => ['confirmed', 'x', 'Home page confirmation does not match.'],
    'date' => ['date', 'not a date', 'Home page must be a date.'],
]);

it('prefers a custom message for a field and rule', function (): void {
    $validator = Validator::make(
        ['email' => ''],
        ['email' => 'required|email'],
        ['email.required' => 'We need your e-mail.', 'email.email' => 'unused'],
    );

    expect($validator->errors())->toBe(['email' => 'We need your e-mail.']);
});
