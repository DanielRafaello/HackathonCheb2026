<?php

declare(strict_types=1);

use App\Exceptions\AbstractException\AppException;
use App\Exceptions\generalExceptions\UnprocessableEntityException;
use App\Exceptions\Validation\ValidationException;

it('is an unprocessable entity error', function (): void {
    $exception = new ValidationException(['email' => 'Email is required.']);

    expect($exception)->toBeInstanceOf(UnprocessableEntityException::class);
    expect($exception)->toBeInstanceOf(AppException::class);
    expect($exception->httpStatus())->toBe(422);
});

it('carries the field errors', function (): void {
    $errors = ['email' => 'Email is required.', 'password' => 'Password is required.'];

    $exception = new ValidationException($errors);

    expect($exception->getErrors())->toBe($errors);
    expect($exception->errors)->toBe($errors);
});

it('uses a default message that can be overridden', function (): void {
    expect((new ValidationException([]))->getMessage())->toBe('Validation failed.');
    expect((new ValidationException([], 'Custom message.'))->getMessage())->toBe('Custom message.');
});
