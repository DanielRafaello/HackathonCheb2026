<?php

declare(strict_types=1);

use App\Exceptions\AbstractException\AppException;
use App\Exceptions\FileSystemExceptions\AbstractException\FileSystemException;
use App\Exceptions\FileSystemExceptions\FileDeleteException;
use App\Exceptions\FileSystemExceptions\FileInvalidPathException;
use App\Exceptions\FileSystemExceptions\FileNotFoundException;
use App\Exceptions\FileSystemExceptions\FileWriteException;
use App\Exceptions\FileSystemExceptions\FileWrongMimeTypeException;
use App\Exceptions\generalExceptions\UnprocessableEntityException;

it('maps each file system exception to its HTTP status', function (string $class, int $status): void {
    $exception = new $class('file.problem');

    expect($exception)->toBeInstanceOf(FileSystemException::class);
    expect($exception)->toBeInstanceOf(AppException::class);
    expect($exception->httpStatus())->toBe($status);
    expect($exception->getMessage())->toBe('file.problem');
})->with([
    'delete failed' => [FileDeleteException::class, 500],
    'write failed' => [FileWriteException::class, 500],
    'invalid path' => [FileInvalidPathException::class, 400],
    'file not found' => [FileNotFoundException::class, 404],
]);

it('reports a wrong mime type as an unprocessable entity', function (): void {
    $exception = new FileWrongMimeTypeException('file.wrong_mime_type');

    expect($exception)->toBeInstanceOf(UnprocessableEntityException::class);
    expect($exception->httpStatus())->toBe(422);
});
