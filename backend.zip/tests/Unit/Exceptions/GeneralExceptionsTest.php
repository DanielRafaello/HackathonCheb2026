<?php

declare(strict_types=1);

use App\Exceptions\AbstractException\AppException;
use App\Exceptions\generalExceptions\BadRequestException;
use App\Exceptions\generalExceptions\ConflictException;
use App\Exceptions\generalExceptions\ForbiddenException;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Exceptions\generalExceptions\UnauthorizedException;
use App\Exceptions\generalExceptions\UnprocessableEntityException;

it('maps each general exception to its HTTP status', function (string $class, int $status): void {
    $exception = new $class('some.message.key');

    expect($exception)->toBeInstanceOf(AppException::class);
    expect($exception)->toBeInstanceOf(RuntimeException::class);
    expect($exception->httpStatus())->toBe($status);
    expect($exception->getMessage())->toBe('some.message.key');
})->with([
    'bad request' => [BadRequestException::class, 400],
    'unauthorized' => [UnauthorizedException::class, 401],
    'forbidden' => [ForbiddenException::class, 403],
    'not found' => [NotFoundException::class, 404],
    'conflict' => [ConflictException::class, 409],
    'unprocessable entity' => [UnprocessableEntityException::class, 422],
]);

it('can be caught as the common application exception', function (): void {
    try {
        throw new NotFoundException('not.found.location');
    } catch (AppException $exception) {
        expect($exception->httpStatus())->toBe(404);

        return;
    }
});
