<?php

declare(strict_types=1);

use App\Enums\HttpStatus;

it('maps each case to its HTTP status code', function (HttpStatus $status, int $code): void {
    expect($status->value)->toBe($code);
})->with([
    'bad request' => [HttpStatus::BAD_REQUEST, 400],
    'unauthorized' => [HttpStatus::UNAUTHORIZED, 401],
    'payment required' => [HttpStatus::PAYMENT_REQUIRED, 402],
    'forbidden' => [HttpStatus::FORBIDDEN, 403],
    'not found' => [HttpStatus::NOT_FOUND, 404],
    'conflict' => [HttpStatus::CONFLICT, 409],
    'unprocessable entity' => [HttpStatus::UNPROCESSABLE_ENTITY, 422],
    'internal server error' => [HttpStatus::INTERNAL_SERVER_ERROR, 500],
    'service unavailable' => [HttpStatus::SERVICE_UNAVAILABLE, 503],
]);

it('covers only error statuses', function (): void {
    foreach (HttpStatus::cases() as $status) {
        expect($status->value)->toBeGreaterThanOrEqual(400)->toBeLessThan(600);
    }

    expect(HttpStatus::cases())->toHaveCount(9);
});

it('builds a status from its code', function (): void {
    expect(HttpStatus::from(404))->toBe(HttpStatus::NOT_FOUND);
    expect(HttpStatus::tryFrom(200))->toBeNull();
});
