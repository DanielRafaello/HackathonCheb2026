<?php

declare(strict_types=1);

use App\Action\User\GetProfileAction;
use App\Domain\LevelProgress;
use App\Domain\Profile;
use App\Domain\Role;
use App\Domain\User;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Responder\User\ProfileResponder;
use App\Services\Contracts\Profile\ProfileServiceInterface;
use Slim\Psr7\Response;

it('returns the profile of the authenticated user', function (): void {
    $profile = new Profile(
        user: new User(7, 'dan@example.com', 'Dan', Role::USER, '2026-10-10 12:00:00+00'),
        pointsFromGuessing: 425,
        pointsFromVisits: 300,
        level: new LevelProgress(level: 2, points: 725, startsAt: 250, nextLevelAt: 750),
        guessedCount: 3,
        visitedCount: 1,
    );

    $service = $this->createMock(ProfileServiceInterface::class);
    $service->expects($this->once())->method('forUser')->with(7)->willReturn($profile);

    $response = (new GetProfileAction($service, new ProfileResponder()))(
        apiRequest('GET', '/me/profile')->withAttribute('user_id', 7),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(200);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect(jsonOf($response))->toBe([
        'profile' => [
            'id' => 7,
            'name' => 'Dan',
            'email' => 'dan@example.com',
            'created_at' => '2026-10-10 12:00:00+00',
            'wafers' => 0,
            'points' => ['total' => 725, 'guessing' => 425, 'visits' => 300],
            'level' => [
                'number' => 2,
                'starts_at' => 250,
                'next_level_at' => 750,
                'points_in_level' => 475,
                'points_to_next_level' => 25,
            ],
            'locations' => ['guessed' => 3, 'visited' => 1],
        ],
    ]);
});

it('lets a not-found error of the service through', function (): void {
    $service = $this->createStub(ProfileServiceInterface::class);
    $service->method('forUser')->willThrowException(new NotFoundException('not.found.user'));

    (new GetProfileAction($service, new ProfileResponder()))(
        apiRequest('GET', '/me/profile')->withAttribute('user_id', 7),
        new Response(),
    );
})->throws(NotFoundException::class, 'not.found.user');
