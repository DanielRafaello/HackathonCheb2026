<?php

declare(strict_types=1);

use App\Action\Location\GetLocationDescriptionAction;
use App\Action\Location\ListLocationsAction;
use App\Action\Location\MarkLocationAction;
use App\Domain\LocationProgress;
use App\Domain\MarkedLocation;
use App\Domain\UserLocation;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Exceptions\Validation\ValidationException;
use App\Responder\Location\LocationListResponder;
use App\Responder\Location\LocationResponder;
use App\Services\Contracts\Location\LocationServiceInterface;
use Slim\Psr7\Response;

beforeEach(function (): void {
    $this->locations = $this->createMock(LocationServiceInterface::class);
});

// ─── GET /locations ───────────────────────────────────────────

it('lists the locations of the authenticated user', function (): void {
    $this->locations->expects($this->once())->method('listForUser')
        ->with(7)
        ->willReturn([new UserLocation(1, 'Hrad Cheb', 50.081137, 12.366035, '2026-10-09T21:42:14Z', null)]);

    $response = (new ListLocationsAction($this->locations, new LocationListResponder()))(
        apiRequest('GET', '/locations')->withAttribute('user_id', 7),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response)['locations'])->toHaveCount(1);
    expect(jsonOf($response)['locations'][0]['name'])->toBe('Hrad Cheb');
    expect(jsonOf($response)['locations'][0]['guessed'])->toBeTrue();
});

// ─── POST /locations/{id}/progress ────────────────────────────

it('marks the location from the path with the state from the body', function (string $state, LocationProgress $progress): void {
    $this->locations->expects($this->once())->method('mark')
        ->with(7, 12, $progress)
        ->willReturn(new MarkedLocation(
            new UserLocation(12, 'Hrad Loket', 50.187104, 12.754285, '2026-10-09T21:42:14Z', null),
            50,
        ));

    $response = (new MarkLocationAction($this->locations, new LocationResponder()))(
        apiRequest('POST', '/locations/12/progress', ['state' => $state])->withAttribute('user_id', 7),
        new Response(),
        ['id' => '12'],
    );

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response)['location']['id'])->toBe(12);
    expect(jsonOf($response)['wafers_earned'])->toBe(50);
})->with([
    'guessed' => ['guessed', LocationProgress::GUESSED],
    'visited' => ['visited', LocationProgress::VISITED],
]);

it('rejects an unknown state before touching the service', function (array $body): void {
    $this->locations->expects($this->never())->method('mark');

    (new MarkLocationAction($this->locations, new LocationResponder()))(
        apiRequest('POST', '/locations/12/progress', $body)->withAttribute('user_id', 7),
        new Response(),
        ['id' => '12'],
    );
})->with([
    'missing state' => [[]],
    'unknown state' => [['state' => 'skipped']],
])->throws(ValidationException::class);

it('lets a not-found error of the service through', function (): void {
    $this->locations->method('mark')->willThrowException(new NotFoundException('not.found.location'));

    (new MarkLocationAction($this->locations, new LocationResponder()))(
        apiRequest('POST', '/locations/999/progress', ['state' => 'guessed'])->withAttribute('user_id', 7),
        new Response(),
        ['id' => '999'],
    );
})->throws(NotFoundException::class, 'not.found.location');

// ─── GET /locations/{id}/description ──────────────────────────

it('answers the description of the location from the path', function (): void {
    $this->locations->expects($this->once())->method('description')
        ->with(7, 12)
        ->willReturn(roundFixture()->target);

    $response = (new GetLocationDescriptionAction($this->locations, new LocationResponder()))(
        apiRequest('GET', '/locations/12/description')->withAttribute('user_id', 7),
        new Response(),
        ['id' => '12'],
    );

    expect($response->getStatusCode())->toBe(200);
    $location = jsonOf($response)['location'];
    expect($location['description'])->toBe('Popis místa.');
    expect($location['category'])->toBe('Hrady, tvrze a zříceniny');
    expect($location['source']['license_code'])->toBe('CC BY 4.0');
    expect($location)->not->toHaveKey('hint1');
});
