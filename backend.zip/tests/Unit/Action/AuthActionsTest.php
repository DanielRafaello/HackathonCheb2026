<?php

declare(strict_types=1);

use App\Action\Auth\LoginAction;
use App\Action\Auth\LogoutAction;
use App\Action\Auth\RefreshAction;
use App\Action\Auth\RegisterAction;
use App\Action\User\MeAction;
use App\Domain\Role;
use App\Domain\User;
use App\Exceptions\Validation\ValidationException;
use App\Responder\Auth\AuthResponder;
use App\Responder\Auth\LogoutResponder;
use App\Responder\User\MeResponder;
use App\Services\Contracts\Auth\AuthServiceInterface;
use Slim\Psr7\Response;

beforeEach(function (): void {
    $this->auth = $this->createMock(AuthServiceInterface::class);
    $this->session = [
        'token' => 'jwt-token',
        'refresh_token' => 'refresh-token',
        'user' => new User(7, 'dan@example.com', 'Dan', Role::USER, '2026-10-10 12:00:00+00'),
    ];
    $this->sessionBody = [
        'token' => 'jwt-token',
        'refresh_token' => 'refresh-token',
        'user' => ['id' => 7, 'name' => 'Dan', 'email' => 'dan@example.com', 'role' => 'user'],
    ];
});

// ─── POST /auth/register ──────────────────────────────────────

it('registers with the validated fields and answers 201', function (): void {
    $this->auth->expects($this->once())->method('register')
        ->with('Dan', 'dan@example.com', 'secret-password')
        ->willReturn($this->session);

    $response = (new RegisterAction($this->auth, new AuthResponder()))(
        apiRequest('POST', '/auth/register', [
            'name' => 'Dan',
            'email' => 'dan@example.com',
            'password' => 'secret-password',
            'password_confirm' => 'secret-password',
        ]),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(201);
    expect(jsonOf($response))->toBe($this->sessionBody);
});

it('rejects an invalid registration before touching the service', function (): void {
    $this->auth->expects($this->never())->method('register');

    try {
        (new RegisterAction($this->auth, new AuthResponder()))(
            apiRequest('POST', '/auth/register', ['name' => 'Dan', 'email' => 'nope']),
            new Response(),
        );
    } catch (ValidationException $exception) {
        expect(array_keys($exception->getErrors()))->toBe(['email', 'password']);

        return;
    }

    $this->fail('An invalid registration was accepted.');
});

// ─── POST /auth/login ─────────────────────────────────────────

it('logs in with the validated credentials and answers 200', function (): void {
    $this->auth->expects($this->once())->method('login')
        ->with('dan@example.com', 'secret-password')
        ->willReturn($this->session);

    $response = (new LoginAction($this->auth, new AuthResponder()))(
        apiRequest('POST', '/auth/login', ['email' => 'dan@example.com', 'password' => 'secret-password']),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response))->toBe($this->sessionBody);
});

it('rejects a login without a body', function (?array $body): void {
    $this->auth->expects($this->never())->method('login');

    (new LoginAction($this->auth, new AuthResponder()))(apiRequest('POST', '/auth/login', $body), new Response());
})->with([
    'no body at all' => [null],
    'empty object' => [[]],
])->throws(ValidationException::class);

// ─── POST /auth/refresh ───────────────────────────────────────

it('refreshes with the given token and answers 200', function (): void {
    $this->auth->expects($this->once())->method('refresh')
        ->with('old-refresh-token')
        ->willReturn($this->session);

    $response = (new RefreshAction($this->auth, new AuthResponder()))(
        apiRequest('POST', '/auth/refresh', ['refreshToken' => 'old-refresh-token']),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response))->toBe($this->sessionBody);
});

it('rejects a refresh without a token', function (): void {
    $this->auth->expects($this->never())->method('refresh');

    (new RefreshAction($this->auth, new AuthResponder()))(apiRequest('POST', '/auth/refresh', []), new Response());
})->throws(ValidationException::class);

// ─── POST /auth/logout ────────────────────────────────────────

it('logs out with the given token', function (): void {
    $this->auth->expects($this->once())->method('logout')->with('refresh-token');

    $response = (new LogoutAction($this->auth, new LogoutResponder()))(
        apiRequest('POST', '/auth/logout', ['refreshToken' => 'refresh-token']),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response))->toBe(['logged_out' => true]);
});

it('rejects a logout without a token', function (): void {
    $this->auth->expects($this->never())->method('logout');

    (new LogoutAction($this->auth, new LogoutResponder()))(apiRequest('POST', '/auth/logout', []), new Response());
})->throws(ValidationException::class);

// ─── GET /me ──────────────────────────────────────────────────

it('returns the user the JWT middleware identified', function (): void {
    $this->auth->expects($this->once())->method('currentUser')
        ->with(7)
        ->willReturn($this->session['user']);

    $response = (new MeAction($this->auth, new MeResponder()))(
        apiRequest('GET', '/me')->withAttribute('user_id', 7),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response)['user'])->toBe([
        'id' => 7,
        'name' => 'Dan',
        'email' => 'dan@example.com',
        'role' => 'user',
        'created_at' => '2026-10-10 12:00:00+00',
        'wafers' => 0,
    ]);
});
