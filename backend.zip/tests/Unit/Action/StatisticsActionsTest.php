<?php

declare(strict_types=1);

use App\Action\Admin\GetStatisticsOverviewAction;
use App\Action\Admin\GetVisitStatisticsAction;
use App\Action\Admin\ListLocationStatisticsAction;
use App\Domain\LocationStatistics;
use App\Domain\StatisticsGranularity;
use App\Domain\StatisticsOverview;
use App\Domain\VisitSeries;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Exceptions\Validation\ValidationException;
use App\Responder\Admin\StatisticsResponder;
use App\Services\Contracts\Statistics\StatisticsServiceInterface;
use Slim\Psr7\Response;

beforeEach(function (): void {
    $this->statistics = $this->createMock(StatisticsServiceInterface::class);
});

// ─── GET /admin/statistics/overview ───────────────────────────

it('returns the overview', function (): void {
    $this->statistics->expects($this->once())->method('overview')
        ->willReturn(new StatisticsOverview(10, 6, 112, 20, 45, 80, 30, 4.2));

    $response = (new GetStatisticsOverviewAction($this->statistics, new StatisticsResponder()))(
        apiRequest('GET', '/admin/statistics/overview'),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response)['overview']['users'])->toBe(['total' => 10, 'active' => 6]);
    expect(jsonOf($response)['overview']['ratings']['average'])->toBe(4.2);
});

// ─── GET /admin/statistics/locations ──────────────────────────

it('returns the statistics of every location', function (): void {
    $this->statistics->expects($this->once())->method('locations')->willReturn([
        new LocationStatistics(12, 'Hrad Loket', 'Hrady, tvrze a zříceniny', 9, 14, 4.6, 7),
    ]);

    $response = (new ListLocationStatisticsAction($this->statistics, new StatisticsResponder()))(
        apiRequest('GET', '/admin/statistics/locations'),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response)['locations'])->toHaveCount(1);
    expect(jsonOf($response)['locations'][0]['visitors'])->toBe(9);
});

// ─── GET /admin/statistics/visits ─────────────────────────────

it('asks for the current year by month when the query is empty', function (array $query): void {
    $this->statistics->expects($this->once())->method('visits')
        ->with(null, StatisticsGranularity::MONTH, null)
        ->willReturn(new VisitSeries(2026, StatisticsGranularity::MONTH, null, []));

    $response = (new GetVisitStatisticsAction($this->statistics, new StatisticsResponder()))(
        apiRequest('GET', '/admin/statistics/visits')->withQueryParams($query),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response)['visits']['year'])->toBe(2026);
})->with([
    'no parameters' => [[]],
    'empty parameters' => [['year' => '', 'granularity' => '', 'location_id' => '']],
]);

it('passes the query parameters to the service with the right types', function (): void {
    $this->statistics->expects($this->once())->method('visits')
        ->with(2025, StatisticsGranularity::DAY, 12)
        ->willReturn(new VisitSeries(2025, StatisticsGranularity::DAY, 12, [
            ['period' => '2025-01-01', 'visits' => 1, 'visitors' => 1],
        ]));

    $response = (new GetVisitStatisticsAction($this->statistics, new StatisticsResponder()))(
        apiRequest('GET', '/admin/statistics/visits')
            ->withQueryParams(['year' => '2025', 'granularity' => 'day', 'location_id' => '12']),
        new Response(),
    );

    expect(jsonOf($response)['visits'])->toBe([
        'year' => 2025,
        'granularity' => 'day',
        'location_id' => 12,
        'total' => 1,
        'series' => [['period' => '2025-01-01', 'visits' => 1, 'visitors' => 1]],
    ]);
});

it('rejects an invalid query before touching the service', function (array $query): void {
    $this->statistics->expects($this->never())->method('visits');

    (new GetVisitStatisticsAction($this->statistics, new StatisticsResponder()))(
        apiRequest('GET', '/admin/statistics/visits')->withQueryParams($query),
        new Response(),
    );
})->with([
    'year as text' => [['year' => 'abc']],
    'unknown granularity' => [['granularity' => 'week']],
    'location id zero' => [['location_id' => '0']],
])->throws(ValidationException::class);

it('lets a not-found location through', function (): void {
    $this->statistics->method('visits')->willThrowException(new NotFoundException('not.found.location'));

    (new GetVisitStatisticsAction($this->statistics, new StatisticsResponder()))(
        apiRequest('GET', '/admin/statistics/visits')->withQueryParams(['location_id' => '999']),
        new Response(),
    );
})->throws(NotFoundException::class, 'not.found.location');
