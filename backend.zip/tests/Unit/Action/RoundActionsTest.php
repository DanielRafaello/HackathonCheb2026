<?php

declare(strict_types=1);

use App\Action\Round\GetDailyRoundAction;
use App\Action\Round\GetRoundAction;
use App\Action\Round\SubmitGuessAction;
use App\Domain\GuessResult;
use App\Domain\GuessSubmission;
use App\Domain\RoundStatus;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Exceptions\Validation\ValidationException;
use App\Responder\Round\RoundResponder;
use App\Services\Contracts\Round\RoundServiceInterface;
use Slim\Psr7\Response;

beforeEach(function (): void {
    $this->rounds = $this->createMock(RoundServiceInterface::class);
});

// ─── GET daily round ──────────────────────────────────────────

it('returns the daily round of the authenticated user and forbids caching', function (): void {
    $this->rounds->expects($this->once())->method('getDaily')->with(7)->willReturn(roundFixture());

    $response = (new GetDailyRoundAction($this->rounds, new RoundResponder()))(
        apiRequest('GET', '/rounds/daily')->withAttribute('user_id', 7),
        new Response(),
    );

    expect($response->getStatusCode())->toBe(200);
    expect($response->getHeaderLine('Cache-Control'))->toBe('no-store');
    expect(jsonOf($response)['round']['id'])->toBe(3);
    expect(jsonOf($response)['round'])->not->toHaveKey('location');
});

// ─── GET round ────────────────────────────────────────────────

it('returns the round from the path for the authenticated user', function (): void {
    $this->rounds->expects($this->once())->method('get')->with(7, 3)->willReturn(roundFixture());

    $response = (new GetRoundAction($this->rounds, new RoundResponder()))(
        apiRequest('GET', '/rounds/3')->withAttribute('user_id', 7),
        new Response(),
        ['id' => '3'],
    );

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response)['round']['status'])->toBe('active');
});

it('lets a not-found round through', function (): void {
    $this->rounds->method('get')->willThrowException(new NotFoundException('not.found.round'));

    (new GetRoundAction($this->rounds, new RoundResponder()))(
        apiRequest('GET', '/rounds/99')->withAttribute('user_id', 7),
        new Response(),
        ['id' => '99'],
    );
})->throws(NotFoundException::class, 'not.found.round');

// ─── POST guess ───────────────────────────────────────────────

it('submits the pin as floats and returns the guess with the round', function (array $body): void {
    $guess = new GuessResult(attemptNumber: 1, hit: false, distanceMeters: 13250, direction: 'SE');

    $this->rounds->expects($this->once())->method('submitGuess')
        ->with(7, 3, 50.123, 12.456)
        ->willReturn(new GuessSubmission(roundFixture(RoundStatus::ACTIVE, 1, lastGuess: $guess), $guess));

    $response = (new SubmitGuessAction($this->rounds, new RoundResponder()))(
        apiRequest('POST', '/rounds/3/guesses', $body)->withAttribute('user_id', 7),
        new Response(),
        ['id' => '3'],
    );

    $payload = jsonOf($response);

    expect($response->getStatusCode())->toBe(200);
    expect($payload['guess']['distance_meters'])->toBeNull();
    expect($payload['guess']['direction'])->toBeNull();
    expect($payload['guess']['compass_active'])->toBeFalse();
    expect($payload['round']['attempts_used'])->toBe(1);
})->with([
    'JSON numbers' => [['latitude' => 50.123, 'longitude' => 12.456]],
    'numeric strings' => [['latitude' => '50.123', 'longitude' => '12.456']],
]);

it('rejects an invalid pin before touching the service', function (array $body): void {
    $this->rounds->expects($this->never())->method('submitGuess');

    (new SubmitGuessAction($this->rounds, new RoundResponder()))(
        apiRequest('POST', '/rounds/3/guesses', $body)->withAttribute('user_id', 7),
        new Response(),
        ['id' => '3'],
    );
})->with([
    'missing longitude' => [['latitude' => 50.123]],
    'latitude out of range' => [['latitude' => 91, 'longitude' => 12.456]],
    'text instead of a number' => [['latitude' => 'north', 'longitude' => 12.456]],
])->throws(ValidationException::class);
