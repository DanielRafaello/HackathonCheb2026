<?php

declare(strict_types=1);

use App\Requests\Location\RateLocationRequest;

it('accepts a whole-star rating from 1 to 5', function (mixed $rating): void {
    expect((new RateLocationRequest(['rating' => $rating]))->passes())->toBeTrue();
})->with([1, 3, 5, '4']);

it('rejects missing, fractional, and out-of-range ratings', function (array $data): void {
    expect((new RateLocationRequest($data))->fails())->toBeTrue();
})->with([
    'missing'  => [[]],
    'zero'     => [['rating' => 0]],
    'six'      => [['rating' => 6]],
    'fraction' => [['rating' => 4.5]],
    'text'     => [['rating' => 'good']],
]);
