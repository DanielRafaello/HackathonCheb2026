<?php

declare(strict_types=1);

use App\Domain\LocationAchievement;
use App\Domain\Role;
use App\Domain\User;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Repositories\Contracts\ProfileRepositoryInterface;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Services\Profile\ProfileService;
use App\Services\Profile\Scoring;

beforeEach(function (): void {
    /**
     * Builds the service over stubbed repositories for user 7.
     *
     * @param list<LocationAchievement> $achievements
     */
    $this->serviceWith = function (array $achievements, bool $userExists = true): ProfileService {
        $users = $this->createStub(UserRepositoryInterface::class);
        $users->method('findById')->willReturn(
            $userExists ? new User(7, 'dan@example.com', 'Dan', Role::USER, '2026-10-10 12:00:00+00') : null,
        );

        $profiles = $this->createStub(ProfileRepositoryInterface::class);
        $profiles->method('findAchievementsForUser')->willReturn($achievements);

        return new ProfileService($users, $profiles, new Scoring());
    };
});

it('gives a new player level 1 with no points', function (): void {
    $profile = ($this->serviceWith)([])->forUser(7);

    expect($profile->user->name)->toBe('Dan');
    expect($profile->points())->toBe(0);
    expect($profile->level->level)->toBe(1);
    expect($profile->level->pointsToNextLevel())->toBe(250);
    expect($profile->guessedCount)->toBe(0);
    expect($profile->visitedCount)->toBe(0);
});

it('sums guess and visit points separately', function (): void {
    $profile = ($this->serviceWith)([
        new LocationAchievement(1, guessedOnAttempt: 1, guessed: true, visited: true),   // 200 + 400
        new LocationAchievement(2, guessedOnAttempt: 5, guessed: true, visited: false),  // 100
        new LocationAchievement(3, guessedOnAttempt: 3, guessed: true, visited: false),  // 125
    ])->forUser(7);

    expect($profile->pointsFromGuessing)->toBe(425);
    expect($profile->pointsFromVisits)->toBe(400);
    expect($profile->points())->toBe(825);
    expect($profile->level->level)->toBe(3);
    expect($profile->level->pointsToNextLevel())->toBe(675);
    expect($profile->guessedCount)->toBe(3);
    expect($profile->visitedCount)->toBe(1);
});

it('gives the minimum for a location hit only after the fifth attempt', function (): void {
    $profile = ($this->serviceWith)([
        new LocationAchievement(6, guessedOnAttempt: 8, guessed: true, visited: false),
    ])->forUser(7);

    expect($profile->pointsFromGuessing)->toBe(50);
    expect($profile->points())->toBe(50);
    expect($profile->guessedCount)->toBe(1);
});

it('counts a visit of a location that was never guessed', function (): void {
    $profile = ($this->serviceWith)([
        new LocationAchievement(4, guessedOnAttempt: null, guessed: false, visited: true),
    ])->forUser(7);

    expect($profile->points())->toBe(400);
    expect($profile->guessedCount)->toBe(0);
    expect($profile->visitedCount)->toBe(1);
});

it('counts a location marked as guessed without a round, but gives no points for it', function (): void {
    $profile = ($this->serviceWith)([
        new LocationAchievement(5, guessedOnAttempt: null, guessed: true, visited: false),
    ])->forUser(7);

    expect($profile->points())->toBe(0);
    expect($profile->guessedCount)->toBe(1);
});

it('reports a deleted account as not found', function (): void {
    ($this->serviceWith)([], userExists: false)->forUser(7);
})->throws(NotFoundException::class, 'not.found.user');
