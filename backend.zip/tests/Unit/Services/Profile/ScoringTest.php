<?php

declare(strict_types=1);

use App\Domain\LocationAchievement;
use App\Services\Profile\Scoring;

it('rewards a hit more the fewer attempts it took', function (int $attempt, int $points): void {
    expect((new Scoring())->pointsForGuess($attempt))->toBe($points);
})->with([
    'first attempt' => [1, 200],
    'second attempt' => [2, 150],
    'third attempt' => [3, 125],
    'fourth attempt' => [4, 110],
    'fifth attempt' => [5, 100],
]);

it('still gives the minimum for a hit after the fifth attempt', function (int $attempt): void {
    expect((new Scoring())->pointsForGuess($attempt))->toBe(50);
})->with([
    'sixth attempt' => [6],
    'tenth attempt' => [10],
    'hundredth attempt' => [100],
]);

it('never pays a late hit more than a hit within five attempts', function (): void {
    expect(Scoring::LATE_GUESS_POINTS)->toBeGreaterThan(0)->toBeLessThan(min(Scoring::GUESS_POINTS));
});

it('gives no guess points for anything that is not a round hit', function (?int $attempt): void {
    expect((new Scoring())->pointsForGuess($attempt))->toBe(0);
})->with([
    'not guessed in a round' => [null],
    'marked without playing' => [0],
    'negative attempt' => [-1],
]);

it('gives 400 points for a visit', function (): void {
    $scoring = new Scoring();

    expect($scoring->pointsForVisit(true))->toBe(400);
    expect($scoring->pointsForVisit(false))->toBe(0);
});

it('values a visit above the best possible guess', function (): void {
    expect(Scoring::VISIT_POINTS)->toBeGreaterThan(max(Scoring::GUESS_POINTS));
});

it('adds guess and visit points of one location', function (?int $attempt, bool $visited, int $points): void {
    $achievement = new LocationAchievement(12, $attempt, $attempt !== null, $visited);

    expect((new Scoring())->pointsFor($achievement))->toBe($points);
})->with([
    'first-attempt hit and a visit' => [1, true, 600],
    'fifth-attempt hit only' => [5, false, 100],
    'late hit and a visit' => [9, true, 450],
    'visit only' => [null, true, 400],
]);

it('starts each level 250 points further than the previous step', function (int $level, int $startsAt): void {
    expect((new Scoring())->levelStartsAt($level))->toBe($startsAt);
})->with([
    [1, 0],
    [2, 250],
    [3, 750],
    [4, 1500],
    [5, 2500],
    [10, 11250],
]);

it('finds the level for a point total', function (int $points, int $level): void {
    expect((new Scoring())->levelFor($points)->level)->toBe($level);
})->with([
    'no points' => [0, 1],
    'one point short of level 2' => [249, 1],
    'exactly level 2' => [250, 2],
    'one point short of level 3' => [749, 2],
    'exactly level 3' => [750, 3],
    'one guessed and visited location' => [600, 2],
    'every one of 112 locations at full score' => [112 * 600, 23],
]);

it('reports the progress inside the level', function (): void {
    $progress = (new Scoring())->levelFor(900);

    expect($progress->level)->toBe(3);
    expect($progress->points)->toBe(900);
    expect($progress->startsAt)->toBe(750);
    expect($progress->nextLevelAt)->toBe(1500);
    expect($progress->pointsInLevel())->toBe(150);
    expect($progress->pointsToNextLevel())->toBe(600);
});

it('always leaves at least one point to the next level', function (): void {
    $scoring = new Scoring();

    foreach ([0, 250, 750, 1500, 56000] as $points) {
        expect($scoring->levelFor($points)->pointsToNextLevel())->toBeGreaterThan(0);
        expect($scoring->levelFor($points)->pointsInLevel())->toBeGreaterThanOrEqual(0);
    }
});
