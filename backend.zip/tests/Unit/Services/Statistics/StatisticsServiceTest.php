<?php

declare(strict_types=1);

use App\Domain\LocationStatistics;
use App\Domain\StatisticsGranularity;
use App\Domain\StatisticsOverview;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Repositories\Contracts\StatisticsRepositoryInterface;
use App\Services\Statistics\StatisticsService;

final class InMemoryStatisticsRepository implements StatisticsRepositoryInterface
{
    /** @var array<string, array{visits: int, visitors: int}> what visitCounts() returns */
    public array $counts = [];

    /** @var list<int> */
    public array $existingLocations = [1, 12];

    /** @var list<array{from: string, to: string, granularity: StatisticsGranularity, locationId: ?int}> */
    public array $visitCountCalls = [];

    public function overview(): StatisticsOverview
    {
        return new StatisticsOverview(10, 6, 112, 20, 45, 80, 30, 4.2);
    }

    public function locationStatistics(): array
    {
        return [
            new LocationStatistics(12, 'Hrad Loket', 'Hrady, tvrze a zříceniny', 9, 14, 4.6, 7),
            new LocationStatistics(1, 'Hrad Cheb', 'Hrady, tvrze a zříceniny', 0, 0, null, 0),
        ];
    }

    public function locationExists(int $locationId): bool
    {
        return in_array($locationId, $this->existingLocations, true);
    }

    public function visitCounts(
        string $from,
        string $to,
        StatisticsGranularity $granularity,
        ?int $locationId = null,
    ): array {
        $this->visitCountCalls[] = compact('from', 'to', 'granularity', 'locationId');

        return $this->counts;
    }
}

beforeEach(function (): void {
    $this->repository = new InMemoryStatisticsRepository();
    $this->service = new StatisticsService($this->repository);
});

it('passes the overview and the location statistics through', function (): void {
    expect($this->service->overview()->usersTotal)->toBe(10);
    expect($this->service->overview()->averageRating)->toBe(4.2);
    expect($this->service->locations())->toHaveCount(2);
    expect($this->service->locations()[0]->name)->toBe('Hrad Loket');
});

it('returns twelve monthly points in calendar order', function (): void {
    $series = $this->service->visits(2026);

    expect($series->year)->toBe(2026);
    expect($series->granularity)->toBe(StatisticsGranularity::MONTH);
    expect($series->locationId)->toBeNull();
    expect(array_column($series->points, 'period'))->toBe([
        '2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06',
        '2026-07', '2026-08', '2026-09', '2026-10', '2026-11', '2026-12',
    ]);
});

it('fills the months without visits with zeros', function (): void {
    $this->repository->counts = [
        '2026-03' => ['visits' => 5, 'visitors' => 3],
        '2026-12' => ['visits' => 1, 'visitors' => 1],
    ];

    $series = $this->service->visits(2026);

    expect($series->points[0])->toBe(['period' => '2026-01', 'visits' => 0, 'visitors' => 0]);
    expect($series->points[2])->toBe(['period' => '2026-03', 'visits' => 5, 'visitors' => 3]);
    expect($series->points[11])->toBe(['period' => '2026-12', 'visits' => 1, 'visitors' => 1]);
    expect($series->totalVisits())->toBe(6);
});

it('returns a zero series for a year without any visits', function (): void {
    $series = $this->service->visits(2031);

    expect($series->points)->toHaveCount(12);
    expect($series->totalVisits())->toBe(0);
});

it('returns one point per day, with 366 points in a leap year', function (int $year, int $days): void {
    $series = $this->service->visits($year, StatisticsGranularity::DAY);

    expect($series->points)->toHaveCount($days);
    expect($series->points[0]['period'])->toBe("{$year}-01-01");
    expect($series->points[$days - 1]['period'])->toBe("{$year}-12-31");
    expect(array_unique(array_column($series->points, 'period')))->toHaveCount($days);
})->with([
    'common year' => [2026, 365],
    'leap year' => [2028, 366],
]);

it('places a daily count on its day', function (): void {
    $this->repository->counts = ['2026-07-04' => ['visits' => 2, 'visitors' => 2]];

    $series = $this->service->visits(2026, StatisticsGranularity::DAY);
    $byPeriod = array_column($series->points, 'visits', 'period');

    expect($byPeriod['2026-07-04'])->toBe(2);
    expect($byPeriod['2026-07-03'])->toBe(0);
    expect($series->totalVisits())->toBe(2);
});

it('asks the repository for exactly the calendar year in local time', function (): void {
    $this->service->visits(2026, StatisticsGranularity::DAY, 12);

    expect($this->repository->visitCountCalls)->toBe([[
        'from' => '2026-01-01 00:00:00',
        'to' => '2027-01-01 00:00:00',
        'granularity' => StatisticsGranularity::DAY,
        'locationId' => 12,
    ]]);
});

it('defaults to the current year in Europe/Prague', function (): void {
    $currentYear = (int) (new DateTimeImmutable('now', new DateTimeZone('Europe/Prague')))->format('Y');

    $series = $this->service->visits();

    expect($series->year)->toBe($currentYear);
    expect($series->points)->toHaveCount(12);
    expect($this->repository->visitCountCalls[0]['from'])->toBe("{$currentYear}-01-01 00:00:00");
});

it('limits the series to one location', function (): void {
    $series = $this->service->visits(2026, StatisticsGranularity::MONTH, 12);

    expect($series->locationId)->toBe(12);
    expect($this->repository->visitCountCalls[0]['locationId'])->toBe(12);
});

it('refuses a location that does not exist without querying visits', function (): void {
    expect(fn () => $this->service->visits(2026, StatisticsGranularity::MONTH, 999))
        ->toThrow(NotFoundException::class, 'not.found.location');
    expect($this->repository->visitCountCalls)->toBe([]);
});

it('ignores counts the repository returns for other periods', function (): void {
    $this->repository->counts = ['2025-12' => ['visits' => 9, 'visitors' => 9]];

    expect($this->service->visits(2026)->totalVisits())->toBe(0);
});
