<?php

declare(strict_types=1);

use App\Domain\Role;
use App\Domain\User;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Exceptions\generalExceptions\UnauthorizedException;
use App\Exceptions\Validation\ValidationException;
use App\Repositories\Contracts\RefreshTokenRepositoryInterface;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Services\Auth\AuthService;
use App\Services\JWT\JwtService;
use Doctrine\DBAL\Connection;

final class InMemoryUserRepository implements UserRepositoryInterface
{
    /** @var array<int, array<string, mixed>> */
    public array $rows = [];

    public function findById(int $id): ?User
    {
        return isset($this->rows[$id]) ? User::fromRow($this->rows[$id]) : null;
    }

    public function existsByEmail(string $email): bool
    {
        return $this->findAuthRecordByEmail($email) !== null;
    }

    public function findAuthRecordByEmail(string $email): ?array
    {
        foreach ($this->rows as $row) {
            if ($row['email'] === $email) {
                return $row;
            }
        }

        return null;
    }

    public function create(string $name, string $email, string $passwordHash, Role $role): User
    {
        $id = count($this->rows) + 1;
        $this->rows[$id] = [
            'id' => $id,
            'email' => $email,
            'name' => $name,
            'role' => $role->value,
            'password_hash' => $passwordHash,
            'created_at' => '2026-10-10 12:00:00+00',
        ];

        return User::fromRow($this->rows[$id]);
    }
}

final class InMemoryRefreshTokenRepository implements RefreshTokenRepositoryInterface
{
    /** @var array<string, array{user_id: int, expires_at: string, revoked_at: ?string}> keyed by token hash */
    public array $rows = [];

    public function create(int $userId, string $tokenHash, string $expiresAt): void
    {
        $this->rows[$tokenHash] = ['user_id' => $userId, 'expires_at' => $expiresAt, 'revoked_at' => null];
    }

    public function findValidUserId(string $tokenHash): ?int
    {
        $row = $this->rows[$tokenHash] ?? null;

        return $row !== null && $row['revoked_at'] === null ? $row['user_id'] : null;
    }

    public function revoke(string $tokenHash): void
    {
        if (isset($this->rows[$tokenHash])) {
            $this->rows[$tokenHash]['revoked_at'] ??= '2026-10-10 12:00:00+00';
        }
    }

    public function deleteExpiredAndRevoked(): int
    {
        return 0;
    }

    public function findByHash(string $tokenHash): ?array
    {
        return $this->rows[$tokenHash] ?? null;
    }

    public function revokeAllForUser(int $userId): void
    {
        foreach ($this->rows as $hash => $row) {
            if ($row['user_id'] === $userId) {
                $this->revoke($hash);
            }
        }
    }

    /** @return list<string> hashes of the tokens that still work */
    public function activeHashes(): array
    {
        return array_keys(array_filter($this->rows, fn (array $row): bool => $row['revoked_at'] === null));
    }
}

beforeEach(function (): void {
    $this->users = new InMemoryUserRepository();
    $this->refreshTokens = new InMemoryRefreshTokenRepository();
    $this->jwt = new JwtService('unit-test-secret-that-is-long-enough-for-hs256', 3600);
    $this->auth = new AuthService(
        $this->createStub(Connection::class),
        $this->users,
        $this->refreshTokens,
        $this->jwt,
        2592000,
    );
});

// ─── register ─────────────────────────────────────────────────

it('registers a user with the user role and returns a token pair', function (): void {
    $result = $this->auth->register('Dan', 'dan@example.com', 'secret-password');

    expect($result['user']->name)->toBe('Dan');
    expect($result['user']->email)->toBe('dan@example.com');
    expect($result['user']->role)->toBe(Role::USER);
    expect($this->jwt->verify($result['token']))->toBe(['sub' => $result['user']->id, 'role' => 'user']);
    expect($result['refresh_token'])->toMatch('/^[a-f0-9]{64}$/');
});

it('stores the password only as a bcrypt hash', function (): void {
    $result = $this->auth->register('Dan', 'dan@example.com', 'secret-password');

    $hash = $this->users->rows[$result['user']->id]['password_hash'];

    expect($hash)->not->toBe('secret-password');
    expect(password_verify('secret-password', $hash))->toBeTrue();
    expect(password_get_info($hash)['algoName'])->toBe('bcrypt');
});

it('stores the refresh token only as a sha256 hash', function (): void {
    $result = $this->auth->register('Dan', 'dan@example.com', 'secret-password');

    expect($this->refreshTokens->rows)->not->toHaveKey($result['refresh_token']);
    expect($this->refreshTokens->rows)->toHaveKey(hash('sha256', $result['refresh_token']));
});

it('makes the refresh token expire after the configured lifetime', function (): void {
    $result = $this->auth->register('Dan', 'dan@example.com', 'secret-password');

    $expiresAt = new DateTimeImmutable($this->refreshTokens->rows[hash('sha256', $result['refresh_token'])]['expires_at']);
    $lifetime = $expiresAt->getTimestamp() - time();

    expect($lifetime)->toBeGreaterThan(2592000 - 5)->toBeLessThanOrEqual(2592000);
});

it('refuses to register an e-mail twice', function (): void {
    $this->auth->register('Dan', 'dan@example.com', 'secret-password');

    try {
        $this->auth->register('Other Dan', 'dan@example.com', 'another-password');
    } catch (ValidationException $exception) {
        expect($exception->getErrors())->toBe(['email' => 'auth.register.email_taken']);
        expect($this->users->rows)->toHaveCount(1);

        return;
    }

    $this->fail('A duplicate e-mail was accepted.');
});

// ─── login ────────────────────────────────────────────────────

it('logs a registered user in with a fresh token pair', function (): void {
    $registered = $this->auth->register('Dan', 'dan@example.com', 'secret-password');

    $result = $this->auth->login('dan@example.com', 'secret-password');

    expect($result['user']->id)->toBe($registered['user']->id);
    expect($this->jwt->verify($result['token'])['sub'])->toBe($registered['user']->id);
    expect($result['refresh_token'])->not->toBe($registered['refresh_token']);
    expect($this->refreshTokens->activeHashes())->toHaveCount(2);
});

it('rejects a wrong password and an unknown e-mail with the same error', function (string $email, string $password): void {
    $this->auth->register('Dan', 'dan@example.com', 'secret-password');

    $this->auth->login($email, $password);
})->with([
    'wrong password' => ['dan@example.com', 'wrong-password'],
    'unknown e-mail' => ['nobody@example.com', 'secret-password'],
])->throws(UnauthorizedException::class, 'not.found.user.invalid.credentials');

// ─── refresh ──────────────────────────────────────────────────

it('rotates the refresh token', function (): void {
    $registered = $this->auth->register('Dan', 'dan@example.com', 'secret-password');

    $result = $this->auth->refresh($registered['refresh_token']);

    expect($result['user']->id)->toBe($registered['user']->id);
    expect($this->jwt->verify($result['token'])['sub'])->toBe($registered['user']->id);
    expect($result['refresh_token'])->not->toBe($registered['refresh_token']);
    expect($this->refreshTokens->activeHashes())->toBe([hash('sha256', $result['refresh_token'])]);
});

it('rejects an unknown refresh token', function (): void {
    $this->auth->refresh(str_repeat('a', 64));
})->throws(UnauthorizedException::class, 'invalid.refresh.token');

it('revokes every session when a refresh token is used twice', function (): void {
    $registered = $this->auth->register('Dan', 'dan@example.com', 'secret-password');
    $this->auth->login('dan@example.com', 'secret-password');
    $this->auth->refresh($registered['refresh_token']);

    expect(fn () => $this->auth->refresh($registered['refresh_token']))
        ->toThrow(UnauthorizedException::class, 'security.token_compromised.relogin_required');
    expect($this->refreshTokens->activeHashes())->toBe([]);
});

it('rejects an expired refresh token', function (): void {
    $registered = $this->auth->register('Dan', 'dan@example.com', 'secret-password');
    $hash = hash('sha256', $registered['refresh_token']);
    $this->refreshTokens->rows[$hash]['expires_at'] = '2020-01-01T00:00:00+00:00';

    $this->auth->refresh($registered['refresh_token']);
})->throws(UnauthorizedException::class, 'invalid.expired.refresh.token');

it('rejects a refresh token of a deleted user', function (): void {
    $registered = $this->auth->register('Dan', 'dan@example.com', 'secret-password');
    $this->users->rows = [];

    $this->auth->refresh($registered['refresh_token']);
})->throws(UnauthorizedException::class, 'not.found.user');

// ─── logout ───────────────────────────────────────────────────

it('revokes the refresh token on logout', function (): void {
    $registered = $this->auth->register('Dan', 'dan@example.com', 'secret-password');

    $this->auth->logout($registered['refresh_token']);

    expect($this->refreshTokens->activeHashes())->toBe([]);
});

it('logs out only the given session', function (): void {
    $registered = $this->auth->register('Dan', 'dan@example.com', 'secret-password');
    $second = $this->auth->login('dan@example.com', 'secret-password');

    $this->auth->logout($registered['refresh_token']);

    expect($this->refreshTokens->activeHashes())->toBe([hash('sha256', $second['refresh_token'])]);
});

it('ignores a logout with an unknown token', function (): void {
    $this->auth->logout(str_repeat('a', 64));
    $this->auth->logout(str_repeat('a', 64));

    expect($this->refreshTokens->rows)->toBe([]);
});

// ─── currentUser ──────────────────────────────────────────────

it('returns the current user', function (): void {
    $registered = $this->auth->register('Dan', 'dan@example.com', 'secret-password');

    $user = $this->auth->currentUser($registered['user']->id);

    expect($user->email)->toBe('dan@example.com');
});

it('reports a missing current user as not found', function (): void {
    $this->auth->currentUser(999);
})->throws(NotFoundException::class, 'not.found.user');

// ─── issueTokensFor ───────────────────────────────────────────

it('issues a token pair for an already resolved user', function (): void {
    $user = new User(5, 'eva@example.com', 'Eva', Role::ADMIN, '2026-10-10 12:00:00+00');

    $tokens = $this->auth->issueTokensFor($user);

    expect(array_keys($tokens))->toBe(['token', 'refresh_token']);
    expect($this->jwt->verify($tokens['token']))->toBe(['sub' => 5, 'role' => 'admin']);
    expect($this->refreshTokens->rows[hash('sha256', $tokens['refresh_token'])]['user_id'])->toBe(5);
});
