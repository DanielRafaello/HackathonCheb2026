<?php

declare(strict_types=1);

use App\Domain\LocationProgress;
use App\Domain\RoundTarget;
use App\Domain\UserLocation;
use App\Exceptions\generalExceptions\ForbiddenException;
use App\Exceptions\generalExceptions\NotFoundException;
use App\Exceptions\generalExceptions\UnprocessableEntityException;
use App\Repositories\Contracts\LocationRepositoryInterface;
use App\Services\Location\LocationService;
use App\Services\Profile\Scoring;

function locationService(
    LocationRepositoryInterface $repository = new InMemoryLocationRepository(),
    InMemoryWaferWallet $wallet = new InMemoryWaferWallet(),
): LocationService {
    return new LocationService($repository, $wallet, new Scoring());
}

final class InMemoryLocationRepository implements LocationRepositoryInterface
{
    private const LOCATIONS = [
        1 => ['Hrad Cheb', 50.081137, 12.366035],
        12 => ['Hrad Loket', 50.187104, 12.754285],
    ];

    /** @var array<string, array{guessed_at: ?string, visited_at: ?string}> keyed by "userId:locationId" */
    private array $progress = [];

    /** @var list<array{int, int, LocationProgress}> */
    public array $markCalls = [];

    public function findAllForUser(int $userId): array
    {
        return array_map(
            fn (int $locationId): UserLocation => $this->findForUser($userId, $locationId),
            array_keys(self::LOCATIONS),
        );
    }

    public function findForUser(int $userId, int $locationId): ?UserLocation
    {
        if (!isset(self::LOCATIONS[$locationId])) {
            return null;
        }

        [$name, $latitude, $longitude] = self::LOCATIONS[$locationId];
        $progress = $this->progress["{$userId}:{$locationId}"] ?? ['guessed_at' => null, 'visited_at' => null];

        return new UserLocation(
            $locationId,
            $name,
            $latitude,
            $longitude,
            $progress['guessed_at'],
            $progress['visited_at'],
            rating: $this->ratings["{$userId}:{$locationId}"] ?? null,
        );
    }

    public function mark(int $userId, int $locationId, LocationProgress $progress): bool
    {
        $this->markCalls[] = [$userId, $locationId, $progress];

        $key = "{$userId}:{$locationId}";
        $this->progress[$key] ??= ['guessed_at' => null, 'visited_at' => null];
        $stamped = $this->progress[$key][$progress->column()] === null;
        $this->progress[$key][$progress->column()] ??= '2026-10-10T12:00:00Z';

        return $stamped;
    }

    /** @var array<string, int> keyed by "userId:locationId" */
    public array $ratings = [];

    public function findCard(int $locationId): ?RoundTarget
    {
        if (!isset(self::LOCATIONS[$locationId])) {
            return null;
        }

        [$name, $latitude, $longitude] = self::LOCATIONS[$locationId];

        return new RoundTarget(
            id: $locationId,
            name: $name,
            latitude: $latitude,
            longitude: $longitude,
            category: 'Hrady, tvrze a zříceniny',
            description: "Popis: {$name}.",
            hint1: 'Klíč 1.',
            hint2: 'Klíč 2.',
            contentSourceUrl: null,
            sourceTitle: 'Hrady',
            sourcePublisher: 'Karlovarský kraj',
            sourcePortalUrl: 'https://datazapad.cz',
            sourceLicenseCode: 'CC BY 4.0',
            sourceLicenseUrl: 'https://creativecommons.org/licenses/by/4.0/',
            sourceAttributionText: 'Zdroj: datazapad.cz',
            sourceRetrievedAt: null,
            sourceUpdatedAt: null,
        );
    }

    public function rate(int $userId, int $locationId, int $rating): bool
    {
        if (($this->progress["{$userId}:{$locationId}"]['visited_at'] ?? null) === null) {
            return false;
        }

        $this->ratings["{$userId}:{$locationId}"] = $rating;

        return true;
    }
}

it('lists every location for the user', function (): void {
    $service = locationService();

    $locations = $service->listForUser(7);

    expect($locations)->toHaveCount(2);
    expect($locations[0]->name)->toBe('Hrad Cheb');
    expect($locations[1]->name)->toBe('Hrad Loket');
    expect($locations[0]->isGuessed())->toBeFalse();
});

it('marks a location and returns its new state', function (LocationProgress $progress, bool $guessed, bool $visited): void {
    $service = locationService();

    $location = $service->mark(7, 12, $progress)->location;

    expect($location->id)->toBe(12);
    expect($location->isGuessed())->toBe($guessed);
    expect($location->isVisited())->toBe($visited);
})->with([
    'guessed' => [LocationProgress::GUESSED, true, false],
    'visited' => [LocationProgress::VISITED, false, true],
]);

it('keeps guessed and visited independent of each other', function (): void {
    $service = locationService();

    $service->mark(7, 12, LocationProgress::GUESSED);
    $location = $service->mark(7, 12, LocationProgress::VISITED)->location;

    expect($location->isGuessed())->toBeTrue();
    expect($location->isVisited())->toBeTrue();
});

it('keeps the progress of each user separate', function (): void {
    $service = locationService();

    $service->mark(7, 12, LocationProgress::GUESSED);

    expect($service->listForUser(7)[1]->isGuessed())->toBeTrue();
    expect($service->listForUser(8)[1]->isGuessed())->toBeFalse();
});

it('refuses to mark a location that does not exist', function (): void {
    $repository = new InMemoryLocationRepository();
    $service = locationService($repository);

    expect(fn () => $service->mark(7, 999, LocationProgress::GUESSED))
        ->toThrow(NotFoundException::class, 'not.found.location');
    expect($repository->markCalls)->toBe([]);
});

it('rates a visited location and lets the rating be replaced', function (): void {
    $service = locationService();
    $service->mark(7, 12, LocationProgress::VISITED);

    expect($service->rate(7, 12, 4)->rating)->toBe(4);
    expect($service->rate(7, 12, 2)->rating)->toBe(2);
});

it('refuses to rate a location the user has not visited', function (): void {
    $repository = new InMemoryLocationRepository();
    $service = locationService($repository);
    $service->mark(7, 12, LocationProgress::GUESSED);

    expect(fn () => $service->rate(7, 12, 5))
        ->toThrow(UnprocessableEntityException::class, 'location.not_visited');
    expect($repository->ratings)->toBe([]);
});

it('refuses to rate a location that does not exist', function (): void {
    $service = locationService();

    $service->rate(7, 999, 5);
})->throws(NotFoundException::class, 'not.found.location');

it('pays fifty wafers for the first visit of a location only', function (): void {
    $wallet = new InMemoryWaferWallet();
    $service = locationService(wallet: $wallet);

    expect($service->mark(7, 12, LocationProgress::VISITED)->wafersEarned)->toBe(50);
    expect($service->mark(7, 12, LocationProgress::VISITED)->wafersEarned)->toBe(0);
    expect($service->mark(7, 1, LocationProgress::VISITED)->wafersEarned)->toBe(50);
    expect($wallet->of(7))->toBe(100);
});

it('pays nothing for marking a location as guessed', function (): void {
    $wallet = new InMemoryWaferWallet();
    $service = locationService(wallet: $wallet);

    expect($service->mark(7, 12, LocationProgress::GUESSED)->wafersEarned)->toBe(0);
    expect($wallet->of(7))->toBe(0);
});

it('gives the description of a guessed or a visited location', function (LocationProgress $progress): void {
    $service = locationService();
    $service->mark(7, 12, $progress);

    $card = $service->description(7, 12);

    expect($card->id)->toBe(12);
    expect($card->description)->toBe('Popis: Hrad Loket.');
    expect($card->sourceLicenseCode)->toBe('CC BY 4.0');
})->with([
    'guessed' => [LocationProgress::GUESSED],
    'visited' => [LocationProgress::VISITED],
]);

it('keeps the description of a location in the fog hidden', function (): void {
    $service = locationService();
    $service->mark(8, 12, LocationProgress::VISITED);

    $service->description(7, 12);
})->throws(ForbiddenException::class, 'location.in_fog');

it('refuses the description of a location that does not exist', function (): void {
    locationService()->description(7, 999);
})->throws(NotFoundException::class, 'not.found.location');
