<?php

declare(strict_types=1);

use App\Domain\Role;
use App\Domain\User;
use App\Exceptions\generalExceptions\UnauthorizedException;
use App\Services\JWT\JwtService;

const JWT_TEST_SECRET = 'unit-test-secret-that-is-long-enough-for-hs256';

function jwtTestUser(Role $role = Role::USER): User
{
    return new User(7, 'dan@example.com', 'Dan', $role, '2026-10-09 21:13:42+00');
}

it('issues a token that verifies back to the user id and role', function (Role $role): void {
    $jwt = new JwtService(JWT_TEST_SECRET, 3600);

    $claims = $jwt->verify($jwt->issue(jwtTestUser($role)));

    expect($claims)->toBe(['sub' => 7, 'role' => $role->value]);
})->with([
    'user' => [Role::USER],
    'admin' => [Role::ADMIN],
]);

it('issues a three-part JWT that expires after the configured lifetime', function (): void {
    $before = time();
    $token = (new JwtService(JWT_TEST_SECRET, 3600))->issue(jwtTestUser());

    $parts = explode('.', $token);
    $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/'), true), true);

    expect($parts)->toHaveCount(3);
    expect($payload['iat'])->toBeGreaterThanOrEqual($before);
    expect($payload['exp'] - $payload['iat'])->toBe(3600);
});

it('keeps personal data out of the token', function (): void {
    $token = (new JwtService(JWT_TEST_SECRET, 3600))->issue(jwtTestUser());

    $payload = json_decode(base64_decode(strtr(explode('.', $token)[1], '-_', '+/'), true), true);

    expect(array_keys($payload))->toBe(['sub', 'role', 'iat', 'exp']);
});

it('rejects an expired token', function (): void {
    $jwt = new JwtService(JWT_TEST_SECRET, -60);

    $jwt->verify($jwt->issue(jwtTestUser()));
})->throws(UnauthorizedException::class, 'Invalid or expired token.');

it('rejects a token signed with another secret', function (): void {
    $token = (new JwtService('another-secret-that-is-also-long-enough-123', 3600))->issue(jwtTestUser());

    (new JwtService(JWT_TEST_SECRET, 3600))->verify($token);
})->throws(UnauthorizedException::class, 'Invalid or expired token.');

it('rejects a token whose payload was changed', function (): void {
    $jwt = new JwtService(JWT_TEST_SECRET, 3600);
    [$header, , $signature] = explode('.', $jwt->issue(jwtTestUser()));

    $forgedPayload = rtrim(strtr(base64_encode(json_encode([
        'sub' => 7,
        'role' => 'admin',
        'iat' => time(),
        'exp' => time() + 3600,
    ])), '+/', '-_'), '=');

    $jwt->verify("{$header}.{$forgedPayload}.{$signature}");
})->throws(UnauthorizedException::class);

it('rejects anything that is not a JWT', function (string $token): void {
    (new JwtService(JWT_TEST_SECRET, 3600))->verify($token);
})->with([
    'empty string' => [''],
    'random text' => ['not-a-token'],
    'three empty parts' => ['..'],
])->throws(UnauthorizedException::class);
