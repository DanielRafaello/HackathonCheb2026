<?php

declare(strict_types=1);

use App\Services\Round\GeoCalculator;

it('calculates distance in metres with the Haversine formula', function (): void {
    $geo = new GeoCalculator();

    expect($geo->distanceMeters(50.22768, 12.879553, 50.22768, 12.879553))->toBe(0);
    expect($geo->distanceMeters(50.22768, 12.879553, 50.23600, 12.879553))
        ->toBeGreaterThan(900)
        ->toBeLessThan(950);
});

it('calculates the eight-point direction from a guess towards the target', function (): void {
    $geo = new GeoCalculator();

    expect($geo->direction(50.0, 12.0, 51.0, 12.0))->toBe('N');
    expect($geo->direction(50.0, 12.0, 50.0, 13.0))->toBe('E');
    expect($geo->direction(50.0, 12.0, 49.0, 11.0))->toBe('SW');
});
