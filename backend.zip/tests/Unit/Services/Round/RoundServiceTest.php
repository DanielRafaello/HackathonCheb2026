<?php

declare(strict_types=1);

use App\Domain\GameRound;
use App\Domain\GuessResult;
use App\Domain\RoundStatus;
use App\Domain\RoundTarget;
use App\Exceptions\generalExceptions\ConflictException;
use App\Repositories\Contracts\RoundRepositoryInterface;
use App\Responder\Round\RoundResponder;
use App\Services\Round\GeoCalculator;
use App\Services\Profile\Scoring;
use App\Services\Round\RoundService;

function testRoundTarget(): RoundTarget
{
    return new RoundTarget(
        id: 42,
        name: 'Tajné místo',
        latitude: 50.0,
        longitude: 12.0,
        category: 'Hrady, tvrze a zříceniny',
        description: 'Popis místa.',
        hint1: 'Pod podlahou se desítky let ukrýval vzácný předmět.',
        hint2: 'Přibližně 10–20 km vzdušnou čarou od centra Chebu.',
        contentSourceUrl: 'https://example.com/place',
        sourceTitle: 'Dataset',
        sourcePublisher: 'Publisher',
        sourcePortalUrl: 'https://example.com/dataset',
        sourceLicenseCode: 'CC BY 4.0',
        sourceLicenseUrl: 'https://creativecommons.org/licenses/by/4.0/',
        sourceAttributionText: 'Attribution',
        sourceRetrievedAt: '2026-10-09T00:00:00+00:00',
        sourceUpdatedAt: '2026-10-08T00:00:00+00:00',
    );
}

final class InMemoryRoundRepository implements RoundRepositoryInterface
{
    /** @var array<int, GameRound> */
    public array $rounds = [];
    private ?GuessResult $pendingGuess = null;

    public function transactional(callable $callback): mixed
    {
        return $callback();
    }

    public function getOrCreateDailyForUser(int $userId, string $date): ?GameRound
    {
        foreach ($this->rounds as $round) {
            if ($round->userId === $userId && $round->dailyDate === $date) {
                return $round;
            }
        }

        return $this->rounds[1] = activeTestRound($date);
    }

    public function findForUser(int $userId, int $roundId, bool $forUpdate = false): ?GameRound
    {
        $round = $this->rounds[$roundId] ?? null;

        return $round?->userId === $userId ? $round : null;
    }

    public function addGuess(int $roundId, float $latitude, float $longitude, GuessResult $guess): void
    {
        $this->pendingGuess = $guess;
    }

    public function updateState(int $roundId, int $attemptsUsed, RoundStatus $status): void
    {
        $round = $this->rounds[$roundId];
        $stars = match ($status) {
            RoundStatus::GUESSED => GameRound::starsForHit($attemptsUsed),
            RoundStatus::ACTIVE, RoundStatus::EXPIRED => null,
        };
        $this->rounds[$roundId] = new GameRound(
            id: $round->id,
            userId: $round->userId,
            status: $status,
            attemptsUsed: $attemptsUsed,
            stars: $stars,
            dailyDate: $round->dailyDate,
            completedAt: $status === RoundStatus::ACTIVE ? null : '2026-10-10T12:00:00Z',
            target: $round->target,
            lastGuess: $this->pendingGuess,
        );
    }

    public function addRound(GameRound $round): void
    {
        $this->rounds[$round->id] = $round;
    }
}

function activeTestRound(string $date = '2026-10-10'): GameRound
{
    return new GameRound(
        id: 1,
        userId: 7,
        status: RoundStatus::ACTIVE,
        attemptsUsed: 0,
        stars: null,
        dailyDate: $date,
        completedAt: null,
        target: testRoundTarget(),
    );
}

function roundServiceFixture(GameRound $round): array
{
    $rounds = new InMemoryRoundRepository();
    $rounds->addRound($round);

    $wallet = new InMemoryWaferWallet();

    return [new RoundService($rounds, new GeoCalculator(), $wallet, new Scoring()), $rounds, $wallet];
}

it('keeps the target and compass secret during the first three misses', function (): void {
    [$service] = roundServiceFixture(activeTestRound());

    for ($attempt = 1; $attempt <= 3; ++$attempt) {
        $submission = $service->submitGuess(7, 1, 49.0, 11.0);
        $payload = RoundResponder::present($submission->round);

        expect($submission->guess->hit)->toBeFalse();
        expect($submission->guess->direction)->toBe('NE');
        expect($submission->round->attemptsUsed)->toBe($attempt);
        expect($payload['compass_active'])->toBeFalse();
        expect($payload['last_guess']['compass_active'])->toBeFalse();
        expect($payload['last_guess']['distance_meters'])->toBeNull();
        expect($payload['last_guess']['direction'])->toBeNull();
        expect($payload['clues'])->toHaveCount($attempt + 1);
        expect($payload)->not->toHaveKey('location');
    }
});

it('activates the compass after the fourth miss', function (): void {
    [$service] = roundServiceFixture(activeTestRound());

    for ($attempt = 1; $attempt <= 4; ++$attempt) {
        $submission = $service->submitGuess(7, 1, 49.0, 11.0);
    }

    $payload = RoundResponder::present($submission->round);

    expect($submission->round->status)->toBe(RoundStatus::ACTIVE);
    expect($submission->round->attemptsUsed)->toBe(4);
    expect($payload['compass_active'])->toBeTrue();
    expect($payload['last_guess']['compass_active'])->toBeTrue();
    expect($payload['last_guess']['distance_meters'])->toBeGreaterThan(0);
    expect($payload['last_guess']['direction'])->toBe('NE');
    expect($payload['clues'])->toHaveCount(4);
    expect($payload)->not->toHaveKey('location');
});

it('finishes a close first guess with five stars', function (): void {
    [$service] = roundServiceFixture(activeTestRound());

    $submission = $service->submitGuess(7, 1, 50.0, 12.0);
    $payload = RoundResponder::present($submission->round);

    expect($submission->guess->hit)->toBeTrue();
    expect($submission->guess->distanceMeters)->toBe(0);
    expect($submission->guess->direction)->toBeNull();
    expect($submission->round->status)->toBe(RoundStatus::GUESSED);
    expect($submission->round->stars)->toBe(5);
    expect($payload['location']['name'])->toBe('Tajné místo');
});

it('counts a guess within 3 km as a hit and one farther away as a miss', function (): void {
    // 0.025° of latitude is about 2.8 km, 0.03° about 3.3 km.
    [$service] = roundServiceFixture(activeTestRound());
    expect($service->submitGuess(7, 1, 50.03, 12.0)->guess->hit)->toBeFalse();

    [$service] = roundServiceFixture(activeTestRound());
    expect($service->submitGuess(7, 1, 50.025, 12.0)->guess->hit)->toBeTrue();
});

it('pays two wafers per star of a hit and none for a miss', function (): void {
    [$service, , $wallet] = roundServiceFixture(activeTestRound());

    expect($service->submitGuess(7, 1, 49.0, 11.0)->wafersEarned)->toBe(0);
    expect($wallet->of(7))->toBe(0);

    // The second attempt hits for 4 stars.
    expect($service->submitGuess(7, 1, 50.0, 12.0)->wafersEarned)->toBe(8);
    expect($wallet->of(7))->toBe(8);
});

it('pays ten wafers for a first-attempt hit and two for a hit with the compass', function (): void {
    [$service, , $wallet] = roundServiceFixture(activeTestRound());
    expect($service->submitGuess(7, 1, 50.0, 12.0)->wafersEarned)->toBe(10);

    [$service, , $wallet] = roundServiceFixture(activeTestRound());
    for ($attempt = 1; $attempt <= 6; ++$attempt) {
        $service->submitGuess(7, 1, 49.0, 11.0);
    }
    expect($service->submitGuess(7, 1, 50.0, 12.0)->wafersEarned)->toBe(2);
    expect($wallet->of(7))->toBe(2);
});

it('stays active after more than five misses without revealing the target', function (): void {
    [$service] = roundServiceFixture(activeTestRound());

    for ($attempt = 1; $attempt <= 7; ++$attempt) {
        $submission = $service->submitGuess(7, 1, 49.0, 11.0);
    }

    $payload = RoundResponder::present($submission->round);

    expect($submission->round->status)->toBe(RoundStatus::ACTIVE);
    expect($submission->round->attemptsUsed)->toBe(7);
    expect($submission->round->stars)->toBeNull();
    expect($payload['attempts_remaining'])->toBeNull();
    expect($payload['max_attempts'])->toBeNull();
    expect($payload['compass_active'])->toBeTrue();
    expect($payload)->not->toHaveKey('location');
});

it('allows a later hit and awards at least one star', function (): void {
    [$service] = roundServiceFixture(activeTestRound());

    for ($attempt = 1; $attempt <= 6; ++$attempt) {
        $service->submitGuess(7, 1, 49.0, 11.0);
    }

    $submission = $service->submitGuess(7, 1, 50.0, 12.0);
    $payload = RoundResponder::present($submission->round);

    expect($submission->guess->attemptNumber)->toBe(7);
    expect($submission->round->status)->toBe(RoundStatus::GUESSED);
    expect($submission->round->stars)->toBe(1);
    expect($payload['compass_active'])->toBeFalse();
    expect($payload['location']['name'])->toBe('Tajné místo');
});

it('rejects guesses for an expired daily location', function (): void {
    $expired = new GameRound(
        id: 1,
        userId: 7,
        status: RoundStatus::EXPIRED,
        attemptsUsed: 2,
        stars: null,
        dailyDate: '2026-10-09',
        completedAt: null,
        target: testRoundTarget(),
    );
    [$service] = roundServiceFixture($expired);

    expect(fn () => $service->submitGuess(7, 1, 50.0, 12.0))
        ->toThrow(ConflictException::class, 'round.not_active');
    expect(RoundResponder::present($expired))->not->toHaveKey('location');
});
