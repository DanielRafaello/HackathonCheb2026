<?php

declare(strict_types=1);

use App\Settings\Settings;
use App\Settings\SettingsFactory;

it('reads a nested value with dot notation', function (): void {
    $settings = new Settings(['db' => ['host' => 'db', 'port' => 5432]]);

    expect($settings->get('db.host'))->toBe('db');
    expect($settings->get('db.port'))->toBe(5432);
    expect($settings->get('db'))->toBe(['host' => 'db', 'port' => 5432]);
});

it('falls back to the default for a missing key', function (string $key): void {
    $settings = new Settings(['db' => ['host' => 'db'], 'name' => 'App']);

    expect($settings->get($key))->toBeNull();
    expect($settings->get($key, 'fallback'))->toBe('fallback');
})->with([
    'missing top-level key' => ['cache'],
    'missing nested key' => ['db.password'],
    'path through a scalar' => ['name.first'],
    'path deeper than the data' => ['db.host.name'],
]);

it('returns a stored null instead of the default', function (): void {
    $settings = new Settings(['db' => ['password' => null]]);

    expect($settings->get('db.password', 'fallback'))->toBeNull();
});

it('prefers a literal key that contains a dot', function (): void {
    $settings = new Settings(['db.host' => 'literal', 'db' => ['host' => 'nested']]);

    expect($settings->get('db.host'))->toBe('literal');
});

describe('SettingsFactory', function (): void {
    beforeEach(function (): void {
        $this->originalEnv = $_ENV;
        $_ENV = [
            'DB_DRIVER' => 'pdo_pgsql',
            'DB_HOST' => 'db',
            'DB_PORT' => '5432',
            'DB_NAME' => 'myapp',
            'DB_USER' => 'myapp',
            'DB_PASSWORD' => 'secret',
            'JWT_SECRET' => 'jwt-secret',
        ];
    });

    afterEach(function (): void {
        $_ENV = $this->originalEnv;
    });

    it('maps the environment to settings and casts numbers', function (): void {
        $_ENV += [
            'APP_NAME' => 'Kde na západě',
            'APP_ENV' => 'development',
            'FRONTEND_URL' => 'https://example.com',
            'JWT_TTL_SECONDS' => '3600',
            'REFRESH_TTL_SECONDS' => '86400',
        ];

        $settings = (new SettingsFactory())();

        expect($settings->get('db'))->toBe([
            'driver' => 'pdo_pgsql',
            'host' => 'db',
            'port' => 5432,
            'dbname' => 'myapp',
            'user' => 'myapp',
            'password' => 'secret',
        ]);
        expect($settings->get('app'))->toBe([
            'name' => 'Kde na západě',
            'env' => 'development',
            'frontend_url' => 'https://example.com',
        ]);
        expect($settings->get('jwt'))->toBe([
            'secret' => 'jwt-secret',
            'ttl_seconds' => 3600,
            'refresh_ttl_seconds' => 86400,
        ]);
    });

    it('defaults to production and safe lifetimes when optional values are missing', function (): void {
        $settings = (new SettingsFactory())();

        expect($settings->get('app.name'))->toBe('App');
        expect($settings->get('app.env'))->toBe('production');
        expect($settings->get('app.frontend_url'))->toBe('http://localhost:5173');
        expect($settings->get('jwt.ttl_seconds'))->toBe(604800);
        expect($settings->get('jwt.refresh_ttl_seconds'))->toBe(2592000);
    });
});
