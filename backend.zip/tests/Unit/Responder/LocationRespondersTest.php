<?php

declare(strict_types=1);

use App\Domain\UserLocation;
use App\Responder\Location\LocationListResponder;
use App\Responder\Location\LocationResponder;
use Slim\Psr7\Response;

it('presents a location with flags derived from the timestamps', function (): void {
    $location = new UserLocation(12, 'Hrad Loket', 50.187104, 12.754285, '2026-10-09T21:42:14Z', null);

    expect(LocationResponder::present($location))->toBe([
        'id' => 12,
        'name' => 'Hrad Loket',
        'latitude' => 50.187104,
        'longitude' => 12.754285,
        'guessed' => true,
        'guessed_at' => '2026-10-09T21:42:14Z',
        'visited' => false,
        'visited_at' => null,
        'rating' => null,
        'rated_at' => null,
        'average_rating' => null,
        'rating_count' => 0,
    ]);
});

it('presents the rating of the caller and of everyone', function (): void {
    $location = new UserLocation(
        12,
        'Hrad Loket',
        50.187104,
        12.754285,
        '2026-10-09T21:42:14Z',
        '2026-10-09T21:42:17Z',
        rating: 4,
        ratedAt: '2026-10-10T08:00:00Z',
        averageRating: 4.3,
        ratingCount: 7,
    );

    $payload = LocationResponder::present($location);

    expect($payload['rating'])->toBe(4);
    expect($payload['rated_at'])->toBe('2026-10-10T08:00:00Z');
    expect($payload['average_rating'])->toBe(4.3);
    expect($payload['rating_count'])->toBe(7);
});

it('wraps a single location', function (): void {
    $location = new UserLocation(1, 'Hrad Cheb', 50.081137, 12.366035, null, null);

    $response = (new LocationResponder())->respond(new Response(), $location);

    expect($response->getStatusCode())->toBe(200);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect(jsonOf($response))->toBe(['location' => LocationResponder::present($location)]);
});

it('lists locations in the given order and the same shape', function (): void {
    $locations = [
        new UserLocation(1, 'Hrad Cheb', 50.081137, 12.366035, null, null),
        new UserLocation(12, 'Hrad Loket', 50.187104, 12.754285, '2026-10-09T21:42:14Z', '2026-10-09T21:42:17Z'),
    ];

    $response = (new LocationListResponder())->respond(new Response(), $locations);

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response))->toBe([
        'locations' => array_map(LocationResponder::present(...), $locations),
    ]);
});

it('returns an empty list, not null, when there are no locations', function (): void {
    $response = (new LocationListResponder())->respond(new Response(), []);

    expect((string) $response->getBody())->toBe('{"locations":[]}');
});

it('keeps the full precision of the coordinates in the JSON', function (): void {
    $location = new UserLocation(1, 'Hrad Cheb', 50.081137, 12.366035, null, null);

    $body = (string) (new LocationResponder())->respond(new Response(), $location)->getBody();

    expect($body)->toContain('"latitude":50.081137')->toContain('"longitude":12.366035');
});
