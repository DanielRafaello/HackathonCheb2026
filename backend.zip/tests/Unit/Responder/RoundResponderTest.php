<?php

declare(strict_types=1);

use App\Domain\GuessResult;
use App\Domain\GuessSubmission;
use App\Domain\RoundStatus;
use App\Responder\Round\RoundResponder;
use Slim\Psr7\Response;

it('presents an active round without anything that identifies the target', function (): void {
    $payload = RoundResponder::present(roundFixture());

    expect($payload)->toBe([
        'id' => 3,
        'status' => 'active',
        'daily_date' => '2026-10-10',
        'attempts_used' => 0,
        'attempts_remaining' => null,
        'max_attempts' => null,
        'compass_active' => false,
        'stars' => null,
        'clues' => [['position' => 1, 'type' => 'distinctive_fact', 'text' => 'První nápověda.']],
        'completed_at' => null,
        'last_guess' => null,
    ]);
});

it('never leaks the target of an unfinished round', function (RoundStatus $status): void {
    $json = json_encode(RoundResponder::present(roundFixture($status, 0)), JSON_UNESCAPED_UNICODE);

    expect($json)
        ->not->toContain('Tajné místo')
        ->not->toContain('Popis místa.')
        ->not->toContain('"location"')
        ->not->toContain('"latitude"');
})->with([
    'active' => [RoundStatus::ACTIVE],
    'expired' => [RoundStatus::EXPIRED],
]);

it('reveals the location with its source once the round is guessed', function (): void {
    $payload = RoundResponder::present(roundFixture(RoundStatus::GUESSED, 5, 1));

    expect($payload['status'])->toBe(RoundStatus::GUESSED->value);
    expect($payload['stars'])->toBe(1);
    expect($payload['completed_at'])->toBe('2026-10-10T12:00:00Z');
    expect($payload['clues'])->toHaveCount(4);
    expect($payload['location'])->toBe([
        'id' => 42,
        'name' => 'Tajné místo',
        'latitude' => 50.0,
        'longitude' => 12.0,
        'category' => 'Hrady, tvrze a zříceniny',
        'description' => 'Popis místa.',
        'content_source_url' => 'https://example.com/place',
        'source' => [
            'title' => 'Dataset',
            'publisher' => 'Publisher',
            'portal_url' => 'https://example.com/dataset',
            'license_code' => 'CC BY 4.0',
            'license_url' => 'https://creativecommons.org/licenses/by/4.0/',
            'attribution_text' => 'Attribution',
            'retrieved_at' => '2026-10-09T00:00:00+00:00',
            'source_updated_at' => '2026-10-08T00:00:00+00:00',
        ],
    ]);
});

it('includes the last guess of the round', function (): void {
    $guess = new GuessResult(attemptNumber: 2, hit: false, distanceMeters: 13250, direction: 'SE');

    $payload = RoundResponder::present(roundFixture(RoundStatus::ACTIVE, 2, lastGuess: $guess));

    expect($payload['last_guess'])->toBe([
        'attempt_number' => 2,
        'hit' => false,
        'distance_meters' => null,
        'direction' => null,
        'compass_active' => false,
    ]);
    expect($payload['attempts_remaining'])->toBeNull();
    expect($payload['max_attempts'])->toBeNull();
    expect($payload['compass_active'])->toBeFalse();
});

it('includes compass feedback from the fourth miss onward', function (): void {
    $guess = new GuessResult(attemptNumber: 4, hit: false, distanceMeters: 13250, direction: 'SE');

    $payload = RoundResponder::present(roundFixture(RoundStatus::ACTIVE, 4, lastGuess: $guess));

    expect($payload['last_guess'])->toBe([
        'attempt_number' => 4,
        'hit' => false,
        'distance_meters' => 13250,
        'direction' => 'SE',
        'compass_active' => true,
    ]);
    expect($payload['compass_active'])->toBeTrue();
});

it('wraps a round and uses the given status', function (): void {
    $round = roundFixture();

    $response = (new RoundResponder())->respond(new Response(), $round, 201);

    expect($response->getStatusCode())->toBe(201);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect(jsonOf($response))->toBe(['round' => RoundResponder::present($round)]);
});

it('answers a guess with the guess and the updated round', function (): void {
    $guess = new GuessResult(attemptNumber: 1, hit: true, distanceMeters: 120, direction: null);
    $round = roundFixture(RoundStatus::GUESSED, 1, 5, $guess);

    $response = (new RoundResponder())->guess(new Response(), new GuessSubmission($round, $guess, 10));

    $body = jsonOf($response);
    expect($body['wafers_earned'])->toBe(10);

    expect($response->getStatusCode())->toBe(200);
    expect($body['guess'])->toBe([
        'attempt_number' => 1,
        'hit' => true,
        'distance_meters' => 120,
        'direction' => null,
        'compass_active' => false,
    ]);
    // toEqual: JSON carries the whole-number coordinates 50.0 / 12.0 as 50 / 12
    expect($body['round'])->toEqual(RoundResponder::present($round));
    expect($body['round']['location']['name'])->toBe('Tajné místo');
});
