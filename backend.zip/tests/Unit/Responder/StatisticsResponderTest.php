<?php

declare(strict_types=1);

use App\Domain\LocationStatistics;
use App\Domain\StatisticsGranularity;
use App\Domain\StatisticsOverview;
use App\Domain\VisitSeries;
use App\Responder\Admin\StatisticsResponder;
use Slim\Psr7\Response;

it('presents the overview grouped by topic', function (): void {
    $overview = new StatisticsOverview(
        usersTotal: 10,
        usersActive: 6,
        locationsTotal: 112,
        locationsVisited: 20,
        visitsTotal: 45,
        guessesTotal: 80,
        ratingsTotal: 30,
        averageRating: 4.2,
    );

    $response = (new StatisticsResponder())->overview(new Response(), $overview);

    expect($response->getStatusCode())->toBe(200);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect(jsonOf($response))->toBe([
        'overview' => [
            'users' => ['total' => 10, 'active' => 6],
            'locations' => ['total' => 112, 'visited' => 20],
            'visits' => ['total' => 45],
            'guesses' => ['total' => 80],
            'ratings' => ['total' => 30, 'average' => 4.2],
        ],
    ]);
});

it('presents an average of null while there are no ratings', function (): void {
    $overview = new StatisticsOverview(0, 0, 112, 0, 0, 0, 0, null);

    $body = jsonOf((new StatisticsResponder())->overview(new Response(), $overview));

    expect($body['overview']['ratings'])->toBe(['total' => 0, 'average' => null]);
});

it('lists location statistics in the given order', function (): void {
    $locations = [
        new LocationStatistics(12, 'Hrad Loket', 'Hrady, tvrze a zříceniny', 9, 14, 4.6, 7),
        new LocationStatistics(1, 'Hrad Cheb', 'Hrady, tvrze a zříceniny', 0, 0, null, 0),
    ];

    $response = (new StatisticsResponder())->locations(new Response(), $locations);

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response))->toBe([
        'locations' => [
            [
                'id' => 12,
                'name' => 'Hrad Loket',
                'category' => 'Hrady, tvrze a zříceniny',
                'visitors' => 9,
                'guessed_by' => 14,
                'average_rating' => 4.6,
                'rating_count' => 7,
            ],
            [
                'id' => 1,
                'name' => 'Hrad Cheb',
                'category' => 'Hrady, tvrze a zříceniny',
                'visitors' => 0,
                'guessed_by' => 0,
                'average_rating' => null,
                'rating_count' => 0,
            ],
        ],
    ]);
});

it('returns an empty list when there are no locations', function (): void {
    $response = (new StatisticsResponder())->locations(new Response(), []);

    expect((string) $response->getBody())->toBe('{"locations":[]}');
});

it('presents a visit series with its total', function (): void {
    $series = new VisitSeries(2026, StatisticsGranularity::MONTH, 12, [
        ['period' => '2026-01', 'visits' => 3, 'visitors' => 2],
        ['period' => '2026-02', 'visits' => 0, 'visitors' => 0],
    ]);

    $response = (new StatisticsResponder())->visits(new Response(), $series);

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response))->toBe([
        'visits' => [
            'year' => 2026,
            'granularity' => 'month',
            'location_id' => 12,
            'total' => 3,
            'series' => [
                ['period' => '2026-01', 'visits' => 3, 'visitors' => 2],
                ['period' => '2026-02', 'visits' => 0, 'visitors' => 0],
            ],
        ],
    ]);
});

it('presents a series over all locations with a null location id', function (): void {
    $series = new VisitSeries(2026, StatisticsGranularity::DAY, null, []);

    $body = jsonOf((new StatisticsResponder())->visits(new Response(), $series));

    expect($body['visits']['location_id'])->toBeNull();
    expect($body['visits']['granularity'])->toBe('day');
    expect($body['visits']['total'])->toBe(0);
    expect($body['visits']['series'])->toBe([]);
});
