<?php

declare(strict_types=1);

use App\Domain\Profile;
use App\Domain\Role;
use App\Domain\User;
use App\Responder\User\ProfileResponder;
use App\Services\Profile\Scoring;
use Slim\Psr7\Response;

function profileWith(int $pointsFromGuessing, int $pointsFromVisits, int $guessed = 0, int $visited = 0): Profile
{
    return new Profile(
        user: new User(7, 'dan@example.com', 'Dan', Role::ADMIN, '2026-10-09 21:13:42.497845+00'),
        pointsFromGuessing: $pointsFromGuessing,
        pointsFromVisits: $pointsFromVisits,
        level: (new Scoring())->levelFor($pointsFromGuessing + $pointsFromVisits),
        guessedCount: $guessed,
        visitedCount: $visited,
    );
}

it('presents the profile with points, level and location counts', function (): void {
    $response = (new ProfileResponder())->respond(new Response(), profileWith(425, 300, 3, 1));

    expect($response->getStatusCode())->toBe(200);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect(jsonOf($response))->toBe([
        'profile' => [
            'id' => 7,
            'name' => 'Dan',
            'email' => 'dan@example.com',
            'created_at' => '2026-10-09 21:13:42.497845+00',
            'wafers' => 0,
            'points' => ['total' => 725, 'guessing' => 425, 'visits' => 300],
            'level' => [
                'number' => 2,
                'starts_at' => 250,
                'next_level_at' => 750,
                'points_in_level' => 475,
                'points_to_next_level' => 25,
            ],
            'locations' => ['guessed' => 3, 'visited' => 1],
        ],
    ]);
});

it('presents a new player as level 1 with zeros, not nulls', function (): void {
    $profile = jsonOf((new ProfileResponder())->respond(new Response(), profileWith(0, 0)))['profile'];

    expect($profile['points'])->toBe(['total' => 0, 'guessing' => 0, 'visits' => 0]);
    expect($profile['level'])->toBe([
        'number' => 1,
        'starts_at' => 0,
        'next_level_at' => 250,
        'points_in_level' => 0,
        'points_to_next_level' => 250,
    ]);
    expect($profile['locations'])->toBe(['guessed' => 0, 'visited' => 0]);
});

it('keeps the level numbers consistent with the total', function (int $guessing, int $visits): void {
    $profile = jsonOf((new ProfileResponder())->respond(new Response(), profileWith($guessing, $visits)))['profile'];

    expect($profile['points']['total'])->toBe($guessing + $visits);
    expect($profile['level']['starts_at'] + $profile['level']['points_in_level'])->toBe($profile['points']['total']);
    expect($profile['level']['next_level_at'] - $profile['level']['points_to_next_level'])->toBe($profile['points']['total']);
})->with([
    'level boundary' => [150, 600],
    'mid level' => [1000, 900],
    'everything' => [112 * 200, 112 * 300],
]);

it('does not expose the role or any password data', function (): void {
    $body = (string) (new ProfileResponder())->respond(new Response(), profileWith(100, 0, 1))->getBody();

    expect($body)->not->toContain('role')->not->toContain('admin')->not->toContain('password');
});
