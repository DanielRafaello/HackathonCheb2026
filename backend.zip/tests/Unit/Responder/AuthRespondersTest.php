<?php

declare(strict_types=1);

use App\Domain\Role;
use App\Domain\User;
use App\Responder\Auth\AuthResponder;
use App\Responder\Auth\LogoutResponder;
use App\Responder\User\MeResponder;
use Slim\Psr7\Response;

function responderUser(): User
{
    return new User(7, 'dan@example.com', 'Dan', Role::ADMIN, '2026-10-09 21:13:42.497845+00');
}

it('returns the token pair and the public user fields', function (): void {
    $response = (new AuthResponder())->respond(new Response(), 'jwt-token', 'refresh-token', responderUser(), 201);

    expect($response->getStatusCode())->toBe(201);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect(jsonOf($response))->toBe([
        'token' => 'jwt-token',
        'refresh_token' => 'refresh-token',
        'user' => ['id' => 7, 'name' => 'Dan', 'email' => 'dan@example.com', 'role' => 'admin'],
    ]);
});

it('uses the status the action asks for', function (int $status): void {
    $response = (new AuthResponder())->respond(new Response(), 't', 'r', responderUser(), $status);

    expect($response->getStatusCode())->toBe($status);
})->with([200, 201]);

it('confirms a logout', function (): void {
    $response = (new LogoutResponder())->loggedOut(new Response());

    expect($response->getStatusCode())->toBe(200);
    expect($response->getHeaderLine('Content-Type'))->toBe('application/json');
    expect(jsonOf($response))->toBe(['logged_out' => true]);
});

it('returns the current user with the registration time', function (): void {
    $response = (new MeResponder())->respond(new Response(), responderUser());

    expect($response->getStatusCode())->toBe(200);
    expect(jsonOf($response))->toBe([
        'user' => [
            'id' => 7,
            'name' => 'Dan',
            'email' => 'dan@example.com',
            'role' => 'admin',
            'created_at' => '2026-10-09 21:13:42.497845+00',
            'wafers' => 0,
        ],
    ]);
});
