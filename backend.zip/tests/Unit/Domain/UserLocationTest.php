<?php

declare(strict_types=1);

use App\Domain\UserLocation;

it('builds a location from a database row and casts numeric strings', function (): void {
    $location = UserLocation::fromRow([
        'id' => '12',
        'name' => 'Hrad Loket',
        'latitude' => '50.187104',
        'longitude' => '12.754285',
        'guessed_at' => '2026-10-09T21:42:14Z',
        'visited_at' => null,
        'rating' => '4',
        'rated_at' => '2026-10-10T08:00:00Z',
        'average_rating' => '4.3',
        'rating_count' => '7',
    ]);

    expect($location->id)->toBe(12);
    expect($location->name)->toBe('Hrad Loket');
    expect($location->latitude)->toBe(50.187104);
    expect($location->longitude)->toBe(12.754285);
    expect($location->guessedAt)->toBe('2026-10-09T21:42:14Z');
    expect($location->visitedAt)->toBeNull();
    expect($location->rating)->toBe(4);
    expect($location->ratedAt)->toBe('2026-10-10T08:00:00Z');
    expect($location->averageRating)->toBe(4.3);
    expect($location->ratingCount)->toBe(7);
});

it('keeps a missing rating as null instead of zero', function (): void {
    $location = UserLocation::fromRow([
        'id' => 1,
        'name' => 'Hrad Cheb',
        'latitude' => 50.081137,
        'longitude' => 12.366035,
        'guessed_at' => null,
        'visited_at' => null,
        'rating' => null,
        'rated_at' => null,
        'average_rating' => null,
        'rating_count' => 0,
    ]);

    expect($location->rating)->toBeNull();
    expect($location->averageRating)->toBeNull();
    expect($location->ratingCount)->toBe(0);
});

it('derives the guessed and visited flags from the timestamps', function (
    ?string $guessedAt,
    ?string $visitedAt,
    bool $guessed,
    bool $visited,
): void {
    $location = new UserLocation(1, 'Hrad Cheb', 50.081137, 12.366035, $guessedAt, $visitedAt);

    expect($location->isGuessed())->toBe($guessed);
    expect($location->isVisited())->toBe($visited);
})->with([
    'untouched' => [null, null, false, false],
    'guessed only' => ['2026-10-09T21:42:14Z', null, true, false],
    'visited only' => [null, '2026-10-09T21:42:17Z', false, true],
    'guessed and visited' => ['2026-10-09T21:42:14Z', '2026-10-09T21:42:17Z', true, true],
]);
