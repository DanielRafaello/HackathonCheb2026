<?php

declare(strict_types=1);

use App\Domain\StatisticsGranularity;
use App\Domain\VisitSeries;

it('builds a granularity from the query value', function (): void {
    expect(StatisticsGranularity::from('month'))->toBe(StatisticsGranularity::MONTH);
    expect(StatisticsGranularity::from('day'))->toBe(StatisticsGranularity::DAY);
    expect(StatisticsGranularity::tryFrom('week'))->toBeNull();
});

it('labels a period the same way in PHP and in SQL', function (
    StatisticsGranularity $granularity,
    string $phpFormat,
    string $sqlFormat,
    string $label,
): void {
    expect($granularity->periodFormat())->toBe($phpFormat);
    expect($granularity->sqlPeriodFormat())->toBe($sqlFormat);
    expect((new DateTimeImmutable('2026-03-04 15:30:00'))->format($granularity->periodFormat()))->toBe($label);
})->with([
    'month' => [StatisticsGranularity::MONTH, 'Y-m', 'YYYY-MM', '2026-03'],
    'day' => [StatisticsGranularity::DAY, 'Y-m-d', 'YYYY-MM-DD', '2026-03-04'],
]);

it('steps from one period to the next', function (StatisticsGranularity $granularity, string $next): void {
    $start = new DateTimeImmutable('2026-01-31 00:00:00');

    expect($start->modify('first day of this month')->modify($granularity->step())->format('Y-m-d'))->toBe($next);
})->with([
    'month' => [StatisticsGranularity::MONTH, '2026-02-01'],
    'day' => [StatisticsGranularity::DAY, '2026-01-02'],
]);

it('sums the visits of a series', function (): void {
    $series = new VisitSeries(2026, StatisticsGranularity::MONTH, null, [
        ['period' => '2026-01', 'visits' => 3, 'visitors' => 2],
        ['period' => '2026-02', 'visits' => 0, 'visitors' => 0],
        ['period' => '2026-03', 'visits' => 4, 'visitors' => 4],
    ]);

    expect($series->totalVisits())->toBe(7);
});

it('totals an empty series to zero', function (): void {
    expect((new VisitSeries(2026, StatisticsGranularity::DAY, 12, []))->totalVisits())->toBe(0);
});
