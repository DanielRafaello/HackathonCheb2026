<?php

declare(strict_types=1);

use App\Domain\RoundStatus;

it('treats every status except active as complete', function (RoundStatus $status, bool $complete): void {
    expect($status->isComplete())->toBe($complete);
})->with([
    'active' => [RoundStatus::ACTIVE, false],
    'guessed' => [RoundStatus::GUESSED, true],
    'expired' => [RoundStatus::EXPIRED, true],
]);

it('reveals the target only after a hit', function (RoundStatus $status, bool $reveals): void {
    expect($status->revealsTarget())->toBe($reveals);
})->with([
    'active' => [RoundStatus::ACTIVE, false],
    'guessed' => [RoundStatus::GUESSED, true],
    'expired' => [RoundStatus::EXPIRED, false],
]);

it('builds a status from its stored value', function (): void {
    expect(RoundStatus::from('guessed'))->toBe(RoundStatus::GUESSED);
    expect(RoundStatus::tryFrom('paused'))->toBeNull();
});
