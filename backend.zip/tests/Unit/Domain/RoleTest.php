<?php

declare(strict_types=1);

use App\Domain\Role;

it('maps roles to the values stored in the database and the JWT', function (): void {
    expect(Role::USER->value)->toBe('user');
    expect(Role::ADMIN->value)->toBe('admin');
    expect(Role::cases())->toHaveCount(2);
});

it('builds a role from its stored value', function (): void {
    expect(Role::from('admin'))->toBe(Role::ADMIN);
    expect(Role::tryFrom('superuser'))->toBeNull();
});
