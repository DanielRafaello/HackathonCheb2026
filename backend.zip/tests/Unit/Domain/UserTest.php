<?php

declare(strict_types=1);

use App\Domain\Role;
use App\Domain\User;

it('builds a user from a database row', function (): void {
    $user = User::fromRow([
        'id' => '7',
        'email' => 'dan@example.com',
        'name' => 'Dan',
        'role' => 'admin',
        'created_at' => '2026-10-09 21:13:42.497845+00',
    ]);

    expect($user->id)->toBe(7);
    expect($user->email)->toBe('dan@example.com');
    expect($user->name)->toBe('Dan');
    expect($user->role)->toBe(Role::ADMIN);
    expect($user->createdAt)->toBe('2026-10-09 21:13:42.497845+00');
});

it('never carries the password hash, even when the row has one', function (): void {
    $user = User::fromRow([
        'id' => 1,
        'email' => 'dan@example.com',
        'name' => 'Dan',
        'role' => 'user',
        'created_at' => '2026-10-09 21:13:42+00',
        'password_hash' => '$2y$10$secret',
    ]);

    expect(get_object_vars($user))->not->toHaveKey('password_hash');
    expect(get_object_vars($user))->not->toHaveKey('passwordHash');
});

it('rejects a row with an unknown role', function (): void {
    User::fromRow([
        'id' => 1,
        'email' => 'dan@example.com',
        'name' => 'Dan',
        'role' => 'superuser',
        'created_at' => '2026-10-09 21:13:42+00',
    ]);
})->throws(ValueError::class);
