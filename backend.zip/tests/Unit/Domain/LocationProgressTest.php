<?php

declare(strict_types=1);

use App\Domain\LocationProgress;

it('maps each progress to its timestamp column', function (LocationProgress $progress, string $column): void {
    expect($progress->column())->toBe($column);
})->with([
    'guessed' => [LocationProgress::GUESSED, 'guessed_at'],
    'visited' => [LocationProgress::VISITED, 'visited_at'],
]);

it('builds a progress from the value sent by the client', function (): void {
    expect(LocationProgress::from('guessed'))->toBe(LocationProgress::GUESSED);
    expect(LocationProgress::from('visited'))->toBe(LocationProgress::VISITED);
    expect(LocationProgress::tryFrom('skipped'))->toBeNull();
});
