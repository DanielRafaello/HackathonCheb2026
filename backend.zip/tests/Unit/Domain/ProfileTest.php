<?php

declare(strict_types=1);

use App\Domain\LevelProgress;
use App\Domain\LocationAchievement;
use App\Domain\Profile;
use App\Domain\Role;
use App\Domain\User;

it('measures the progress inside a level', function (): void {
    $progress = new LevelProgress(level: 3, points: 900, startsAt: 750, nextLevelAt: 1500);

    expect($progress->pointsInLevel())->toBe(150);
    expect($progress->pointsToNextLevel())->toBe(600);
});

it('starts a level with nothing earned in it yet', function (): void {
    $progress = new LevelProgress(level: 2, points: 250, startsAt: 250, nextLevelAt: 750);

    expect($progress->pointsInLevel())->toBe(0);
    expect($progress->pointsToNextLevel())->toBe(500);
});

it('splits the points of a level between earned and missing', function (int $points): void {
    $progress = new LevelProgress(level: 4, points: $points, startsAt: 1500, nextLevelAt: 2500);

    expect($progress->pointsInLevel() + $progress->pointsToNextLevel())->toBe(1000);
})->with([1500, 1501, 2000, 2499]);

it('adds guessing and visit points into the profile total', function (): void {
    $profile = new Profile(
        user: new User(7, 'dan@example.com', 'Dan', Role::USER, '2026-10-10 12:00:00+00'),
        pointsFromGuessing: 425,
        pointsFromVisits: 300,
        level: new LevelProgress(level: 2, points: 725, startsAt: 250, nextLevelAt: 750),
        guessedCount: 3,
        visitedCount: 1,
    );

    expect($profile->points())->toBe(725);
    expect($profile->points())->toBe($profile->level->points);
    expect($profile->user->name)->toBe('Dan');
    expect($profile->guessedCount)->toBe(3);
    expect($profile->visitedCount)->toBe(1);
});

it('describes what a user achieved on one location', function (): void {
    $hit = new LocationAchievement(locationId: 12, guessedOnAttempt: 2, guessed: true, visited: false);
    $visitOnly = new LocationAchievement(locationId: 13, guessedOnAttempt: null, guessed: false, visited: true);

    expect($hit->locationId)->toBe(12);
    expect($hit->guessedOnAttempt)->toBe(2);
    expect($hit->guessed)->toBeTrue();
    expect($hit->visited)->toBeFalse();
    expect($visitOnly->guessedOnAttempt)->toBeNull();
    expect($visitOnly->visited)->toBeTrue();
});
