<?php

declare(strict_types=1);

use App\Domain\GameRound;
use App\Domain\GuessResult;
use App\Domain\GuessSubmission;
use App\Domain\RoundStatus;
use App\Domain\RoundTarget;

function gameRoundWith(
    RoundStatus $status,
    int $attemptsUsed,
    ?GuessResult $lastGuess = null,
    string $targetName = 'Tajné místo',
): GameRound {
    return new GameRound(
        id: 3,
        userId: 7,
        status: $status,
        attemptsUsed: $attemptsUsed,
        stars: null,
        dailyDate: '2026-10-10',
        completedAt: null,
        target: new RoundTarget(
            id: 42,
            name: $targetName,
            latitude: 50.0,
            longitude: 12.0,
            category: 'Hrady, tvrze a zříceniny',
            description: 'Popis místa.',
            hint1: 'První nápověda.',
            hint2: 'Třetí nápověda.',
            contentSourceUrl: null,
            sourceTitle: 'Dataset',
            sourcePublisher: 'Publisher',
            sourcePortalUrl: 'https://example.com/dataset',
            sourceLicenseCode: 'CC BY 4.0',
            sourceLicenseUrl: 'https://creativecommons.org/licenses/by/4.0/',
            sourceAttributionText: 'Attribution',
            sourceRetrievedAt: null,
            sourceUpdatedAt: null,
        ),
        lastGuess: $lastGuess,
    );
}

it('activates the compass on the fourth miss', function (): void {
    expect(GameRound::COMPASS_START_ATTEMPT)->toBe(4);
});

it('reports whether the compass is active', function (RoundStatus $status, int $attemptsUsed, bool $active): void {
    expect(gameRoundWith($status, $attemptsUsed)->compassActive())->toBe($active);
})->with([
    'fresh round' => [RoundStatus::ACTIVE, 0, false],
    'after two misses' => [RoundStatus::ACTIVE, 2, false],
    'after three misses' => [RoundStatus::ACTIVE, 3, false],
    'after four misses' => [RoundStatus::ACTIVE, 4, true],
    'later active guess' => [RoundStatus::ACTIVE, 8, true],
    'guessed round' => [RoundStatus::GUESSED, 4, false],
    'expired round' => [RoundStatus::EXPIRED, 4, false],
]);

it('awards at least one star for every hit', function (int $attemptNumber, int $stars): void {
    expect(GameRound::starsForHit($attemptNumber))->toBe($stars);
})->with([
    'first attempt' => [1, 5],
    'fifth attempt' => [5, 1],
    'later attempt' => [12, 1],
]);

it('unlocks one more clue with every attempt of an active round', function (int $attemptsUsed, int $clueCount): void {
    $clues = gameRoundWith(RoundStatus::ACTIVE, $attemptsUsed)->visibleClues();

    expect($clues)->toHaveCount($clueCount);
    expect(array_column($clues, 'position'))->toBe(range(1, $clueCount));
})->with([
    'before the first guess' => [0, 1],
    'after one miss' => [1, 2],
    'after two misses' => [2, 3],
    'after three misses' => [3, 4],
    'never more than four clues' => [5, 4],
]);

it('orders the clues and derives name edges from Unicode letters', function (): void {
    $clues = gameRoundWith(RoundStatus::ACTIVE, 3)->visibleClues();

    expect($clues)->toBe([
        ['position' => 1, 'type' => 'distinctive_fact', 'text' => 'První nápověda.'],
        ['position' => 2, 'type' => 'category', 'text' => 'Hrady, tvrze a zříceniny'],
        ['position' => 3, 'type' => 'area_narrowing', 'text' => 'Třetí nápověda.'],
        ['position' => 4, 'type' => 'name_edges', 'text' => 'Název začíná písmenem „T“ a končí písmenem „o“.'],
    ]);
});

it('ignores punctuation around the name edges', function (): void {
    $clues = gameRoundWith(
        RoundStatus::ACTIVE,
        3,
        targetName: '„Žlutý dům!“',
    )->visibleClues();

    expect($clues[3])->toBe([
        'position' => 4,
        'type' => 'name_edges',
        'text' => 'Název začíná písmenem „Ž“ a končí písmenem „m“.',
    ]);
});

it('shows every clue once the target is guessed', function (): void {
    expect(gameRoundWith(RoundStatus::GUESSED, 1)->visibleClues())->toHaveCount(4);
});

it('keeps the clues locked for an expired round', function (): void {
    expect(gameRoundWith(RoundStatus::EXPIRED, 0)->visibleClues())->toHaveCount(1);
});

it('has no last guess until one is submitted', function (): void {
    expect(gameRoundWith(RoundStatus::ACTIVE, 0)->lastGuess)->toBeNull();
});

it('carries the guess result next to the updated round', function (): void {
    $guess = new GuessResult(attemptNumber: 1, hit: false, distanceMeters: 13250, direction: 'SE');
    $round = gameRoundWith(RoundStatus::ACTIVE, 1, $guess);

    $submission = new GuessSubmission($round, $guess);

    expect($submission->round)->toBe($round);
    expect($submission->guess)->toBe($guess);
    expect($submission->round->lastGuess)->toBe($guess);
    expect($guess->attemptNumber)->toBe(1);
    expect($guess->hit)->toBeFalse();
    expect($guess->distanceMeters)->toBe(13250);
    expect($guess->direction)->toBe('SE');
});
