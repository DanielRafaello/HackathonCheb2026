# Production deployment (aether217.zcu.cz)

Three independent manual jobs in GitLab (CI/CD → Pipelines → ▶ on `main`):

| Job | Compose file | Services |
|-----|--------------|----------|
| `deploy-infra` | `docker-compose.infra.yml` | Traefik, Portainer, PostgreSQL, DbGate |
| `deploy-backend` | `docker-compose.backend.yml` | backend, then migrations and seeds |
| `deploy-multiplayer` | `docker-compose.multiplayer.yml` | multiplayer socket server |

Run `deploy-infra` first. It creates the `kdenazapade` network that the backend and the multiplayer server join. Then run `deploy-backend`, because the multiplayer server reads the places from the database that the backend migrations and seeds fill. After that, each job can be redeployed on its own.

The multiplayer server keeps lobbies and games in memory and runs as a single container. Redeploying it ends every running multiplayer game; the clients see the connection drop and must create a new lobby.

| URL | Service | Access |
|-----|---------|--------|
| `https://aether217.zcu.cz/api/*` | backend (`/api` prefix stripped) | `ALLOWED_SOURCE_RANGE` |
| `wss://aether217.zcu.cz/ws` | multiplayer socket server (WebSocket, path kept) | `ALLOWED_SOURCE_RANGE` |
| `https://aether217.zcu.cz/ws/health` | multiplayer health check | `ALLOWED_SOURCE_RANGE` |
| `https://aether217.zcu.cz/_admin/portainer/` | Portainer | `ADMIN_SOURCE_RANGE` |
| `https://aether217.zcu.cz/_admin/dbgate/` | DbGate | `ADMIN_SOURCE_RANGE` |
| `https://aether217.zcu.cz/_admin/traefik/` | Traefik dashboard (basic auth) | `ADMIN_SOURCE_RANGE` |

The jobs run on the group runner `hackathon-nuada`, a docker executor on this server. Each job runs in a `docker:28-cli` container and drives the server's Docker daemon through `/var/run/docker.sock`. The containers it starts run on the server itself.

## One-time setup

### Runner

The runner must mount the Docker socket into job containers. In `/etc/gitlab-runner/config.toml` on the server:

```toml
[[runners]]
  [runners.docker]
    volumes = ["/var/run/docker.sock:/var/run/docker.sock", "/cache"]
```

Then run `sudo gitlab-runner restart`. Each job prints `Docker host <name>` first. The name must be this server, not a Docker-in-Docker service.

### Server

```sh
# Caddy used to hold ports 80/443, Traefik takes them over
sudo systemctl disable --now caddy
```

### Secrets

In GitLab, open the backend project (or the `open-data-2026` group) → Settings → CI/CD → Variables → Add variable:

- Key: `ENV_FILE`
- Type: **File**
- Value: the content of `docker/production/env.example`, with every `change-me` filled in
- Flags: Protected (deploys run on protected branches only: `main`, and `multiplayer` while it is deployed on its own). Uncheck **Expand variable reference**, otherwise GitLab mangles the `$` signs in the Portainer bcrypt hash.

Portainer password hash (paste it in single quotes):

```sh
docker run --rm httpd:2.4-alpine htpasswd -nbB admin 'your-password' | cut -d: -f2
```

The backend and the multiplayer server read their configuration from environment variables (`env_file` in `docker-compose.backend.yml` and `docker-compose.multiplayer.yml`). The multiplayer server shares `DB_*`, `JWT_SECRET`, and `FRONTEND_URL` with the backend and has its own `MP_*` section. No `.env` file with secrets is stored on the server or in the image.

### Deploying the multiplayer branch

Until `multiplayer` is merged into `main`, every deploy job can also run manually on the `multiplayer` branch, in this repository and in the frontend repository. Both branches deploy into the same containers, so the last deploy wins.

1. Protect the branch in both repositories: Settings → Repository → Protected branches → `multiplayer`, allowed to merge and push: Maintainers (or Developers + Maintainers). Without it, the protected `ENV_FILE` is not passed to the jobs, and a runner that runs only protected branches does not take them.
2. Fill the `MP_*` section of `docker/production/env.example` into `ENV_FILE`, and check `FRONTEND_URL=https://aether217.zcu.cz`: the socket server refuses browser connections from any other origin.
3. On the `multiplayer` branch, run `deploy-backend` (migrations and seeds), then `deploy-multiplayer`, then `deploy-frontend` in the frontend repository. Run `deploy-infra` only when `ALLOWED_SOURCE_RANGE` or another infrastructure value changed.
4. Check `https://aether217.zcu.cz/ws/health`: it answers `{"status":"ok"}`.

Merge `multiplayer` into `main` first whenever `main` moved on, or the deploy takes main's newer features off the server.

## Firewall

Docker publishes container ports past ufw. The ufw rule for 443 therefore does not protect Traefik. Access is restricted by Traefik middlewares, driven by the `ENV_FILE` variable:

- `ALLOWED_SOURCE_RANGE` covers the Game API, the multiplayer socket server, and the web app. Set `0.0.0.0/0` to open the game to everyone (visits from mobile data), then run `deploy-infra`.
- `ADMIN_SOURCE_RANGE` covers Portainer and DbGate. Keep it on the ZČU network.

Port 80 must stay open to the internet for Let's Encrypt.

## Logs

Portainer at `/_admin/portainer/` shows the logs of every container. On the server:

```sh
docker logs -f kdz-infra-traefik-1
docker logs -f kdz-backend-backend-1
docker logs -f kdz-multiplayer-multiplayer-1
```

The backend also writes two files into the `backend_logs` volume (`/app/var/log` in the container), which survive redeploys:

| File | Content |
|------|---------|
| `app-YYYY-MM-DD.log` | Failed requests, one JSON record per line; `"level_name":"ERROR"` marks a 500 and carries the stack trace. One file per day, 14 days kept. The same records are in `docker logs`. |
| `php_errors.log` | Native PHP warnings and fatal errors. Not in `docker logs`. Not rotated. |

```sh
docker exec kdz-backend-backend-1 sh -c 'grep "\"level_name\":\"ERROR\"" /app/var/log/app-*.log | tail -n 5'
docker exec kdz-backend-backend-1 tail -n 50 /app/var/log/php_errors.log
```
