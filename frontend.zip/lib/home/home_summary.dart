import '../game/area.dart';

export '../game/area.dart';

/// Progress in one area: guessed + visited places out of all playable ones.
class AreaProgress {
  const AreaProgress({required this.area, required this.known, this.total});

  final Area area;

  /// Guessed and visited places in the area.
  final int known;

  /// Playable places in the area, or null while unknown.
  final int? total;

  double get fraction {
    final total = this.total;
    return total == null || total == 0 ? 0 : known / total;
  }
}

/// Where today's place of the day stands for the player
/// (`GET /rounds/daily`, `round.status`).
enum DailyStatus {
  /// Not started, or started and not finished: the player can still guess.
  /// A round has no guess limit, so it stays open until a hit.
  open,

  /// Hit today.
  guessed,

  /// The player has guessed every place there is
  /// (409 `round.no_eligible_daily_location`).
  allGuessed;

  /// The round is over for today.
  bool get isFinished => this == guessed;
}

/// What Home shows: the player's progress and today's place of the day.
///
/// It never holds anything about a place the player has not guessed: of
/// today's round only the status and the attempts, never the clues or the
/// location.
class HomeSummary {
  const HomeSummary({
    required this.guessed,
    required this.visited,
    required this.areas,
    required this.attemptsUsedToday,
    this.dailyStatus = DailyStatus.open,
    this.wafers,
  });

  /// A player with no progress who has not played today: a guest, and a
  /// signed-in player while the summary loads or when loading fails.
  static const empty = HomeSummary(
    guessed: 0,
    visited: 0,
    areas: [],
    attemptsUsedToday: 0,
  );

  final int guessed;
  final int visited;

  /// Progress per area; empty when no place has a known area, in which
  /// case Home shows no area progress.
  final List<AreaProgress> areas;

  /// Guesses already spent on today's place of the day.
  final int attemptsUsedToday;

  final DailyStatus dailyStatus;

  /// The wafer balance of an account; null for a guest or when it did not
  /// load, and Home then shows none.
  final int? wafers;

  /// The places on my map.
  int get known => guessed + visited;
}
