import 'package:flutter/widgets.dart';

import '../config/game_config.dart';
import '../design_system/design_system.dart';

/// The place of the day on Home (`components.md`, DailyHeroCard): a blue
/// card with a foggy landscape, what the round offers, and the Play button.
///
/// A started round goes on where the player left it. Once today's round is
/// [finished], the card says so and the button shows the result instead.
class DailyHeroCard extends StatelessWidget {
  const DailyHeroCard({
    super.key,
    required this.day,
    required this.attemptsUsed,
    required this.config,
    required this.onPlay,
    this.finished = false,
  });

  /// Today's game day (Europe/Prague).
  final DateTime day;

  /// Guesses already spent on today's place.
  final int attemptsUsed;

  /// Today's place is guessed. A round has no guess limit, so it ends
  /// only with a hit.
  final bool finished;
  final GameConfig config;

  /// Opens the place of the day: the game, or its result when [finished].
  final VoidCallback onPlay;

  static const _illustrationHeight = 120.0;

  @override
  Widget build(BuildContext context) {
    final onCard = KnzColors.textOnPrimary;
    final guesses = Czech.count(attemptsUsed, 'pokus', 'pokusy', 'pokusů');
    final started = attemptsUsed > 0;
    final played = finished
        ? 'Dnes dohráno\u00A0· $guesses'
        : started
        ? 'Rozehráno\u00A0· $guesses'
        : 'Zatím bez pokusu';
    return KnzEdgeBox(
      color: KnzColors.primary,
      edgeColor: KnzColors.primaryEdge,
      radius: KnzRadius.xl4,
      depth: KnzDepth.xl,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(KnzRadius.xl4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                KnzSpace.s20,
                KnzSpace.s18,
                KnzSpace.s20,
                0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    alignment: WrapAlignment.spaceBetween,
                    spacing: KnzSpace.s12,
                    runSpacing: KnzSpace.s4,
                    children: [
                      Text(
                        'MÍSTO DNE\u00A0· ${Czech.shortDate(day)}',
                        style: KnzText.overline.copyWith(
                          color: KnzPalette.blueOn,
                        ),
                      ),
                      Text(
                        played,
                        style: KnzText.weight(
                          KnzText.caption,
                          900,
                        ).copyWith(color: KnzPalette.blueOn),
                      ),
                    ],
                  ),
                  const SizedBox(height: KnzSpace.s6),
                  Semantics(
                    header: true,
                    child: Text(
                      'Kde to je?',
                      style: KnzText.titleXl.copyWith(color: onCard),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: _illustrationHeight,
              // The Play button's press and hover animations repaint the
              // card; the boundary keeps the landscape's layer as it is.
              child: RepaintBoundary(
                child: CustomPaint(painter: _FoggyLandscapePainter.instance),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                KnzSpace.s20,
                KnzSpace.s12,
                KnzSpace.s20,
                KnzSpace.s20,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Wrap(
                    spacing: KnzSpace.s8,
                    runSpacing: KnzSpace.s8,
                    children: [
                      KnzChip(
                        label: Czech.count(
                          config.placeOfTheDayClues,
                          'klíč',
                          'klíče',
                          'klíčů',
                        ),
                      ),
                      const KnzChip(label: 'kompas'),
                      KnzChip(
                        label:
                            'až\u00A0${Czech.count(config.maxStars, 'hvězda', 'hvězdy', 'hvězd')}',
                      ),
                    ],
                  ),
                  const SizedBox(height: KnzSpace.s16),
                  KnzButton(
                    label: finished
                        ? 'Zobrazit výsledek'
                        : started
                        ? 'Hrát dál'
                        : 'Hrát místo dne',
                    sentiment: KnzSentiment.accent,
                    size: KnzButtonSize.cta,
                    onPressed: onPlay,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Hills in fog with a castle and a gold pin with a question mark: the
/// unknown place of the day. Layered blues on the primary card.
class _FoggyLandscapePainter extends CustomPainter {
  // Repaints when the system fonts change, so the "?" picks up Nunito.
  _FoggyLandscapePainter()
    : super(repaint: PaintingBinding.instance.systemFonts);

  /// The only instance; the landscape has no parameters.
  static final instance = _FoggyLandscapePainter();

  /// The landscape recorded at the last size, dropped when the fonts
  /// change.
  static final _cache = () {
    final cache = KnzPictureCache();
    PaintingBinding.instance.systemFonts.addListener(cache.clear);
    return cache;
  }();

  @override
  void paint(Canvas canvas, Size size) =>
      _cache.paint(canvas, size, (canvas) => _draw(canvas, size));

  void _draw(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final fill = Paint();

    KnzIllustration.castle(
      canvas,
      Offset(0.62 * w, 0.62 * h),
      0.50 * h,
      KnzPalette.blue600,
    );

    // The far hills.
    canvas.drawPath(
      Path()
        ..moveTo(0, 0.78 * h)
        ..cubicTo(0.25 * w, 0.60 * h, 0.55 * w, 0.66 * h, w, 0.56 * h)
        ..lineTo(w, h)
        ..lineTo(0, h)
        ..close(),
      fill..color = KnzPalette.blue450,
    );

    KnzIllustration.tree(
      canvas,
      Offset(0.20 * w, 0.95 * h),
      0.28 * h,
      KnzPalette.blue300,
    );
    KnzIllustration.tree(
      canvas,
      Offset(0.25 * w, 0.95 * h),
      0.20 * h,
      KnzPalette.blue300,
    );
    KnzIllustration.tree(
      canvas,
      Offset(0.84 * w, 0.92 * h),
      0.28 * h,
      KnzPalette.blue300,
    );

    // The valley in front.
    canvas.drawPath(
      Path()
        ..moveTo(0, 0.86 * h)
        ..cubicTo(0.35 * w, 0.80 * h, 0.65 * w, 0.88 * h, w, 0.80 * h)
        ..lineTo(w, h)
        ..lineTo(0, h)
        ..close(),
      fill..color = KnzPalette.blue400,
    );

    KnzIllustration.cloud(canvas, Offset(0.30 * w, 0.68 * h), 0.30 * w);
    KnzIllustration.cloud(canvas, Offset(0.72 * w, 0.58 * h), 0.30 * w);

    _pin(canvas, Offset(0.5 * w, 0.84 * h), 0.62 * h);
  }

  /// A gold pin standing with its tip on [tip], [height] tall.
  void _pin(Canvas canvas, Offset tip, double height) {
    final r = height * 0.38;
    final centre = tip - Offset(0, height - r);
    final fill = Paint();

    // Its shadow on the ground.
    canvas.drawOval(
      Rect.fromCenter(center: tip, width: r * 1.1, height: r * 0.3),
      fill..color = KnzPalette.blue600,
    );

    final body = Path()
      ..moveTo(tip.dx, tip.dy)
      ..cubicTo(
        tip.dx - r * 0.35,
        tip.dy - r * 0.55,
        centre.dx - r,
        centre.dy + r * 0.55,
        centre.dx - r,
        centre.dy,
      )
      ..arcToPoint(Offset(centre.dx + r, centre.dy), radius: Radius.circular(r))
      ..cubicTo(
        centre.dx + r,
        centre.dy + r * 0.55,
        tip.dx + r * 0.35,
        tip.dy - r * 0.55,
        tip.dx,
        tip.dy,
      )
      ..close();
    canvas
      ..drawPath(body, fill..color = KnzPalette.gold500)
      ..drawPath(
        body,
        Paint()
          ..color = KnzPalette.gold600
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3,
      )
      ..drawCircle(centre, r * 0.58, fill..color = KnzPalette.ink0);

    final question = TextPainter(
      text: TextSpan(
        text: '?',
        style: KnzText.titleMd.copyWith(
          color: KnzColors.text,
          fontSize: r * 0.85,
          height: 1,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    question.paint(
      canvas,
      centre - Offset(question.width / 2, question.height / 2),
    );
  }

  @override
  bool shouldRepaint(_FoggyLandscapePainter old) => false;
}
