import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../app_routes.dart';
import '../design_system/design_system.dart';

/// Shown while the session from the previous start is being restored.
class LoadingPage extends StatelessWidget {
  const LoadingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KnzColors.surface,
      body: Center(
        child: Semantics(
          label: 'Načítám…',
          child: const KnzMascot(mood: KnzMood.happy, width: 96),
        ),
      ),
    );
  }
}

/// A screen whose game part is not built yet (the round, free play).
///
/// Vřídlík says so in the bubble; nothing pretends to work.
class ComingSoonPage extends StatelessWidget {
  const ComingSoonPage({super.key, this.showBackHome = false});

  /// A full-screen page outside the bottom navigation needs a way back.
  final bool showBackHome;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: KnzColors.surface,
      child: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Padding(
              padding: const EdgeInsets.all(KnzSize.screenGutter),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const KnzSpeechBubble(
                    mood: KnzMood.think,
                    text: 'Tuhle část hry ještě chystám. Brzy se tu uvidíme!',
                  ),
                  if (showBackHome) ...[
                    const SizedBox(height: KnzSpace.s24),
                    KnzButton(
                      label: 'Zpět domů',
                      variant: KnzButtonVariant.ghost,
                      onPressed: () => context.go(AppRoutes.home),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
