import '../api/authorized_client.dart';
import '../my_map/locations_api.dart';
import '../my_map/my_map_summary.dart';
import 'home_summary.dart';

/// Home's summary for a signed-in player, from the Game API: the counts
/// and areas from `GET /locations`, today's attempts and status from
/// `GET /rounds/daily`, and the wafer balance from `GET /me`.
///
/// Of the round it reads only `attempts_used` and `status`. The clues and the revealed location stay out of Home
/// (FRONTEND_API_GUIDE, "Load the player's map"). The daily call never
/// consumes a guess, and it creates today's round if there is none yet.
class AccountHomeSummary {
  AccountHomeSummary({required this._locations, required this._client});

  final LocationsApi _locations;
  final AuthorizedClient _client;

  /// Throws [LocationsApiException] when my map cannot be loaded. A
  /// failing daily call does not fail the summary: Home then shows no
  /// guess spent today, and the round screen tells the truth.
  Future<HomeSummary> load() async {
    final places = await _locations.list();
    final summary = MyMapSummary.of(places);
    final (daily, wafers) = await (_daily(), _wafers()).wait;
    return HomeSummary(
      guessed: summary.guessed,
      visited: summary.visited,
      areas: summary.areas,
      attemptsUsedToday: daily.attemptsUsed,
      dailyStatus: daily.status,
      wafers: wafers,
    );
  }

  /// The wafer balance (`user.wafers` of `GET /me`), or null when it cannot
  /// be had: a failing call does not fail the summary.
  Future<int?> _wafers() async {
    try {
      final response = await _client.get('me');
      if (response.statusCode < 200 || response.statusCode >= 300) return null;
      final user = jsonBody(response)['user'];
      final wafers = user is Map<String, dynamic> ? user['wafers'] : null;
      return wafers is num ? wafers.toInt() : null;
    } on Object {
      return null;
    }
  }

  Future<_Daily> _daily() async {
    try {
      final response = await _client.get('rounds/daily');
      if (response.statusCode == 409) return const _Daily.allGuessed();
      if (response.statusCode < 200 || response.statusCode >= 300) {
        return const _Daily.unknown();
      }
      final round = jsonBody(response)['round'];
      if (round is! Map<String, dynamic>) return const _Daily.unknown();
      return _Daily(
        attemptsUsed: (round['attempts_used'] as num?)?.toInt() ?? 0,
        status: round['status'] == 'guessed'
            ? DailyStatus.guessed
            : DailyStatus.open,
      );
    } on Object {
      return const _Daily.unknown();
    }
  }
}

class _Daily {
  const _Daily({required this.attemptsUsed, required this.status});

  const _Daily.unknown() : attemptsUsed = 0, status = DailyStatus.open;

  const _Daily.allGuessed() : attemptsUsed = 0, status = DailyStatus.allGuessed;

  final int attemptsUsed;
  final DailyStatus status;
}
