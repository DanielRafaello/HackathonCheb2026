import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../app_routes.dart';
import '../design_system/design_system.dart';

/// The main screens with the bottom navigation: DNES · MINIHRY · MAPA · PROFIL.
class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.location, required this.child});

  /// The current path, which selects the active tab.
  final String location;
  final Widget child;

  static const _tabs = [
    (AppRoutes.home, KnzNavItem(icon: KnzIcons.calendar, label: 'Dnes')),
    (AppRoutes.freePlay, KnzNavItem(icon: KnzIcons.compass, label: 'Minihry')),
    (AppRoutes.myMap, KnzNavItem(icon: KnzIcons.map, label: 'Mapa')),
    (AppRoutes.profile, KnzNavItem(icon: KnzIcons.profile, label: 'Profil')),
  ];

  @override
  Widget build(BuildContext context) {
    final index = _tabs.indexWhere((tab) => tab.$1 == location);
    return Scaffold(
      backgroundColor: KnzColors.surface,
      body: child,
      bottomNavigationBar: KnzBottomNav(
        items: [for (final tab in _tabs) tab.$2],
        currentIndex: index < 0 ? 0 : index,
        onSelected: (i) => context.go(_tabs[i].$1),
      ),
    );
  }
}
