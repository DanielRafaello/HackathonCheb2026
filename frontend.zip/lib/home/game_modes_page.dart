import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../app_routes.dart';
import '../design_system/design_system.dart';

/// MINIHRY: the mini games, one large tile each, filling the screen
/// between the heading and the bottom navigation (`components.md`,
/// GameTile).
class GameModesPage extends StatelessWidget {
  const GameModesPage({super.key});

  /// A tile never gets shorter than this; on a short screen the page
  /// scrolls instead.
  static const minTileHeight = 180.0;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: KnzColors.surface,
      child: SafeArea(
        bottom: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: CustomScrollView(
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(
                    KnzSize.screenGutter,
                    KnzSpace.s20,
                    KnzSize.screenGutter,
                    KnzSpace.s24,
                  ),
                  sliver: SliverFillRemaining(
                    hasScrollBody: false,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Semantics(
                          header: true,
                          child: Text('Minihry', style: KnzText.titleLg),
                        ),
                        const SizedBox(height: KnzSpace.s4),
                        Text(
                          'Vyber si, jak chceš hrát.',
                          style: KnzText.bodyLg.copyWith(
                            color: KnzColors.textMuted,
                          ),
                        ),
                        const SizedBox(height: KnzSpace.s20),
                        Expanded(
                          child: _GameTile(
                            icon: KnzIcons.calendar,
                            sentiment: KnzSentiment.primary,
                            title: 'Místo dne',
                            subtitle:
                                'Každý den jedno nové místo. Čtyři klíče, '
                                'pak kompas.',
                            onPressed: () =>
                                context.push(AppRoutes.placeOfTheDay),
                          ),
                        ),
                        const SizedBox(height: KnzSpace.s14),
                        Expanded(
                          child: _GameTile(
                            icon: KnzIcons.players,
                            sentiment: KnzSentiment.explore,
                            title: 'Hra s kamarády',
                            subtitle:
                                'Stejná místa pro všechny, vyhraje '
                                'nejpřesnější.',
                            onPressed: () =>
                                context.push(AppRoutes.multiplayer),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// One mini game as a large tinted card: a big icon tile, the name and one
/// line about it, and an arrow. The whole tile opens the game.
class _GameTile extends StatelessWidget {
  const _GameTile({
    required this.icon,
    required this.sentiment,
    required this.title,
    required this.subtitle,
    required this.onPressed,
  });

  final KnzIcons icon;
  final KnzSentiment sentiment;
  final String title;
  final String subtitle;
  final VoidCallback onPressed;

  static const _iconTile = 72.0;

  @override
  Widget build(BuildContext context) {
    final colors = sentiment.colors;
    return ConstrainedBox(
      constraints: const BoxConstraints(minHeight: GameModesPage.minTileHeight),
      child: KnzCard(
        sentiment: sentiment,
        variant: KnzCardVariant.tinted,
        radius: KnzRadius.xl3,
        padding: const EdgeInsets.all(KnzSpace.s20),
        onPressed: onPressed,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: _iconTile,
              height: _iconTile,
              decoration: BoxDecoration(
                color: colors.solid,
                borderRadius: BorderRadius.circular(KnzRadius.xl),
                border: Border(
                  bottom: BorderSide(color: colors.edge, width: KnzDepth.md),
                ),
              ),
              alignment: Alignment.center,
              child: KnzIcon(icon, size: 36, color: colors.onSolid),
            ),
            const SizedBox(height: KnzSpace.s16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: KnzText.titleMd),
                      const SizedBox(height: KnzSpace.s4),
                      Text(
                        subtitle,
                        style: KnzText.body.copyWith(
                          color: KnzColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: KnzSpace.s12),
                KnzIcon(KnzIcons.next, size: 28, color: colors.ink),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
