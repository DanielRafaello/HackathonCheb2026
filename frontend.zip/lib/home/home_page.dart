import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

import '../app_routes.dart';
import '../config/game_config.dart';
import '../design_system/design_system.dart';
import '../game/game_day.dart';
import 'daily_hero_card.dart';
import 'home_summary.dart';

/// Home (`01 Home`): the place of the day, free play, and the player's
/// progress in the region. The bottom navigation is around it.
///
/// The summary loads every time the page is created. Until it arrives, and
/// when it fails, the page shows [HomeSummary.empty].
class HomePage extends StatefulWidget {
  const HomePage({
    super.key,
    required this.load,
    required this.config,
    required this.now,
  });

  /// Loads the summary for a signed-in player; null for a guest, whose
  /// Home shows [HomeSummary.empty].
  final Future<HomeSummary> Function()? load;
  final GameConfig config;

  /// The current time; injected so that the date and greeting are testable.
  final DateTime now;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  HomeSummary _summary = HomeSummary.empty;

  @override
  void initState() {
    super.initState();
    final load = widget.load;
    if (load != null) {
      load().then<void>(
        (summary) {
          if (mounted) setState(() => _summary = summary);
        },
        onError: (Object _) {
          if (!mounted) return;
          KnzToast.show(
            context,
            'Tvůj postup se nepodařilo načíst. Zkontroluj připojení.',
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final summary = _summary;
    final config = widget.config;
    final now = widget.now;
    final wallClock = GameDay.wallClock(now);
    return ColoredBox(
      color: KnzColors.surface,
      child: SafeArea(
        bottom: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(
                KnzSize.screenGutter,
                KnzSpace.s12,
                KnzSize.screenGutter,
                KnzSpace.s24,
              ),
              children: [
                _AppHeader(known: summary.known, wafers: summary.wafers),
                const SizedBox(height: KnzSpace.s16),
                KnzSpeechBubble(
                  mood: KnzMood.wave,
                  mascotWidth: 72,
                  text:
                      '${_greeting(wallClock.hour)} '
                      '${_bubble(summary.dailyStatus)}',
                ),
                const SizedBox(height: KnzSpace.s20),
                DailyHeroCard(
                  day: GameDay.of(now),
                  attemptsUsed: summary.attemptsUsedToday,
                  finished: summary.dailyStatus.isFinished,
                  config: config,
                  onPlay: () => context.push(AppRoutes.placeOfTheDay),
                ),
                const SizedBox(height: KnzSpace.s14),
                _RegionCard(
                  summary: summary,
                  onOpen: () => context.go(AppRoutes.myMap),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  static String _greeting(int hour) => switch (hour) {
    >= 4 && < 10 => 'Dobré ráno!',
    >= 18 => 'Dobrý večer!',
    _ => 'Ahoj!',
  };

  /// What Vřídlík says about today's place (copy.md: short, no blame).
  static String _bubble(DailyStatus status) => switch (status) {
    DailyStatus.guessed =>
      'Dnešní místo už máš na mapě. Nové tu bude o\u00A0půlnoci.',
    DailyStatus.open || DailyStatus.allGuessed =>
      'Dnešní místo je zahalené v\u00A0mlze. Najdeš ho?',
  };
}

/// The logo, the wafer balance, and the count of places on my map
/// (`components.md`, AppHeader).
class _AppHeader extends StatelessWidget {
  const _AppHeader({required this.known, this.wafers});

  final int known;

  /// The wafer balance; null hides it (a guest, or it did not load).
  final int? wafers;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const KnzIcon(KnzIcons.logoPin, size: 30),
        const SizedBox(width: KnzSpace.s8),
        Expanded(
          child: Semantics(
            header: true,
            child: Text.rich(
              TextSpan(
                text: 'Kde na ',
                children: [
                  TextSpan(
                    text: 'západě',
                    style: KnzText.titleMd.copyWith(color: KnzColors.primary),
                  ),
                ],
              ),
              style: KnzText.titleMd,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        if (wafers case final wafers?) ...[
          const SizedBox(width: KnzSpace.s8),
          KnzWaferPill(wafers: wafers, compact: true),
        ],
        const SizedBox(width: KnzSpace.s8),
        KnzPressable(
          onPressed: () => context.go(AppRoutes.myMap),
          isLink: true,
          semanticLabel:
              'Mapa: ${Czech.count(known, 'místo', 'místa', 'míst')}',
          builder: (context, state) => Container(
            constraints: const BoxConstraints(minHeight: KnzSize.touch),
            padding: const EdgeInsets.symmetric(horizontal: KnzSpace.s14),
            decoration: BoxDecoration(
              color: state.hovered
                  ? KnzColors.surfaceSubtle
                  : KnzColors.surface,
              border: Border.all(
                color: KnzColors.border,
                width: KnzDepth.border,
              ),
              borderRadius: BorderRadius.circular(KnzRadius.pill),
              boxShadow: state.focused ? KnzShadows.focus : null,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                KnzIcon(
                  known == 0 ? KnzIcons.starEmpty : KnzIcons.star,
                  size: 22,
                ),
                const SizedBox(width: KnzSpace.s6),
                Text('$known', style: KnzText.weight(KnzText.body, 800)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// "Tvoje mapa kraje": progress per area and the place counts.
class _RegionCard extends StatelessWidget {
  const _RegionCard({required this.summary, required this.onOpen});

  final HomeSummary summary;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    return KnzCard(
      padding: const EdgeInsets.fromLTRB(
        KnzSpace.s16,
        KnzSpace.s6,
        KnzSpace.s16,
        KnzSpace.s14,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Semantics(
                  header: true,
                  child: Text('Tvoje mapa kraje', style: KnzText.titleSm),
                ),
              ),
              KnzPressable(
                onPressed: onOpen,
                isLink: true,
                semanticLabel: 'Otevřít profil',
                builder: (context, state) => ConstrainedBox(
                  constraints: const BoxConstraints(
                    minHeight: KnzSize.touch,
                    minWidth: KnzSize.touch,
                  ),
                  child: Center(
                    widthFactor: 1,
                    child: Text(
                      'Otevřít',
                      style: KnzText.weight(KnzText.bodyLg, 900).copyWith(
                        color: state.hovered || state.pressed
                            ? KnzColors.textLinkHover
                            : KnzColors.textLink,
                        decoration: state.focused
                            ? TextDecoration.underline
                            : null,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          // Area progress only when the backend tells which area a place
          // is in; otherwise the counts alone.
          if (summary.areas.isNotEmpty) ...[
            const SizedBox(height: KnzSpace.s6),
            Row(
              children: [
                for (final (i, area) in summary.areas.indexed) ...[
                  if (i > 0) const SizedBox(width: KnzSpace.s10),
                  Expanded(child: _AreaColumn(progress: area)),
                ],
              ],
            ),
          ],
          const SizedBox(height: KnzSpace.s14),
          Wrap(
            spacing: KnzSpace.s20,
            runSpacing: KnzSpace.s8,
            children: [
              _CountLabel(
                marker: SvgPicture.asset(
                  'design-system/assets/map/marker-guessed.svg',
                  width: 22,
                  height: 22,
                  excludeFromSemantics: true,
                ),
                text: '${summary.guessed}\u00A0uhodnuto',
              ),
              _CountLabel(
                marker: const KnzIcon(KnzIcons.star, size: 20),
                text: '${summary.visited}\u00A0navštíveno',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AreaColumn extends StatelessWidget {
  const _AreaColumn({required this.progress});

  final AreaProgress progress;

  @override
  Widget build(BuildContext context) {
    final total = progress.total;
    final known = progress.known;
    final description = total == null
        ? Czech.count(known, 'místo', 'místa', 'míst')
        : Czech.fraction(known, total);
    return Semantics(
      label: '${progress.area.label}: $description',
      excludeSemantics: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              // A narrow screen shrinks the name rather than cutting it.
              Expanded(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    progress.area.label,
                    maxLines: 1,
                    style: KnzText.weight(KnzText.body, 800),
                  ),
                ),
              ),
              const SizedBox(width: KnzSpace.s4),
              Text(
                '$known',
                style: KnzText.weight(
                  KnzText.body,
                  800,
                ).copyWith(color: KnzColors.textMuted),
              ),
            ],
          ),
          const SizedBox(height: KnzSpace.s8),
          KnzProgressBar(
            value: progress.fraction,
            semanticLabel: progress.area.label,
            sentiment: progress.area.sentiment,
          ),
        ],
      ),
    );
  }
}

class _CountLabel extends StatelessWidget {
  const _CountLabel({required this.marker, required this.text});

  final Widget marker;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        marker,
        const SizedBox(width: KnzSpace.s6),
        Text(
          text,
          style: KnzText.weight(
            KnzText.bodyLg,
            800,
          ).copyWith(color: KnzColors.textSecondary),
        ),
      ],
    );
  }
}
