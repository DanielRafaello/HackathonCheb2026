import 'package:shared_preferences/shared_preferences.dart';

import 'tab_storage.dart';

/// A seat to take back after the app or the page reloads.
class StoredSeat {
  const StoredSeat({
    required this.resumeToken,
    required this.lobbyCode,
    required this.owner,
  });

  final String resumeToken;
  final String lobbyCode;

  /// Who took the seat (`MultiplayerController` identity): the seat is
  /// taken back only by the same account, or by a guest when a guest took
  /// it.
  final String owner;
}

/// What multiplayer remembers on this device: a guest's nickname and the
/// seat of the last lobby.
abstract interface class MultiplayerStore {
  Future<String?> readNickname();
  Future<void> writeNickname(String nickname);
  Future<StoredSeat?> readSeat();

  /// Null forgets the seat.
  Future<void> writeSeat(StoredSeat? seat);
}

/// [MultiplayerStore] for tests and as a fallback.
class MemoryMultiplayerStore implements MultiplayerStore {
  MemoryMultiplayerStore({this.nickname, this.seat});

  String? nickname;
  StoredSeat? seat;

  @override
  Future<String?> readNickname() async => nickname;

  @override
  Future<void> writeNickname(String nickname) async => this.nickname = nickname;

  @override
  Future<StoredSeat?> readSeat() async => seat;

  @override
  Future<void> writeSeat(StoredSeat? seat) async => this.seat = seat;
}

/// [MultiplayerStore] in the platform's preferences.
///
/// On the web the seat is kept per browser tab ([tab], the tab's
/// `sessionStorage`), because every tab shares the preferences: a second
/// tab would otherwise take the first tab's seat. The nickname is shared.
///
/// Never throws: in a private browser window, or when the storage is
/// broken, a read gives null and a write is dropped, and the player only
/// types the nickname again (CLAUDE.md, Platforms: Storage).
class SharedPreferencesMultiplayerStore implements MultiplayerStore {
  SharedPreferencesMultiplayerStore({
    this._preferences = SharedPreferences.getInstance,
    TabStorage? tab,
  }) : _tab = tab ?? tabStorage;

  final Future<SharedPreferences> Function() _preferences;
  final TabStorage? _tab;

  static const nicknameKey = 'knz.multiplayer.v1.nickname';
  static const resumeTokenKey = 'knz.multiplayer.v1.resumeToken';
  static const lobbyCodeKey = 'knz.multiplayer.v1.lobbyCode';
  static const seatOwnerKey = 'knz.multiplayer.v1.seatOwner';

  @override
  Future<String?> readNickname() async {
    try {
      return (await _preferences()).getString(nicknameKey);
    } on Object {
      return null;
    }
  }

  @override
  Future<void> writeNickname(String nickname) async {
    try {
      await (await _preferences()).setString(nicknameKey, nickname);
    } on Object {
      // Remembered for this session only.
    }
  }

  @override
  Future<StoredSeat?> readSeat() async {
    try {
      final String? Function(String key) read;
      if (_tab case final tab?) {
        read = tab.read;
      } else {
        read = (await _preferences()).getString;
      }
      final token = read(resumeTokenKey);
      final code = read(lobbyCodeKey);
      final owner = read(seatOwnerKey);
      if (token == null || code == null || owner == null) return null;
      return StoredSeat(resumeToken: token, lobbyCode: code, owner: owner);
    } on Object {
      return null;
    }
  }

  @override
  Future<void> writeSeat(StoredSeat? seat) async {
    final values = {
      resumeTokenKey: seat?.resumeToken,
      lobbyCodeKey: seat?.lobbyCode,
      seatOwnerKey: seat?.owner,
    };
    try {
      if (_tab case final tab?) {
        values.forEach(tab.write);
        return;
      }
      final preferences = await _preferences();
      for (final MapEntry(:key, :value) in values.entries) {
        if (value == null) {
          await preferences.remove(key);
        } else {
          await preferences.setString(key, value);
        }
      }
    } on Object {
      // The seat is kept in memory for this session only.
    }
  }
}
