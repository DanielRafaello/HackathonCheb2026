/// Strings kept for one browser tab only.
///
/// - Web: the tab's `sessionStorage`. Every tab of a browser shares
///   `localStorage`, so a seat kept there would be taken back by a second
///   tab, which then pushes the first one off the seat.
/// - Android and iOS: none ([tabStorage] is null); the app has one window.
library;

export 'tab_storage_io.dart'
    if (dart.library.js_interop) 'tab_storage_web.dart';

/// String values for one browser tab. Never throws.
abstract interface class TabStorage {
  String? read(String key);

  /// Null removes the value.
  void write(String key, String? value);
}
