import '../design_system/czech.dart';
import 'multiplayer_controller.dart';
import 'protocol.dart';

/// The Czech texts of multiplayer that depend on data (`copy.md`).
abstract final class MultiplayerCopy {
  static const _nbsp = ' ';

  /// The countdown: "4:05", "0:09".
  static String countdown(Duration left) {
    final seconds = left.inSeconds < 0 ? 0 : left.inSeconds;
    final minutes = seconds ~/ 60;
    final rest = (seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$rest';
  }

  /// The countdown for a screen reader: "Zbývají 4 minuty a 5 sekund",
  /// "Zbývá 1 minuta", "Zbývá 9 sekund". The verb agrees with the first
  /// number.
  static String countdownLabel(Duration left) {
    final seconds = left.inSeconds < 0 ? 0 : left.inSeconds;
    final minutes = seconds ~/ 60;
    final rest = seconds % 60;
    final parts = [
      if (minutes > 0) Czech.count(minutes, 'minuta', 'minuty', 'minut'),
      if (rest > 0 || minutes == 0)
        Czech.count(rest, 'sekunda', 'sekundy', 'sekund'),
    ];
    final verb = Czech.plural(
      minutes > 0 ? minutes : rest,
      'Zbývá',
      'Zbývají',
      'Zbývá',
    );
    return '$verb ${parts.join(' a$_nbsp')}';
  }

  /// A game length in the settings: "5 min", "1,5 min" never happens; the
  /// options are whole minutes, otherwise seconds.
  static String duration(int seconds) =>
      seconds % 60 == 0 ? '${seconds ~/ 60}${_nbsp}min' : '$seconds${_nbsp}s';

  /// "10 míst".
  static String places(int count) =>
      Czech.count(count, 'místo', 'místa', 'míst');

  /// "8 hráčů".
  static String players(int count) =>
      Czech.count(count, 'hráč', 'hráči', 'hráčů');

  /// The place's position in the game: "MÍSTO 3 Z 10".
  static String placeOverline(int number, int total) =>
      'MÍSTO ${Czech.fraction(number, total).toUpperCase()}';

  /// A distance in metres from the server: "550 m", "1,4 km".
  static String distance(int meters) => Czech.distance(meters.toDouble());

  /// "3 z 10 míst" for the guessed count on the leaderboard.
  static String guessed(int count, int total) =>
      '${Czech.fraction(count, total)}${_nbsp}míst';

  /// Below this a guess is "almost exact".
  static const closeMeters = 1000;

  /// Below this a guess was "not far".
  static const nearMeters = 15000;

  /// Vřídlík's line after a guess, by how close it was. After the [last]
  /// guess of the game it does not point to a next place.
  static String resultLine(int meters, {bool last = false}) {
    if (meters < closeMeters) return 'Skoro přesně! Tohle místo znáš.';
    if (meters < 5000) return 'Pěkný tip, jen kousek vedle.';
    if (meters < nearMeters) {
      return last
          ? 'Nebylo to daleko.'
          : 'Nebylo to daleko. Další místo ti půjde.';
    }
    return last
        ? 'Tohle bylo těžké.'
        : 'Tohle bylo těžké. Zkus to u${_nbsp}dalšího místa.';
  }

  /// What a player in the lobby is doing, next to their name.
  static String playerStatus(LobbyPlayer player, {required int placeCount}) {
    if (!player.connected) return 'Bez spojení';
    return switch (player.view) {
      PlayerView.lobby => 'V${_nbsp}místnosti',
      PlayerView.game =>
        'Hraje$_nbsp· ${Czech.fractionSlash(player.guessedCount, placeCount)}',
      PlayerView.results => 'Prohlíží výsledky',
    };
  }

  /// The toast for a [notice].
  static String notice(MultiplayerNotice notice) => switch (notice) {
    MultiplayerNotice.connectionFailed =>
      'Nepodařilo se připojit ke hře. Zkontroluj připojení a${_nbsp}zkus to znovu.',
    MultiplayerNotice.lobbyNotFound =>
      'Místnost s${_nbsp}tímhle kódem neexistuje.',
    MultiplayerNotice.lobbyFull => 'Místnost je plná.',
    MultiplayerNotice.notHost => 'Tohle může jen hostitel.',
    MultiplayerNotice.notEnoughPlayers => 'Na začátek hry je tu málo hráčů.',
    MultiplayerNotice.lobbyInGame =>
      'Hra právě běží. Nastavení změníš po jejím konci.',
    MultiplayerNotice.settingsInvalid => 'Tohle nastavení nejde použít.',
    MultiplayerNotice.outsideRegion =>
      'Tip musí ležet v${_nbsp}Karlovarském kraji. Tenhle se nepočítá.',
    MultiplayerNotice.guessRejected =>
      'Tip se nepodařilo uložit. Zkus to znovu.',
    MultiplayerNotice.rateLimited => 'Moc zpráv najednou. Zkus to za chvíli.',
    MultiplayerNotice.signInExpired => 'Přihlášení vypršelo. Přihlas se znovu.',
    MultiplayerNotice.seatLost =>
      'Spojení bylo pryč moc dlouho, připojuji tě do místnosti znovu.',
    MultiplayerNotice.removed => 'Už nejsi v${_nbsp}místnosti.',
    MultiplayerNotice.serverError =>
      'Něco se pokazilo na naší straně. Zkus to za chvíli.',
  };

  /// The error under a field of the entry form.
  static String entryError(EntryError error) => switch (error) {
    EntryError.nicknameInvalid =>
      'Přezdívka musí mít ${MultiplayerController.minNicknameLength} až '
          '${MultiplayerController.maxNicknameLength} znaků.',
    EntryError.codeInvalid =>
      'Kód místnosti má ${MultiplayerController.codeLength} znaků.',
    EntryError.lobbyNotFound => 'Místnost s${_nbsp}tímhle kódem neexistuje.',
    EntryError.lobbyFull => 'Místnost je plná.',
  };
}
