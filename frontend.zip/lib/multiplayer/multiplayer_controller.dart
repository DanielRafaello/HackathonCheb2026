import 'dart:async';

import 'package:flutter/foundation.dart';

import '../game/region.dart';
import '../round/geo.dart';
import 'multiplayer_connection.dart';
import 'multiplayer_store.dart';
import 'protocol.dart';

/// Where the player is in multiplayer.
enum MultiplayerPhase {
  /// Not connected: the player picks a nickname and creates or joins a
  /// lobby.
  entry,

  /// Connecting, or waiting for the server to answer a create, join, or
  /// resume.
  connecting,

  /// In the lobby: before a game, or waiting while others play.
  lobby,

  /// Playing a game.
  playing,

  /// Looking at the results of the game that just ended.
  results,

  /// The connection was lost and could not be restored.
  disconnected,
}

/// Something the player should know, shown as a toast.
enum MultiplayerNotice {
  connectionFailed,
  lobbyNotFound,
  lobbyFull,
  notHost,
  notEnoughPlayers,
  lobbyInGame,
  settingsInvalid,
  outsideRegion,
  guessRejected,
  rateLimited,
  signInExpired,
  seatLost,
  removed,
  serverError,
}

/// Why the entry form did not go through; shown under its field.
enum EntryError { nicknameInvalid, codeInvalid, lobbyNotFound, lobbyFull }

/// The result of the player's own guess on one place.
class PlaceResult {
  const PlaceResult({
    required this.index,
    required this.distanceMeters,
    required this.guess,
    required this.place,
  });

  final int index;
  final int distanceMeters;
  final GeoPoint guess;
  final PlaceReveal place;
}

/// What the controller is trying to do on the next connection.
sealed class _Intent {
  const _Intent();
}

class _Create extends _Intent {
  const _Create();
}

class _Join extends _Intent {
  const _Join(this.code);

  final String code;
}

/// Take the seat in lobby [code] back with the resume token; when the
/// seat is gone, join the lobby again.
class _Resume extends _Intent {
  const _Resume(this.code);

  final String code;
}

Stream<void> _everySecond() =>
    Stream<void>.periodic(const Duration(seconds: 1));

String? _noToken() => null;

String _guest() => MultiplayerController.guestIdentity;

/// The WebSocket close code with which the server closes a connection
/// whose seat another connection took back with the same resume token.
const closeReplaced = 4001;

/// Waits 1, 2, 4, 8, 15, 30 s between attempts: about a minute in all, the
/// time the server keeps a seat.
Duration defaultReconnectDelay(int attempt) =>
    Duration(seconds: const [1, 2, 4, 8, 15, 30][attempt.clamp(0, 5)]);

/// A multiplayer game over the socket server.
///
/// The server owns the lobby and the game; the controller keeps the
/// latest snapshot of them ([lobby]), the player's unconfirmed pin, and
/// the connection. A lost connection is restored with the resume token
/// the server issued, so the player keeps the seat.
class MultiplayerController extends ChangeNotifier {
  MultiplayerController({
    required this._connect,
    required this._store,
    this._token = _noToken,
    this._refreshToken,
    this._clock = DateTime.now,
    this._ticker = _everySecond,
    this._reconnectDelay = defaultReconnectDelay,
    this.maxReconnectAttempts = 6,
    this._identity = _guest,
    this.pingInterval = const Duration(seconds: 15),
    this.answerTimeout = const Duration(seconds: 10),
  });

  final MultiplayerConnector _connect;
  final MultiplayerStore _store;
  final String? Function() _token;
  final Future<bool> Function()? _refreshToken;
  final DateTime Function() _clock;
  final Stream<void> Function() _ticker;
  final Duration Function(int attempt) _reconnectDelay;

  /// Who plays: [guestIdentity], or the signed-in account (for example
  /// `account:42`). A stored seat is taken back only by the same identity.
  final String Function() _identity;

  /// Reconnect attempts before the controller gives up.
  final int maxReconnectAttempts;

  /// How often the controller pings the server to find a dead connection
  /// that never closed (a phone that slept or lost its signal).
  final Duration pingInterval;

  /// How long the controller waits for any message after a hello or a
  /// ping before it takes the connection for lost.
  final Duration answerTimeout;

  /// The identity of a player who is not signed in.
  static const guestIdentity = 'guest';

  /// Guest nicknames: 2–24 characters (the server's rule).
  static const minNicknameLength = 2;
  static const maxNicknameLength = 24;

  /// Lobby codes: 6 characters.
  static const codeLength = 6;

  final _notices = StreamController<MultiplayerNotice>.broadcast();

  /// Things to tell the player, as toasts.
  Stream<MultiplayerNotice> get notices => _notices.stream;

  MultiplayerPhase _phase = MultiplayerPhase.connecting;
  MultiplayerPhase get phase => _phase;

  bool _reconnecting = false;

  /// The connection was lost and the controller is restoring it; the
  /// screen stays as it was.
  bool get reconnecting => _reconnecting;

  bool _openElsewhere = false;

  /// The seat was taken over by the same player in another window or tab;
  /// this one does not take it back by itself.
  bool get openElsewhere => _openElsewhere;

  EntryError? _entryError;
  EntryError? get entryError => _entryError;

  String? _nickname;

  /// The guest's remembered nickname, or the name the server knows the
  /// player by.
  String? get nickname => _nickname;

  /// The lobby code from an invite link, for the entry form.
  String? _initialCode;
  String? get initialCode => _initialCode;

  bool get isSignedIn => _token() != null;

  WelcomeMessage? _welcome;
  MultiplayerLimits? get limits => _welcome?.limits;
  LobbySettings? get defaults => _welcome?.defaults;

  LobbyView? _lobby;

  /// The latest snapshot of the player's lobby.
  LobbyView? get lobby => _lobby;
  GameView? get game => _lobby?.game;

  GameView? _finishedGame;

  /// The game whose results the player looks at: the lobby's game once it
  /// has finished, or the last finished one while the next game runs
  /// without this player.
  GameView? get resultsGame {
    final game = this.game;
    return game?.status == GameStatus.finished ? game : _finishedGame;
  }

  SelfGame? get selfGame => game?.self;

  GeoPoint? _pin;

  /// The unconfirmed guess on the current place.
  GeoPoint? get pin => _pin;

  bool _submitting = false;
  bool get submitting => _submitting;

  PlaceResult? _shownResult;

  /// The result of the guess the player just made, until they go on to
  /// the next place.
  PlaceResult? get shownResult => _shownResult;

  /// The server's clock minus this device's clock.
  Duration _clockOffset = Duration.zero;

  /// Now, on the server's clock.
  DateTime get serverNow => _clock().add(_clockOffset);

  /// Time left in the running game, or null when no game runs.
  Duration? get remaining {
    final game = this.game;
    if (game == null || game.status != GameStatus.playing) return null;
    final left = game.endsAt.difference(serverNow);
    return left.isNegative ? Duration.zero : left;
  }

  /// The player has guessed every place and waits for the others.
  bool get finishedAllPlaces {
    final self = selfGame;
    final game = this.game;
    return self != null && game != null && self.currentIndex >= game.placeCount;
  }

  bool get canGuess =>
      _phase == MultiplayerPhase.playing &&
      !_reconnecting &&
      !_submitting &&
      _shownResult == null &&
      selfGame?.currentPlaceName != null;

  /// The host may start a game now.
  bool get canStart {
    final lobby = _lobby;
    if (lobby == null || !lobby.isHost || _reconnecting) return false;
    if (lobby.phase == LobbyPhase.playing) return false;
    if (lobby.self?.view != PlayerView.lobby) return false;
    final ready = lobby.players
        .where((p) => p.connected && p.view == PlayerView.lobby)
        .length;
    return ready >= (limits?.minPlayers ?? 1);
  }

  MultiplayerConnection? _connection;
  StreamSubscription<ServerMessage>? _subscription;
  StreamSubscription<void>? _tick;
  Timer? _retryTimer;
  Timer? _pingTimer;
  Timer? _answerTimer;

  /// Bumped for every connection, so events of an old one are dropped.
  int _generation = 0;
  _Intent? _intent;
  String? _resumeToken;

  /// The hello of the current connection carried a resume token.
  bool _helloResumed = false;
  String? _lobbyCode;
  int _reconnectAttempts = 0;
  bool _authRetried = false;

  /// The server welcomed the player on the current connection.
  bool _welcomed = false;
  int? _submittedIndex;
  bool _guessInDoubt = false;
  DateTime? _gameStartedAt;
  bool _disposed = false;

  /// Starts multiplayer: takes back the seat of the last lobby, joins
  /// [joinCode] from an invite link, or shows the entry form.
  Future<void> start({String? joinCode}) async {
    final code = joinCode == null ? null : normalizeCode(joinCode);
    _initialCode = code;
    _nickname = await _store.readNickname();
    var seat = await _store.readSeat();
    if (_disposed) return;
    if (seat != null && seat.owner != _identity()) {
      // Someone else took this seat on this device: an account that has
      // signed out since, or a guest before this account signed in.
      seat = null;
      unawaited(_store.writeSeat(null));
    }
    final canEnter = isSignedIn || validNickname(_nickname) != null;
    if (seat != null && canEnter && (code == null || code == seat.lobbyCode)) {
      _resumeToken = seat.resumeToken;
      _lobbyCode = seat.lobbyCode;
      await _open(_Resume(seat.lobbyCode));
    } else if (code != null && code.length == codeLength && canEnter) {
      await _open(_Join(code));
    } else {
      _setPhase(MultiplayerPhase.entry);
    }
  }

  /// A lobby code as the server writes it: capitals, no spaces.
  static String normalizeCode(String code) =>
      code.replaceAll(RegExp(r'\s+'), '').toUpperCase();

  /// Control, format, and line or paragraph separator characters, which
  /// the server refuses in a nickname.
  static final _forbiddenNicknameCharacters = RegExp(
    r'[\p{Cc}\p{Cf}\p{Zl}\p{Zp}]',
    unicode: true,
  );

  /// The nickname as the server keeps it (trimmed, runs of whitespace
  /// made one space), or null when it breaks the server's rule: 2–24
  /// characters, counted as Unicode code points, and no control or format
  /// characters.
  static String? validNickname(String? nickname) {
    final trimmed = nickname?.trim() ?? '';
    if (_forbiddenNicknameCharacters.hasMatch(trimmed)) return null;
    final normalized = trimmed.replaceAll(RegExp(r'\s+'), ' ');
    final length = normalized.runes.length;
    if (length < minNicknameLength || length > maxNicknameLength) return null;
    return normalized;
  }

  /// Creates a lobby; a guest plays as [nickname].
  Future<void> createLobby({String? nickname}) async {
    if (!_acceptNickname(nickname)) return;
    await _open(const _Create());
  }

  /// Joins lobby [code]; a guest plays as [nickname].
  Future<void> joinLobby(String code, {String? nickname}) async {
    final normalized = normalizeCode(code);
    if (normalized.length != codeLength) {
      _entryError = EntryError.codeInvalid;
      _notify();
      return;
    }
    if (!_acceptNickname(nickname)) return;
    await _open(_Join(normalized));
  }

  bool _acceptNickname(String? nickname) {
    _entryError = null;
    if (isSignedIn) return true;
    final valid = validNickname(nickname);
    if (valid == null) {
      _entryError = EntryError.nicknameInvalid;
      _notify();
      return false;
    }
    _nickname = valid;
    unawaited(_store.writeNickname(valid));
    return true;
  }

  /// Tries again after the connection could not be restored.
  Future<void> retry() async {
    final code = _lobbyCode;
    if (code == null) {
      _setPhase(MultiplayerPhase.entry);
      return;
    }
    _reconnectAttempts = 0;
    _openElsewhere = false;
    _setPhase(MultiplayerPhase.connecting);
    await _open(_Resume(code));
  }

  /// Leaves the lobby for good: the seat is freed.
  void leave() {
    _connection?.send(const LeaveLobbyMessage());
    _retryTimer?.cancel();
    _retryTimer = null;
    _intent = null;
    _reconnectAttempts = 0;
    _closeConnection();
    // After a takeover the seat is the other window's, which keeps its own
    // copy (its own tab storage on the web). The copy stored here is
    // forgotten too, or entering multiplayer here again would take the
    // seat back and push the other window off.
    _openElsewhere = false;
    _forgetSeat();
    _lobby = null;
    _finishedGame = null;
    _pin = null;
    _submitting = false;
    _guessInDoubt = false;
    _shownResult = null;
    _reconnecting = false;
    _stopTicker();
    _setPhase(MultiplayerPhase.entry);
  }

  /// The host changes the settings; only the given ones change.
  void updateSettings({
    int? maxPlayers,
    int? placeCount,
    int? durationSeconds,
  }) {
    _connection?.send(
      UpdateSettingsMessage(
        maxPlayers: maxPlayers,
        placeCount: placeCount,
        durationSeconds: durationSeconds,
      ),
    );
  }

  void startGame() {
    if (!canStart) return;
    _connection?.send(const StartGameMessage());
  }

  /// From the results back to the lobby, for another game.
  void returnToLobby() => _connection?.send(const ReturnToLobbyMessage());

  /// Puts the pin on the map, or moves it.
  void placePin(GeoPoint position) {
    if (!canGuess || !position.isValid) return;
    _pin = position;
    _notify();
  }

  /// Sends the one guess on the current place. A pin outside the region
  /// is not sent; it stays so the player can move it.
  void confirmGuess() {
    final pin = _pin;
    final self = selfGame;
    if (!canGuess || pin == null || self == null) return;
    if (!Region.contains(pin)) {
      _notice(MultiplayerNotice.outsideRegion);
      return;
    }
    _submitting = true;
    _submittedIndex = self.currentIndex;
    _connection?.send(GuessMessage(index: self.currentIndex, position: pin));
    _notify();
  }

  /// Checks that the connection still answers, as after the app comes
  /// back to the foreground: a connection that went dead meanwhile is
  /// restored.
  void checkConnection() {
    if (_connection == null || !_welcomed) return;
    _ping();
  }

  /// Goes on from the result of a place to the next one.
  void dismissResult() {
    if (_shownResult == null) return;
    _shownResult = null;
    _notify();
  }

  // -------------------------------------------------------------------------
  // Connection
  // -------------------------------------------------------------------------

  Future<void> _open(_Intent intent) async {
    _retryTimer?.cancel();
    _closeConnection();
    _intent = intent;
    _welcomed = false;
    if (intent is! _Resume) _setPhase(MultiplayerPhase.connecting);
    final generation = ++_generation;
    if (intent is! _Resume) _notify();
    final MultiplayerConnection connection;
    try {
      connection = await _connect();
    } on Object catch (error) {
      debugPrint('Multiplayer connection failed: $error');
      if (_disposed || generation != _generation) return;
      _connectionLost();
      return;
    }
    if (_disposed || generation != _generation) {
      unawaited(connection.close());
      return;
    }
    _connection = connection;
    _subscription = connection.messages.listen(
      (message) {
        if (generation == _generation) _onMessage(message);
      },
      onDone: () {
        if (generation == _generation) {
          _connection = null;
          _stopLiveness();
          if (connection.closeCode == closeReplaced) {
            _takenOver();
          } else {
            _connectionLost();
          }
        }
      },
    );
    final token = _token();
    _helloResumed = _resumeToken != null;
    connection.send(
      HelloMessage(
        token: token,
        nickname: token == null ? _nickname : null,
        resumeToken: _resumeToken,
      ),
    );
    _awaitAnswer();
  }

  /// Pings the server and waits for its answer.
  void _ping() {
    _connection?.send(const PingMessage());
    _awaitAnswer();
  }

  /// Any message from the server must come within [answerTimeout];
  /// otherwise the connection is dead without having closed, and it is
  /// restored like a dropped one.
  void _awaitAnswer() {
    _answerTimer ??= Timer(answerTimeout, () {
      _answerTimer = null;
      if (_disposed || _connection == null) return;
      debugPrint('Multiplayer server does not answer; reconnecting.');
      _closeConnection();
      _connectionLost();
    });
  }

  void _stopLiveness() {
    _pingTimer?.cancel();
    _pingTimer = null;
    _answerTimer?.cancel();
    _answerTimer = null;
  }

  /// The same player took the seat back in another window or tab. Taking
  /// it back here would push that one off, and so on without end, so this
  /// one stops until the player asks.
  void _takenOver() {
    _retryTimer?.cancel();
    _intent = null;
    _reconnecting = false;
    _openElsewhere = true;
    _submitting = false;
    _guessInDoubt = false;
    _stopTicker();
    _setPhase(MultiplayerPhase.disconnected);
  }

  /// Drops the current connection; its events are ignored from now on.
  void _closeConnection() {
    _generation++;
    _stopLiveness();
    final subscription = _subscription;
    final connection = _connection;
    _subscription = null;
    _connection = null;
    unawaited(subscription?.cancel());
    unawaited(connection?.close());
  }

  /// The connection ended without the player leaving.
  void _connectionLost() {
    final intent = _intent;
    final inLobby =
        _lobby != null ||
        intent is _Resume ||
        _phase == MultiplayerPhase.disconnected;
    if (!inLobby) {
      _intent = null;
      _setPhase(MultiplayerPhase.entry);
      _notice(MultiplayerNotice.connectionFailed);
      return;
    }
    // Whether a guess in flight landed is known only from the next state.
    if (_submitting) _guessInDoubt = true;
    if (_reconnectAttempts >= maxReconnectAttempts) {
      _reconnecting = false;
      _stopTicker();
      _setPhase(MultiplayerPhase.disconnected);
      return;
    }
    final delay = _reconnectDelay(_reconnectAttempts++);
    _reconnecting = true;
    _notify();
    final code = _lobbyCode;
    _retryTimer?.cancel();
    _retryTimer = Timer(delay, () {
      if (_disposed) return;
      if (code == null) {
        _reconnecting = false;
        _setPhase(MultiplayerPhase.entry);
      } else {
        unawaited(_open(_Resume(code)));
      }
    });
  }

  void _onMessage(ServerMessage message) {
    // The connection is alive.
    _answerTimer?.cancel();
    _answerTimer = null;
    switch (message) {
      case WelcomeMessage():
        _onWelcome(message);
      case StateMessage():
        _onState(message);
      case GuessResultMessage():
        _onGuessResult(message);
      case ErrorMessage(:final code):
        _onError(code);
      case PongMessage() || UnknownMessage():
        break;
    }
  }

  void _onWelcome(WelcomeMessage welcome) {
    _welcome = welcome;
    _welcomed = true;
    _nickname = isSignedIn ? welcome.nickname : _nickname;
    _authRetried = false;
    _resumeToken = welcome.resumeToken;
    switch (_intent) {
      case _Create():
        _connection?.send(const CreateLobbyMessage());
      case _Join(:final code):
        _connection?.send(JoinLobbyMessage(code));
      case _Resume(:final code) when !_helloResumed:
        // No seat to take back (it was lost before): join the lobby again.
        _intent = _Join(code);
        _connection?.send(JoinLobbyMessage(code));
      case _Resume() || null:
        // The server sends the lobby right after a resumed hello.
        break;
    }
    _pingTimer?.cancel();
    _pingTimer = Timer.periodic(pingInterval, (_) => _ping());
    _notify();
  }

  void _onState(StateMessage state) {
    _clockOffset = state.serverNow.difference(_clock());
    final lobby = state.lobby;
    if (lobby == null) {
      // Right after a hello, before the create or join is answered.
      if (_intent != null) return;
      final wasInLobby = _lobby != null;
      _lobby = null;
      _forgetSeat();
      _stopTicker();
      _setPhase(MultiplayerPhase.entry);
      if (wasInLobby) _notice(MultiplayerNotice.removed);
      return;
    }
    _intent = null;
    _reconnecting = false;
    _reconnectAttempts = 0;
    _entryError = null;
    _lobby = lobby;
    _lobbyCode = lobby.code;
    final token = _resumeToken;
    if (token != null) {
      unawaited(
        _store.writeSeat(
          StoredSeat(
            resumeToken: token,
            lobbyCode: lobby.code,
            owner: _identity(),
          ),
        ),
      );
    }

    final game = lobby.game;
    if (game != null && game.status == GameStatus.finished) {
      _finishedGame = game;
    }
    if (game?.startedAt != _gameStartedAt) {
      // A new game: nothing of the last one carries over.
      _gameStartedAt = game?.startedAt;
      _pin = null;
      _shownResult = null;
      _submitting = false;
      _submittedIndex = null;
      _guessInDoubt = false;
    }
    _reconcileGuess(game?.self);

    if (game != null && game.status == GameStatus.playing) {
      _startTicker();
    } else {
      _stopTicker();
    }
    final view = lobby.self?.view ?? PlayerView.lobby;
    final phase = switch (view) {
      PlayerView.lobby => MultiplayerPhase.lobby,
      PlayerView.game => MultiplayerPhase.playing,
      PlayerView.results => MultiplayerPhase.results,
    };
    if (phase != MultiplayerPhase.playing) {
      _pin = null;
      _submitting = false;
      // The guess that ended the game, or the result the player looked at
      // when the time ran out, stays until the player has seen it; the
      // results come after it.
      final gameOver =
          phase == MultiplayerPhase.results &&
          game?.status == GameStatus.finished;
      if (!gameOver) _shownResult = null;
    }
    _setPhase(phase);
  }

  /// A guess whose answer was lost with the connection: once the state
  /// shows the player past that place, the guess landed and its result is
  /// in the rounds. Otherwise it did not land and the pin stays.
  void _reconcileGuess(SelfGame? self) {
    final index = _submittedIndex;
    if (index == null || self == null) {
      _guessInDoubt = false;
      return;
    }
    if (self.currentIndex > index) {
      final round = self.round(index);
      final place = round?.place;
      final guess = round?.guess;
      final distance = round?.distanceMeters;
      if (_submitting && place != null && guess != null && distance != null) {
        _shownResult = PlaceResult(
          index: index,
          distanceMeters: distance,
          guess: guess,
          place: place,
        );
        _pin = null;
      }
      _submitting = false;
      _submittedIndex = null;
      _guessInDoubt = false;
    } else if (_guessInDoubt) {
      _submitting = false;
      _submittedIndex = null;
      _guessInDoubt = false;
    }
  }

  void _onGuessResult(GuessResultMessage result) {
    _shownResult = PlaceResult(
      index: result.index,
      distanceMeters: result.distanceMeters,
      guess: result.guess,
      place: result.place,
    );
    _pin = null;
    _submitting = false;
    _submittedIndex = null;
    _notify();
  }

  void _onError(String code) {
    const entryCodes = {
      'resume.invalid',
      'auth.invalid_token',
      'nickname.invalid',
      'lobby.not_found',
      'lobby.full',
    };
    if (_intent != null && !entryCodes.contains(code)) {
      // The hello, create, or join failed in a way the player cannot fix
      // (the server broke, or refused too many messages).
      _entryInterrupted(
        code == 'rate_limited'
            ? MultiplayerNotice.rateLimited
            : MultiplayerNotice.serverError,
      );
      return;
    }
    switch (code) {
      case 'resume.invalid':
        // The seat is gone; the hello still went through as a new player.
        _resumeToken = null;
        unawaited(_store.writeSeat(null));
        final intent = _intent;
        if (intent is _Resume) {
          _intent = _Join(intent.code);
          _initialCode ??= intent.code;
          // The server answers resume.invalid before its welcome, which
          // then sends the join; a join sent earlier would race the
          // hello. Only after this connection's welcome is it sent here.
          if (_welcomed && _connection != null) {
            _connection?.send(JoinLobbyMessage(intent.code));
          }
        }
        if (_lobby != null) _notice(MultiplayerNotice.seatLost);
      case 'auth.invalid_token':
        unawaited(_onAuthRejected());
      case 'nickname.invalid':
        _failEntry(EntryError.nicknameInvalid);
      case 'lobby.not_found':
        if (_intent != null) {
          _failEntry(EntryError.lobbyNotFound);
        } else {
          _notice(MultiplayerNotice.lobbyNotFound);
        }
      case 'lobby.full':
        if (_intent != null) {
          _failEntry(EntryError.lobbyFull);
        } else {
          _notice(MultiplayerNotice.lobbyFull);
        }
      case 'lobby.not_host':
        _notice(MultiplayerNotice.notHost);
      case 'lobby.not_enough_players':
        _notice(MultiplayerNotice.notEnoughPlayers);
      case 'lobby.in_game':
        _notice(MultiplayerNotice.lobbyInGame);
      case 'settings.invalid':
        _notice(MultiplayerNotice.settingsInvalid);
      case 'guess.outside_region':
        _guessRefused(MultiplayerNotice.outsideRegion);
      case 'guess.invalid' ||
          'guess.wrong_index' ||
          'game.not_playing' ||
          'game.no_places':
        _guessRefused(MultiplayerNotice.guessRejected);
      case 'rate_limited':
        _guessRefused(MultiplayerNotice.rateLimited);
      default:
        _submitting = false;
        _notice(MultiplayerNotice.serverError);
        _notify();
    }
  }

  void _guessRefused(MultiplayerNotice notice) {
    _submitting = false;
    _submittedIndex = null;
    _notice(notice);
    _notify();
  }

  /// The server could not answer the hello, the create, or the join. A
  /// player who is restoring the connection to a lobby tries again, like
  /// after a dropped connection; otherwise the player is back at the form.
  void _entryInterrupted(MultiplayerNotice notice) {
    if (_lobby != null || _intent is _Resume) {
      _closeConnection();
      _connectionLost();
      return;
    }
    _failEntry(null);
    _notice(notice);
  }

  /// The create or join did not go through: back to the form.
  void _failEntry(EntryError? error) {
    _intent = null;
    _entryError = error;
    _retryTimer?.cancel();
    _closeConnection();
    _lobby = null;
    _finishedGame = null;
    _reconnecting = false;
    _reconnectAttempts = 0;
    _stopTicker();
    _forgetSeat();
    _setPhase(MultiplayerPhase.entry);
  }

  /// The JWT expired: refresh it once and connect again, otherwise the
  /// player must sign in again.
  Future<void> _onAuthRejected() async {
    final intent =
        _intent ?? (_lobbyCode == null ? null : _Resume(_lobbyCode!));
    _closeConnection();
    final generation = _generation;
    final refresh = _refreshToken;
    if (!_authRetried && refresh != null && intent != null) {
      _authRetried = true;
      final ok = await refresh();
      // Disposed, or the player left or started over meanwhile.
      if (_disposed || generation != _generation) return;
      if (ok && _token() != null) {
        await _open(intent);
        return;
      }
    }
    _intent = null;
    _lobby = null;
    _reconnecting = false;
    _stopTicker();
    _setPhase(MultiplayerPhase.entry);
    _notice(MultiplayerNotice.signInExpired);
  }

  void _forgetSeat() {
    _resumeToken = null;
    _lobbyCode = null;
    unawaited(_store.writeSeat(null));
  }

  void _startTicker() {
    _tick ??= _ticker().listen((_) => _notify());
  }

  void _stopTicker() {
    unawaited(_tick?.cancel());
    _tick = null;
  }

  void _notice(MultiplayerNotice notice) {
    if (!_disposed) _notices.add(notice);
  }

  void _setPhase(MultiplayerPhase phase) {
    _phase = phase;
    _notify();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _retryTimer?.cancel();
    _stopTicker();
    // The seat stays for the reconnect grace period; leaving is explicit.
    _closeConnection();
    unawaited(_notices.close());
    super.dispose();
  }
}
