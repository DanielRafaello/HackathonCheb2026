import 'dart:convert';

import '../round/round.dart';

/// The multiplayer socket protocol: JSON text frames, each with a `type`.
///
/// The server owns the game. Before a player guesses a place, the client
/// holds only its name and index; the place's location and card arrive in
/// [GuessResultMessage] after the player's own guess, and for every place
/// once the game has finished.

/// Thrown when a frame from the server does not have the expected shape.
class ProtocolException implements Exception {
  const ProtocolException(this.message);

  final String message;

  @override
  String toString() => 'ProtocolException: $message';
}

Map<String, dynamic> _map(Object? value, String what) {
  if (value is Map<String, dynamic>) return value;
  if (value is Map) return value.cast<String, dynamic>();
  throw ProtocolException('$what is not an object');
}

List<Object?> _list(Object? value, String what) {
  if (value is List) return value;
  throw ProtocolException('$what is not a list');
}

int _int(Object? value, String what) {
  if (value is num && value.isFinite) return value.round();
  throw ProtocolException('$what is not a number');
}

int? _intOrNull(Object? value, String what) =>
    value == null ? null : _int(value, what);

double _double(Object? value, String what) {
  if (value is num && value.isFinite) return value.toDouble();
  throw ProtocolException('$what is not a number');
}

String _string(Object? value, String what) {
  if (value is String) return value;
  throw ProtocolException('$what is not a string');
}

String? _stringOrNull(Object? value) => value is String ? value : null;

bool _bool(Object? value) => value == true;

GeoPoint _point(Object? value, String what) {
  final json = _map(value, what);
  return GeoPoint(
    _double(json['latitude'], '$what.latitude'),
    _double(json['longitude'], '$what.longitude'),
  );
}

// ---------------------------------------------------------------------------
// Client → server
// ---------------------------------------------------------------------------

/// A message to the server.
sealed class ClientMessage {
  const ClientMessage();

  String get type;

  Map<String, Object?> toJson() => {'type': type, ..._fields()};

  Map<String, Object?> _fields() => const {};

  String encode() => jsonEncode(toJson());
}

/// The first message on every connection: a signed-in player sends the
/// JWT, a guest the nickname. [resumeToken] takes the seat back after a
/// lost connection.
class HelloMessage extends ClientMessage {
  const HelloMessage({this.token, this.nickname, this.resumeToken});

  final String? token;
  final String? nickname;
  final String? resumeToken;

  @override
  String get type => 'hello';

  @override
  Map<String, Object?> _fields() => {
    'token': ?token,
    'nickname': ?nickname,
    'resumeToken': ?resumeToken,
  };
}

class CreateLobbyMessage extends ClientMessage {
  const CreateLobbyMessage();

  @override
  String get type => 'createLobby';
}

class JoinLobbyMessage extends ClientMessage {
  const JoinLobbyMessage(this.code);

  final String code;

  @override
  String get type => 'joinLobby';

  @override
  Map<String, Object?> _fields() => {'code': code};
}

class LeaveLobbyMessage extends ClientMessage {
  const LeaveLobbyMessage();

  @override
  String get type => 'leaveLobby';
}

/// The host changes the lobby's settings; only the given ones change.
class UpdateSettingsMessage extends ClientMessage {
  const UpdateSettingsMessage({
    this.maxPlayers,
    this.placeCount,
    this.durationSeconds,
  });

  final int? maxPlayers;
  final int? placeCount;
  final int? durationSeconds;

  @override
  String get type => 'updateSettings';

  @override
  Map<String, Object?> _fields() => {
    'settings': {
      'maxPlayers': ?maxPlayers,
      'placeCount': ?placeCount,
      'durationSeconds': ?durationSeconds,
    },
  };
}

class StartGameMessage extends ClientMessage {
  const StartGameMessage();

  @override
  String get type => 'startGame';
}

/// The one guess on place [index], which must be the player's current one.
class GuessMessage extends ClientMessage {
  const GuessMessage({required this.index, required this.position});

  final int index;
  final GeoPoint position;

  @override
  String get type => 'guess';

  @override
  Map<String, Object?> _fields() => {
    'index': index,
    'latitude': position.latitude,
    'longitude': position.longitude,
  };
}

class ReturnToLobbyMessage extends ClientMessage {
  const ReturnToLobbyMessage();

  @override
  String get type => 'returnToLobby';
}

class PingMessage extends ClientMessage {
  const PingMessage();

  @override
  String get type => 'ping';
}

// ---------------------------------------------------------------------------
// Server → client
// ---------------------------------------------------------------------------

/// A message from the server.
sealed class ServerMessage {
  const ServerMessage();

  /// Parses one text frame. A frame that is not JSON or has no known
  /// `type` becomes [UnknownMessage], so a newer server cannot break an
  /// older app; a known type with a broken shape throws
  /// [ProtocolException].
  static ServerMessage parse(String frame) {
    final Object? json;
    try {
      json = jsonDecode(frame);
    } on FormatException {
      return const UnknownMessage(null);
    }
    if (json is! Map) return const UnknownMessage(null);
    return fromJson(json.cast<String, dynamic>());
  }

  static ServerMessage fromJson(Map<String, dynamic> json) {
    final type = json['type'];
    return switch (type) {
      'welcome' => WelcomeMessage.fromJson(json),
      'state' => StateMessage.fromJson(json),
      'guessResult' => GuessResultMessage.fromJson(json),
      'error' => ErrorMessage(
        _stringOrNull(json['code']) ?? 'server.error',
        _stringOrNull(json['message']),
      ),
      'pong' => const PongMessage(),
      _ => UnknownMessage(type is String ? type : null),
    };
  }
}

/// What the host may set, within these limits.
class MultiplayerLimits {
  const MultiplayerLimits({
    required this.maxPlayers,
    required this.minPlayers,
    required this.maxPlaceCount,
    required this.minDurationSeconds,
    required this.maxDurationSeconds,
    required this.penaltyDistanceMeters,
  });

  factory MultiplayerLimits.fromJson(Map<String, dynamic> json) =>
      MultiplayerLimits(
        maxPlayers: _int(json['maxPlayers'], 'limits.maxPlayers'),
        minPlayers: _int(json['minPlayers'], 'limits.minPlayers'),
        maxPlaceCount: _int(json['maxPlaceCount'], 'limits.maxPlaceCount'),
        minDurationSeconds: _int(
          json['minDurationSeconds'],
          'limits.minDurationSeconds',
        ),
        maxDurationSeconds: _int(
          json['maxDurationSeconds'],
          'limits.maxDurationSeconds',
        ),
        penaltyDistanceMeters: _int(
          json['penaltyDistanceMeters'],
          'limits.penaltyDistanceMeters',
        ),
      );

  final int maxPlayers;
  final int minPlayers;
  final int maxPlaceCount;
  final int minDurationSeconds;
  final int maxDurationSeconds;

  /// What an unguessed place counts as in the average.
  final int penaltyDistanceMeters;
}

/// A lobby's settings.
class LobbySettings {
  const LobbySettings({
    required this.maxPlayers,
    required this.placeCount,
    required this.durationSeconds,
  });

  factory LobbySettings.fromJson(Map<String, dynamic> json) => LobbySettings(
    maxPlayers: _int(json['maxPlayers'], 'settings.maxPlayers'),
    placeCount: _int(json['placeCount'], 'settings.placeCount'),
    durationSeconds: _int(json['durationSeconds'], 'settings.durationSeconds'),
  );

  final int maxPlayers;
  final int placeCount;
  final int durationSeconds;
}

/// The server accepted the player.
class WelcomeMessage extends ServerMessage {
  const WelcomeMessage({
    required this.playerId,
    required this.resumeToken,
    required this.nickname,
    required this.isGuest,
    required this.limits,
    required this.defaults,
  });

  factory WelcomeMessage.fromJson(Map<String, dynamic> json) => WelcomeMessage(
    playerId: _string(json['playerId'], 'playerId'),
    resumeToken: _string(json['resumeToken'], 'resumeToken'),
    nickname: _string(json['nickname'], 'nickname'),
    isGuest: _bool(json['isGuest']),
    limits: MultiplayerLimits.fromJson(_map(json['limits'], 'limits')),
    defaults: LobbySettings.fromJson(_map(json['defaults'], 'defaults')),
  );

  final String playerId;

  /// Takes the seat back after a lost connection.
  final String resumeToken;
  final String nickname;
  final bool isGuest;
  final MultiplayerLimits limits;
  final LobbySettings defaults;
}

/// The player's lobby as the player may see it, after every change.
class StateMessage extends ServerMessage {
  const StateMessage({required this.serverNow, required this.lobby});

  factory StateMessage.fromJson(Map<String, dynamic> json) => StateMessage(
    serverNow: DateTime.fromMillisecondsSinceEpoch(
      _int(json['serverNow'], 'serverNow'),
      isUtc: true,
    ),
    lobby: json['lobby'] == null
        ? null
        : LobbyView.fromJson(_map(json['lobby'], 'lobby')),
  );

  /// The server's clock when it sent the message.
  final DateTime serverNow;

  /// Null when the player is in no lobby.
  final LobbyView? lobby;
}

/// The reveal of the place the player just guessed.
class GuessResultMessage extends ServerMessage {
  const GuessResultMessage({
    required this.index,
    required this.distanceMeters,
    required this.guess,
    required this.place,
  });

  factory GuessResultMessage.fromJson(Map<String, dynamic> json) =>
      GuessResultMessage(
        index: _int(json['index'], 'index'),
        distanceMeters: _int(json['distanceMeters'], 'distanceMeters'),
        guess: _point(json['guess'], 'guess'),
        place: PlaceReveal.fromJson(_map(json['place'], 'place')),
      );

  final int index;
  final int distanceMeters;
  final GeoPoint guess;
  final PlaceReveal place;
}

/// The server refused a message; [code] is a stable key such as
/// `lobby.not_found`.
class ErrorMessage extends ServerMessage {
  const ErrorMessage(this.code, [this.message]);

  final String code;
  final String? message;
}

class PongMessage extends ServerMessage {
  const PongMessage();
}

/// A message this version of the app does not know. It is ignored.
class UnknownMessage extends ServerMessage {
  const UnknownMessage(this.type);

  final String? type;
}

enum LobbyPhase {
  /// No game yet.
  waiting,
  playing,

  /// A game has ended and no new one has started.
  finished;

  static LobbyPhase fromWire(Object? wire) => switch (wire) {
    'playing' => playing,
    'finished' => finished,
    _ => waiting,
  };
}

/// Where a player is in the lobby.
enum PlayerView {
  lobby,
  game,
  results;

  static PlayerView fromWire(Object? wire) => switch (wire) {
    'game' => game,
    'results' => results,
    _ => lobby,
  };
}

class LobbyPlayer {
  const LobbyPlayer({
    required this.id,
    required this.nickname,
    required this.isGuest,
    required this.isHost,
    required this.connected,
    required this.view,
    required this.guessedCount,
  });

  factory LobbyPlayer.fromJson(Map<String, dynamic> json) => LobbyPlayer(
    id: _string(json['id'], 'player.id'),
    nickname: _string(json['nickname'], 'player.nickname'),
    isGuest: _bool(json['isGuest']),
    isHost: _bool(json['isHost']),
    connected: json['connected'] != false,
    view: PlayerView.fromWire(json['view']),
    guessedCount: _intOrNull(json['guessedCount'], 'guessedCount') ?? 0,
  );

  final String id;
  final String nickname;
  final bool isGuest;
  final bool isHost;
  final bool connected;
  final PlayerView view;

  /// Places this player has guessed in the current game; the only live
  /// progress the others see.
  final int guessedCount;
}

class LobbyView {
  const LobbyView({
    required this.code,
    required this.hostId,
    required this.selfId,
    required this.phase,
    required this.settings,
    required this.players,
    required this.game,
  });

  factory LobbyView.fromJson(Map<String, dynamic> json) {
    final players = [
      for (final player in _list(json['players'], 'players'))
        _map(player, 'player'),
    ];
    var game = json['game'] == null ? null : _map(json['game'], 'game');
    final leaderboard = game?['leaderboard'] == null
        ? null
        : [
            for (final row in _list(game!['leaderboard'], 'leaderboard'))
              _map(row, 'leaderboard row'),
          ];
    final names = distinctNicknames([
      for (final player in players)
        (
          _string(player['id'], 'player.id'),
          _string(player['nickname'], 'player.nickname'),
        ),
      for (final row in leaderboard ?? const <Map<String, dynamic>>[])
        (
          _string(row['playerId'], 'playerId'),
          _string(row['nickname'], 'nickname'),
        ),
    ]);
    if (game != null && leaderboard != null) {
      game = {
        ...game,
        'leaderboard': [
          for (final row in leaderboard)
            {...row, 'nickname': names[row['playerId']]},
        ],
      };
    }
    return LobbyView(
      code: _string(json['code'], 'lobby.code'),
      hostId: _string(json['hostId'], 'lobby.hostId'),
      selfId: _string(json['selfId'], 'lobby.selfId'),
      phase: LobbyPhase.fromWire(json['phase']),
      settings: LobbySettings.fromJson(_map(json['settings'], 'settings')),
      players: [
        for (final player in players)
          LobbyPlayer.fromJson({...player, 'nickname': names[player['id']]}),
      ],
      game: game == null ? null : GameView.fromJson(game),
    );
  }

  final String code;
  final String hostId;
  final String selfId;
  final LobbyPhase phase;
  final LobbySettings settings;
  final List<LobbyPlayer> players;

  /// The running game, or the last finished one until the next starts.
  final GameView? game;

  bool get isHost => hostId == selfId;

  LobbyPlayer? get self {
    for (final player in players) {
      if (player.id == selfId) return player;
    }
    return null;
  }

  LobbyPlayer? player(String id) {
    for (final player in players) {
      if (player.id == id) return player;
    }
    return null;
  }
}

/// The name to show for each player id in [players] (id and nickname, the
/// lobby's players in join order first): the server allows the same
/// nickname twice, for example the same guest in two browser tabs, so a
/// repeated nickname gets a number, "Alice (2)". The first player id with
/// a nickname keeps it as it is.
Map<String, String> distinctNicknames(Iterable<(String, String)> players) {
  final names = <String, String>{};
  final seen = <String, int>{};
  for (final (id, nickname) in players) {
    if (names.containsKey(id)) continue;
    final count = (seen[nickname] ?? 0) + 1;
    seen[nickname] = count;
    names[id] = count == 1 ? nickname : '$nickname ($count)';
  }
  return names;
}

enum GameStatus {
  playing,
  finished;

  static GameStatus fromWire(Object? wire) =>
      wire == 'finished' ? finished : playing;
}

class GameView {
  const GameView({
    required this.status,
    required this.startedAt,
    required this.endsAt,
    required this.placeCount,
    required this.participantIds,
    required this.self,
    required this.leaderboard,
    required this.places,
    required this.guesses,
  });

  factory GameView.fromJson(Map<String, dynamic> json) {
    final guesses = json['guesses'];
    return GameView(
      status: GameStatus.fromWire(json['status']),
      startedAt: _time(json['startedAt'], 'startedAt'),
      endsAt: _time(json['endsAt'], 'endsAt'),
      placeCount: _int(json['placeCount'], 'placeCount'),
      participantIds: [
        for (final id in _list(json['participantIds'], 'participantIds'))
          _string(id, 'participantId'),
      ],
      self: json['self'] == null
          ? null
          : SelfGame.fromJson(_map(json['self'], 'self')),
      leaderboard: json['leaderboard'] == null
          ? null
          : [
              for (final row in _list(json['leaderboard'], 'leaderboard'))
                LeaderboardRow.fromJson(_map(row, 'leaderboard row')),
            ],
      places: json['places'] == null
          ? null
          : [
              for (final place in _list(json['places'], 'places'))
                PlaceReveal.fromJson(_map(place, 'place')),
            ],
      guesses: guesses == null
          ? null
          : {
              for (final entry in _map(guesses, 'guesses').entries)
                entry.key: [
                  for (final guess in _list(entry.value, 'guesses'))
                    guess == null
                        ? null
                        : PlayerGuess.fromJson(_map(guess, 'guess')),
                ],
            },
    );
  }

  static DateTime _time(Object? value, String what) =>
      DateTime.fromMillisecondsSinceEpoch(_int(value, what), isUtc: true);

  final GameStatus status;
  final DateTime startedAt;

  /// When the game timer runs out, on the server's clock.
  final DateTime endsAt;
  final int placeCount;
  final List<String> participantIds;

  /// Null when this player is not playing this game.
  final SelfGame? self;

  /// Only once the game has finished.
  final List<LeaderboardRow>? leaderboard;

  /// Every place in game order, only once the game has finished.
  final List<PlaceReveal>? places;

  /// Every participant's guesses by player id, only once the game has
  /// finished; null for a place the player did not guess.
  final Map<String, List<PlayerGuess?>>? guesses;
}

/// This player's own game.
class SelfGame {
  const SelfGame({
    required this.currentIndex,
    required this.currentPlaceName,
    required this.rounds,
  });

  factory SelfGame.fromJson(Map<String, dynamic> json) => SelfGame(
    currentIndex: _int(json['currentIndex'], 'currentIndex'),
    currentPlaceName: _stringOrNull(json['currentPlaceName']),
    rounds: [
      for (final round in _list(json['rounds'] ?? const [], 'rounds'))
        MultiplayerRound.fromJson(_map(round, 'round')),
    ],
  );

  /// The place to guess now, which is also the number of guesses made;
  /// equal to the place count when the player has guessed them all.
  final int currentIndex;

  /// The name of the place at [currentIndex] while the game runs.
  final String? currentPlaceName;

  /// The places already guessed while the game runs; all of them once it
  /// has finished.
  final List<MultiplayerRound> rounds;

  MultiplayerRound? round(int index) {
    for (final round in rounds) {
      if (round.index == index) return round;
    }
    return null;
  }
}

/// One place of this player's game.
class MultiplayerRound {
  const MultiplayerRound({
    required this.index,
    required this.name,
    required this.guess,
    required this.distanceMeters,
    required this.place,
  });

  factory MultiplayerRound.fromJson(Map<String, dynamic> json) =>
      MultiplayerRound(
        index: _int(json['index'], 'round.index'),
        name: _string(json['name'], 'round.name'),
        guess: json['guess'] == null ? null : _point(json['guess'], 'guess'),
        distanceMeters: _intOrNull(json['distanceMeters'], 'distanceMeters'),
        place: json['place'] == null
            ? null
            : PlaceReveal.fromJson(_map(json['place'], 'place')),
      );

  final int index;
  final String name;

  /// Null when the player did not guess this place in time.
  final GeoPoint? guess;
  final int? distanceMeters;
  final PlaceReveal? place;
}

class LeaderboardRow {
  const LeaderboardRow({
    required this.rank,
    required this.playerId,
    required this.nickname,
    required this.averageDistanceMeters,
    required this.guessedCount,
    required this.totalDistanceMeters,
    required this.finishedAt,
  });

  factory LeaderboardRow.fromJson(Map<String, dynamic> json) => LeaderboardRow(
    rank: _int(json['rank'], 'rank'),
    playerId: _string(json['playerId'], 'playerId'),
    nickname: _string(json['nickname'], 'nickname'),
    averageDistanceMeters: _int(
      json['averageDistanceMeters'],
      'averageDistanceMeters',
    ),
    guessedCount: _int(json['guessedCount'], 'guessedCount'),
    totalDistanceMeters: _int(
      json['totalDistanceMeters'],
      'totalDistanceMeters',
    ),
    finishedAt: json['finishedAt'] == null
        ? null
        : DateTime.fromMillisecondsSinceEpoch(
            _int(json['finishedAt'], 'finishedAt'),
            isUtc: true,
          ),
  );

  final int rank;
  final String playerId;
  final String nickname;

  /// Unguessed places count as the penalty distance.
  final int averageDistanceMeters;
  final int guessedCount;
  final int totalDistanceMeters;
  final DateTime? finishedAt;
}

/// One player's guess on one place, in the final results.
class PlayerGuess {
  const PlayerGuess({required this.position, required this.distanceMeters});

  factory PlayerGuess.fromJson(Map<String, dynamic> json) => PlayerGuess(
    position: _point(json, 'guess'),
    distanceMeters: _int(json['distanceMeters'], 'distanceMeters'),
  );

  final GeoPoint position;
  final int distanceMeters;
}

/// A place revealed to the player: where it is and its card.
class PlaceReveal {
  const PlaceReveal({
    required this.index,
    required this.id,
    required this.name,
    required this.location,
    required this.category,
    required this.description,
    required this.contentSourceUrl,
    required this.source,
  });

  factory PlaceReveal.fromJson(Map<String, dynamic> json) {
    final source = json['source'];
    return PlaceReveal(
      index: _int(json['index'], 'place.index'),
      id: _int(json['id'], 'place.id'),
      name: _string(json['name'], 'place.name'),
      location: _point(json, 'place'),
      category: _stringOrNull(json['category']) ?? '',
      description: _stringOrNull(json['description']) ?? '',
      contentSourceUrl: _stringOrNull(json['contentSourceUrl']),
      source: source is Map
          ? PlaceSource.fromJson(source.cast<String, dynamic>())
          : null,
    );
  }

  final int index;
  final int id;
  final String name;
  final GeoPoint location;
  final String category;
  final String description;
  final String? contentSourceUrl;
  final PlaceSource? source;

  /// A spring's card always carries the water warning.
  bool get isSpring => category.toLowerCase().contains('pramen');

  /// The place's card, as the round screens show it.
  PlaceCard toCard() => PlaceCard(
    id: id,
    name: name,
    type: category,
    description: description,
    location: location,
    source: source?.label,
    licence: source?.licenseCode,
    isSpring: isSpring,
  );
}

/// Where a place's data comes from, and under which licence.
class PlaceSource {
  const PlaceSource({
    this.title,
    this.publisher,
    this.portalUrl,
    this.licenseCode,
    this.licenseUrl,
    this.attributionText,
  });

  factory PlaceSource.fromJson(Map<String, dynamic> json) => PlaceSource(
    title: _stringOrNull(json['title']),
    publisher: _stringOrNull(json['publisher']),
    portalUrl: _stringOrNull(json['portalUrl']),
    licenseCode: _stringOrNull(json['licenseCode']),
    licenseUrl: _stringOrNull(json['licenseUrl']),
    attributionText: _stringOrNull(json['attributionText']),
  );

  final String? title;
  final String? publisher;
  final String? portalUrl;
  final String? licenseCode;
  final String? licenseUrl;
  final String? attributionText;

  /// The source as a place card names it: the attribution text when the
  /// publisher requires one, otherwise the publisher or the dataset title.
  String? get label {
    for (final candidate in [attributionText, publisher, title]) {
      if (candidate != null && candidate.trim().isNotEmpty) {
        return candidate.trim();
      }
    }
    return null;
  }
}
