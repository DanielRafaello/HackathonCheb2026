import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import 'multiplayer_connection.dart';
import 'protocol.dart';

/// [MultiplayerConnection] over a WebSocket, on every platform
/// (`web_socket_channel` uses the browser's WebSocket on the web and
/// `dart:io` elsewhere).
class WebSocketMultiplayerConnection implements MultiplayerConnection {
  WebSocketMultiplayerConnection._(this._channel) {
    _subscription = _channel.stream.listen(
      (frame) {
        if (frame is! String) return;
        try {
          _messages.add(ServerMessage.parse(frame));
        } on ProtocolException catch (error) {
          // A broken frame is dropped; the next state message repairs the
          // picture.
          debugPrint('Multiplayer frame dropped: $error');
        }
      },
      onError: (Object error) => debugPrint('Multiplayer socket: $error'),
      onDone: _finish,
      cancelOnError: false,
    );
  }

  /// Connects to [url] and waits until the socket is open.
  static Future<MultiplayerConnection> connect(
    Uri url, {
    Duration timeout = const Duration(seconds: 10),
  }) async {
    final channel = WebSocketChannel.connect(url);
    try {
      await channel.ready.timeout(timeout);
    } on Object {
      unawaited(channel.sink.close().catchError((Object _) {}));
      rethrow;
    }
    return WebSocketMultiplayerConnection._(channel);
  }

  final WebSocketChannel _channel;
  final _messages = StreamController<ServerMessage>();
  late final StreamSubscription<Object?> _subscription;
  bool _closed = false;

  @override
  Stream<ServerMessage> get messages => _messages.stream;

  @override
  int? get closeCode => _channel.closeCode;

  @override
  void send(ClientMessage message) {
    if (_closed) return;
    try {
      _channel.sink.add(message.encode());
    } on Object catch (error) {
      debugPrint('Multiplayer message not sent: $error');
    }
  }

  @override
  Future<void> close() async {
    if (_closed) return;
    try {
      await _channel.sink.close().timeout(const Duration(seconds: 2));
    } on Object {
      // Closing a dead socket can hang or fail; the stream ends anyway.
    }
    _finish();
  }

  void _finish() {
    if (_closed) return;
    _closed = true;
    unawaited(_subscription.cancel());
    unawaited(_messages.close());
  }
}
