import 'tab_storage.dart';

/// Android and iOS: the app has one window, so nothing is kept per tab.
TabStorage? get tabStorage => null;
