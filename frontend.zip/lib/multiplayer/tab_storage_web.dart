import 'package:web/web.dart' as web;

import 'tab_storage.dart';

/// Web: the tab's `sessionStorage`.
TabStorage? get tabStorage => const _SessionStorage();

class _SessionStorage implements TabStorage {
  const _SessionStorage();

  @override
  String? read(String key) {
    try {
      return web.window.sessionStorage.getItem(key);
    } on Object {
      return null;
    }
  }

  @override
  void write(String key, String? value) {
    try {
      if (value == null) {
        web.window.sessionStorage.removeItem(key);
      } else {
        web.window.sessionStorage.setItem(key, value);
      }
    } on Object {
      // Blocked storage: the seat is kept in memory for this page only.
    }
  }
}
