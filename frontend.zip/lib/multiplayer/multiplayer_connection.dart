import 'protocol.dart';

/// One open connection to the multiplayer socket server.
abstract interface class MultiplayerConnection {
  /// The server's messages, in order. The stream ends when the connection
  /// closes, from either side; it never emits an error.
  Stream<ServerMessage> get messages;

  /// The WebSocket close code once [messages] has ended, or null when it
  /// is not known (the connection is open, or it broke without one).
  int? get closeCode;

  /// Sends [message]. Dropped once the connection has closed.
  void send(ClientMessage message);

  /// Closes the connection; [messages] ends.
  Future<void> close();
}

/// Opens a connection, or throws when the server cannot be reached.
typedef MultiplayerConnector = Future<MultiplayerConnection> Function();
