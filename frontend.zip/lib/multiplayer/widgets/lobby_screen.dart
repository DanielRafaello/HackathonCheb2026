import 'dart:math';

import 'package:flutter/material.dart';

import '../../design_system/design_system.dart';
import '../multiplayer_controller.dart';
import '../multiplayer_copy.dart';
import '../protocol.dart';
import 'invite_qr_code.dart';
import 'multiplayer_layout.dart';

/// The lobby: its code and invite QR code to share, the players, the
/// settings, and the start for the host.
class LobbyScreen extends StatelessWidget {
  const LobbyScreen({
    super.key,
    required this.controller,
    required this.inviteLink,
    required this.onCopyCode,
    required this.onCopyLink,
    required this.onLeave,
  });

  final MultiplayerController controller;

  /// The link that opens this lobby, shown as a QR code.
  final String inviteLink;
  final VoidCallback onCopyCode;
  final VoidCallback onCopyLink;
  final VoidCallback onLeave;

  @override
  Widget build(BuildContext context) {
    final lobby = controller.lobby!;
    final settings = lobby.settings;
    final gameRunning = lobby.phase == LobbyPhase.playing;
    final placeCount = lobby.game?.placeCount ?? settings.placeCount;
    return MultiplayerLayout(
      reconnecting: controller.reconnecting,
      topBar: MultiplayerTopBar(
        onClose: onLeave,
        closeLabel: 'Odejít z místnosti',
        remaining: controller.remaining,
      ),
      footer: [
        if (lobby.isHost)
          KnzButton(
            label: 'Start hry',
            sentiment: KnzSentiment.accent,
            size: KnzButtonSize.cta,
            onPressed: controller.canStart ? controller.startGame : null,
          )
        else
          Text(
            gameRunning
                ? 'Další hru spustí hostitel, až tahle skončí.'
                : 'Hru spustí hostitel.',
            textAlign: TextAlign.center,
            style: KnzText.bodySm.copyWith(color: KnzColors.textMuted),
          ),
        KnzButton(
          label: 'Odejít',
          variant: KnzButtonVariant.ghost,
          onPressed: onLeave,
        ),
      ],
      children: [
        _CodeCard(
          code: lobby.code,
          inviteLink: inviteLink,
          onCopyCode: onCopyCode,
          onCopyLink: onCopyLink,
        ),
        if (gameRunning) ...[
          const SizedBox(height: KnzSpace.s16),
          const KnzSpeechBubble(
            mood: KnzMood.think,
            text:
                'Právě běží hra. Počkej tu, další hru už odehraješ '
                's ostatními.',
          ),
        ],
        const SizedBox(height: KnzSpace.s20),
        SectionLabel(
          'HRÁČI · ${Czech.fraction(lobby.players.length, settings.maxPlayers).toUpperCase()}',
        ),
        const SizedBox(height: KnzSpace.s8),
        for (final player in lobby.players) ...[
          PlayerRow(
            player: player,
            isSelf: player.id == lobby.selfId,
            status: MultiplayerCopy.playerStatus(
              player,
              placeCount: placeCount,
            ),
          ),
          const SizedBox(height: KnzSpace.s8),
        ],
        const SizedBox(height: KnzSpace.s12),
        const SectionLabel('NASTAVENÍ HRY'),
        const SizedBox(height: KnzSpace.s8),
        if (lobby.isHost && !gameRunning)
          _HostSettings(controller: controller, lobby: lobby)
        else
          _SettingsSummary(settings: settings),
      ],
    );
  }
}

/// The lobby code, big, the invite QR code, and the copy buttons.
class _CodeCard extends StatelessWidget {
  const _CodeCard({
    required this.code,
    required this.inviteLink,
    required this.onCopyCode,
    required this.onCopyLink,
  });

  final String code;
  final String inviteLink;
  final VoidCallback onCopyCode;
  final VoidCallback onCopyLink;

  @override
  Widget build(BuildContext context) {
    return KnzCard(
      sentiment: KnzSentiment.primary,
      variant: KnzCardVariant.tinted,
      padding: const EdgeInsets.all(KnzSpace.s16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'KÓD MÍSTNOSTI',
            textAlign: TextAlign.center,
            style: KnzText.overline.copyWith(color: KnzColors.primaryEdge),
          ),
          const SizedBox(height: KnzSpace.s4),
          Semantics(
            label: 'Kód místnosti: ${code.split('').join(' ')}',
            excludeSemantics: true,
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                code,
                style: KnzText.display.copyWith(
                  color: KnzColors.primaryEdge,
                  letterSpacing: KnzSpace.s6,
                ),
              ),
            ),
          ),
          const SizedBox(height: KnzSpace.s12),
          Center(child: InviteQrCode(link: inviteLink)),
          const SizedBox(height: KnzSpace.s12),
          Text(
            'Pošli kód nebo odkaz kamarádům. Kdo je u tebe, '
            'načte QR kód fotoaparátem.',
            textAlign: TextAlign.center,
            style: KnzText.bodySm.copyWith(color: KnzColors.textSecondary),
          ),
          const SizedBox(height: KnzSpace.s12),
          Row(
            children: [
              Expanded(
                child: KnzButton(
                  label: 'Kopírovat kód',
                  variant: KnzButtonVariant.secondary,
                  compact: true,
                  onPressed: onCopyCode,
                ),
              ),
              const SizedBox(width: KnzSpace.s10),
              Expanded(
                child: KnzButton(
                  label: 'Sdílet odkaz',
                  icon: KnzIcons.share,
                  variant: KnzButtonVariant.secondary,
                  compact: true,
                  onPressed: onCopyLink,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// One player in the lobby (`components.md`, PlayerRow **(added)**): the
/// initial, the nickname, the host and "you" labels, and what they do.
class PlayerRow extends StatelessWidget {
  const PlayerRow({
    super.key,
    required this.player,
    required this.isSelf,
    required this.status,
  });

  final LobbyPlayer player;
  final bool isSelf;
  final String status;

  @override
  Widget build(BuildContext context) {
    final initial = player.nickname.isEmpty
        ? '?'
        : player.nickname.characters.first.toUpperCase();
    return MergeSemantics(
      child: KnzCard(
        sentiment: isSelf ? KnzSentiment.primary : KnzSentiment.neutral,
        variant: isSelf ? KnzCardVariant.tinted : KnzCardVariant.outlined,
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s14,
          vertical: KnzSpace.s10,
        ),
        child: Row(
          children: [
            Container(
              width: KnzSize.touch,
              height: KnzSize.touch,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: player.connected
                    ? KnzColors.primary
                    : KnzColors.surfaceDisabled,
                shape: BoxShape.circle,
              ),
              child: ExcludeSemantics(
                child: Text(
                  initial,
                  style: KnzText.titleSm.copyWith(
                    color: player.connected
                        ? KnzColors.textOnPrimary
                        : KnzColors.textMuted,
                  ),
                ),
              ),
            ),
            const SizedBox(width: KnzSpace.s12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    spacing: KnzSpace.s6,
                    runSpacing: KnzSpace.s4,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      Text(player.nickname, style: KnzText.cardTitle),
                      if (player.isHost)
                        const KnzPill(
                          label: 'HOSTITEL',
                          sentiment: KnzSentiment.accent,
                        ),
                      if (isSelf) const KnzPill(label: 'TY'),
                    ],
                  ),
                  Text(
                    status,
                    style: KnzText.bodySm.copyWith(color: KnzColors.textMuted),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// The host's settings: one segmented control per setting, with options
/// within the server's limits.
class _HostSettings extends StatelessWidget {
  const _HostSettings({required this.controller, required this.lobby});

  final MultiplayerController controller;
  final LobbyView lobby;

  /// The options offered, with the server's default and the current
  /// value; the server's limits decide which of them show.
  static const _placeOptions = [5, 10, 15, 20];
  static const _durationOptions = [180, 300, 600, 900];
  static const _playerOptions = [2, 4, 6, 8];

  static List<int> _options(
    List<int> presets,
    int? fallback,
    int current,
    int min,
    int max,
  ) {
    final values = {
      for (final value in [...presets, ?fallback])
        if (value >= min && value <= max) value,
      current,
    }.toList()..sort();
    return values;
  }

  @override
  Widget build(BuildContext context) {
    final settings = lobby.settings;
    final limits = controller.limits;
    final defaults = controller.defaults;
    final places = _options(
      _placeOptions,
      defaults?.placeCount,
      settings.placeCount,
      1,
      limits?.maxPlaceCount ?? settings.placeCount,
    );
    final durations = _options(
      _durationOptions,
      defaults?.durationSeconds,
      settings.durationSeconds,
      limits?.minDurationSeconds ?? settings.durationSeconds,
      limits?.maxDurationSeconds ?? settings.durationSeconds,
    );
    // The server takes no fewer than the players needed to start, and no
    // fewer than are in the lobby.
    final players = _options(
      _playerOptions,
      defaults?.maxPlayers,
      settings.maxPlayers,
      max(limits?.minPlayers ?? 1, lobby.players.length),
      limits?.maxPlayers ?? settings.maxPlayers,
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _Setting(
          label: 'Počet míst',
          child: KnzSegmentedControl(
            labels: [for (final p in places) '$p'],
            selected: places.indexOf(settings.placeCount),
            onSelected: (i) => controller.updateSettings(placeCount: places[i]),
          ),
        ),
        _Setting(
          label: 'Čas na hru',
          child: KnzSegmentedControl(
            labels: [for (final d in durations) MultiplayerCopy.duration(d)],
            selected: durations.indexOf(settings.durationSeconds),
            onSelected: (i) =>
                controller.updateSettings(durationSeconds: durations[i]),
          ),
        ),
        _Setting(
          label: 'Nejvýš hráčů',
          child: KnzSegmentedControl(
            labels: [for (final p in players) '$p'],
            selected: players.indexOf(settings.maxPlayers),
            onSelected: (i) =>
                controller.updateSettings(maxPlayers: players[i]),
          ),
        ),
      ],
    );
  }
}

class _Setting extends StatelessWidget {
  const _Setting({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: KnzSpace.s12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            label,
            style: KnzText.weight(
              KnzText.caption,
              900,
            ).copyWith(color: KnzColors.textSecondary),
          ),
          const SizedBox(height: KnzSpace.s6),
          child,
        ],
      ),
    );
  }
}

/// The settings for players who are not the host, read only.
class _SettingsSummary extends StatelessWidget {
  const _SettingsSummary({required this.settings});

  final LobbySettings settings;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: KnzSpace.s8,
      runSpacing: KnzSpace.s8,
      children: [
        for (final text in [
          MultiplayerCopy.places(settings.placeCount),
          MultiplayerCopy.duration(settings.durationSeconds),
          'nejvýš ${MultiplayerCopy.players(settings.maxPlayers)}',
        ])
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: KnzSpace.s10,
              vertical: KnzSpace.s6,
            ),
            decoration: BoxDecoration(
              color: KnzColors.surfaceSubtle,
              borderRadius: BorderRadius.circular(KnzRadius.sm),
            ),
            child: Text(
              text,
              style: KnzText.caption.copyWith(color: KnzColors.textSecondary),
            ),
          ),
      ],
    );
  }
}
