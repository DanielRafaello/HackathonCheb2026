import 'package:flutter/material.dart';

import '../../design_system/design_system.dart';
import '../multiplayer_copy.dart';

/// The widest the multiplayer screens get, on a desktop browser.
const multiplayerMaxWidth = 480.0;

/// Centres [child] at the multiplayer screen width.
Widget centred(Widget child, {double maxWidth = multiplayerMaxWidth}) => Center(
  child: ConstrainedBox(
    constraints: BoxConstraints(maxWidth: maxWidth),
    child: child,
  ),
);

/// A multiplayer screen (`DESIGN.md`, game screen structure): the top bar,
/// content that scrolls, and the footer with the main action.
class MultiplayerLayout extends StatelessWidget {
  const MultiplayerLayout({
    super.key,
    required this.topBar,
    required this.children,
    this.footer = const [],
    this.reconnecting = false,
  });

  final Widget topBar;
  final List<Widget> children;

  /// The actions at the bottom, main action first.
  final List<Widget> footer;

  /// Shows the [ReconnectBanner] under the top bar.
  final bool reconnecting;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        centred(topBar),
        if (reconnecting)
          centred(
            const Padding(
              padding: EdgeInsets.fromLTRB(
                KnzSize.screenGutter,
                0,
                KnzSize.screenGutter,
                KnzSpace.s8,
              ),
              child: ReconnectBanner(),
            ),
          ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(
              KnzSize.screenGutter,
              KnzSpace.s8,
              KnzSize.screenGutter,
              KnzSpace.s16,
            ),
            child: centred(
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: children,
              ),
            ),
          ),
        ),
        if (footer.isNotEmpty)
          centred(
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(
                  KnzSize.screenGutter,
                  KnzSpace.s14,
                  KnzSize.screenGutter,
                  KnzSpace.s28,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (final (i, action) in footer.indexed) ...[
                      if (i > 0) const SizedBox(height: KnzSpace.s8),
                      action,
                    ],
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}

/// The top bar of a multiplayer screen (`components.md`, GameTopBar
/// *multiplayer*): close, the guessed places, and the game countdown.
class MultiplayerTopBar extends StatelessWidget {
  const MultiplayerTopBar({
    super.key,
    required this.onClose,
    this.closeIcon = KnzIcons.close,
    this.closeLabel = 'Zavřít',
    this.guessed,
    this.placeCount,
    this.remaining,
  });

  final VoidCallback onClose;
  final KnzIcons closeIcon;
  final String closeLabel;

  /// Places guessed so far; with [placeCount] the bar shows the progress.
  final int? guessed;
  final int? placeCount;

  /// The game countdown, while a game runs.
  final Duration? remaining;

  @override
  Widget build(BuildContext context) {
    final guessed = this.guessed;
    final total = placeCount;
    final remaining = this.remaining;
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        KnzSpace.s20 - KnzSpace.s10,
        KnzSpace.s18,
        KnzSpace.s20,
        KnzSpace.s8,
      ),
      child: Row(
        children: [
          KnzIconButton(
            icon: closeIcon,
            semanticLabel: closeLabel,
            onPressed: onClose,
          ),
          const SizedBox(width: KnzSpace.s4),
          if (guessed != null && total != null && total > 0) ...[
            Expanded(
              child: KnzProgressBar(
                value: guessed / total,
                semanticLabel:
                    'Uhodnutá místa: '
                    '${Czech.fraction(guessed.clamp(0, total), total)}',
              ),
            ),
            const SizedBox(width: KnzSpace.s8),
            ExcludeSemantics(
              child: Text(
                Czech.fractionSlash(guessed, total),
                style: KnzText.caption.copyWith(color: KnzColors.textMuted),
              ),
            ),
          ] else
            const Spacer(),
          if (remaining != null) ...[
            const SizedBox(width: KnzSpace.s14),
            CountdownPill(remaining: remaining),
          ],
        ],
      ),
    );
  }
}

/// The game countdown "4:05" on a pill **(added)**. Under 30 s the pill
/// turns red, and the screen reader hears the time left in words.
class CountdownPill extends StatelessWidget {
  const CountdownPill({super.key, required this.remaining});

  final Duration remaining;

  /// Below this the pill warns that time runs out.
  static const warnBelow = Duration(seconds: 30);

  @override
  Widget build(BuildContext context) {
    final warn = remaining < warnBelow;
    return Semantics(
      label: MultiplayerCopy.countdownLabel(remaining),
      excludeSemantics: true,
      child: Container(
        constraints: const BoxConstraints(minWidth: 64),
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s12,
          vertical: KnzSpace.s6,
        ),
        decoration: BoxDecoration(
          color: warn ? KnzColors.dangerTint : KnzColors.surfaceSubtle,
          borderRadius: BorderRadius.circular(KnzRadius.pill),
          border: Border.all(
            color: warn ? KnzColors.dangerSoft : KnzColors.border,
            width: KnzDepth.border,
          ),
        ),
        alignment: Alignment.center,
        child: Text(
          MultiplayerCopy.countdown(remaining),
          style: KnzText.weight(KnzText.titleSm, 900).copyWith(
            color: warn ? KnzColors.dangerEdge : KnzColors.text,
            fontFeatures: const [FontFeature.tabularFigures()],
          ),
        ),
      ),
    );
  }
}

/// "Spojení se přerušilo, připojuji znovu…" while the connection is being
/// restored **(added)**: an info row like RevealCard's.
class ReconnectBanner extends StatelessWidget {
  const ReconnectBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      liveRegion: true,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s12,
          vertical: KnzSpace.s8,
        ),
        decoration: BoxDecoration(
          color: KnzColors.surfaceSubtle,
          borderRadius: BorderRadius.circular(KnzRadius.sm),
        ),
        child: Row(
          children: [
            const KnzIcon(KnzIcons.info, size: 16, color: KnzColors.iconMuted),
            const SizedBox(width: KnzSpace.s8),
            Expanded(
              child: Text(
                'Spojení se přerušilo, připojuji znovu…',
                style: KnzText.caption.copyWith(color: KnzColors.textSecondary),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// A section heading in CAPS: "HRÁČI · 3 Z 8".
class SectionLabel extends StatelessWidget {
  const SectionLabel(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      header: true,
      child: Text(
        text,
        style: KnzText.overline.copyWith(color: KnzColors.textMuted),
      ),
    );
  }
}

/// Vřídlík with a message and actions: connecting, a lost connection.
class MultiplayerMessage extends StatelessWidget {
  const MultiplayerMessage({
    super.key,
    required this.onClose,
    required this.mood,
    required this.text,
    this.actions = const [],
  });

  final VoidCallback onClose;
  final KnzMood mood;
  final String text;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        centred(MultiplayerTopBar(onClose: onClose)),
        Expanded(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(KnzSize.screenGutter),
              child: centred(
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Semantics(
                      liveRegion: true,
                      child: KnzSpeechBubble(mood: mood, text: text),
                    ),
                    for (final action in actions) ...[
                      const SizedBox(height: KnzSpace.s12),
                      action,
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// Asks before the player leaves a running game (`components.md`,
/// LeaveGameSheet **(added)**, after VisitSheet). Returns true to leave.
Future<bool> confirmLeaveGame(BuildContext context) async {
  final leave = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: KnzColors.surface,
    barrierColor: KnzColors.text.withValues(alpha: 0.55),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(
        top: Radius.circular(KnzRadius.sheet),
      ),
    ),
    builder: (context) => SafeArea(
      top: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(
          KnzSize.screenGutter,
          KnzSpace.s10,
          KnzSize.screenGutter,
          KnzSpace.s20,
        ),
        child: centred(
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: KnzSize.touch,
                  height: KnzSpace.s6,
                  decoration: BoxDecoration(
                    color: KnzColors.borderStrong,
                    borderRadius: BorderRadius.circular(KnzRadius.pill),
                  ),
                ),
              ),
              const SizedBox(height: KnzSpace.s14),
              Row(
                children: [
                  const KnzMascot(mood: KnzMood.sad, width: 72),
                  const SizedBox(width: KnzSpace.s12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Odejít ze hry?', style: KnzText.titleMd),
                        const SizedBox(height: KnzSpace.s4),
                        Text(
                          'Hra poběží dál bez tebe. Místa bez tipu se ti '
                          'počítají s trestnou vzdáleností.',
                          style: KnzText.weight(
                            KnzText.body,
                            800,
                          ).copyWith(color: KnzColors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: KnzSpace.s20),
              KnzButton(
                label: 'Hrát dál',
                size: KnzButtonSize.cta,
                onPressed: () => Navigator.pop(context, false),
              ),
              const SizedBox(height: KnzSpace.s12),
              KnzButton(
                label: 'Odejít',
                sentiment: KnzSentiment.danger,
                variant: KnzButtonVariant.secondary,
                size: KnzButtonSize.cta,
                onPressed: () => Navigator.pop(context, true),
              ),
            ],
          ),
        ),
      ),
    ),
  );
  return leave ?? false;
}
