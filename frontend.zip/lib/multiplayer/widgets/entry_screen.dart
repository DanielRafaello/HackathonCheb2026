import 'package:flutter/material.dart';

import '../../design_system/design_system.dart';
import '../multiplayer_controller.dart';
import '../multiplayer_copy.dart';
import 'multiplayer_layout.dart';

/// The start of multiplayer: a guest picks a nickname, then the player
/// creates a lobby or joins one by its code.
class EntryScreen extends StatefulWidget {
  const EntryScreen({
    super.key,
    required this.controller,
    required this.accountNickname,
    required this.onClose,
  });

  final MultiplayerController controller;

  /// The signed-in player's name; null for a guest, who types one.
  final String? accountNickname;
  final VoidCallback onClose;

  @override
  State<EntryScreen> createState() => _EntryScreenState();
}

class _EntryScreenState extends State<EntryScreen> {
  late final _nickname = TextEditingController(
    text: widget.controller.nickname ?? '',
  );
  late final _code = TextEditingController(
    text: widget.controller.initialCode ?? '',
  );

  @override
  void dispose() {
    _nickname.dispose();
    _code.dispose();
    super.dispose();
  }

  bool get _guest => widget.accountNickname == null;

  void _create() =>
      widget.controller.createLobby(nickname: _guest ? _nickname.text : null);

  void _join() => widget.controller.joinLobby(
    _code.text,
    nickname: _guest ? _nickname.text : null,
  );

  @override
  Widget build(BuildContext context) {
    final error = widget.controller.entryError;
    final nicknameError = error == EntryError.nicknameInvalid
        ? MultiplayerCopy.entryError(error!)
        : null;
    final codeError = switch (error) {
      EntryError.codeInvalid ||
      EntryError.lobbyNotFound ||
      EntryError.lobbyFull => MultiplayerCopy.entryError(error!),
      _ => null,
    };
    return MultiplayerLayout(
      topBar: MultiplayerTopBar(onClose: widget.onClose),
      children: [
        Semantics(
          header: true,
          child: Text('Hra s kamarády', style: KnzText.titleLg),
        ),
        const SizedBox(height: KnzSpace.s16),
        const KnzSpeechBubble(
          mood: KnzMood.wave,
          text:
              'Založ místnost a pošli kamarádům kód. Nebo zadej kód, '
              'který ti poslali.',
        ),
        const SizedBox(height: KnzSpace.s20),
        if (_guest)
          KnzTextField(
            label: 'Tvoje přezdívka',
            controller: _nickname,
            placeholder: 'Jak ti máme říkat?',
            errorText: nicknameError,
            textInputAction: TextInputAction.done,
            autofillHints: const [AutofillHints.nickname],
          )
        else
          _SignedInAs(nickname: widget.accountNickname!),
        const SizedBox(height: KnzSpace.s16),
        KnzButton(
          label: 'Založit místnost',
          icon: KnzIcons.players,
          onPressed: _create,
        ),
        const SizedBox(height: KnzSpace.s20),
        const _OrDivider(),
        const SizedBox(height: KnzSpace.s16),
        KnzTextField(
          label: 'Kód místnosti',
          controller: _code,
          placeholder: 'Např. K7M2QX',
          errorText: codeError,
          textInputAction: TextInputAction.go,
          onSubmitted: (_) => _join(),
        ),
        const SizedBox(height: KnzSpace.s12),
        KnzButton(
          label: 'Připojit se',
          variant: KnzButtonVariant.secondary,
          onPressed: _join,
        ),
      ],
    );
  }
}

/// "Hraješ jako Eva" for a signed-in player: an info chip row.
class _SignedInAs extends StatelessWidget {
  const _SignedInAs({required this.nickname});

  final String nickname;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: KnzSpace.s12,
        vertical: KnzSpace.s10,
      ),
      decoration: BoxDecoration(
        color: KnzColors.surfaceSubtle,
        borderRadius: BorderRadius.circular(KnzRadius.sm),
      ),
      child: Row(
        children: [
          const KnzIcon(KnzIcons.profile, size: 16, color: KnzColors.iconMuted),
          const SizedBox(width: KnzSpace.s8),
          Expanded(
            child: Text(
              'Hraješ jako $nickname',
              style: KnzText.caption.copyWith(color: KnzColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}

/// The divider "NEBO" (`components.md`).
class _OrDivider extends StatelessWidget {
  const _OrDivider();

  @override
  Widget build(BuildContext context) {
    Widget line() => Expanded(
      child: Container(height: KnzDepth.border, color: KnzColors.border),
    );
    return Row(
      children: [
        line(),
        const SizedBox(width: KnzSpace.s12),
        Text(
          'NEBO',
          style: KnzText.label.copyWith(color: KnzColors.textDisabled),
        ),
        const SizedBox(width: KnzSpace.s12),
        line(),
      ],
    );
  }
}
