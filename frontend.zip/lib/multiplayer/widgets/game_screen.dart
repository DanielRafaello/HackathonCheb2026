import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:pointer_interceptor/pointer_interceptor.dart';

import '../../design_system/design_system.dart';
import '../../round/geo.dart';
import '../../round/guess_map_view.dart';
import '../../round/round_copy.dart';
import '../../round/widgets/hit_view.dart';
import '../../round/widgets/map_overlays.dart';
import '../multiplayer_controller.dart';
import '../multiplayer_copy.dart';
import '../protocol.dart';
import 'multiplayer_layout.dart';

/// A running game for a participant: the place to find, the blind map,
/// the result of each guess, and the wait for the others at the end.
class GameScreen extends StatefulWidget {
  const GameScreen({
    super.key,
    required this.controller,
    required this.mapBuilder,
    required this.onLeave,
  });

  final MultiplayerController controller;
  final GuessMapBuilder mapBuilder;

  /// Asks, then leaves the game.
  final VoidCallback onLeave;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  /// The blind map over the whole screen, where the player guesses.
  bool _mapOpen = false;

  /// The map preview is never smaller than this.
  static const _minPreviewHeight = 160.0;

  MultiplayerController get _controller => widget.controller;

  /// The system back closes the full-screen map, like its back button;
  /// elsewhere in the game it asks before the player leaves.
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        if (_mapOpen) {
          setState(() => _mapOpen = false);
        } else {
          widget.onLeave();
        }
      },
      child: _content(),
    );
  }

  Widget _content() {
    final controller = _controller;
    final game = controller.game!;
    final self = controller.selfGame!;
    final result = controller.shownResult;
    // The answer closes the map; so does the end of the player's places.
    if (result != null || controller.finishedAllPlaces) _mapOpen = false;

    final topBar = MultiplayerTopBar(
      onClose: widget.onLeave,
      closeLabel: 'Odejít ze hry',
      guessed: self.currentIndex,
      placeCount: game.placeCount,
      remaining: controller.remaining,
    );

    if (result != null) {
      return PlaceResultView(
        topBar: topBar,
        result: result,
        placeCount: game.placeCount,
        reconnecting: controller.reconnecting,
        onNext: controller.dismissResult,
      );
    }
    if (controller.finishedAllPlaces) {
      return WaitingView(
        topBar: topBar,
        lobby: controller.lobby!,
        reconnecting: controller.reconnecting,
      );
    }
    final name = self.currentPlaceName ?? '';
    final number = self.currentIndex + 1;
    if (_mapOpen) {
      return _FullScreenMap(
        controller: controller,
        mapBuilder: widget.mapBuilder,
        placeName: name,
        number: number,
        placeCount: game.placeCount,
        onBack: () => setState(() => _mapOpen = false),
      );
    }
    void openMap() {
      if (controller.canGuess) setState(() => _mapOpen = true);
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        centred(topBar),
        if (controller.reconnecting)
          centred(
            const Padding(
              padding: EdgeInsets.fromLTRB(
                KnzSize.screenGutter,
                0,
                KnzSize.screenGutter,
                KnzSpace.s8,
              ),
              child: ReconnectBanner(),
            ),
          ),
        // The map preview takes the room the prompt leaves. On a short
        // screen (a phone on its side, large text) it keeps its minimum
        // height and the prompt and the preview scroll.
        Expanded(
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: centred(
                  Padding(
                    padding: const EdgeInsets.fromLTRB(
                      KnzSize.screenGutter,
                      KnzSpace.s8,
                      KnzSize.screenGutter,
                      0,
                    ),
                    child: PlacePrompt(
                      name: name,
                      number: number,
                      placeCount: game.placeCount,
                    ),
                  ),
                ),
              ),
              // The preview fills the rest of the viewport. Its height is
              // computed here and given to it: the real map is built by a
              // LayoutBuilder, which cannot report an intrinsic height, so
              // nothing may ask the preview for one (SliverFillRemaining
              // with hasScrollBody: false does).
              SliverLayoutBuilder(
                builder: (context, constraints) {
                  const top = KnzSpace.s12;
                  final rest =
                      constraints.viewportMainAxisExtent -
                      constraints.precedingScrollExtent;
                  final height = math.max(_minPreviewHeight + top, rest);
                  return SliverToBoxAdapter(
                    child: SizedBox(
                      height: height,
                      child: centred(
                        Padding(
                          padding: const EdgeInsets.fromLTRB(
                            KnzSize.screenGutter,
                            top,
                            KnzSize.screenGutter,
                            0,
                          ),
                          child: _MapFrame(
                            pin: controller.pin,
                            onOpen: controller.canGuess ? openMap : null,
                            child: widget.mapBuilder(
                              GuessMapView(
                                pin: controller.pin,
                                lastGuess: null,
                                enabled: false,
                                onPin: controller.placePin,
                                interactive: false,
                              ),
                            ),
                          ),
                        ),
                        maxWidth: 560,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
        centred(
          RoundFooter(
            button: KnzButton(
              label: 'Tipnout na mapě',
              size: KnzButtonSize.cta,
              onPressed: controller.canGuess ? openMap : null,
            ),
          ),
        ),
      ],
    );
  }
}

/// The place to find (`components.md`, PlacePrompt **(added)**): Vřídlík
/// asks for the place by its name. In multiplayer the name is all a player
/// sees before the guess; no clues.
class PlacePrompt extends StatelessWidget {
  const PlacePrompt({
    super.key,
    required this.name,
    required this.number,
    required this.placeCount,
  });

  final String name;
  final int number;
  final int placeCount;

  @override
  Widget build(BuildContext context) {
    return KnzSpeechBubble(
      mood: KnzMood.think,
      mascotWidth: 72,
      raised: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            MultiplayerCopy.placeOverline(number, placeCount),
            style: KnzText.label.copyWith(color: KnzColors.accentText),
          ),
          const SizedBox(height: KnzSpace.s4),
          Text('Kde je tohle místo?', style: KnzText.bodySm),
          Semantics(
            header: true,
            liveRegion: true,
            child: Text(name, style: KnzText.titleMd),
          ),
        ],
      ),
    );
  }
}

/// The preview of the blind map in its frame (`components.md`, MapFrame).
/// A tap opens the map over the whole screen.
class _MapFrame extends StatelessWidget {
  const _MapFrame({
    required this.pin,
    required this.onOpen,
    required this.child,
  });

  final GeoPoint? pin;
  final VoidCallback? onOpen;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final pin = this.pin;
    final pinPlace = pin == null ? null : RoundCopy.nearTown(pin);
    final description = [
      'Mapa kraje',
      if (pin != null)
        'tvůj tip ${pinPlace ?? 'je na mapě'}'
      else
        'zatím bez tipu',
    ].join(': ');
    final frame = KnzEdgeBox(
      color: KnzColors.surfaceSubtle,
      edgeColor: KnzColors.borderStrong,
      radius: KnzRadius.xl3,
      frame: KnzDepth.border,
      depth: KnzDepth.lg,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(KnzRadius.xl3 - KnzDepth.border),
        child: Stack(
          fit: StackFit.expand,
          children: [
            child,
            // The preview takes no gestures; on the web the map is an HTML
            // element that would take the pointer.
            PointerInterceptor(
              child: Listener(
                behavior: HitTestBehavior.opaque,
                child: const SizedBox.expand(),
              ),
            ),
            if (pin == null)
              const IgnorePointer(
                child: Center(
                  child: MapInstruction(
                    text: 'Klepni na mapu a polož svůj tip.',
                  ),
                ),
              )
            else
              GuessLabelOverlay(
                text: pinPlace == null ? 'Tvůj tip' : 'Tvůj tip: $pinPlace',
              ),
          ],
        ),
      ),
    );
    final open = onOpen;
    if (open == null) {
      return Semantics(label: description, container: true, child: frame);
    }
    return Semantics(
      container: true,
      child: KnzPressable(
        onPressed: open,
        semanticLabel: description,
        builder: (context, state) => frame,
      ),
    );
  }
}

/// The blind map over the whole screen (`components.md`, MapFrame
/// *full-screen guess map*), where the player places and confirms the one
/// guess on the place.
class _FullScreenMap extends StatelessWidget {
  const _FullScreenMap({
    required this.controller,
    required this.mapBuilder,
    required this.placeName,
    required this.number,
    required this.placeCount,
    required this.onBack,
  });

  final MultiplayerController controller;
  final GuessMapBuilder mapBuilder;
  final String placeName;
  final int number;
  final int placeCount;
  final VoidCallback onBack;

  static const _compactHeight = 680.0;
  static const _maxWidth = 560.0;

  @override
  Widget build(BuildContext context) {
    final pin = controller.pin;
    final pinPlace = pin == null ? null : RoundCopy.nearTown(pin);
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxHeight < _compactHeight;
        return Column(
          children: [
            centred(
              MultiplayerTopBar(
                onClose: onBack,
                closeIcon: KnzIcons.back,
                closeLabel: 'Zpět na místo',
                guessed: number - 1,
                placeCount: placeCount,
                remaining: controller.remaining,
              ),
              maxWidth: _maxWidth,
            ),
            centred(
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  KnzSize.screenGutter,
                  0,
                  KnzSize.screenGutter,
                  KnzSpace.s10,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      MultiplayerCopy.placeOverline(number, placeCount),
                      style: KnzText.label.copyWith(
                        color: KnzColors.accentText,
                      ),
                    ),
                    Text(
                      placeName,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: KnzText.titleSm,
                    ),
                  ],
                ),
              ),
              maxWidth: _maxWidth,
            ),
            if (controller.reconnecting)
              centred(
                const Padding(
                  padding: EdgeInsets.fromLTRB(
                    KnzSize.screenGutter,
                    0,
                    KnzSize.screenGutter,
                    KnzSpace.s8,
                  ),
                  child: ReconnectBanner(),
                ),
                maxWidth: _maxWidth,
              ),
            Expanded(
              child: DecoratedBox(
                position: DecorationPosition.foreground,
                decoration: const BoxDecoration(
                  border: Border.symmetric(
                    horizontal: BorderSide(
                      color: KnzColors.border,
                      width: KnzDepth.border,
                    ),
                  ),
                ),
                child: Semantics(
                  label: [
                    'Mapa kraje',
                    if (pin != null)
                      'tvůj tip ${pinPlace ?? 'je na mapě'}'
                    else
                      'zatím bez tipu',
                  ].join(': '),
                  container: true,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      mapBuilder(
                        GuessMapView(
                          pin: pin,
                          lastGuess: null,
                          enabled: controller.canGuess,
                          onPin: controller.placePin,
                          interactive: true,
                        ),
                      ),
                      if (pin == null)
                        const IgnorePointer(
                          child: Center(
                            child: MapInstruction(
                              text: 'Klepni do mapy a polož špendlík.',
                            ),
                          ),
                        )
                      else
                        GuessLabelOverlay(
                          text: pinPlace == null
                              ? 'Tvůj tip'
                              : 'Tvůj tip: $pinPlace',
                        ),
                    ],
                  ),
                ),
              ),
            ),
            centred(
              RoundFooter(
                hint: compact
                    ? null
                    : 'Na každé místo máš jen jeden tip. Posuň špendlík '
                          'tažením, mapu přiblížíš dvěma prsty.',
                button: KnzButton(
                  label: controller.submitting
                      ? 'Posílám tip…'
                      : 'Potvrdit tip',
                  size: KnzButtonSize.cta,
                  onPressed: controller.canGuess && pin != null
                      ? controller.confirmGuess
                      : null,
                ),
              ),
              maxWidth: _maxWidth,
            ),
          ],
        );
      },
    );
  }
}

/// The result of one guess (`components.md`, PlaceResult **(added)**):
/// how far it was, and the place revealed.
class PlaceResultView extends StatelessWidget {
  const PlaceResultView({
    super.key,
    required this.topBar,
    required this.result,
    required this.placeCount,
    required this.reconnecting,
    required this.onNext,
    this.gameOver = false,
  });

  final Widget topBar;
  final PlaceResult result;
  final int placeCount;
  final bool reconnecting;
  final VoidCallback onNext;

  /// The game has ended; the results come next, not another place.
  final bool gameOver;

  @override
  Widget build(BuildContext context) {
    final meters = result.distanceMeters;
    final last = gameOver || result.index + 1 >= placeCount;
    return MultiplayerLayout(
      topBar: topBar,
      reconnecting: reconnecting,
      footer: [
        KnzButton(
          label: last ? 'Hotovo' : 'Další místo',
          size: KnzButtonSize.cta,
          onPressed: onNext,
        ),
      ],
      children: [
        Text(
          MultiplayerCopy.placeOverline(result.index + 1, placeCount),
          style: KnzText.overline.copyWith(color: KnzColors.textMuted),
        ),
        const SizedBox(height: KnzSpace.s8),
        Semantics(
          liveRegion: true,
          child: KnzSpeechBubble(
            mood: meters < MultiplayerCopy.closeMeters
                ? KnzMood.cheer
                : meters < MultiplayerCopy.nearMeters
                ? KnzMood.happy
                : KnzMood.sad,
            mascotWidth: 72,
            text: MultiplayerCopy.resultLine(meters, last: last),
          ),
        ),
        const SizedBox(height: KnzSpace.s16),
        ResultStat(
          label: 'Od cíle',
          value: MultiplayerCopy.distance(meters),
          sentiment: KnzSentiment.primary,
        ),
        const SizedBox(height: KnzSpace.s14),
        HitPlaceCard(place: result.place.toCard(), addedToMap: false),
      ],
    );
  }
}

/// The player has guessed every place and waits for the others
/// (`components.md`, WaitingRoom **(added)**): how far each participant
/// is.
class WaitingView extends StatelessWidget {
  const WaitingView({
    super.key,
    required this.topBar,
    required this.lobby,
    required this.reconnecting,
  });

  final Widget topBar;
  final LobbyView lobby;
  final bool reconnecting;

  @override
  Widget build(BuildContext context) {
    final game = lobby.game!;
    return MultiplayerLayout(
      topBar: topBar,
      reconnecting: reconnecting,
      children: [
        const KnzSpeechBubble(
          mood: KnzMood.happy,
          text:
              'Máš hotovo! Počkáme na ostatní. Výsledky uvidíš, až '
              'všichni dohrají nebo vyprší čas.',
        ),
        const SizedBox(height: KnzSpace.s20),
        const SectionLabel('POSTUP HRÁČŮ'),
        const SizedBox(height: KnzSpace.s12),
        for (final id in game.participantIds)
          if (lobby.player(id) case final player?) ...[
            KnzProgressRow(
              // Not by the colour alone (DESIGN.md): the own row says so.
              label: id == lobby.selfId
                  ? '${player.nickname} (ty)'
                  : player.nickname,
              count: player.guessedCount,
              total: game.placeCount,
              sentiment: id == lobby.selfId
                  ? KnzSentiment.primary
                  : KnzSentiment.neutral,
            ),
            const SizedBox(height: KnzSpace.s12),
          ],
      ],
    );
  }
}
