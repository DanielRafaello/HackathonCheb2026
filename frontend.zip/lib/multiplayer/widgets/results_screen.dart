import 'package:flutter/material.dart';

import '../../design_system/design_system.dart';
import '../multiplayer_copy.dart';
import '../protocol.dart';
import 'multiplayer_layout.dart';

/// The end of a game: the leaderboard and every place with the player's
/// guess and the closest guess of all.
class ResultsScreen extends StatelessWidget {
  const ResultsScreen({
    super.key,
    required this.lobby,
    required this.game,
    required this.penaltyDistanceMeters,
    required this.reconnecting,
    required this.onReturnToLobby,
    required this.onLeave,
  });

  final LobbyView lobby;

  /// The finished game. While the next game runs without this player the
  /// lobby holds that one, so the controller keeps the finished one; null
  /// when it is not known (the app restarted meanwhile).
  final GameView? game;

  /// What an unguessed place counts as; null when unknown.
  final int? penaltyDistanceMeters;
  final bool reconnecting;
  final VoidCallback onReturnToLobby;
  final VoidCallback onLeave;

  @override
  Widget build(BuildContext context) {
    final game = this.game;
    final leaderboard = game?.leaderboard ?? const <LeaderboardRow>[];
    LeaderboardRow? own;
    for (final row in leaderboard) {
      if (row.playerId == lobby.selfId) own = row;
    }
    final penalty = penaltyDistanceMeters;
    return MultiplayerLayout(
      reconnecting: reconnecting,
      topBar: MultiplayerTopBar(onClose: onLeave, closeLabel: 'Odejít'),
      footer: [
        KnzButton(
          label: 'Zpět do místnosti',
          size: KnzButtonSize.cta,
          onPressed: onReturnToLobby,
        ),
        KnzButton(
          label: 'Odejít',
          variant: KnzButtonVariant.ghost,
          onPressed: onLeave,
        ),
      ],
      children: [
        Text(
          'HRA SKONČILA',
          style: KnzText.overline.copyWith(color: KnzColors.textMuted),
        ),
        Semantics(
          header: true,
          child: Text('Výsledky', style: KnzText.titleLg),
        ),
        const SizedBox(height: KnzSpace.s16),
        if (own != null)
          Semantics(
            liveRegion: true,
            child: KnzSpeechBubble(
              mood: own.guessedCount == 0
                  ? KnzMood.think
                  : own.rank == 1
                  ? KnzMood.cheer
                  : KnzMood.happy,
              mascotWidth: 72,
              // Without a single guess the rank and the average are only
              // penalties, nothing to praise.
              text: own.guessedCount == 0
                  ? 'Čas vypršel. Tentokrát nemáš tipnuté žádné místo.'
                  : own.rank == 1 && leaderboard.length > 1
                  ? 'Jsi první! Tvoje tipy byly v průměru '
                        '${MultiplayerCopy.distance(own.averageDistanceMeters)} '
                        'od cíle.'
                  : 'Dohráno! Tvoje tipy byly v průměru '
                        '${MultiplayerCopy.distance(own.averageDistanceMeters)} '
                        'od cíle.',
            ),
          ),
        if (game == null)
          const KnzSpeechBubble(
            mood: KnzMood.think,
            text:
                'Výsledky minulé hry už tu nemám. Vrať se do místnosti '
                'a zahraj si další hru.',
          )
        else ...[
          const SizedBox(height: KnzSpace.s20),
          const SectionLabel('POŘADÍ'),
          const SizedBox(height: KnzSpace.s8),
          for (final row in leaderboard) ...[
            LeaderboardRowCard(
              row: row,
              placeCount: game.placeCount,
              isSelf: row.playerId == lobby.selfId,
            ),
            const SizedBox(height: KnzSpace.s8),
          ],
          if (penalty != null)
            Text(
              'Pořadí určuje průměrná vzdálenost tipů od cíle. Místo bez '
              'tipu se počítá jako ${MultiplayerCopy.distance(penalty)}.',
              style: KnzText.bodySm.copyWith(color: KnzColors.textMuted),
            ),
          const SizedBox(height: KnzSpace.s20),
          const SectionLabel('MÍSTA VE HŘE'),
          const SizedBox(height: KnzSpace.s8),
          for (final place in game.places ?? const <PlaceReveal>[]) ...[
            _PlaceRow(place: place, game: game, selfId: lobby.selfId),
            const SizedBox(height: KnzSpace.s8),
          ],
        ],
      ],
    );
  }
}

/// One row of the leaderboard (`components.md`, LeaderboardRow
/// **(added)**): the rank, the nickname, the average distance, and the
/// places guessed. The player's own row is tinted.
class LeaderboardRowCard extends StatelessWidget {
  const LeaderboardRowCard({
    super.key,
    required this.row,
    required this.placeCount,
    required this.isSelf,
  });

  final LeaderboardRow row;
  final int placeCount;
  final bool isSelf;

  @override
  Widget build(BuildContext context) {
    final average = MultiplayerCopy.distance(row.averageDistanceMeters);
    final guessed = MultiplayerCopy.guessed(row.guessedCount, placeCount);
    return Semantics(
      label:
          '${row.rank}. místo: ${row.nickname}${isSelf ? ' (ty)' : ''}, '
          'průměr $average, uhodnuto $guessed',
      excludeSemantics: true,
      child: KnzCard(
        sentiment: isSelf ? KnzSentiment.primary : KnzSentiment.neutral,
        variant: isSelf ? KnzCardVariant.tinted : KnzCardVariant.outlined,
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s14,
          vertical: KnzSpace.s10,
        ),
        child: Row(
          children: [
            Container(
              width: KnzSize.touch,
              height: KnzSize.touch,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: row.rank == 1 ? KnzColors.accent : KnzColors.track,
                shape: BoxShape.circle,
              ),
              child: Text('${row.rank}.', style: KnzText.titleSm),
            ),
            const SizedBox(width: KnzSpace.s12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    spacing: KnzSpace.s6,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      Text(row.nickname, style: KnzText.cardTitle),
                      if (isSelf) const KnzPill(label: 'TY'),
                    ],
                  ),
                  Text(
                    guessed,
                    style: KnzText.bodySm.copyWith(color: KnzColors.textMuted),
                  ),
                ],
              ),
            ),
            const SizedBox(width: KnzSpace.s8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  'PRŮMĚR',
                  style: KnzText.badge.copyWith(color: KnzColors.textMuted),
                ),
                Text(
                  average,
                  style: KnzText.titleSm.copyWith(color: KnzColors.primaryEdge),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// One place of the finished game: its name and type, the player's own
/// distance, and the closest guess of all players.
class _PlaceRow extends StatelessWidget {
  const _PlaceRow({
    required this.place,
    required this.game,
    required this.selfId,
  });

  final PlaceReveal place;
  final GameView game;
  final String selfId;

  @override
  Widget build(BuildContext context) {
    final guesses = game.guesses ?? const <String, List<PlayerGuess?>>{};
    final own = _guessOf(guesses[selfId]);
    String? bestId;
    PlayerGuess? best;
    for (final entry in guesses.entries) {
      final guess = _guessOf(entry.value);
      if (guess == null) continue;
      if (best == null || guess.distanceMeters < best.distanceMeters) {
        best = guess;
        bestId = entry.key;
      }
    }
    final bestName = bestId == null
        ? null
        : _nickname(bestId, game.leaderboard ?? const []);
    return KnzCard(
      padding: const EdgeInsets.all(KnzSpace.s12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (place.category.isNotEmpty)
                      KnzPill(label: place.category.toUpperCase()),
                    const SizedBox(height: KnzSpace.s4),
                    Text(
                      '${place.index + 1}. ${place.name}',
                      style: KnzText.cardTitle,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: KnzSpace.s8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    'TVŮJ TIP',
                    style: KnzText.badge.copyWith(color: KnzColors.textMuted),
                  ),
                  Text(
                    own == null
                        ? 'bez tipu'
                        : MultiplayerCopy.distance(own.distanceMeters),
                    style: KnzText.titleSm.copyWith(
                      color: own == null
                          ? KnzColors.textMuted
                          : KnzColors.primaryEdge,
                    ),
                  ),
                ],
              ),
            ],
          ),
          if (best != null && bestName != null) ...[
            const SizedBox(height: KnzSpace.s6),
            Text(
              'Nejblíž: $bestName · ${MultiplayerCopy.distance(best.distanceMeters)}',
              style: KnzText.bodySm.copyWith(color: KnzColors.textSecondary),
            ),
          ],
          if (_attribution case final attribution?) ...[
            const SizedBox(height: KnzSpace.s4),
            Text(
              attribution,
              style: KnzText.micro.copyWith(color: KnzColors.textMuted),
            ),
          ],
        ],
      ),
    );
  }

  /// The data source and its licence, as every place card shows them.
  String? get _attribution {
    final source = place.source;
    final parts = [?source?.label, ?source?.licenseCode];
    return parts.isEmpty ? null : parts.join('\u00A0· ');
  }

  PlayerGuess? _guessOf(List<PlayerGuess?>? guesses) =>
      guesses == null || place.index >= guesses.length
      ? null
      : guesses[place.index];

  static String? _nickname(String id, List<LeaderboardRow> rows) {
    for (final row in rows) {
      if (row.playerId == id) return row.nickname;
    }
    return null;
  }
}
