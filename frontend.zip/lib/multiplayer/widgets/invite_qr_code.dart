import 'package:flutter/widgets.dart';
import 'package:qr/qr.dart';

import '../../design_system/design_system.dart';

/// The invite link as a QR code (`components.md`, LobbyCode **(added)**):
/// a friend next to the host scans it with the phone camera and lands in
/// the lobby.
///
/// Dark modules in the text colour on a white outlined card, with the
/// four-module quiet zone that QR readers need.
class InviteQrCode extends StatelessWidget {
  const InviteQrCode({super.key, required this.link});

  /// The invite link: `https://aether217.zcu.cz/multiplayer/K7M2QX`.
  final String link;

  @override
  Widget build(BuildContext context) {
    final image = QrImage(
      QrCode(
        payload: QrPayload.fromString(link),
        errorCorrectLevel: QrErrorCorrectLevel.medium,
      ),
    );
    return Semantics(
      image: true,
      label: 'QR kód s odkazem do místnosti',
      child: KnzCard(
        variant: KnzCardVariant.outlined,
        padding: EdgeInsets.zero,
        child: SizedBox.square(
          dimension: KnzSize.qrCode,
          child: CustomPaint(painter: _QrPainter(image)),
        ),
      ),
    );
  }
}

class _QrPainter extends CustomPainter {
  _QrPainter(this.image);

  final QrImage image;

  /// Modules of white around the code on each side.
  static const _quietZone = 4;

  @override
  void paint(Canvas canvas, Size size) {
    final count = image.moduleCount;
    final module = size.shortestSide / (count + 2 * _quietZone);
    final paint = Paint()
      ..color = KnzColors.text
      ..isAntiAlias = false;
    for (var y = 0; y < count; y++) {
      for (var x = 0; x < count; x++) {
        if (!image.isDark(y, x)) continue;
        // Overlap by a hair so no seams show between dark modules.
        canvas.drawRect(
          Rect.fromLTWH(
            (x + _quietZone) * module,
            (y + _quietZone) * module,
            module + 0.5,
            module + 0.5,
          ),
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(_QrPainter oldDelegate) => oldDelegate.image != image;
}
