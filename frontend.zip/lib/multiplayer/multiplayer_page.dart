import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../account/session.dart';
import '../config/multiplayer_config.dart';
import '../design_system/design_system.dart';
import '../round/guess_map_view.dart';
import '../round/widgets/map_overlays.dart';
import 'multiplayer_connection.dart';
import 'multiplayer_controller.dart';
import 'multiplayer_copy.dart';
import 'multiplayer_store.dart';
import 'websocket_multiplayer_connection.dart';
import 'widgets/entry_screen.dart';
import 'widgets/game_screen.dart';
import 'widgets/lobby_screen.dart';
import 'widgets/multiplayer_layout.dart';
import 'widgets/results_screen.dart';

/// Copies text; the app uses the clipboard.
typedef CopyText = Future<void> Function(String text);

Future<void> _copyToClipboard(String text) =>
    Clipboard.setData(ClipboardData(text: text));

/// Multiplayer ("Hra s kamarády"): the entry, the lobby, the game, and the
/// results, over the socket server.
class MultiplayerPage extends StatefulWidget {
  const MultiplayerPage({
    super.key,
    required this.config,
    required this.session,
    required this.mapBuilder,
    required this.onClose,
    this.joinCode,
    this.connect,
    this.store,
    this.clock = DateTime.now,
    this.ticker,
    this.copyText = _copyToClipboard,
  });

  final MultiplayerConfig config;

  /// A signed-in player plays under the account's name; a guest types a
  /// nickname.
  final Session session;
  final GuessMapBuilder mapBuilder;

  /// Leaves multiplayer.
  final VoidCallback onClose;

  /// The lobby code from an invite link (`/multiplayer/K7M2QX`).
  final String? joinCode;

  /// Opens a connection; the app connects a WebSocket to [config].
  final MultiplayerConnector? connect;
  final MultiplayerStore? store;
  final DateTime Function() clock;

  /// Ticks the countdown; every second by default.
  final Stream<void> Function()? ticker;
  final CopyText copyText;

  @override
  State<MultiplayerPage> createState() => _MultiplayerPageState();
}

class _MultiplayerPageState extends State<MultiplayerPage> {
  late final MultiplayerController _controller = MultiplayerController(
    connect:
        widget.connect ??
        () => WebSocketMultiplayerConnection.connect(widget.config.url),
    store: widget.store ?? SharedPreferencesMultiplayerStore(),
    token: () => widget.session.token,
    refreshToken: widget.session.refresh,
    clock: widget.clock,
    ticker: widget.ticker ?? _everySecond,
    identity: () => switch (widget.session.account) {
      final account? => 'account:${account.id}',
      null => MultiplayerController.guestIdentity,
    },
  );
  late final StreamSubscription<MultiplayerNotice> _notices;

  /// Back in the foreground, the connection may have died meanwhile.
  late final AppLifecycleListener _lifecycle;

  /// Toasts stay above a footer with two actions (START HRY + ODEJÍT).
  static const _toastAbove = RoundFooter.height + KnzSize.button + KnzSpace.s8;

  static Stream<void> _everySecond() =>
      Stream<void>.periodic(const Duration(seconds: 1));

  @override
  void initState() {
    super.initState();
    _notices = _controller.notices.listen((notice) {
      if (mounted) {
        KnzToast.show(
          context,
          MultiplayerCopy.notice(notice),
          above: _toastAbove,
        );
      }
    });
    _lifecycle = AppLifecycleListener(onResume: _controller.checkConnection);
    _controller.start(joinCode: widget.joinCode);
  }

  @override
  void dispose() {
    _lifecycle.dispose();
    _notices.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _leave() {
    _controller.leave();
    widget.onClose();
  }

  Future<void> _leaveGame() async {
    if (await confirmLeaveGame(context)) _leave();
  }

  Future<void> _copy(String text, String done) async {
    String message;
    try {
      await widget.copyText(text);
      message = done;
    } on Object catch (error) {
      debugPrint('Not copied: $error');
      message = 'Nepodařilo se zkopírovat.';
    }
    if (mounted) KnzToast.show(context, message, above: _toastAbove);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KnzColors.surface,
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: _controller,
          builder: (context, _) => _guardBack(_body()),
        ),
      ),
    );
  }

  /// The system back leaves the lobby like its close button does. In a
  /// running game [GameScreen] handles it: it closes the full-screen map,
  /// or asks before the player leaves.
  Widget _guardBack(Widget child) {
    final phase = _controller.phase;
    final inLobby =
        phase == MultiplayerPhase.lobby || phase == MultiplayerPhase.results;
    if (!inLobby) return child;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        _leave();
      },
      child: child,
    );
  }

  Widget _body() {
    final controller = _controller;
    switch (controller.phase) {
      case MultiplayerPhase.entry:
        return EntryScreen(
          controller: controller,
          accountNickname: widget.session.isSignedIn
              ? widget.session.account?.nickname ?? controller.nickname ?? ''
              : null,
          onClose: widget.onClose,
        );
      case MultiplayerPhase.connecting:
        return MultiplayerMessage(
          onClose: _leave,
          mood: KnzMood.think,
          text: 'Připojuji tě ke hře…',
        );
      case MultiplayerPhase.disconnected:
        final elsewhere = controller.openElsewhere;
        return MultiplayerMessage(
          onClose: _leave,
          mood: elsewhere ? KnzMood.think : KnzMood.sad,
          text: elsewhere
              ? 'Hru máš otevřenou v jiném okně. Hraj tam, nebo ji '
                    'přenes sem.'
              : 'Spojení se hrou se přerušilo. Zkontroluj připojení '
                    'a zkus to znovu.',
          actions: [
            KnzButton(
              label: elsewhere ? 'Hrát tady' : 'Zkusit znovu',
              size: KnzButtonSize.cta,
              onPressed: controller.retry,
            ),
            KnzButton(
              label: 'Odejít',
              variant: KnzButtonVariant.ghost,
              onPressed: _leave,
            ),
          ],
        );
      case MultiplayerPhase.lobby:
        final code = controller.lobby!.code;
        return LobbyScreen(
          controller: controller,
          inviteLink: widget.config.inviteLink(code).toString(),
          onLeave: _leave,
          onCopyCode: () => _copy(code, 'Kód místnosti je ve schránce.'),
          onCopyLink: () => _copy(
            widget.config.inviteLink(code).toString(),
            'Odkaz je ve schránce. Pošli ho kamarádům.',
          ),
        );
      case MultiplayerPhase.playing:
        return GameScreen(
          controller: controller,
          mapBuilder: widget.mapBuilder,
          onLeave: _leaveGame,
        );
      case MultiplayerPhase.results:
        final result = controller.shownResult;
        final game = controller.resultsGame;
        if (result != null && game != null) {
          // The guess that ended the game, before its results.
          return PlaceResultView(
            topBar: MultiplayerTopBar(
              onClose: _leave,
              closeLabel: 'Odejít',
              guessed: game.self?.currentIndex,
              placeCount: game.placeCount,
            ),
            result: result,
            placeCount: game.placeCount,
            reconnecting: controller.reconnecting,
            onNext: controller.dismissResult,
            gameOver: true,
          );
        }
        return ResultsScreen(
          lobby: controller.lobby!,
          game: controller.resultsGame,
          penaltyDistanceMeters: controller.limits?.penaltyDistanceMeters,
          reconnecting: controller.reconnecting,
          onReturnToLobby: controller.returnToLobby,
          onLeave: _leave,
        );
    }
  }
}
