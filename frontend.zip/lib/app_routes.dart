/// The app's locations. On the web they are the URL paths.
abstract final class AppRoutes {
  /// Shown while the session from the previous start is being restored.
  static const loading = '/loading';
  static const signIn = '/sign-in';
  static const register = '/register';

  /// Home (DNES).
  static const home = '/';

  /// The mini games (MINIHRY).
  static const freePlay = '/free-play';

  /// My map (MAPA).
  static const myMap = '/map';

  /// The profile with the badges (PROFIL).
  static const profile = '/profile';

  /// The place card of a guessed or visited place, opened from my map.
  static const placePattern = '/place/:id';
  static String place(int id) => '/place/$id';

  /// The place card over a sample place, without sign-in or backend
  /// (`lib/place/place_demo.dart`). Debug and profile builds only.
  static const placeDemo = '/place/demo';

  static const placeOfTheDay = '/place-of-the-day';

  /// Multiplayer ("Hra s kamarády"): create or join a lobby.
  static const multiplayer = '/multiplayer';

  /// An invite link that joins lobby `code`.
  static const multiplayerLobbyPattern = '/multiplayer/:code';
  static String multiplayerLobby(String code) =>
      '/multiplayer/${Uri.encodeComponent(code)}';
  static const designSystem = '/design-system';

  /// Where to go after sign-in: [from] when it is a location in this app,
  /// otherwise Home. Never another site (`//evil.example`) and never back to
  /// an account page.
  static String after(String? from) {
    if (from == null || !from.startsWith('/') || from.startsWith('//')) {
      return home;
    }
    final path = Uri.tryParse(from)?.path;
    if (path == null || const {loading, signIn, register}.contains(path)) {
      return home;
    }
    return from;
  }
}
