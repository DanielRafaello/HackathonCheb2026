import 'package:flutter/material.dart';
import 'package:flutter_web_plugins/url_strategy.dart';
import 'package:go_router/go_router.dart';

import 'account/account_api.dart';
import 'account/session.dart';
import 'account/token_storage.dart';
import 'api/authorized_client.dart';
import 'app_router.dart';
import 'config/api_config.dart';
import 'config/map_config.dart';
import 'config/multiplayer_config.dart';
import 'multiplayer/multiplayer_store.dart';
import 'multiplayer/tab_storage.dart';
import 'my_map/locations_api.dart';
import 'progress/shared_preferences_place_card_cache.dart';
import 'theme.dart';

void main() {
  // Session.restore() reads secure storage over a platform channel before
  // runApp, which needs the binding.
  WidgetsFlutterBinding.ensureInitialized();
  // Plain paths (/design-system) instead of /#/design-system on the web, so
  // the password reset link and App/Universal Links can open a real path.
  // docker/nginx.conf serves index.html for every path. No-op off the web.
  usePathUrlStrategy();
  final apiConfig = ApiConfig.fromEnvironment();
  final session = Session(
    api: AccountApi(config: apiConfig),
    storage: SecureTokenStorage(),
    tab: tabStorage,
  )..restore();
  final client = AuthorizedClient(config: apiConfig, session: session);
  runApp(
    App(
      router: createRouter(
        session: session,
        mapConfig: MapConfig.fromEnvironment(),
        client: client,
        locationsApi: LocationsApi(client: client),
        placeCardCache: SharedPreferencesPlaceCardCache(),
        multiplayerConfig: MultiplayerConfig.fromEnvironment(),
        multiplayerStore: SharedPreferencesMultiplayerStore(),
      ),
    ),
  );
}

class App extends StatelessWidget {
  const App({super.key, required this.router});

  final GoRouter router;

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Kde na západě',
      theme: AppTheme.light,
      routerConfig: router,
    );
  }
}
