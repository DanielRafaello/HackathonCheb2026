import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../design_system/design_system.dart';

/// The coloured header of the account pages (`components.md`, HeroHeader).
///
/// A flat landscape with Vřídlík: blue for sign-in, gold for registration.
/// The header has bottom corners of 36 px and a 6 px bottom edge.
enum AuthHero {
  /// Primary blue: a night landscape with a castle, the Ohře and Vřídlík
  /// waving (`00 Sign-in`).
  signIn(height: 268, mascotWidth: 120),

  /// Spa gold: sand dunes, a folded map and a pin (added; the design has
  /// no registration screen).
  register(height: 176, mascotWidth: 84);

  const AuthHero({required this.height, required this.mascotWidth});

  /// The height of the face, without the edge and the status bar.
  final double height;
  final double mascotWidth;

  Color get _edge => switch (this) {
    signIn => KnzColors.primaryEdge,
    register => KnzColors.accentEdge,
  };

  /// The sky colour at the top of the header. The browser bar and the
  /// installed app's title bar take it too (`theme-color`).
  Color get sky => switch (this) {
    signIn => KnzColors.primary,
    register => KnzColors.accent,
  };

  CustomPainter get _painter => switch (this) {
    signIn => const _NightLandscapePainter(),
    register => const _DunesPainter(),
  };
}

class AuthHeroHeader extends StatelessWidget {
  const AuthHeroHeader({
    super.key,
    required this.hero,
    this.topInset = 0,
    this.roundTop = false,
    this.leading,
  });

  final AuthHero hero;

  /// Extra height under the status bar, so the colour reaches the top.
  final double topInset;

  /// Rounds the top corners too, when the header does not touch the screen
  /// edge (wide screens).
  final bool roundTop;

  /// A control in the top left corner, such as the Back button.
  final Widget? leading;

  @override
  Widget build(BuildContext context) {
    const bottom = Radius.circular(KnzRadius.hero);
    final top = roundTop ? const Radius.circular(KnzRadius.xl4) : Radius.zero;
    final radius = BorderRadius.vertical(top: top, bottom: bottom);
    return DecoratedBox(
      decoration: BoxDecoration(color: hero._edge, borderRadius: radius),
      child: Padding(
        padding: const EdgeInsets.only(bottom: KnzDepth.xl),
        child: ClipRRect(
          borderRadius: radius,
          child: SizedBox(
            height: topInset + hero.height,
            child: Stack(
              children: [
                Positioned.fill(
                  top: topInset,
                  // The waving mascot repaints every frame; the boundary
                  // keeps the landscape's layer out of those repaints.
                  child: RepaintBoundary(
                    child: CustomPaint(painter: hero._painter),
                  ),
                ),
                // The status bar area continues the sky.
                Positioned(
                  left: 0,
                  right: 0,
                  top: 0,
                  height: topInset,
                  child: ColoredBox(color: hero.sky),
                ),
                if (hero == AuthHero.register)
                  Positioned.fill(
                    top: topInset,
                    child: Align(
                      alignment: const Alignment(0.56, -0.2),
                      child: SvgPicture.asset(
                        'design-system/assets/map/marker-guess.svg',
                        width: 48,
                        excludeFromSemantics: true,
                      ),
                    ),
                  ),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: hero == AuthHero.signIn
                      ? 0.24 * hero.height
                      : 0.12 * hero.height,
                  child: Center(
                    child: KnzMascot(
                      mood: KnzMood.wave,
                      width: hero.mascotWidth,
                    ),
                  ),
                ),
                if (leading != null)
                  Positioned(
                    left: KnzSpace.s8,
                    top: topInset + KnzSpace.s8,
                    child: leading!,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _NightLandscapePainter extends CustomPainter {
  const _NightLandscapePainter();

  /// The landscape recorded at the last size.
  static final _cache = KnzPictureCache();

  @override
  void paint(Canvas canvas, Size size) =>
      _cache.paint(canvas, size, (canvas) => _draw(canvas, size));

  void _draw(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final fill = Paint();
    canvas.drawRect(Offset.zero & size, fill..color = KnzPalette.blue500);

    // Stars.
    fill.color = KnzPalette.blue400;
    for (final (x, y, r) in const [
      (0.10, 0.17, 3.0),
      (0.23, 0.09, 2.5),
      (0.64, 0.11, 3.0),
      (0.92, 0.44, 2.5),
    ]) {
      canvas.drawCircle(Offset(x * w, y * h), r, fill);
    }

    // The sun.
    canvas.drawCircle(
      Offset(w - 58, 0.23 * h),
      20,
      fill..color = KnzPalette.gold500,
    );

    // A castle on the far hill: a keep with a pointed roof and a wall
    // with battlements.
    final castleX = w * 0.70;
    final castle = Path()
      ..moveTo(castleX + 14, 0.62 * h)
      ..lineTo(castleX + 14, 0.39 * h)
      ..lineTo(castleX + 23, 0.30 * h)
      ..lineTo(castleX + 32, 0.39 * h)
      ..lineTo(castleX + 32, 0.62 * h)
      ..close()
      ..addRect(Rect.fromLTRB(castleX - 14, 0.46 * h, castleX + 14, 0.62 * h));
    for (var i = 0; i < 3; i++) {
      castle.addRect(
        Rect.fromLTWH(castleX - 14 + i * 10, 0.43 * h, 6, 0.04 * h),
      );
    }
    canvas.drawPath(castle, fill..color = KnzPalette.blue600);

    // The far hill, rising to the right.
    canvas.drawPath(
      Path()
        ..moveTo(0, 0.68 * h)
        ..cubicTo(0.30 * w, 0.62 * h, 0.55 * w, 0.52 * h, w, 0.50 * h)
        ..lineTo(w, h)
        ..lineTo(0, h)
        ..close(),
      fill..color = KnzPalette.blue450,
    );

    KnzIllustration.tree(
      canvas,
      Offset(0.10 * w, 0.78 * h),
      0.17 * h,
      KnzPalette.blue300,
    );
    KnzIllustration.tree(
      canvas,
      Offset(0.15 * w, 0.78 * h),
      0.12 * h,
      KnzPalette.blue300,
    );
    KnzIllustration.tree(
      canvas,
      Offset(0.90 * w, 0.75 * h),
      0.17 * h,
      KnzPalette.blue300,
    );

    // The valley in front.
    canvas.drawPath(
      Path()
        ..moveTo(0, 0.79 * h)
        ..cubicTo(0.35 * w, 0.73 * h, 0.65 * w, 0.80 * h, w, 0.73 * h)
        ..lineTo(w, h)
        ..lineTo(0, h)
        ..close(),
      fill..color = KnzPalette.blue400,
    );

    KnzIllustration.cloud(canvas, Offset(0.20 * w, 0.63 * h), 0.24 * w);
    KnzIllustration.cloud(canvas, Offset(0.74 * w, 0.55 * h), 0.24 * w);

    // The Ohře.
    canvas.drawPath(
      Path()
        ..moveTo(0, 0.89 * h)
        ..cubicTo(0.30 * w, 0.84 * h, 0.60 * w, 0.90 * h, w, 0.86 * h),
      Paint()
        ..color = KnzPalette.teal300
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(_NightLandscapePainter old) => false;
}

class _DunesPainter extends CustomPainter {
  const _DunesPainter();

  /// The dunes recorded at the last size.
  static final _cache = KnzPictureCache();

  @override
  void paint(Canvas canvas, Size size) =>
      _cache.paint(canvas, size, (canvas) => _draw(canvas, size));

  void _draw(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final fill = Paint();
    canvas.drawRect(Offset.zero & size, fill..color = KnzPalette.gold500);

    fill.color = KnzPalette.gold200;
    canvas
      ..drawCircle(Offset(0.12 * w, 0.22 * h), 3, fill)
      ..drawCircle(Offset(0.87 * w, 0.18 * h), 3, fill);

    // Two dunes, lighter towards the front.
    canvas.drawPath(
      Path()
        ..moveTo(0, 0.68 * h)
        ..cubicTo(0.30 * w, 0.58 * h, 0.60 * w, 0.66 * h, w, 0.62 * h)
        ..lineTo(w, h)
        ..lineTo(0, h)
        ..close(),
      fill..color = Color.lerp(KnzPalette.gold500, KnzPalette.ink0, 0.3)!,
    );
    canvas.drawPath(
      Path()
        ..moveTo(0, 0.86 * h)
        ..cubicTo(0.35 * w, 0.80 * h, 0.65 * w, 0.82 * h, w, 0.80 * h)
        ..lineTo(w, h)
        ..lineTo(0, h)
        ..close(),
      fill..color = Color.lerp(KnzPalette.gold500, KnzPalette.ink0, 0.55)!,
    );

    _foldedMap(canvas, Rect.fromLTWH(0.09 * w, 0.30 * h, 0.19 * w, 0.36 * h));
  }

  /// A folded paper map with a dashed route ending in a blue dot.
  void _foldedMap(Canvas canvas, Rect r) {
    final panel = r.width / 3;
    final rise = r.height * 0.06;
    final fill = Paint();
    for (var i = 0; i < 3; i++) {
      final left = r.left + i * panel;
      final up = i.isOdd ? rise : 0.0;
      final down = i.isOdd ? 0.0 : rise;
      canvas.drawPath(
        Path()
          ..moveTo(left, r.top + up)
          ..lineTo(left + panel, r.top + down)
          ..lineTo(left + panel, r.bottom + down)
          ..lineTo(left, r.bottom + up)
          ..close(),
        fill..color = i.isOdd ? KnzPalette.ink75 : KnzPalette.ink0,
      );
    }

    final route = Path()
      ..moveTo(r.left + r.width * 0.08, r.top + r.height * 0.62)
      ..cubicTo(
        r.left + r.width * 0.40,
        r.top + r.height * 0.75,
        r.left + r.width * 0.55,
        r.top + r.height * 0.30,
        r.left + r.width * 0.88,
        r.top + r.height * 0.40,
      );
    final dash = Paint()
      ..color = KnzPalette.red500
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round;
    // All dashes in one path, drawn with one call.
    final dashes = Path();
    for (final metric in route.computeMetrics()) {
      for (var d = 0.0; d < metric.length - 6; d += 9) {
        dashes.addPath(metric.extractPath(d, d + 5), Offset.zero);
      }
    }
    canvas.drawPath(dashes, dash);
    canvas.drawCircle(
      Offset(r.left + r.width * 0.88, r.top + r.height * 0.40),
      4.5,
      fill..color = KnzPalette.blue500,
    );
  }

  @override
  bool shouldRepaint(_DunesPainter old) => false;
}
