import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../app_routes.dart';
import '../design_system/design_system.dart';
import 'account_api.dart';
import 'auth_hero.dart';
import 'auth_layout.dart';
import 'session.dart';

/// Sign-in with e-mail and password. Once signed in, the router moves on
/// to [from]. The player can also go on without an account.
class SignInPage extends StatefulWidget {
  const SignInPage({super.key, required this.session, this.from});

  final Session session;

  /// The location to continue to after sign-in.
  final String? from;

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  AccountApiException? _error;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    setState(() => _error = null);
    if (!_formKey.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await widget.session.signIn(email: _email.text, password: _password.text);
    } on AccountApiException catch (e) {
      if (mounted) setState(() => _error = e);
    } on Object catch (e) {
      // Never leave the player at a form that silently did nothing.
      debugPrint('$e');
      if (mounted) {
        setState(
          () => _error = const AccountApiException(AccountErrorKind.server),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _openRegistration() {
    final from = widget.from;
    context.pushReplacement(
      from == null
          ? AppRoutes.register
          : Uri(
              path: AppRoutes.register,
              queryParameters: {'from': from},
            ).toString(),
    );
  }

  /// Playing without an account is always possible.
  void _playAsGuest() {
    widget.session.continueAsGuest();
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(AppRoutes.after(widget.from));
    }
  }

  @override
  Widget build(BuildContext context) {
    final error = _error;
    return AuthLayout(
      hero: AuthHero.signIn,
      title: const Text.rich(
        TextSpan(
          text: 'Kde na ',
          children: [
            TextSpan(
              text: 'západě',
              style: TextStyle(color: KnzColors.primary),
            ),
          ],
        ),
      ),
      subtitle: 'Přihlas se a tvoje mapa kraje zůstane s tebou.',
      footer: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          AuthSwitchLink(
            question: 'Nemáš účet?',
            link: 'Zaregistruj se',
            onPressed: _busy ? null : _openRegistration,
          ),
          const SizedBox(height: KnzSpace.s8),
          KnzButton(
            label: 'Zkusit bez účtu',
            variant: KnzButtonVariant.ghost,
            sentiment: KnzSentiment.explore,
            size: KnzButtonSize.small,
            onPressed: _busy ? null : _playAsGuest,
          ),
        ],
      ),
      child: AutofillGroup(
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (error != null)
                AuthErrorBanner(
                  message: AccountMessages.form(error, signIn: true),
                ),
              KnzTextField(
                label: 'E-mail',
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                autofillHints: const [AutofillHints.email],
                textInputAction: TextInputAction.next,
                validator: AccountMessages.validateEmail,
                errorText: AccountMessages.field(error, 'email'),
              ),
              const SizedBox(height: KnzSpace.s16),
              KnzTextField(
                label: 'Heslo',
                controller: _password,
                password: true,
                autofillHints: const [AutofillHints.password],
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => _submit(),
                validator: (value) =>
                    (value ?? '').isEmpty ? 'Zadej heslo.' : null,
              ),
              const SizedBox(height: KnzSpace.s24),
              KnzButton(
                label: _busy ? 'Přihlašuji…' : 'Přihlásit se',
                size: KnzButtonSize.cta,
                onPressed: _busy ? null : _submit,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
