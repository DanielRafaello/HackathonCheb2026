import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../design_system/design_system.dart';
import 'account_api.dart';
import 'auth_hero.dart';

/// The frame of the sign-in and registration pages (`00 Sign-in`).
///
/// A coloured header with Vřídlík, a centred title and subtitle, the form,
/// and a footer with links at the bottom of the screen. On a wide screen
/// the page is a centred phone-width column.
class AuthLayout extends StatelessWidget {
  const AuthLayout({
    super.key,
    required this.hero,
    required this.title,
    required this.subtitle,
    required this.child,
    required this.footer,
    this.onBack,
  });

  final AuthHero hero;
  final Widget title;
  final String subtitle;
  final Widget child;
  final Widget footer;

  /// Shows a Back button in the header that calls it.
  final VoidCallback? onBack;

  static const _maxWidth = 480.0;

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.paddingOf(context).top;
    // The keyboard shrinks the body (and so the scroll viewport, which
    // lets a focused field scroll above the keyboard), but the page keeps
    // the full screen height and paints on behind the keyboard. Otherwise
    // the footer jumps and a bare white block shows behind the keyboard
    // while it slides, most visibly in Safari on iOS, which reports the
    // keyboard only once it has finished moving.
    final pageHeight = MediaQuery.sizeOf(context).height;
    return _BrowserThemeColor(
      color: hero.sky,
      child: Scaffold(
        backgroundColor: KnzColors.surface,
        body: LayoutBuilder(
          builder: (context, constraints) {
            final wide = constraints.maxWidth > _maxWidth;
            return CustomScrollView(
              clipBehavior: Clip.none,
              slivers: [
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minHeight: pageHeight),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: _maxWidth),
                        child: Padding(
                          padding: EdgeInsets.only(
                            top: wide ? topInset + KnzSpace.s24 : 0,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              AuthHeroHeader(
                                hero: hero,
                                topInset: wide ? 0 : topInset,
                                roundTop: wide,
                                leading: onBack == null
                                    ? null
                                    : KnzIconButton(
                                        icon: KnzIcons.back,
                                        semanticLabel: 'Zpět',
                                        color: KnzColors.text,
                                        onPressed: onBack,
                                      ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(KnzSpace.s24),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.stretch,
                                  children: [
                                    Semantics(
                                      header: true,
                                      child: DefaultTextStyle.merge(
                                        textAlign: TextAlign.center,
                                        style: KnzText.display,
                                        child: title,
                                      ),
                                    ),
                                    const SizedBox(height: KnzSpace.s6),
                                    Text(
                                      subtitle,
                                      textAlign: TextAlign.center,
                                      style: KnzText.weight(KnzText.bodyLg, 700)
                                          .copyWith(
                                            color: KnzColors.textSecondary,
                                          ),
                                    ),
                                    const SizedBox(height: KnzSpace.s24),
                                    child,
                                  ],
                                ),
                              ),
                              const Spacer(),
                              Padding(
                                padding: EdgeInsets.fromLTRB(
                                  KnzSpace.s24,
                                  0,
                                  KnzSpace.s24,
                                  KnzSpace.s16 +
                                      MediaQuery.paddingOf(context).bottom,
                                ),
                                child: footer,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

/// Colours the browser bar and the installed app's title bar (the
/// `theme-color` meta tag on the web, the task switcher on Android) while
/// the page is open. `web/manifest.json` holds the colour for the rest of
/// the app, [KnzColors.primary].
class _BrowserThemeColor extends StatefulWidget {
  const _BrowserThemeColor({required this.color, required this.child});

  final Color color;
  final Widget child;

  @override
  State<_BrowserThemeColor> createState() => _BrowserThemeColorState();
}

class _BrowserThemeColorState extends State<_BrowserThemeColor> {
  /// The page whose colour is shown. When sign-in replaces registration,
  /// the new page sets its colour before the old one is disposed, so only
  /// the current owner may restore the default.
  static _BrowserThemeColorState? _owner;

  static void _apply(Color color) {
    SystemChrome.setApplicationSwitcherDescription(
      ApplicationSwitcherDescription(
        label: 'Kde na západě',
        primaryColor: color.toARGB32(),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _owner = this;
    _apply(widget.color);
  }

  @override
  void didUpdateWidget(_BrowserThemeColor oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (_owner == this && oldWidget.color != widget.color) {
      _apply(widget.color);
    }
  }

  @override
  void dispose() {
    if (_owner == this) {
      _owner = null;
      _apply(KnzColors.primary);
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

/// "Nemáš účet? Zaregistruj se": a question with a link (`copy.md`).
class AuthSwitchLink extends StatelessWidget {
  const AuthSwitchLink({
    super.key,
    required this.question,
    required this.link,
    required this.onPressed,
  });

  final String question;
  final String link;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        Text(
          '$question ',
          style: KnzText.bodyLg.copyWith(color: KnzColors.textMuted),
        ),
        KnzPressable(
          onPressed: onPressed,
          isLink: true,
          semanticLabel: link,
          builder: (context, state) => ConstrainedBox(
            constraints: const BoxConstraints(minHeight: KnzSize.touch),
            child: Center(
              widthFactor: 1,
              child: Text(
                link,
                style: KnzText.weight(KnzText.bodyLg, 900).copyWith(
                  color: state.hovered || state.pressed
                      ? KnzColors.textLinkHover
                      : KnzColors.textLink,
                  decoration: state.focused ? TextDecoration.underline : null,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// A form-wide error, such as a wrong password or no connection.
class AuthErrorBanner extends StatelessWidget {
  const AuthErrorBanner({super.key, required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      liveRegion: true,
      child: Container(
        margin: const EdgeInsets.only(bottom: KnzSpace.s16),
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s14,
          vertical: KnzSpace.s12,
        ),
        decoration: BoxDecoration(
          color: KnzColors.dangerTint,
          borderRadius: BorderRadius.circular(KnzRadius.md),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const KnzIcon(KnzIcons.info, size: 20, color: KnzColors.dangerEdge),
            const SizedBox(width: KnzSpace.s10),
            Expanded(
              child: Text(
                message,
                style: KnzText.bodySm.copyWith(color: KnzColors.dangerEdge),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Czech texts for the errors of the account endpoints.
abstract final class AccountMessages {
  static String form(AccountApiException error, {required bool signIn}) =>
      switch (error.kind) {
        AccountErrorKind.unauthorized =>
          signIn
              ? 'Nesprávný e-mail nebo heslo.'
              : 'Přihlášení vypršelo. Přihlas se prosím znovu.',
        AccountErrorKind.invalid => 'Zkontroluj prosím vyplněné údaje.',
        AccountErrorKind.tooManyRequests =>
          'Příliš mnoho pokusů. Zkus to prosím za chvíli.',
        AccountErrorKind.network =>
          'Nepodařilo se spojit se serverem. Zkontroluj připojení k internetu.',
        AccountErrorKind.server =>
          'Na serveru se něco pokazilo. Zkus to prosím znovu.',
      };

  /// The message for one field, or null when the backend did not reject it.
  static String? field(AccountApiException? error, String field) {
    final messages = error?.fieldErrors[field];
    if (messages == null || messages.isEmpty) return null;
    return switch (field) {
      'email' when messages.any((m) => m.contains('email_taken')) =>
        'Tenhle e-mail už má účet. Zkus se přihlásit.',
      'email' => 'Zadej platný e-mail.',
      'password' when messages.any((m) => m.contains('confirmation')) =>
        'Hesla se neshodují.',
      'password' => 'Heslo musí mít aspoň 8 znaků.',
      'name' => 'Přezdívka musí mít 2 až 100 znaků.',
      _ => 'Zkontroluj tenhle údaj.',
    };
  }

  static String? validateEmail(String? value) {
    final email = value?.trim() ?? '';
    if (email.isEmpty) return 'Zadej e-mail.';
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email)) {
      return 'Zadej platný e-mail.';
    }
    return null;
  }
}
