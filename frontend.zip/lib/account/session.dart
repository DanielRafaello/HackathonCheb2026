import 'package:flutter/foundation.dart';

import '../multiplayer/tab_storage.dart';
import 'account_api.dart';
import 'token_storage.dart';

/// Who is playing: a guest, or a signed-in account.
///
/// The backend issues a short-lived JWT and a refresh token on every app
/// platform; the session keeps both in [TokenStorage] and replaces them
/// whenever the backend issues fresh ones.
class Session extends ChangeNotifier {
  Session({required this._api, required this._storage, this._tab});

  final AccountApi _api;
  final TokenStorage _storage;

  /// On the web, the browser tab's storage ([tabStorage]): it keeps the
  /// guest choice over a reload of the page, so a guest in a timed
  /// multiplayer game goes straight back to it. A new tab starts without it.
  final TabStorage? _tab;

  static const guestKey = 'knz.session.v1.guest';

  StoredTokens? _tokens;
  Account? _account;
  bool _restored = false;
  bool _playsAsGuest = false;

  /// The signed-in account, or null for a guest.
  Account? get account => _account;
  bool get isSignedIn => _account != null;

  /// The player chose to play without an account ("Zkusit bez účtu").
  bool get isGuest => _playsAsGuest && !isSignedIn;

  /// Whether the player may enter the game: signed in, or playing as a
  /// guest. The router sends everyone else to sign-in.
  bool get hasEntered => isSignedIn || _playsAsGuest;

  /// Enters the game without an account. Playing without an account is
  /// always possible (PRODUCT_SPECIFICATION.md, accounts). The choice lasts
  /// until sign-out or the next app start; on the web a reload of the page
  /// keeps it, a new tab does not.
  void continueAsGuest() {
    if (_playsAsGuest) return;
    _playsAsGuest = true;
    _tab?.write(guestKey, '1');
    notifyListeners();
  }

  /// Whether [restore] has finished.
  bool get isRestored => _restored;

  /// The current JWT for `Authorization: Bearer <JWT>`, or null for a guest.
  String? get token => _tokens?.token;

  /// Resumes the session from the previous app start, if there is one.
  Future<void> restore() async {
    if (_tab?.read(guestKey) == '1') _playsAsGuest = true;
    final stored = await _storage.read();
    if (stored != null) {
      _tokens = stored;
      try {
        _account = await _api.me(stored.token);
      } on AccountApiException catch (e) {
        // The JWT is short-lived, so an expired one is the usual case. When
        // offline, keep the tokens and try again at the next start.
        if (e.kind == AccountErrorKind.unauthorized) await refresh();
      }
    }
    _restored = true;
    notifyListeners();
  }

  Future<bool>? _refreshing;

  /// Exchanges the refresh token for a fresh JWT. A rejected refresh token
  /// signs the player out. Returns whether the session is still valid.
  ///
  /// Each refresh token works once, so several requests that fail together
  /// share one refresh (FRONTEND_API_GUIDE, "Refresh an expired access
  /// token").
  Future<bool> refresh() => _refreshing ??= _refresh().whenComplete(() {
    _refreshing = null;
  });

  Future<bool> _refresh() async {
    final tokens = _tokens;
    if (tokens == null) return false;
    try {
      final result = await _api.refresh(tokens.refreshToken);
      // The player signed out, or in again, while the refresh ran: this
      // answer belongs to a session that is gone.
      if (!identical(_tokens, tokens)) return _tokens != null;
      await _start(result);
      return true;
    } on AccountApiException catch (e) {
      if (!identical(_tokens, tokens)) return _tokens != null;
      if (e.kind == AccountErrorKind.unauthorized) await _end();
      return false;
    }
  }

  /// Throws [AccountApiException] when the backend refuses.
  Future<void> signIn({required String email, required String password}) async {
    await _start(await _api.login(email: email.trim(), password: password));
  }

  /// Throws [AccountApiException] when the backend refuses.
  Future<void> register({
    required String nickname,
    required String email,
    required String password,
  }) async {
    await _start(
      await _api.register(
        nickname: nickname.trim(),
        email: email.trim(),
        password: password,
      ),
    );
  }

  /// Signs out on this device at once. The backend then revokes the
  /// refresh token; the player does not wait for it, and when it cannot be
  /// reached, the token simply expires.
  Future<void> signOut() async {
    final tokens = _tokens;
    await _end();
    if (tokens != null) {
      try {
        await _api.logout(tokens.refreshToken);
      } on AccountApiException catch (e) {
        debugPrint('Sign-out not confirmed by the backend: $e');
      }
    }
  }

  /// Takes the new tokens and the account, and tells the app at once; the
  /// tokens are stored after. Secure storage on the web encrypts with
  /// WebCrypto, which must not hold up leaving the sign-in page.
  Future<void> _start(AuthResult result) async {
    final tokens = StoredTokens(
      token: result.token,
      refreshToken: result.refreshToken,
    );
    _tokens = tokens;
    _account = result.account;
    notifyListeners();
    await _storage.write(tokens);
  }

  Future<void> _end() async {
    _tokens = null;
    _account = null;
    _playsAsGuest = false;
    _tab?.write(guestKey, null);
    notifyListeners();
    await _storage.clear();
  }
}
