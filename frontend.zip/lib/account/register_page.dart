import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../app_routes.dart';
import '../design_system/design_system.dart';
import 'account_api.dart';
import 'auth_hero.dart';
import 'auth_layout.dart';
import 'session.dart';

/// Registration with nickname, e-mail, and password. Once the account
/// exists, the player is signed in and the router moves on to [from].
class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key, required this.session, this.from});

  /// The product rule for passwords (PRODUCT_SPECIFICATION.md, accounts).
  static const minPasswordLength = 8;

  final Session session;

  /// The location to continue to after registration.
  final String? from;

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final _nickname = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  AccountApiException? _error;

  @override
  void dispose() {
    _nickname.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    setState(() => _error = null);
    if (!_formKey.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await widget.session.register(
        nickname: _nickname.text.trim(),
        email: _email.text,
        password: _password.text,
      );
    } on AccountApiException catch (e) {
      if (mounted) setState(() => _error = e);
    } on Object catch (e) {
      // Never leave the player at a form that silently did nothing.
      debugPrint('$e');
      if (mounted) {
        setState(
          () => _error = const AccountApiException(AccountErrorKind.server),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _openSignIn() {
    context.pushReplacement(_withFrom(AppRoutes.signIn));
  }

  String _withFrom(String path) {
    final from = widget.from;
    return from == null
        ? path
        : Uri(path: path, queryParameters: {'from': from}).toString();
  }

  void _back() {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(_withFrom(AppRoutes.signIn));
    }
  }

  @override
  Widget build(BuildContext context) {
    final error = _error;
    // Field errors are shown at their fields; the banner covers the rest.
    final showBanner = error != null && error.fieldErrors.isEmpty;
    return AuthLayout(
      hero: AuthHero.register,
      onBack: _back,
      title: const Text('Vytvoř si účet'),
      subtitle: 'Uhodnutá místa se ti uloží na osobní mapu.',
      footer: AuthSwitchLink(
        question: 'Už máš účet?',
        link: 'Přihlas se',
        onPressed: _busy ? null : _openSignIn,
      ),
      child: AutofillGroup(
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (showBanner)
                AuthErrorBanner(
                  message: AccountMessages.form(error, signIn: false),
                ),
              KnzTextField(
                label: 'Přezdívka',
                controller: _nickname,
                autofillHints: const [AutofillHints.nickname],
                textInputAction: TextInputAction.next,
                validator: (value) {
                  final length = value?.trim().length ?? 0;
                  if (length == 0) return 'Zadej přezdívku.';
                  if (length < 2 || length > 100) {
                    return 'Přezdívka musí mít 2 až 100 znaků.';
                  }
                  return null;
                },
                errorText: AccountMessages.field(error, 'name'),
              ),
              const SizedBox(height: KnzSpace.s16),
              KnzTextField(
                label: 'E-mail',
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                autofillHints: const [AutofillHints.email],
                textInputAction: TextInputAction.next,
                validator: AccountMessages.validateEmail,
                errorText: AccountMessages.field(error, 'email'),
              ),
              const SizedBox(height: KnzSpace.s16),
              KnzTextField(
                label: 'Heslo',
                controller: _password,
                password: true,
                autofillHints: const [AutofillHints.newPassword],
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => _submit(),
                errorText: AccountMessages.field(error, 'password'),
                validator: (value) =>
                    (value ?? '').length < RegisterPage.minPasswordLength
                    ? 'Heslo musí mít aspoň '
                          '${RegisterPage.minPasswordLength} znaků.'
                    : null,
              ),
              ListenableBuilder(
                listenable: _password,
                builder: (context, _) =>
                    PasswordStrengthMeter(password: _password.text),
              ),
              const SizedBox(height: KnzSpace.s24),
              KnzButton(
                label: _busy ? 'Vytvářím účet…' : 'Vytvořit účet',
                size: KnzButtonSize.cta,
                onPressed: _busy ? null : _submit,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// How strong a new password looks. Only a hint: the backend's rule is the
/// minimum length.
enum PasswordStrength {
  short('Krátké heslo', 1),
  good('Dobré heslo', 2),
  strong('Silné heslo', 3);

  const PasswordStrength(this.label, this.segments);

  final String label;
  final int segments;

  static PasswordStrength of(String password) {
    if (password.length < RegisterPage.minPasswordLength) return short;
    final kinds = [
      RegExp(r'[a-zá-ž]'),
      RegExp(r'[A-ZÁ-Ž]'),
      RegExp(r'\d'),
      RegExp(r'[^\p{L}\d]', unicode: true),
    ].where((kind) => kind.hasMatch(password)).length;
    return password.length >= 12 && kinds >= 3 ? strong : good;
  }
}

/// Three segments and a label under the password field (added; the design
/// has no registration screen). Hidden while the field is empty.
class PasswordStrengthMeter extends StatelessWidget {
  const PasswordStrengthMeter({super.key, required this.password});

  final String password;

  static const _segmentHeight = 8.0;

  @override
  Widget build(BuildContext context) {
    if (password.isEmpty) return const SizedBox.shrink();
    final strength = PasswordStrength.of(password);
    final (fill, text) = strength == PasswordStrength.short
        ? (KnzColors.danger, KnzColors.dangerEdge)
        : (KnzColors.success, KnzColors.successText);
    return Padding(
      padding: const EdgeInsets.only(top: KnzSpace.s10),
      child: Semantics(
        label: strength.label,
        excludeSemantics: true,
        child: Row(
          children: [
            for (var i = 0; i < 3; i++) ...[
              Expanded(
                child: Container(
                  height: _segmentHeight,
                  decoration: BoxDecoration(
                    color: i < strength.segments ? fill : KnzColors.track,
                    borderRadius: BorderRadius.circular(KnzRadius.pill),
                  ),
                ),
              ),
              const SizedBox(width: KnzSpace.s6),
            ],
            const SizedBox(width: KnzSpace.s4),
            Text(strength.label, style: KnzText.caption.copyWith(color: text)),
          ],
        ),
      ),
    );
  }
}
