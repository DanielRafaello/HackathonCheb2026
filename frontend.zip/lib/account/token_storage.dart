import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// The session tokens kept between app starts.
class StoredTokens {
  const StoredTokens({required this.token, required this.refreshToken});

  final String token;
  final String refreshToken;
}

/// Keeps the session tokens.
///
/// Implementations never throw: when the storage fails (for example in a
/// private browser window), the session simply lasts until the app closes.
abstract interface class TokenStorage {
  Future<StoredTokens?> read();
  Future<void> write(StoredTokens tokens);
  Future<void> clear();
}

/// Secure storage: Keychain on iOS, Keystore on Android, and encrypted
/// local storage on the web.
class SecureTokenStorage implements TokenStorage {
  SecureTokenStorage([FlutterSecureStorage? storage])
    : _storage = storage ?? const FlutterSecureStorage();

  static const _tokenKey = 'session.token';
  static const _refreshTokenKey = 'session.refreshToken';

  final FlutterSecureStorage _storage;

  @override
  Future<StoredTokens?> read() async {
    try {
      final token = await _storage.read(key: _tokenKey);
      final refreshToken = await _storage.read(key: _refreshTokenKey);
      if (token == null || refreshToken == null) return null;
      return StoredTokens(token: token, refreshToken: refreshToken);
    } on Object catch (error) {
      debugPrint('Session storage unavailable: $error');
      return null;
    }
  }

  @override
  Future<void> write(StoredTokens tokens) async {
    try {
      await _storage.write(key: _tokenKey, value: tokens.token);
      await _storage.write(key: _refreshTokenKey, value: tokens.refreshToken);
    } on Object catch (error) {
      debugPrint('Session storage unavailable: $error');
    }
  }

  @override
  Future<void> clear() async {
    try {
      await _storage.delete(key: _tokenKey);
      await _storage.delete(key: _refreshTokenKey);
    } on Object catch (error) {
      debugPrint('Session storage unavailable: $error');
    }
  }
}

/// Keeps the tokens in memory only. For tests.
class MemoryTokenStorage implements TokenStorage {
  StoredTokens? tokens;

  @override
  Future<StoredTokens?> read() async => tokens;

  @override
  Future<void> write(StoredTokens tokens) async => this.tokens = tokens;

  @override
  Future<void> clear() async => tokens = null;
}
