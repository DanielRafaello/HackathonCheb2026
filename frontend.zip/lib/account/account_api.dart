import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/api_config.dart';

/// A signed-in player's account.
class Account {
  const Account({
    required this.id,
    required this.email,
    required this.nickname,
  });

  factory Account.fromJson(Map<String, dynamic> json) => Account(
    id: (json['id'] as num).toInt(),
    email: json['email'] as String,
    nickname: json['name'] as String,
  );

  final int id;
  final String email;
  final String nickname;
}

/// The tokens and the account that registration, sign-in, and refresh return.
class AuthResult {
  const AuthResult({
    required this.token,
    required this.refreshToken,
    required this.account,
  });

  factory AuthResult.fromJson(Map<String, dynamic> json) => AuthResult(
    token: json['token'] as String,
    refreshToken: json['refresh_token'] as String,
    account: Account.fromJson(json['user'] as Map<String, dynamic>),
  );

  /// The short-lived JWT, sent as `Authorization: Bearer <JWT>`.
  final String token;

  /// The long-lived token that buys a new JWT. Each one works once.
  final String refreshToken;

  final Account account;
}

enum AccountErrorKind {
  /// Wrong e-mail or password, or a rejected token.
  unauthorized,

  /// The backend rejected some fields, see [AccountApiException.fieldErrors].
  invalid,
  tooManyRequests,
  network,
  server,
}

class AccountApiException implements Exception {
  const AccountApiException(this.kind, {this.fieldErrors = const {}});

  final AccountErrorKind kind;

  /// Backend validation messages by field name (`email`, `password`, `name`).
  final Map<String, List<String>> fieldErrors;

  @override
  String toString() => 'AccountApiException($kind, $fieldErrors)';
}

/// The account endpoints of the Game API.
///
/// Every call ends within [timeout]; a lost request counts as no
/// connection. Any answer that is not what the endpoint promises throws
/// [AccountApiException], never anything else, so the forms can always say
/// what went wrong.
class AccountApi {
  AccountApi({
    required this.config,
    http.Client? client,
    this.timeout = const Duration(seconds: 15),
  }) : _client = client ?? http.Client();

  final ApiConfig config;
  final http.Client _client;

  /// How long one request may take, like `AuthorizedClient.timeout`.
  final Duration timeout;

  Future<AuthResult> register({
    required String nickname,
    required String email,
    required String password,
  }) async => _parse(
    AuthResult.fromJson,
    await _post('auth/register', {
      'name': nickname,
      'email': email,
      'password': password,
      // The backend's `confirmed` rule; the form has already checked it.
      'password_confirm': password,
    }),
  );

  Future<AuthResult> login({
    required String email,
    required String password,
  }) async => _parse(
    AuthResult.fromJson,
    await _post('auth/login', {'email': email, 'password': password}),
  );

  Future<AuthResult> refresh(String refreshToken) async => _parse(
    AuthResult.fromJson,
    await _post('auth/refresh', {'refreshToken': refreshToken}),
  );

  Future<void> logout(String refreshToken) async {
    await _post('auth/logout', {'refreshToken': refreshToken});
  }

  Future<Account> me(String token) async {
    final json = await _send(
      () => _client.get(
        config.resolve('me'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer $token',
        },
      ),
    );
    return _parse(
      (json) => Account.fromJson(json['user'] as Map<String, dynamic>),
      json,
    );
  }

  /// [read] over a success body; a body without the promised fields, for
  /// example a page of a proxy, is a server error.
  static T _parse<T>(
    T Function(Map<String, dynamic>) read,
    Map<String, dynamic> json,
  ) {
    try {
      return read(json);
    } on Object {
      throw const AccountApiException(AccountErrorKind.server);
    }
  }

  Future<Map<String, dynamic>> _post(String path, Map<String, Object> body) =>
      _send(
        () => _client.post(
          config.resolve(path),
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          body: jsonEncode(body),
        ),
      );

  Future<Map<String, dynamic>> _send(
    Future<http.Response> Function() request,
  ) async {
    final http.Response response;
    try {
      response = await request().timeout(timeout);
    } on Exception {
      // No connection, or no answer in time (TimeoutException).
      throw const AccountApiException(AccountErrorKind.network);
    }

    Map<String, dynamic> json;
    try {
      json =
          jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    } on Object {
      json = const {};
    }

    final status = response.statusCode;
    if (status >= 200 && status < 300) return json;
    throw AccountApiException(switch (status) {
      401 || 403 => AccountErrorKind.unauthorized,
      400 || 422 => AccountErrorKind.invalid,
      429 => AccountErrorKind.tooManyRequests,
      _ => AccountErrorKind.server,
    }, fieldErrors: _fieldErrors(json['errors']));
  }

  /// The backend sends either one message or a list of them per field.
  static Map<String, List<String>> _fieldErrors(Object? errors) {
    if (errors is! Map) return const {};
    return {
      for (final MapEntry(:key, :value) in errors.entries)
        '$key': value is List ? [for (final m in value) '$m'] : ['$value'],
    };
  }
}
