import 'package:flutter/widgets.dart';

import 'tokens.dart';

/// A rounded surface with a frame and a 3D bottom edge.
///
/// The edge is painted as an outer rounded shape in [edgeColor] with the
/// surface inset by [frame] on three sides and by [depth] at the bottom, so
/// it looks like a CSS `border` with a thicker `border-bottom`. Every
/// tappable and coloured surface in the design system is built on it.
class KnzEdgeBox extends StatelessWidget {
  const KnzEdgeBox({
    super.key,
    required this.color,
    required this.edgeColor,
    required this.radius,
    this.frame = 0,
    this.depth = 0,
    this.dashed = false,
    this.shadows,
    this.child,
  });

  final Color color;
  final Color edgeColor;
  final double radius;

  /// The frame width on the top, left and right.
  final double frame;

  /// The bottom edge width, including the frame.
  final double depth;

  /// Draws the frame dashed (locked clue, places in the fog). A dashed
  /// frame has no 3D edge.
  final bool dashed;

  /// Solid offset shadows or a focus ring; never blurred shadows.
  final List<BoxShadow>? shadows;

  final Widget? child;

  @override
  Widget build(BuildContext context) {
    final outer = BorderRadius.circular(radius);
    if (dashed) {
      // No RepaintBoundary: the cached frame is one draw call, cheaper than
      // a layer per dashed card.
      return CustomPaint(
        foregroundPainter: _DashedFramePainter(
          color: edgeColor,
          width: frame,
          radius: radius,
        ),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: color,
            borderRadius: outer,
            boxShadow: shadows,
          ),
          child: Padding(padding: EdgeInsets.all(frame), child: child),
        ),
      );
    }
    return DecoratedBox(
      decoration: BoxDecoration(
        color: edgeColor,
        borderRadius: outer,
        boxShadow: shadows,
      ),
      child: Padding(
        padding: EdgeInsets.fromLTRB(frame, frame, frame, depth),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(
              (radius - frame).clamp(0, KnzRadius.pill),
            ),
          ),
          child: child,
        ),
      ),
    );
  }
}

class _DashedFramePainter extends CustomPainter {
  const _DashedFramePainter({
    required this.color,
    required this.width,
    required this.radius,
  });

  final Color color;
  final double width;
  final double radius;

  static const _dash = 6.0;
  static const _gap = 4.0;

  /// Built dash paths by size, frame width and radius. Dashed cards share
  /// a few sizes (locked clue tiles, places in the fog), so the cache stays
  /// small; the oldest path goes first when it is full.
  static final _paths = <(Size, double, double), Path>{};
  static const _maxPaths = 64;

  @override
  void paint(Canvas canvas, Size size) {
    final key = (size, width, radius);
    var dashes = _paths.remove(key);
    if (dashes == null) {
      dashes = _dashes(size);
      if (_paths.length >= _maxPaths) _paths.remove(_paths.keys.first);
    }
    // Re-inserted last, so the map keeps its least recently used path first.
    _paths[key] = dashes;
    canvas.drawPath(
      dashes,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = width,
    );
  }

  /// All dashes of the frame in one path, drawn with one call.
  Path _dashes(Size size) {
    final inset = width / 2;
    final rect = RRect.fromRectAndRadius(
      Rect.fromLTWH(inset, inset, size.width - width, size.height - width),
      Radius.circular(radius - inset),
    );
    final dashes = Path();
    for (final metric in (Path()..addRRect(rect)).computeMetrics()) {
      for (var d = 0.0; d < metric.length; d += _dash + _gap) {
        dashes.addPath(metric.extractPath(d, d + _dash), Offset.zero);
      }
    }
    return dashes;
  }

  @override
  bool shouldRepaint(_DashedFramePainter old) =>
      old.color != color || old.width != width || old.radius != radius;
}
