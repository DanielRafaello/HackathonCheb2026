import 'package:flutter/widgets.dart';

import 'icon.dart';
import 'sentiment.dart';
import 'tokens.dart';

/// A small label in CAPITAL LETTERS (`components.md`, Pill / Chip).
///
/// [tinted] is the place type label ("NÁRODNÍ KULTURNÍ PAMÁTKA"); solid is a
/// status label ("UHODNUTO · 4 HVĚZDY", "NAVŠTÍVENO", "NOVĚ ODEMČENO").
class KnzPill extends StatelessWidget {
  const KnzPill({
    super.key,
    required this.label,
    this.sentiment = KnzSentiment.primary,
    this.tinted = true,
    this.icon,
  });

  final String label;
  final KnzSentiment sentiment;
  final bool tinted;
  final KnzIcons? icon;

  @override
  Widget build(BuildContext context) {
    final c = sentiment.colors;
    final foreground = tinted ? c.onTint : c.onSolid;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: KnzSpace.s8, vertical: 3),
      decoration: BoxDecoration(
        color: tinted ? c.tint : c.solid,
        borderRadius: BorderRadius.circular(KnzRadius.pill),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            KnzIcon(icon!, size: 14, color: foreground),
            const SizedBox(width: KnzSpace.s4),
          ],
          // A long place type wraps instead of overflowing a narrow screen.
          Flexible(
            child: Text(
              label.toUpperCase(),
              style: KnzText.badge.copyWith(color: foreground),
            ),
          ),
        ],
      ),
    );
  }
}

/// A chip on a coloured surface (`components.md`, Pill / Chip): "5 klíčů",
/// "5 pokusů", "až 5 hvězd" on the place of the day card.
class KnzChip extends StatelessWidget {
  const KnzChip({
    super.key,
    required this.label,
    this.sentiment = KnzSentiment.primary,
  });

  final String label;

  /// The surface the chip sits on; the chip takes its edge colour.
  final KnzSentiment sentiment;

  @override
  Widget build(BuildContext context) {
    final c = sentiment.colors;
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: KnzSpace.s10,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: c.edge,
        borderRadius: BorderRadius.circular(KnzRadius.pill),
      ),
      child: Text(label, style: KnzText.caption.copyWith(color: c.onSolid)),
    );
  }
}
