import 'package:flutter/widgets.dart';

import 'tokens.dart';

/// The game meaning a component's colour carries.
///
/// One colour has one meaning (`design-system/DESIGN.md`, rule 2): pick the
/// sentiment by what the element means, never for decoration.
enum KnzSentiment {
  /// Regional blue: the main action, place of the day, guessed.
  primary,

  /// Spa gold: stars, clues, visited, the Play button.
  accent,

  /// Cheb red: the player's guess, the compass, a wrong guess.
  danger,

  /// Slavkovský les green: a hit.
  success,

  /// Vřídlo turquoise: free play (Luštit dál), water, the mascot.
  explore,

  /// No game meaning: secondary actions, plain cards.
  neutral;

  KnzSentimentColors get colors => switch (this) {
    primary => const KnzSentimentColors(
      solid: KnzColors.primary,
      edge: KnzColors.primaryEdge,
      onSolid: KnzColors.textOnPrimary,
      line: KnzColors.primary,
      ink: KnzColors.primary,
      tint: KnzColors.primaryTint,
      onTint: KnzColors.primaryEdge,
      bar: KnzColors.primary,
    ),
    // Text on gold is always ink or gold-900, never white.
    accent => const KnzSentimentColors(
      solid: KnzColors.accent,
      edge: KnzColors.accentEdge,
      onSolid: KnzColors.text,
      line: KnzColors.accent,
      ink: KnzColors.accentText,
      tint: KnzColors.accentTint,
      onTint: KnzPalette.gold900,
      bar: KnzPalette.gold600,
    ),
    danger => const KnzSentimentColors(
      solid: KnzColors.danger,
      edge: KnzColors.dangerEdge,
      onSolid: KnzColors.textOnPrimary,
      line: KnzColors.danger,
      ink: KnzColors.dangerEdge,
      tint: KnzColors.dangerTint,
      onTint: KnzColors.dangerEdge,
      bar: KnzColors.danger,
    ),
    // A green surface with white text uses success-strong for contrast.
    success => const KnzSentimentColors(
      solid: KnzColors.successStrong,
      edge: KnzColors.successEdge,
      onSolid: KnzColors.textOnPrimary,
      line: KnzColors.success,
      ink: KnzColors.successText,
      tint: KnzColors.successTint,
      onTint: KnzColors.successEdge,
      bar: KnzColors.success,
    ),
    // White on turquoise is too faint, so solid turquoise carries ink text
    // (added; the design has no turquoise button). Turquoise text is always
    // explore-text.
    explore => const KnzSentimentColors(
      solid: KnzColors.explore,
      edge: KnzColors.exploreEdge,
      onSolid: KnzColors.text,
      line: KnzColors.explore,
      ink: KnzColors.exploreText,
      tint: KnzColors.exploreTint,
      onTint: KnzColors.exploreText,
      bar: KnzColors.explore,
    ),
    // Solid neutral is ink, as in the NAVŠTÍVENO label and the map
    // instruction pill.
    neutral => const KnzSentimentColors(
      solid: KnzColors.text,
      edge: KnzPalette.ink950,
      onSolid: KnzColors.textOnPrimary,
      line: KnzColors.border,
      ink: KnzColors.textSecondary,
      tint: KnzColors.surfaceSubtle,
      onTint: KnzColors.textSecondary,
      bar: KnzColors.iconMuted,
    ),
  };
}

/// The tokens one sentiment resolves to.
@immutable
class KnzSentimentColors {
  const KnzSentimentColors({
    required this.solid,
    required this.edge,
    required this.onSolid,
    required this.line,
    required this.ink,
    required this.tint,
    required this.onTint,
    required this.bar,
  });

  /// Background of a solid surface (button, hero card, solid label).
  final Color solid;

  /// The darker 3D bottom edge under [solid].
  final Color edge;

  /// Text and icons on [solid].
  final Color onSolid;

  /// Frame of an outlined or tinted surface.
  final Color line;

  /// Text and icons in this colour on a white surface.
  final Color ink;

  /// Background of a tinted surface.
  final Color tint;

  /// Text and icons on [tint].
  final Color onTint;

  /// The fill of a progress bar.
  final Color bar;
}
