import 'package:flutter/widgets.dart';

import 'pressable.dart';
import 'tokens.dart';

/// A row of mutually exclusive options in a track (`components.md`,
/// SegmentedControl). The active segment is white and raised.
class KnzSegmentedControl extends StatelessWidget {
  const KnzSegmentedControl({
    super.key,
    required this.labels,
    required this.selected,
    required this.onSelected,
  });

  final List<String> labels;
  final int selected;
  final ValueChanged<int> onSelected;

  static const _segmentHeight = 36.0;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(KnzSpace.s4),
      decoration: BoxDecoration(
        color: KnzColors.track,
        borderRadius: BorderRadius.circular(KnzRadius.md),
      ),
      child: Row(
        children: [
          for (final (i, label) in labels.indexed)
            Expanded(
              child: _Segment(
                label: label,
                active: i == selected,
                onPressed: () => onSelected(i),
              ),
            ),
        ],
      ),
    );
  }
}

class _Segment extends StatelessWidget {
  const _Segment({
    required this.label,
    required this.active,
    required this.onPressed,
  });

  final String label;
  final bool active;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      selected: active,
      child: KnzPressable(
        onPressed: onPressed,
        semanticLabel: label,
        // The track's padding brings the 36 px segment to the 44 px target.
        builder: (context, state) => AnimatedContainer(
          duration: KnzMotion.of(context, KnzMotion.fast),
          height: KnzSegmentedControl._segmentHeight,
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(horizontal: KnzSpace.s4),
          decoration: BoxDecoration(
            color: active ? KnzColors.surface : null,
            borderRadius: BorderRadius.circular(KnzRadius.xs),
            boxShadow: state.focused
                ? KnzShadows.focus
                : active
                ? KnzShadows.raisedSm
                : null,
          ),
          // A narrow screen shrinks the label rather than cutting it.
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              label,
              maxLines: 1,
              style: KnzText.weight(KnzText.bodySm, active ? 900 : 800)
                  .copyWith(
                    color: active || state.hovered
                        ? KnzColors.text
                        : KnzColors.textMuted,
                  ),
            ),
          ),
        ),
      ),
    );
  }
}
