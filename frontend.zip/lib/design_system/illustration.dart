import 'dart:ui' as ui;

import 'package:flutter/widgets.dart';

import 'tokens.dart';

/// Shapes shared by the flat illustrations (`DESIGN.md`, Illustrations):
/// solid colours, no outlines, no gradients.
abstract final class KnzIllustration {
  /// A white cloud with 0.92 opacity, [width] wide, centred on [centre].
  static void cloud(Canvas canvas, Offset centre, double width) {
    final paint = Paint()..color = KnzPalette.ink0.withValues(alpha: 0.92);
    canvas
      ..drawOval(
        Rect.fromCenter(center: centre, width: width, height: width * 0.32),
        paint,
      )
      ..drawOval(
        Rect.fromCenter(
          center: centre + Offset(width * 0.22, -width * 0.08),
          width: width * 0.55,
          height: width * 0.3,
        ),
        paint,
      );
  }

  /// A conifer: a flat triangle standing on [base].
  static void tree(Canvas canvas, Offset base, double height, Color color) {
    canvas.drawPath(
      Path()
        ..moveTo(base.dx - height * 0.36, base.dy)
        ..lineTo(base.dx, base.dy - height)
        ..lineTo(base.dx + height * 0.36, base.dy)
        ..close(),
      Paint()..color = color,
    );
  }

  /// A castle silhouette: a keep with a pointed roof and a wall with
  /// battlements. [base] is the bottom left corner of the wall, [height]
  /// the height of the keep with its roof.
  static void castle(Canvas canvas, Offset base, double height, Color color) {
    final unit = height / 32;
    final x = base.dx;
    final y = base.dy;
    final path = Path()
      // The keep with its roof.
      ..moveTo(x + 28 * unit, y)
      ..lineTo(x + 28 * unit, y - 23 * unit)
      ..lineTo(x + 37 * unit, y - 32 * unit)
      ..lineTo(x + 46 * unit, y - 23 * unit)
      ..lineTo(x + 46 * unit, y)
      ..close()
      // The wall.
      ..addRect(Rect.fromLTRB(x, y - 16 * unit, x + 28 * unit, y));
    for (var i = 0; i < 3; i++) {
      path.addRect(
        Rect.fromLTWH(x + i * 10 * unit, y - 19 * unit, 6 * unit, 3 * unit),
      );
    }
    canvas.drawPath(path, Paint()..color = color);
  }
}

/// Records a static drawing once and replays it while its key stays the
/// same.
///
/// Illustrations inside scrolling views or next to an animation are painted
/// again and again at the same size. Replaying the recorded picture skips
/// rebuilding their paths and laying out their text on every paint.
final class KnzPictureCache {
  Object? _key;
  ui.Picture? _picture;

  /// Draws the picture recorded for [key], recording it with [draw] first
  /// when [key] differs from the last one. The key must hold everything the
  /// drawing depends on, usually the size.
  void paint(Canvas canvas, Object key, void Function(Canvas canvas) draw) {
    var picture = _picture;
    if (picture == null || key != _key) {
      // A replaced picture may still be held by a retained layer, so it is
      // left to the garbage collector instead of being disposed here.
      final recorder = ui.PictureRecorder();
      draw(Canvas(recorder));
      picture = _picture = recorder.endRecording();
      _key = key;
    }
    canvas.drawPicture(picture);
  }

  /// Forgets the recording, for example after the system fonts change.
  void clear() {
    _key = null;
    _picture = null;
  }
}
