import 'package:flutter/widgets.dart';

import 'czech.dart';
import 'edge_box.dart';
import 'sentiment.dart';
import 'tokens.dart';

/// A pill progress track (`components.md`, ProgressBar).
///
/// The fill is at least 14 px wide while [value] is above zero, so even
/// small progress shows.
class KnzProgressBar extends StatelessWidget {
  const KnzProgressBar({
    super.key,
    required this.value,
    required this.semanticLabel,
    this.sentiment = KnzSentiment.primary,
    this.height = KnzSize.progressBar,
  });

  /// Progress from 0 to 1.
  final double value;

  /// What the bar shows, read with the value: "Chebsko".
  final String semanticLabel;
  final KnzSentiment sentiment;

  /// 10 on Home, 12 on My map.
  final double height;

  static const _minFill = 14.0;

  @override
  Widget build(BuildContext context) {
    final clamped = value.clamp(0.0, 1.0);
    return Semantics(
      label: semanticLabel,
      value: '${(clamped * 100).round()} %',
      child: ClipRRect(
        borderRadius: BorderRadius.circular(KnzRadius.pill),
        child: Container(
          height: height,
          color: KnzColors.track,
          alignment: Alignment.centerLeft,
          child: clamped == 0
              ? null
              : LayoutBuilder(
                  builder: (context, constraints) {
                    final width = (constraints.maxWidth * clamped).clamp(
                      _minFill,
                      constraints.maxWidth,
                    );
                    return AnimatedContainer(
                      duration: KnzMotion.of(context, KnzMotion.base),
                      width: width,
                      decoration: BoxDecoration(
                        color: sentiment.colors.bar,
                        borderRadius: BorderRadius.circular(KnzRadius.pill),
                      ),
                    );
                  },
                ),
        ),
      ),
    );
  }
}

/// A row with a name, a [KnzProgressBar] and a count: "Chebsko ··· 9 ze 148",
/// or just "9" while the total is unknown.
class KnzProgressRow extends StatelessWidget {
  const KnzProgressRow({
    super.key,
    required this.label,
    required this.count,
    required this.total,
    this.sentiment = KnzSentiment.primary,
    this.height = KnzSize.progressBar,
  });

  final String label;
  final int count;
  final int? total;
  final KnzSentiment sentiment;
  final double height;

  @override
  Widget build(BuildContext context) {
    final total = this.total;
    final fraction = total == null ? '$count' : Czech.fraction(count, total);
    return MergeSemantics(
      child: Semantics(
        label: '$label: $fraction',
        excludeSemantics: true,
        child: Row(
          children: [
            SizedBox(
              width: 96,
              child: Text(
                label,
                style: KnzText.weight(KnzText.body, 800),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: KnzSpace.s8),
            Expanded(
              child: KnzProgressBar(
                value: total == null || total == 0 ? 0 : count / total,
                semanticLabel: label,
                sentiment: sentiment,
                height: height,
              ),
            ),
            const SizedBox(width: KnzSpace.s8),
            SizedBox(
              width: 64,
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerRight,
                child: Text(
                  fraction,
                  maxLines: 1,
                  style: KnzText.caption.copyWith(color: KnzColors.textMuted),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// The guess indicator: one segment per guess (`components.md`,
/// AttemptProgress). Missed guesses are soft red, the current one is in the
/// sentiment colour with an inner bottom edge, the rest are empty.
class KnzAttemptProgress extends StatelessWidget {
  const KnzAttemptProgress({
    super.key,
    required this.missed,
    required this.total,
    this.sentiment = KnzSentiment.primary,
    this.height = KnzSize.progressSegment,
    this.semanticLabel,
  });

  /// What a screen reader says instead of "Pokus 2 z 5", for a round that
  /// goes on after the last segment.
  final String? semanticLabel;

  /// Wrong guesses so far.
  final int missed;

  /// Guesses in a round, from the game configuration.
  final int total;

  /// primary on the place of the day, explore in Luštit dál.
  final KnzSentiment sentiment;

  /// 14, or 12 in Luštit dál.
  final double height;

  @override
  Widget build(BuildContext context) {
    final exhausted = missed >= total;
    final label =
        semanticLabel ??
        (exhausted
            ? 'Všech $total pokusů vyčerpáno'
            : 'Pokus ${Czech.fraction(missed + 1, total)}');
    final c = sentiment.colors;
    return Semantics(
      label: label,
      excludeSemantics: true,
      child: Row(
        children: [
          for (var i = 0; i < total; i++) ...[
            if (i > 0) const SizedBox(width: KnzSpace.s6),
            Expanded(
              child: SizedBox(
                height: height,
                child: i < missed
                    ? const KnzEdgeBox(
                        color: KnzColors.dangerSoft,
                        edgeColor: KnzColors.dangerSoft,
                        radius: KnzRadius.pill,
                      )
                    : i == missed
                    ? KnzEdgeBox(
                        color: c.bar,
                        edgeColor: c.edge,
                        radius: KnzRadius.pill,
                        depth: KnzDepth.md,
                      )
                    : const KnzEdgeBox(
                        color: KnzColors.surfaceDisabled,
                        edgeColor: KnzColors.surfaceDisabled,
                        radius: KnzRadius.pill,
                      ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
