import 'package:flutter/widgets.dart';

import 'edge_box.dart';
import 'icon.dart';
import 'pressable.dart';
import 'sentiment.dart';
import 'tokens.dart';

/// How a [KnzButton] is drawn (`components.md`, Button).
enum KnzButtonVariant {
  /// A solid surface in the sentiment colour with a 5 px darker edge.
  solid,

  /// White with a 2 px frame and a 5 px bottom edge; text in the sentiment
  /// colour (neutral = text-secondary). SDÍLET, PŘESKOČIT.
  secondary,

  /// Text only. ZPĚT DOMŮ, ZKUSIT BEZ ÚČTU.
  ghost,
}

/// Button heights from `components.md`.
enum KnzButtonSize {
  /// The main action in a screen footer.
  cta(KnzSize.buttonCta),

  /// A regular button.
  regular(KnzSize.button),

  /// A smaller button with the `button-sm` type role.
  small(KnzSize.touch);

  const KnzButtonSize(this.height);

  final double height;
}

/// The 3D button. The label is shown in CAPITAL LETTERS.
///
/// Disabled when [onPressed] is null. Pressing moves the face down 3 px and
/// shrinks the edge to 2 px, so the total height stays the same.
class KnzButton extends StatelessWidget {
  const KnzButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.sentiment = KnzSentiment.primary,
    this.variant = KnzButtonVariant.solid,
    this.size = KnzButtonSize.regular,
    this.icon,
    this.expand = true,
    this.compact = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final KnzSentiment sentiment;
  final KnzButtonVariant variant;
  final KnzButtonSize size;

  /// A 20 px icon to the left of the label.
  final KnzIcons? icon;

  /// Full width (the default for the main action).
  final bool expand;

  /// Two actions side by side in a narrow footer (NAVIGOVAT + ULOŽIT NA
  /// MAPU): the `button-sm` text role and 12 px side padding at any height.
  final bool compact;

  static const _pressShift = KnzDepth.sm;
  static const _pressedDepth = KnzDepth.border;

  @override
  Widget build(BuildContext context) {
    return KnzPressable(
      onPressed: onPressed,
      builder: (context, state) {
        final duration = KnzMotion.of(context, KnzMotion.fast);
        final face = _Face.of(sentiment, variant, state.enabled);
        final textStyle =
            (size == KnzButtonSize.small || compact
                    ? KnzText.buttonSm
                    : KnzText.button)
                .copyWith(color: face.text);
        final content = Padding(
          padding: EdgeInsets.symmetric(
            horizontal: compact ? KnzSpace.s12 : KnzSpace.s20,
          ),
          child: Row(
            mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                KnzIcon(icon!, size: 20, color: face.text),
                const SizedBox(width: KnzSpace.s8),
              ],
              // A long label in a narrow button shrinks rather than
              // losing its end ("POKRAČOV…").
              Flexible(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    label.toUpperCase(),
                    style: textStyle,
                    maxLines: 1,
                  ),
                ),
              ),
            ],
          ),
        );

        if (variant == KnzButtonVariant.ghost) {
          return AnimatedOpacity(
            duration: duration,
            opacity: state.pressed ? 0.7 : 1,
            child: Container(
              height: size.height,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(KnzRadius.lg),
                color: state.hovered ? face.hover : null,
                boxShadow: state.focused ? KnzShadows.focus : null,
              ),
              child: content,
            ),
          );
        }

        final depth = state.pressed ? _pressedDepth : KnzDepth.lg;
        return SizedBox(
          height: size.height,
          child: AnimatedPadding(
            duration: duration,
            padding: EdgeInsets.only(top: state.pressed ? _pressShift : 0),
            child: KnzEdgeBox(
              color: state.hovered ? face.hover : face.background,
              edgeColor: face.edge,
              radius: KnzRadius.lg,
              frame: variant == KnzButtonVariant.secondary
                  ? KnzDepth.border
                  : 0,
              depth: depth,
              shadows: state.focused ? KnzShadows.focus : null,
              child: Center(child: content),
            ),
          ),
        );
      },
    );
  }
}

/// The colours of one button face.
class _Face {
  const _Face(this.background, this.edge, this.text, this.hover);

  final Color background;
  final Color edge;
  final Color text;

  /// Background on hover (web): 4 % lighter.
  final Color hover;

  static _Face of(KnzSentiment sentiment, KnzButtonVariant variant, bool on) {
    if (!on) {
      return switch (variant) {
        KnzButtonVariant.ghost => const _Face(
          KnzColors.surface,
          KnzColors.surface,
          KnzColors.textDisabled,
          KnzColors.surface,
        ),
        _ => const _Face(
          KnzColors.surfaceDisabled,
          KnzColors.borderStrong,
          KnzColors.textDisabled,
          KnzColors.surfaceDisabled,
        ),
      };
    }
    final c = sentiment.colors;
    return switch (variant) {
      KnzButtonVariant.solid => _Face(
        c.solid,
        c.edge,
        c.onSolid,
        Color.lerp(c.solid, KnzColors.surface, 0.04)!,
      ),
      KnzButtonVariant.secondary => _Face(
        KnzColors.surface,
        KnzColors.borderStrong,
        c.ink,
        KnzColors.surfaceSubtle,
      ),
      KnzButtonVariant.ghost => _Face(
        KnzColors.surface,
        KnzColors.surface,
        c.ink,
        c.tint,
      ),
    };
  }
}

/// A 44×44 icon button. [semanticLabel] is required: "Zavřít", "Zpět".
class KnzIconButton extends StatelessWidget {
  const KnzIconButton({
    super.key,
    required this.icon,
    required this.semanticLabel,
    required this.onPressed,
    this.color = KnzColors.iconSubtle,
    this.raised = false,
  });

  final KnzIcons icon;
  final String semanticLabel;
  final VoidCallback? onPressed;
  final Color color;

  /// A white tile on an illustration (Place card), radius 14, solid shadow.
  final bool raised;

  @override
  Widget build(BuildContext context) {
    return KnzPressable(
      onPressed: onPressed,
      semanticLabel: semanticLabel,
      builder: (context, state) {
        final iconColor = state.enabled
            ? (raised ? KnzColors.text : color)
            : KnzColors.textDisabled;
        return AnimatedSlide(
          duration: KnzMotion.of(context, KnzMotion.fast),
          offset: Offset(0, raised && state.pressed ? 0.05 : 0),
          child: Container(
            width: KnzSize.touch,
            height: KnzSize.touch,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: raised
                  ? KnzColors.surface
                  : (state.hovered || state.pressed
                        ? KnzColors.surfaceSubtle
                        : null),
              borderRadius: BorderRadius.circular(KnzRadius.md),
              boxShadow: [
                if (state.focused) ...KnzShadows.focus,
                if (raised && !state.pressed) ...KnzShadows.raisedMd,
              ],
            ),
            child: KnzIcon(icon, color: iconColor),
          ),
        );
      },
    );
  }
}
