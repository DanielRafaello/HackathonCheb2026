import 'package:flutter/widgets.dart';

import 'edge_box.dart';
import 'tokens.dart';

/// A count of places with its marker (`components.md`, CountTile): "28
/// uhodnuto". The [inFog] variant has a dashed frame and a muted number.
class KnzCountTile extends StatelessWidget {
  const KnzCountTile({
    super.key,
    required this.marker,
    required this.count,
    required this.label,
    this.inFog = false,
  });

  /// A 22–26 px marker drawn before the number.
  final Widget marker;
  final int count;
  final String label;
  final bool inFog;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      container: true,
      label: '$count $label',
      excludeSemantics: true,
      child: KnzEdgeBox(
        color: inFog ? KnzColors.surfaceInput : KnzColors.surface,
        edgeColor: inFog ? KnzPalette.ink300 : KnzColors.border,
        radius: KnzRadius.lg,
        frame: KnzDepth.border,
        depth: inFog ? KnzDepth.border : KnzDepth.md,
        dashed: inFog,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            KnzSpace.s10,
            KnzSpace.s10,
            KnzSpace.s10,
            KnzSpace.s8,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  marker,
                  const SizedBox(width: KnzSpace.s4),
                  Flexible(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(
                        '$count',
                        maxLines: 1,
                        style: KnzText.titleMd.copyWith(
                          color: inFog ? KnzColors.textMuted : KnzColors.text,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: KnzSpace.s2),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: KnzText.micro.copyWith(color: KnzColors.textMuted),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
