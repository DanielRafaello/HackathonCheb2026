import 'package:flutter/widgets.dart';

import 'czech.dart';
import 'icon.dart';
import 'pressable.dart';
import 'tokens.dart';

/// The star counter in the round's top bar (`components.md`, StarCounter):
/// a 22 px star and the number of stars a hit can still earn. At 0 the star
/// is empty and the number is muted.
class KnzStarCounter extends StatelessWidget {
  const KnzStarCounter({super.key, required this.stars});

  final int stars;

  @override
  Widget build(BuildContext context) {
    final none = stars <= 0;
    return Semantics(
      label: 'Hvězdy za trefu: $stars',
      excludeSemantics: true,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          KnzIcon(none ? KnzIcons.starEmpty : KnzIcons.star, size: 22),
          const SizedBox(width: KnzSpace.s6),
          Text(
            '$stars',
            style: KnzText.weight(KnzText.bodyLg, 900).copyWith(
              height: 1,
              color: none ? KnzColors.iconMuted : KnzColors.accentText,
            ),
          ),
        ],
      ),
    );
  }
}

/// The player's rating of a place (`components.md`, StarPicker): [max]
/// stars of 36 px, each a 44 px touch target; tapping star n rates n.
/// The first [stars] are filled, none while unrated. Disabled without
/// [onChanged].
class KnzStarPicker extends StatelessWidget {
  const KnzStarPicker({
    super.key,
    required this.stars,
    required this.max,
    required this.onChanged,
  });

  /// The current rating, or null when the player has not rated yet.
  final int? stars;
  final int max;
  final ValueChanged<int>? onChanged;

  static const _size = 36.0;

  @override
  Widget build(BuildContext context) {
    final filled = (stars ?? 0).clamp(0, max);
    final onChanged = this.onChanged;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 1; i <= max; i++)
          Semantics(
            selected: i == stars,
            child: KnzPressable(
              onPressed: onChanged == null ? null : () => onChanged(i),
              semanticLabel:
                  'Ohodnotit: ${Czech.fraction(i, max)} '
                  '${Czech.plural(max, 'hvězdy', 'hvězd', 'hvězd')}',
              builder: (context, state) => SizedBox.square(
                dimension: KnzSize.touch,
                child: Center(
                  child: AnimatedScale(
                    duration: KnzMotion.of(context, KnzMotion.fast),
                    scale: state.pressed ? 0.88 : 1,
                    child: KnzIcon(
                      i <= filled ? KnzIcons.star : KnzIcons.starEmpty,
                      size: _size,
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

/// The rating after a hit (`components.md`, StarRating): [max] stars of
/// 40 px, the first [stars] filled.
class KnzStarRating extends StatelessWidget {
  const KnzStarRating({
    super.key,
    required this.stars,
    required this.max,
    this.size = 40,
  });

  final int stars;
  final int max;
  final double size;

  @override
  Widget build(BuildContext context) {
    final filled = stars.clamp(0, max);
    return Semantics(
      label:
          '${Czech.fraction(filled, max)} '
          '${Czech.plural(max, 'hvězdy', 'hvězd', 'hvězd')}',
      excludeSemantics: true,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (var i = 0; i < max; i++) ...[
            if (i > 0) const SizedBox(width: KnzSpace.s6),
            KnzIcon(
              i < filled ? KnzIcons.star : KnzIcons.starEmpty,
              size: size,
            ),
          ],
        ],
      ),
    );
  }
}
