import 'package:flutter/widgets.dart';

import 'edge_box.dart';
import 'pressable.dart';
import 'sentiment.dart';
import 'tokens.dart';

/// How a [KnzCard] is drawn.
enum KnzCardVariant {
  /// White with a 2 px frame and a 5 px bottom edge in the sentiment's line
  /// colour; neutral is the plain card (border). PlaceCard, RevealCard.
  outlined,

  /// The sentiment tint with the same frame. ClueCard "newly unlocked"
  /// (accent), Luštit dál (explore).
  tinted,

  /// A solid block in the sentiment colour with a 6 px edge and text in the
  /// on-colour. DailyHeroCard.
  solid,

  /// A dashed 2 px frame with no edge. LockedClue, places in the fog.
  dashed,
}

/// A card with a 3D bottom edge (`components.md`).
///
/// With [onPressed] the whole card is tappable (ListCard): it presses down
/// like a button and is announced as a link.
class KnzCard extends StatelessWidget {
  const KnzCard({
    super.key,
    required this.child,
    this.sentiment = KnzSentiment.neutral,
    this.variant = KnzCardVariant.outlined,
    this.padding = const EdgeInsets.all(KnzSpace.s14),
    this.radius = KnzRadius.xl2,
    this.onPressed,
  });

  final Widget child;
  final KnzSentiment sentiment;
  final KnzCardVariant variant;
  final EdgeInsetsGeometry padding;
  final double radius;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    if (onPressed == null) return _surface(context, pressed: false);
    return KnzPressable(
      onPressed: onPressed,
      isLink: true,
      builder: (context, state) => AnimatedPadding(
        duration: KnzMotion.of(context, KnzMotion.fast),
        padding: EdgeInsets.only(top: state.pressed ? KnzDepth.sm : 0),
        child: _surface(
          context,
          pressed: state.pressed,
          focused: state.focused,
          hovered: state.hovered,
        ),
      ),
    );
  }

  Widget _surface(
    BuildContext context, {
    required bool pressed,
    bool focused = false,
    bool hovered = false,
  }) {
    final c = sentiment.colors;
    final restingDepth = variant == KnzCardVariant.solid
        ? KnzDepth.xl
        : KnzDepth.lg;
    final depth = pressed ? KnzDepth.border : restingDepth;
    final (background, edge, text) = switch (variant) {
      KnzCardVariant.outlined => (KnzColors.surface, c.line, KnzColors.text),
      KnzCardVariant.tinted => (c.tint, c.line, KnzColors.text),
      KnzCardVariant.solid => (c.solid, c.edge, c.onSolid),
      KnzCardVariant.dashed => (
        KnzColors.surfaceSubtle,
        KnzColors.borderStrong,
        KnzColors.textMuted,
      ),
    };
    return KnzEdgeBox(
      color: hovered && variant != KnzCardVariant.solid
          ? Color.lerp(background, c.tint, 0.5)!
          : background,
      edgeColor: edge,
      radius: radius,
      frame: variant == KnzCardVariant.solid ? 0 : KnzDepth.border,
      depth: variant == KnzCardVariant.dashed ? KnzDepth.border : depth,
      dashed: variant == KnzCardVariant.dashed,
      shadows: focused ? KnzShadows.focus : null,
      child: DefaultTextStyle.merge(
        style: KnzText.body.copyWith(color: text),
        child: IconTheme.merge(
          data: IconThemeData(color: text),
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}
