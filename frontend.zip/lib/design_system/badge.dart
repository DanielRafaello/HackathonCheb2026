import 'package:flutter/widgets.dart';

import 'czech.dart';
import 'edge_box.dart';
import 'icon.dart';
import 'sentiment.dart';
import 'tokens.dart';

/// A badge on the profile (`components.md`, Badge): a round medal with an
/// icon and the name below it.
///
/// An earned badge is solid in its [sentiment] with a pale ring and a 3D
/// edge. A locked one is gray with a lock and shows the progress, "9 / 148".
class KnzBadge extends StatelessWidget {
  const KnzBadge({
    super.key,
    required this.label,
    required this.icon,
    required this.sentiment,
    required this.count,
    required this.goal,
  });

  final String label;
  final KnzIcons icon;
  final KnzSentiment sentiment;
  final int count;
  final int goal;

  bool get earned => count >= goal;

  static const size = 72.0;
  static const _ring = KnzSpace.s4;
  static const _lock = 24.0;

  @override
  Widget build(BuildContext context) {
    final colors = sentiment.colors;
    final medal = KnzEdgeBox(
      color: earned ? colors.solid : KnzColors.surfaceSubtle,
      edgeColor: earned ? colors.edge : KnzColors.borderStrong,
      radius: KnzRadius.pill,
      depth: KnzDepth.md,
      child: Center(
        child: KnzIcon(
          icon,
          size: 30,
          color: earned ? colors.onSolid : KnzColors.iconSubtle,
        ),
      ),
    );
    return Semantics(
      container: true,
      excludeSemantics: true,
      label: earned
          ? '$label, získáno'
          : '$label, zamčeno, ${Czech.fraction(count.clamp(0, goal), goal)}',
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox.square(
            dimension: size,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: earned
                            ? colors.line.withValues(alpha: 0.4)
                            : KnzColors.borderStrong,
                        width: _ring,
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.all(_ring + KnzSpace.s2),
                    child: medal,
                  ),
                ),
                if (!earned)
                  const Positioned(
                    right: 0,
                    bottom: 0,
                    child: _LockChip(size: _lock),
                  ),
              ],
            ),
          ),
          const SizedBox(height: KnzSpace.s6),
          Text(
            label,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: KnzText.weight(
              KnzText.caption,
              900,
            ).copyWith(color: earned ? KnzColors.text : KnzColors.textMuted),
          ),
          if (!earned)
            Text(
              Czech.fractionSlash(count.clamp(0, goal), goal),
              style: KnzText.micro.copyWith(color: KnzColors.textMuted),
            ),
        ],
      ),
    );
  }
}

class _LockChip extends StatelessWidget {
  const _LockChip({required this.size});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: KnzColors.surface,
        shape: BoxShape.circle,
        border: Border.all(
          color: KnzColors.borderStrong,
          width: KnzDepth.border,
        ),
      ),
      child: const KnzIcon(KnzIcons.lock, size: 14, color: KnzColors.iconMuted),
    );
  }
}
