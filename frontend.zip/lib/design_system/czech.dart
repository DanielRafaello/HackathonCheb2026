/// Czech text helpers for the design system components.
abstract final class Czech {
  /// "z" or "ze" before [number] in the genitive, as in "Pokus 1 z 5" and
  /// "9 ze 148": "ze" when the spoken number starts with s, š, z, ž or č.
  static String outOf(int number) => _startsWithSibilant(number) ? 'ze' : 'z';

  /// "[part] z(e) [total]", with no-break spaces (`copy.md`).
  static String fraction(int part, int total) =>
      '$part\u00A0${outOf(total)}\u00A0$total';

  /// Guesses or clues used: "2 / 5", with no-break spaces (`copy.md`).
  static String fractionSlash(int part, int total) =>
      '$part\u00A0/\u00A0$total';

  /// The Czech plural form for [count], as `Intl.PluralRules('cs')` picks
  /// it for whole numbers: [one] for 1, [few] for 2–4, [many] otherwise
  /// ("1 klíč", "3 klíče", "5 klíčů", "0 klíčů").
  static String plural(int count, String one, String few, String many) =>
      switch (count) {
        1 => one,
        2 || 3 || 4 => few,
        _ => many,
      };

  /// [count] and its plural form joined by a no-break space: "5 pokusů".
  static String count(int count, String one, String few, String many) =>
      '$count\u00A0${plural(count, one, few, many)}';

  /// A whole number with thousands separated by a no-break space, as
  /// `Intl.NumberFormat('cs-CZ')` writes it: "56 000" (`copy.md`).
  static String number(int n) {
    final digits = n.abs().toString();
    final groups = <String>[];
    for (var end = digits.length; end > 0; end -= 3) {
      groups.insert(0, digits.substring(end < 3 ? 0 : end - 3, end));
    }
    return '${n < 0 ? '-' : ''}${groups.join('\u00A0')}';
  }

  /// [value] with [digits] decimals and a decimal comma (`copy.md`): "4,3".
  static String decimal(double value, int digits) =>
      value.toStringAsFixed(digits).replaceAll('.', ',');

  /// A WGS 84 position as Czech maps write it: "50,0811° s. š.,
  /// 12,3660° v. d." Western and southern positions use "z. d." and "j. š.".
  static String coordinates(double latitude, double longitude) {
    final lat =
        '${decimal(latitude.abs(), 4)}° '
        '${latitude < 0 ? 'j.' : 's.'} š.';
    final lon =
        '${decimal(longitude.abs(), 4)}° '
        '${longitude < 0 ? 'z.' : 'v.'} d.';
    return '$lat, $lon';
  }

  static const _weekdays = ['PO', 'ÚT', 'ST', 'ČT', 'PÁ', 'SO', 'NE'];

  /// The weekday and date for an overline: "ČT 9. 10." (`copy.md`).
  static String shortDate(DateTime date) =>
      '${_weekdays[date.weekday - 1]}\u00A0${date.day}.\u00A0${date.month}.';

  /// A date without the weekday: "9. 10." (`copy.md`).
  static String dayMonth(DateTime date) => '${date.day}.\u00A0${date.month}.';

  /// A distance with a no-break space and a decimal comma (`copy.md`):
  /// "40 m" (rounded to 10 m), "1,4 km" below 10 km, "31 km" above.
  static String distance(double meters) {
    if (meters < 995) {
      return '${(meters / 10).round() * 10}\u00A0m';
    }
    final km = meters / 1000;
    if (km < 9.95) {
      final tenths = (km * 10).round();
      final text = tenths % 10 == 0
          ? '${tenths ~/ 10}'
          : '${tenths ~/ 10},${tenths % 10}';
      return '$text\u00A0km';
    }
    return '${km.round()}\u00A0km';
  }

  static bool _startsWithSibilant(int n) {
    if (n >= 1000) {
      final thousands = n ~/ 1000;
      // "tisíce" for 1 000–1 999, otherwise the thousands are spoken first.
      return thousands == 1 ? false : _startsWithSibilant(thousands);
    }
    if (n >= 100) {
      // sto (100–199), čtyři sta, šest set, sedm set
      return const {1, 4, 6, 7}.contains(n ~/ 100);
    }
    if (n >= 20) {
      // čtyřiceti, šedesáti, sedmdesáti
      return const {4, 6, 7}.contains(n ~/ 10);
    }
    // čtyř, šesti, sedmi; čtrnácti, šestnácti, sedmnácti
    return const {4, 6, 7, 14, 16, 17}.contains(n);
  }
}
