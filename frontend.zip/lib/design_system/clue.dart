import 'package:flutter/widgets.dart';

import 'card.dart';
import 'icon.dart';
import 'pill.dart';
import 'sentiment.dart';
import 'tokens.dart';

/// The header and text of a clue (`components.md`, ClueCard): a key icon
/// and the label in gold capitals, then the clue in the `clue` role.
class KnzClueContent extends StatelessWidget {
  const KnzClueContent({
    super.key,
    required this.label,
    required this.text,
    this.isNew = false,
  });

  /// "KLÍČ 1 · HÁDANKA", already in capitals.
  final String label;
  final String text;

  /// Adds the NOVĚ ODEMČENO label on the right.
  final bool isNew;

  @override
  Widget build(BuildContext context) {
    return MergeSemantics(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const KnzIcon(
                KnzIcons.key,
                size: 16,
                color: KnzColors.accentText,
              ),
              const SizedBox(width: KnzSpace.s6),
              Expanded(
                child: Text(
                  label,
                  style: KnzText.label.copyWith(color: KnzColors.accentText),
                ),
              ),
              if (isNew) ...[
                const SizedBox(width: KnzSpace.s8),
                const KnzPill(
                  label: 'Nově odemčeno',
                  sentiment: KnzSentiment.accent,
                  tinted: false,
                ),
              ],
            ],
          ),
          const SizedBox(height: KnzSpace.s6),
          Text(text, style: KnzText.clue),
        ],
      ),
    );
  }
}

/// An unlocked clue as a card. [isNew] is the "newly unlocked" variant:
/// a gold frame and the NOVĚ ODEMČENO label.
class KnzClueCard extends StatelessWidget {
  const KnzClueCard({
    super.key,
    required this.label,
    required this.text,
    this.isNew = false,
  });

  final String label;
  final String text;
  final bool isNew;

  @override
  Widget build(BuildContext context) {
    return KnzCard(
      sentiment: isNew ? KnzSentiment.accent : KnzSentiment.neutral,
      radius: KnzRadius.xl,
      padding: const EdgeInsets.symmetric(
        horizontal: KnzSpace.s16,
        vertical: KnzSpace.s12,
      ),
      child: KnzClueContent(label: label, text: text, isNew: isNew),
    );
  }
}

/// A clue that is still locked (`components.md`, LockedClue): a dashed tile
/// with a lock and the clue's short name.
class KnzLockedClue extends StatelessWidget {
  const KnzLockedClue({super.key, required this.label});

  /// "Typ", "Čísla".
  final String label;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Zamčený klíč: $label',
      excludeSemantics: true,
      child: KnzCard(
        variant: KnzCardVariant.dashed,
        radius: KnzRadius.md,
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s6,
          vertical: KnzSpace.s10,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const KnzIcon(KnzIcons.lock, size: 16, color: KnzColors.iconSubtle),
            const SizedBox(height: KnzSpace.s4),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: KnzText.caption.copyWith(color: KnzColors.iconMuted),
            ),
          ],
        ),
      ),
    );
  }
}
