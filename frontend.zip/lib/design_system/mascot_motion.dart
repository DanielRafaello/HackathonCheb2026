import 'dart:math' as math;
import 'dart:ui' show Offset;

import 'package:xml/xml.dart';

import 'mascot.dart' show KnzMood;

// Vřídlík's motion (`DESIGN.md`, Mascot motion). The SVGs in
// `design-system/assets/mascot/` stay the only drawing: [mascotLayers] cuts
// a mood's SVG into parts in document order, and [MascotPose.at] says where
// each part is at a given time. The pose depends on the time alone, so the
// same time always gives the same frame.

/// A part of Vřídlík that moves on its own.
enum MascotPart {
  shadow,
  steamLeft,
  steamRight,
  armLeft,
  armRight,

  /// The body, its shading and highlight, and the cheeks.
  body,

  /// The eye whites, or the closed eyes when cheering.
  eyes,

  /// The pupils and their glints.
  pupils,
  brows,
  mouth,
  tear,

  /// The hand under the chin while thinking.
  hand,
  bubbleSmall,
  bubbleLarge,
}

/// The parts of each top-level element of a mood's SVG, in document order.
/// One part takes the whole element; several parts split a group's children.
const _structure = <KnzMood, List<List<MascotPart>>>{
  KnzMood.wave: [
    ..._head,
    [MascotPart.armLeft, MascotPart.armRight],
    ..._body,
    _openEyes,
    [MascotPart.mouth],
  ],
  KnzMood.happy: [
    ..._head,
    [MascotPart.armLeft, MascotPart.armRight],
    ..._body,
    _openEyes,
    [MascotPart.mouth],
  ],
  KnzMood.cheer: [
    ..._head,
    [MascotPart.armLeft, MascotPart.armRight],
    ..._body,
    [MascotPart.eyes, MascotPart.eyes],
    [MascotPart.mouth],
  ],
  KnzMood.sad: [
    ..._head,
    [MascotPart.armLeft, MascotPart.armRight],
    ..._body,
    _openEyes,
    [MascotPart.brows],
    [MascotPart.mouth, MascotPart.tear],
  ],
  KnzMood.think: [
    ..._head,
    [MascotPart.armLeft],
    ..._body,
    _openEyes,
    [MascotPart.mouth],
    [MascotPart.hand, MascotPart.bubbleSmall, MascotPart.bubbleLarge],
  ],
};

const _head = [
  [MascotPart.shadow],
  [MascotPart.steamLeft],
  [MascotPart.steamRight],
];

const _body = [
  [MascotPart.body],
  [MascotPart.body],
  [MascotPart.body],
  [MascotPart.body],
  [MascotPart.body],
];

const _openEyes = [
  MascotPart.eyes,
  MascotPart.eyes,
  MascotPart.pupils,
  MascotPart.pupils,
  MascotPart.pupils,
  MascotPart.pupils,
];

/// One layer of a mood: a standalone SVG with the viewBox of the original
/// and the elements of one [part].
class MascotLayer {
  const MascotLayer(this.part, this.svg);

  final MascotPart part;
  final String svg;
}

/// Cuts [svg], the asset of [mood], into layers. Neighbouring elements of the
/// same part share a layer; the drawing order is kept. Throws a
/// [FormatException] when the SVG no longer has the structure this file
/// expects, so that a redrawn mascot fails loudly instead of moving wrongly.
List<MascotLayer> mascotLayers(String svg, KnzMood mood) {
  final root = XmlDocument.parse(svg).rootElement;
  final elements = root.childElements
      .where((e) => e.name.local != 'metadata')
      .toList();
  final structure = _structure[mood]!;
  if (elements.length != structure.length) {
    throw FormatException(
      '${mood.file}: ${elements.length} elements, expected '
      '${structure.length}',
    );
  }

  final pieces = <(MascotPart, XmlElement)>[];
  for (var i = 0; i < elements.length; i++) {
    final element = elements[i];
    final parts = structure[i];
    if (parts.length == 1) {
      pieces.add((parts.single, element));
      continue;
    }
    final children = element.childElements.toList();
    if (element.name.local != 'g' || children.length != parts.length) {
      throw FormatException(
        '${mood.file}: element $i should be a group of ${parts.length}',
      );
    }
    for (var j = 0; j < children.length; j++) {
      // Keep the group's own attributes, if it has any.
      pieces.add((
        parts[j],
        XmlElement(
          XmlName.parts('g'),
          element.attributes.map((a) => a.copy()),
          [children[j].copy()],
        ),
      ));
    }
  }

  final viewBox = root.getAttribute('viewBox');
  final width = root.getAttribute('width');
  final height = root.getAttribute('height');
  String wrap(Iterable<XmlElement> body) =>
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="$viewBox" '
      'width="$width" height="$height">${body.join()}</svg>';

  final layers = <MascotLayer>[];
  var start = 0;
  for (var i = 1; i <= pieces.length; i++) {
    if (i == pieces.length || pieces[i].$1 != pieces[start].$1) {
      layers.add(
        MascotLayer(
          pieces[start].$1,
          wrap(pieces.sublist(start, i).map((p) => p.$2)),
        ),
      );
      start = i;
    }
  }
  return layers;
}

/// A move of one part around its pivot, in viewBox units (120 × 140).
class MascotTransform {
  const MascotTransform({
    this.dx = 0,
    this.dy = 0,
    this.rotation = 0,
    this.scaleX = 1,
    this.scaleY = 1,
    this.opacity = 1,
  });

  static const identity = MascotTransform();

  final double dx;
  final double dy;

  /// Radians, clockwise on screen.
  final double rotation;
  final double scaleX;
  final double scaleY;
  final double opacity;
}

/// Where Vřídlík is at one moment. [root] moves everything except the
/// shadow around the bottom of the drop; each part then moves around its
/// own [pivot].
class MascotPose {
  const MascotPose(this.root, this.parts);

  final MascotTransform root;
  final Map<MascotPart, MascotTransform> parts;

  MascotTransform operator [](MascotPart part) =>
      parts[part] ?? MascotTransform.identity;

  /// The point the root turns and squashes around: the bottom of the drop.
  static const rootPivot = Offset(60, 132);

  /// The point [part] of [mood] turns around: a shoulder for an arm, the
  /// base for a steam wisp, the centre for the rest.
  static Offset pivot(KnzMood mood, MascotPart part) => switch (part) {
    MascotPart.shadow => const Offset(60, 134),
    MascotPart.steamLeft => const Offset(57, 17),
    MascotPart.steamRight => const Offset(67, 15),
    MascotPart.armLeft when mood == KnzMood.cheer => const Offset(22.6, 84.6),
    MascotPart.armLeft => const Offset(25.2, 94.9),
    MascotPart.armRight when mood == KnzMood.cheer => const Offset(97.4, 84.6),
    MascotPart.armRight when mood == KnzMood.wave => const Offset(98, 82.4),
    MascotPart.armRight => const Offset(94.8, 94.9),
    MascotPart.body => rootPivot,
    MascotPart.eyes || MascotPart.pupils => const Offset(60, 84),
    MascotPart.brows => const Offset(60, 73),
    MascotPart.mouth => const Offset(60, 104),
    MascotPart.tear => const Offset(85, 84),
    MascotPart.hand => const Offset(87.7, 123.4),
    MascotPart.bubbleSmall => const Offset(104, 40),
    MascotPart.bubbleLarge => const Offset(111, 27),
  };

  /// The pose of [mood] [t] seconds after Vřídlík appeared. Every mood
  /// breathes, blinks, and lets its steam sway; then each acts its mood.
  static MascotPose at(KnzMood mood, double t) => switch (mood) {
    KnzMood.wave => _wave(t),
    KnzMood.happy => _happy(t),
    KnzMood.cheer => _cheer(t),
    KnzMood.think => _think(t),
    KnzMood.sad => _sad(t),
  };
}

// Time helpers. Periods and amplitudes are tuned by eye on the 120 × 140
// drawing; angles are in degrees until [_deg].

double _deg(double degrees) => degrees * math.pi / 180;

double _sine(double t, double period, [double phase = 0]) =>
    math.sin(2 * math.pi * t / period + phase);

double _clamp01(double x) => x.clamp(0.0, 1.0);

/// Smoothstep from 0 at [a] to 1 at [b].
double _ramp(double x, double a, double b) {
  final u = _clamp01((x - a) / (b - a));
  return u * u * (3 - 2 * u);
}

/// 0 outside [a, d], 1 inside [b, c], smooth ramps between.
double _window(double x, double a, double b, double c, double d) =>
    _ramp(x, a, b) * (1 - _ramp(x, c, d));

/// The time inside a [period] long cycle that starts at [start]; negative
/// before the first cycle.
double _cycle(double t, double period, [double start = 0]) =>
    t < start ? -1 : (t - start) % period;

/// The wobble of a drop that has just landed: starts and ends at 0, decays
/// like a damped spring (ζ 0.3, 2.6 Hz).
double _jiggle(double t) {
  const zeta = 0.3;
  const omega = 2 * math.pi * 2.6;
  final damped = omega * math.sqrt(1 - zeta * zeta);
  return math.exp(-zeta * omega * t) * math.sin(damped * t);
}

/// An underdamped spring from 0 to 1 (ζ 0.45): pops in with a small
/// overshoot.
double _spring(double t, {double frequency = 2.2}) {
  if (t <= 0) return 0;
  const zeta = 0.45;
  final omega = 2 * math.pi * frequency;
  final damped = omega * math.sqrt(1 - zeta * zeta);
  return 1 -
      math.exp(-zeta * omega * t) *
          (math.cos(damped * t) +
              zeta / math.sqrt(1 - zeta * zeta) * math.sin(damped * t));
}

/// How closed the eyes are, 0–1. Blinks come at uneven, fixed intervals so
/// they don't look mechanical; [slow] stretches them for a sad drop.
double _blink(double t, {bool slow = false}) {
  const gaps = [3.4, 4.2, 2.8, 0.32, 4.6, 3.6];
  const period = 3.4 + 4.2 + 2.8 + 0.32 + 4.6 + 3.6;
  final close = slow ? 0.14 : 0.1;
  final open = slow ? 0.2 : 0.12;
  var u = _cycle(t, period, 1.2);
  if (u < 0) return 0;
  for (final gap in gaps) {
    if (u < gap) break;
    u -= gap;
  }
  if (u < close) return _ramp(u, 0, close);
  if (u < close + open) return 1 - _ramp(u, close, close + open);
  return 0;
}

/// Breathing, the landing jiggle, and the swaying steam that every mood
/// shares. [calm] slows and shrinks them.
({MascotTransform root, MascotTransform steamLeft, MascotTransform steamRight})
_idle(double t, {bool calm = false, bool land = true}) {
  final breath = _sine(t, calm ? 3.6 : 2.6) * (calm ? 0.012 : 0.018);
  final wobble = land ? _jiggle(t) : 0.0;
  final sway = calm ? 0.5 : 1.0;
  return (
    root: MascotTransform(
      scaleX: 1 - breath * 0.7 + wobble * 0.08,
      scaleY: 1 + breath - wobble * 0.11,
    ),
    steamLeft: MascotTransform(
      rotation: _deg(7 * sway) * _sine(t, calm ? 2.6 : 1.9),
      scaleY: 1 + 0.08 * _sine(t, 1.3),
      opacity: 0.8 + 0.2 * _sine(t, 1.7),
    ),
    steamRight: MascotTransform(
      rotation: _deg(-8 * sway) * _sine(t, calm ? 2.2 : 1.6, 1),
      scaleY: 1 + 0.1 * _sine(t, 1.1, 2),
      opacity: 0.8 + 0.2 * _sine(t, 1.5, 1),
    ),
  );
}

MascotTransform _blinkEyes(double t, {bool slow = false}) =>
    MascotTransform(scaleY: 1 - 0.9 * _blink(t, slow: slow));

MascotTransform _shadowUnder(MascotTransform root, {double lift = 0}) {
  final rise = _clamp01(lift / 16);
  return MascotTransform(
    scaleX: root.scaleX * (1 - 0.35 * rise),
    scaleY: 1 - 0.35 * rise,
    opacity: 1 - 0.45 * rise,
  );
}

/// Hello: a burst of three waves every 3.6 s, leaning into it.
MascotPose _wave(double t) {
  final idle = _idle(t);
  final u = _cycle(t, 3.6, 0.2);
  final active = u < 0 ? 0.0 : _window(u, 0, 0.15, 1.3, 1.6);
  final swing = _sine(math.max(u, 0), 0.5);
  final root = MascotTransform(
    rotation: _deg(2.5) * active + _deg(0.8) * swing * active,
    scaleX: idle.root.scaleX,
    scaleY: idle.root.scaleY,
  );
  final eyes = _blinkEyes(t);
  return MascotPose(root, {
    MascotPart.shadow: _shadowUnder(root),
    MascotPart.steamLeft: idle.steamLeft,
    MascotPart.steamRight: idle.steamRight,
    MascotPart.armLeft: MascotTransform(rotation: _deg(3) * _sine(t, 2.6)),
    MascotPart.armRight: MascotTransform(rotation: _deg(24) * swing * active),
    MascotPart.eyes: eyes,
    MascotPart.pupils: eyes,
  });
}

/// The default: calm, with a happy wiggle every 4.8 s.
MascotPose _happy(double t) {
  final idle = _idle(t);
  final u = _cycle(t, 4.8, 1.6);
  final wiggle = u < 0 ? 0.0 : _window(u, 0, 0.15, 1.0, 1.25) * _sine(u, 0.6);
  final root = MascotTransform(
    rotation: _deg(4) * wiggle,
    scaleX: idle.root.scaleX,
    scaleY: idle.root.scaleY,
  );
  final flap = _deg(5) * _sine(t, 2.6);
  final eyes = _blinkEyes(t);
  return MascotPose(root, {
    MascotPart.shadow: _shadowUnder(root),
    MascotPart.steamLeft: idle.steamLeft,
    MascotPart.steamRight: idle.steamRight,
    MascotPart.armLeft: MascotTransform(rotation: -flap),
    MascotPart.armRight: MascotTransform(rotation: flap),
    MascotPart.eyes: eyes,
    MascotPart.pupils: eyes,
  });
}

/// A hit: three hops with squash and stretch, a short rest, again.
MascotPose _cheer(double t) {
  const hop = 0.62;
  const rest = 1.0;
  const height = 16.0;
  final idle = _idle(t, land: false);
  final u = _cycle(t, 3 * hop + rest);
  final hopping = u < 3 * hop;
  final h = hopping ? u % hop : 0.0;

  var lift = 0.0;
  var squash = 0.0; // > 0 squashes, < 0 stretches.
  if (!hopping) {
    // Resting between the bursts: only breathing.
  } else if (h < 0.1) {
    // Anticipation.
    squash = 0.1 * math.sin(h / 0.1 * math.pi);
  } else if (h < 0.52) {
    // In the air, on a parabola; stretched when fast, round at the top.
    final p = (h - 0.1) / 0.42;
    lift = height * 4 * p * (1 - p);
    squash = -0.07 * math.sin(2 * math.pi * p).abs();
  } else {
    // Landing.
    squash = 0.12 * math.sin((h - 0.52) / 0.1 * math.pi);
  }

  final root = MascotTransform(
    dy: -lift,
    scaleX: idle.root.scaleX * (1 + squash * 0.8),
    scaleY: idle.root.scaleY * (1 - squash),
  );
  final excited = _window(u, 0, 0.1, 3 * hop - 0.1, 3 * hop + 0.2);
  final shake = _deg(5 + 7 * excited) * _sine(t, 0.31);
  final joy = lift / height;
  return MascotPose(root, {
    MascotPart.shadow: _shadowUnder(root, lift: lift),
    MascotPart.steamLeft: idle.steamLeft,
    MascotPart.steamRight: idle.steamRight,
    MascotPart.armLeft: MascotTransform(rotation: -shake),
    MascotPart.armRight: MascotTransform(rotation: shake),
    MascotPart.eyes: MascotTransform(scaleY: 1 + 0.12 * joy),
    MascotPart.mouth: MascotTransform(
      scaleX: 1 + 0.06 * joy,
      scaleY: 1 + 0.12 * joy,
    ),
  });
}

/// Guessing: looks up to the side and back, taps the chin, the thought
/// bubbles pop in and float.
MascotPose _think(double t) {
  final idle = _idle(t);
  final u = _cycle(t, 4.0);
  final gaze = _ramp(u, 1.6, 1.9) * (1 - _ramp(u, 3.6, 3.9));
  final look = _ramp(u, 1.6, 2.4) * (1 - _ramp(u, 3.6, 4.0));
  final root = MascotTransform(
    rotation: _deg(-2.5) * look + _deg(1.2) * _sine(t, 3.4),
    scaleX: idle.root.scaleX,
    scaleY: idle.root.scaleY,
  );
  double tap(double at) {
    final v = u - at;
    return v < 0 || v > 0.2 ? 0 : math.sin(v / 0.2 * math.pi);
  }

  final eyes = _blinkEyes(t);
  MascotTransform bubble(double appear, double phase) {
    final s = _spring(t - appear) * (1 + 0.1 * _sine(t, 1.8, phase));
    return MascotTransform(
      dy: -1.5 * _sine(t, 2.4, phase),
      scaleX: s,
      scaleY: s,
    );
  }

  return MascotPose(root, {
    MascotPart.shadow: _shadowUnder(root),
    MascotPart.steamLeft: idle.steamLeft,
    MascotPart.steamRight: idle.steamRight,
    MascotPart.armLeft: MascotTransform(rotation: _deg(3) * _sine(t, 2.6)),
    MascotPart.eyes: eyes,
    MascotPart.pupils: MascotTransform(dx: -4 * gaze, scaleY: eyes.scaleY),
    MascotPart.mouth: MascotTransform(dx: -1.2 * look),
    MascotPart.hand: MascotTransform(
      rotation: _deg(-6) * (tap(0.4) + tap(0.75)),
    ),
    MascotPart.bubbleSmall: bubble(0.15, 0),
    MascotPart.bubbleLarge: bubble(0.4, -1.2),
  });
}

/// A failed round: slow breath, a sigh every 5 s, a tear that keeps
/// rolling.
MascotPose _sad(double t) {
  final idle = _idle(t, calm: true);
  final s = _cycle(t, 5.0, 0.8);
  final sigh = s < 0 ? 0.0 : _window(s, 0, 0.5, 0.9, 1.9);
  final root = MascotTransform(
    dy: 3.5 * sigh,
    scaleX: idle.root.scaleX * (1 + 0.04 * sigh),
    scaleY: idle.root.scaleY * (1 - 0.05 * sigh),
  );
  final eyes = _blinkEyes(t, slow: true);

  // The tear grows under the eye, holds, rolls down and fades.
  final u = (t + 0.4) % 2.8;
  final MascotTransform tear;
  if (u < 0.4) {
    final g = _ramp(u, 0, 0.4);
    tear = MascotTransform(scaleX: g, scaleY: g);
  } else if (u < 1.0) {
    tear = MascotTransform(scaleY: 1 + 0.05 * _sine(u, 0.3));
  } else if (u < 2.0) {
    final p = u - 1.0;
    tear = MascotTransform(dy: 14 * p * p, opacity: 1 - _ramp(p, 0.6, 1));
  } else {
    tear = const MascotTransform(dy: 14, opacity: 0);
  }

  return MascotPose(root, {
    MascotPart.shadow: _shadowUnder(root),
    MascotPart.steamLeft: idle.steamLeft,
    MascotPart.steamRight: idle.steamRight,
    MascotPart.armLeft: MascotTransform(rotation: _deg(-9) * sigh),
    MascotPart.armRight: MascotTransform(rotation: _deg(9) * sigh),
    MascotPart.eyes: eyes,
    MascotPart.pupils: MascotTransform(dy: 1.5 * sigh, scaleY: eyes.scaleY),
    MascotPart.brows: MascotTransform(dy: -1.2 * sigh),
    MascotPart.mouth: MascotTransform(dy: 0.5 * sigh),
    MascotPart.tear: tear,
  });
}
