import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:vector_graphics/vector_graphics_compat.dart'
    show RenderingStrategy;

/// The icons in `design-system/assets/icons/`.
enum KnzIcons {
  administrativeDistrict('administrative-district'),
  back('back'),
  calendar('calendar'),
  cinema('cinema'),
  close('close'),
  compass('compass'),
  directionSe('direction-se'),
  done('done'),
  elevation('elevation'),
  eye('eye'),
  flag('flag', coloured: true),

  /// The flag with a white pole, for ink surfaces (NAVŠTÍVENO label).
  flagOnDark('flag-on-dark', coloured: true),
  info('info'),
  key('key'),
  locate('locate'),
  lock('lock'),
  logoPin('logo-pin', coloured: true),
  map('map'),
  municipality('municipality'),
  navigate('navigate'),
  next('next'),
  place('place'),

  /// Several players: the multiplayer game mode (added).
  players('players'),
  profile('profile'),
  share('share'),
  signOut('sign-out'),
  skip('skip'),
  spring('spring'),
  starEmpty('star-empty', coloured: true),
  star('star', coloured: true),
  swimming('swimming'),
  tap('tap'),

  /// A spa wafer (oplatka), the game's currency (added).
  wafer('wafer', coloured: true);

  const KnzIcons(this.file, {this.coloured = false});

  final String file;

  /// The icon has its own colours and ignores [KnzIcon.color].
  final bool coloured;

  String get asset => 'design-system/assets/icons/$file.svg';
}

/// A design system icon. Stroke icons take [color] (`currentColor`), or the
/// ambient [IconTheme] colour. Icons are decorative; give the surrounding
/// control the text label.
///
/// The icon is drawn with [RenderingStrategy.raster]: it is rasterised once
/// per asset and physical size (logical size × device pixel ratio), shared
/// between all icons of that size, and the tint is applied to the image
/// paint. The default picture strategy wraps every tinted icon in an
/// offscreen layer (`saveLayer`) on every paint, which makes animation and
/// scrolling lag in mobile browsers. The raster does not follow ancestor
/// scale transforms, so don't enlarge an icon with `Transform.scale` or a
/// `FittedBox`; set [size] instead. Rotation is fine.
class KnzIcon extends StatelessWidget {
  const KnzIcon(this.icon, {super.key, this.size = 24, this.color});

  final KnzIcons icon;
  final double size;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final tint = color ?? IconTheme.of(context).color;
    return ExcludeSemantics(
      child: SvgPicture.asset(
        icon.asset,
        width: size,
        height: size,
        renderingStrategy: RenderingStrategy.raster,
        colorFilter: icon.coloured || tint == null
            ? null
            : ColorFilter.mode(tint, BlendMode.srcIn),
      ),
    );
  }
}
