import 'package:flutter/material.dart';

import 'design_system.dart';

/// A catalogue of the design system components in every sentiment and
/// state, at `/design-system`. The texts are samples, not game data.
class DesignSystemPage extends StatelessWidget {
  const DesignSystemPage({super.key});

  static const routeName = '/design-system';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KnzColors.surface,
      body: SafeArea(
        child: DefaultTextStyle(
          style: KnzText.body,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(
              KnzSize.screenGutter,
              KnzSpace.s8,
              KnzSize.screenGutter,
              KnzSpace.s28 * 2,
            ),
            children: [
              Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1040),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _Header(),
                      _ButtonsSection(),
                      _IconButtonsSection(),
                      _TextFieldsSection(),
                      _CardsSection(),
                      _ProgressSection(),
                      _PillsSection(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// The sentiments in display order, with a Czech caption.
const _sentiments = [
  (KnzSentiment.primary, 'primary · modrá'),
  (KnzSentiment.accent, 'accent · zlatá'),
  (KnzSentiment.danger, 'danger · červená'),
  (KnzSentiment.success, 'success · zelená'),
  (KnzSentiment.explore, 'explore · tyrkysová'),
  (KnzSentiment.neutral, 'neutral'),
];

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: KnzSpace.s8),
      child: Row(
        children: [
          Transform.translate(
            offset: const Offset(-10, 0),
            child: KnzIconButton(
              icon: KnzIcons.back,
              semanticLabel: 'Zpět',
              color: KnzColors.iconMuted,
              onPressed: () => Navigator.of(context).maybePop(),
            ),
          ),
          const KnzIcon(KnzIcons.logoPin, size: 30),
          const SizedBox(width: KnzSpace.s8),
          Expanded(
            child: Semantics(
              header: true,
              child: Text('Design system', style: KnzText.titleXl),
            ),
          ),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({
    required this.title,
    required this.description,
    required this.children,
  });

  final String title;
  final String description;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: KnzSpace.s28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Semantics(header: true, child: Text(title, style: KnzText.titleMd)),
          const SizedBox(height: KnzSpace.s4),
          Text(
            description,
            style: KnzText.bodySm.copyWith(color: KnzColors.textMuted),
          ),
          const SizedBox(height: KnzSpace.s16),
          for (final (i, child) in children.indexed) ...[
            if (i > 0) const SizedBox(height: KnzSpace.s20),
            child,
          ],
        ],
      ),
    );
  }
}

/// A captioned group of samples.
class _Group extends StatelessWidget {
  const _Group({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          label.toUpperCase(),
          style: KnzText.label.copyWith(color: KnzColors.textMuted),
        ),
        const SizedBox(height: KnzSpace.s10),
        child,
      ],
    );
  }
}

/// Lays samples out in columns of at least [minWidth].
class _Grid extends StatelessWidget {
  const _Grid({required this.children, this.minWidth = 240});

  final List<Widget> children;
  final double minWidth;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        const gap = KnzSpace.s12;
        final columns = ((constraints.maxWidth + gap) / (minWidth + gap))
            .floor()
            .clamp(1, children.length);
        final width = (constraints.maxWidth - gap * (columns - 1)) / columns;
        return Wrap(
          spacing: gap,
          runSpacing: KnzSpace.s14,
          children: [
            for (final child in children) SizedBox(width: width, child: child),
          ],
        );
      },
    );
  }
}

/// A sample with a small caption under it.
class _Sample extends StatelessWidget {
  const _Sample({required this.caption, required this.child});

  final String caption;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        child,
        const SizedBox(height: KnzSpace.s6),
        Text(
          caption,
          style: KnzText.micro.copyWith(color: KnzColors.textMuted),
        ),
      ],
    );
  }
}

void _noop() {}

class _ButtonsSection extends StatelessWidget {
  const _ButtonsSection();

  static const _solidLabels = {
    KnzSentiment.primary: 'Potvrdit tip',
    KnzSentiment.accent: 'Hrát místo dne',
    KnzSentiment.danger: 'Tipnout znovu',
    KnzSentiment.success: 'Pokračovat',
    KnzSentiment.explore: 'Luštit dál',
    KnzSentiment.neutral: 'Zavřít',
  };

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'Tlačítka',
      description:
          'Barva nese stav hry. Stiskni tlačítko a uvidíš 3D hranu, '
          'na webu zkus i najetí myší a Tab.',
      children: [
        _Group(
          label: 'Plná',
          child: _Grid(
            children: [
              for (final (sentiment, caption) in _sentiments)
                _Sample(
                  caption: caption,
                  child: KnzButton(
                    label: _solidLabels[sentiment]!,
                    sentiment: sentiment,
                    onPressed: _noop,
                  ),
                ),
            ],
          ),
        ),
        _Group(
          label: 'Vedlejší',
          child: _Grid(
            children: [
              for (final (sentiment, caption) in _sentiments)
                _Sample(
                  caption: caption,
                  child: KnzButton(
                    label: 'Sdílet',
                    icon: KnzIcons.share,
                    sentiment: sentiment,
                    variant: KnzButtonVariant.secondary,
                    onPressed: _noop,
                  ),
                ),
            ],
          ),
        ),
        _Group(
          label: 'Textová',
          child: _Grid(
            children: [
              for (final (sentiment, caption) in _sentiments)
                _Sample(
                  caption: caption,
                  child: KnzButton(
                    label: 'Zpět domů',
                    sentiment: sentiment,
                    variant: KnzButtonVariant.ghost,
                    size: KnzButtonSize.small,
                    onPressed: _noop,
                  ),
                ),
            ],
          ),
        ),
        const _Group(
          label: 'Neaktivní',
          child: _Grid(
            children: [
              _Sample(
                caption: 'solid',
                child: KnzButton(label: 'Luštit dál', onPressed: null),
              ),
              _Sample(
                caption: 'secondary',
                child: KnzButton(
                  label: 'Přeskočit',
                  icon: KnzIcons.skip,
                  variant: KnzButtonVariant.secondary,
                  onPressed: null,
                ),
              ),
              _Sample(
                caption: 'ghost',
                child: KnzButton(
                  label: 'Zkusit bez účtu',
                  variant: KnzButtonVariant.ghost,
                  size: KnzButtonSize.small,
                  onPressed: null,
                ),
              ),
            ],
          ),
        ),
        _Group(
          label: 'Velikosti a vedle sebe',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const _Grid(
                children: [
                  _Sample(
                    caption: 'cta · 54 px',
                    child: KnzButton(
                      label: 'Navigovat na místo',
                      icon: KnzIcons.navigate,
                      size: KnzButtonSize.cta,
                      onPressed: _noop,
                    ),
                  ),
                  _Sample(
                    caption: 'regular · 52 px',
                    child: KnzButton(label: 'Přihlásit se', onPressed: _noop),
                  ),
                  _Sample(
                    caption: 'small · 44 px',
                    child: KnzButton(
                      label: 'Sdílet',
                      size: KnzButtonSize.small,
                      sentiment: KnzSentiment.success,
                      onPressed: _noop,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: KnzSpace.s14),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 390),
                child: const _Sample(
                  caption: 'trefa: SDÍLET + POKRAČOVAT, mezera 10',
                  child: Row(
                    children: [
                      Expanded(
                        child: KnzButton(
                          label: 'Sdílet',
                          icon: KnzIcons.share,
                          variant: KnzButtonVariant.secondary,
                          onPressed: _noop,
                        ),
                      ),
                      SizedBox(width: KnzSpace.s10),
                      Expanded(
                        child: KnzButton(
                          label: 'Pokračovat',
                          sentiment: KnzSentiment.success,
                          onPressed: _noop,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _IconButtonsSection extends StatelessWidget {
  const _IconButtonsSection();

  @override
  Widget build(BuildContext context) {
    return const _Section(
      title: 'Ikonová tlačítka',
      description: 'Dotyková plocha 44 × 44 px, vždy s popisem pro čtečku.',
      children: [
        Wrap(
          spacing: KnzSpace.s16,
          runSpacing: KnzSpace.s12,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            KnzIconButton(
              icon: KnzIcons.close,
              semanticLabel: 'Zavřít',
              onPressed: _noop,
            ),
            KnzIconButton(
              icon: KnzIcons.back,
              semanticLabel: 'Zpět',
              color: KnzColors.iconMuted,
              onPressed: _noop,
            ),
            KnzIconButton(
              icon: KnzIcons.back,
              semanticLabel: 'Zpět na mapu',
              raised: true,
              onPressed: _noop,
            ),
            KnzIconButton(
              icon: KnzIcons.share,
              semanticLabel: 'Sdílet',
              onPressed: null,
            ),
          ],
        ),
      ],
    );
  }
}

class _TextFieldsSection extends StatefulWidget {
  const _TextFieldsSection();

  @override
  State<_TextFieldsSection> createState() => _TextFieldsSectionState();
}

class _TextFieldsSectionState extends State<_TextFieldsSection> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _filled = TextEditingController(text: 'vridlik@example.cz');
  final _password = TextEditingController(text: 'tajneheslo');

  @override
  void dispose() {
    _email.dispose();
    _filled.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'Pole formuláře',
      description:
          'Popisek nad polem, při psaní modrý rámeček, chyba červeně '
          'pod polem.',
      children: [
        _Grid(
          minWidth: 300,
          children: [
            const _Sample(
              caption: 'výchozí s nápovědou',
              child: KnzTextField(
                label: 'E-mail',
                placeholder: 'ty@example.cz',
                keyboardType: TextInputType.emailAddress,
              ),
            ),
            _Sample(
              caption: 'vyplněné',
              child: KnzTextField(label: 'E-mail', controller: _filled),
            ),
            _Sample(
              caption: 'heslo s odkazem u popisku',
              child: KnzTextField(
                label: 'Heslo',
                controller: _password,
                password: true,
                labelLink: (label: 'Zapomenuté heslo?', onPressed: _noop),
              ),
            ),
            const _Sample(
              caption: 'chyba',
              child: KnzTextField(
                label: 'Přezdívka',
                placeholder: 'Jak ti máme říkat?',
                errorText: 'Přezdívka musí mít 2 až 100 znaků.',
              ),
            ),
            const _Sample(
              caption: 'neaktivní',
              child: KnzTextField(
                label: 'E-mail',
                placeholder: 'ty@example.cz',
                enabled: false,
              ),
            ),
          ],
        ),
        _Group(
          label: 'Ověření ve formuláři',
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 390),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  KnzTextField(
                    label: 'E-mail',
                    controller: _email,
                    placeholder: 'ty@example.cz',
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) =>
                        (value ?? '').contains('@') ? null : 'Zadej e-mail.',
                  ),
                  const SizedBox(height: KnzSpace.s14),
                  KnzButton(
                    label: 'Ověřit',
                    onPressed: () => _formKey.currentState!.validate(),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _CardsSection extends StatelessWidget {
  const _CardsSection();

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'Karty',
      description:
          'Bílá karta s rámečkem, tónovaná, plná a čárkovaná. Karta '
          's odkazem se dá stisknout.',
      children: [
        for (final variant in KnzCardVariant.values.where(
          (v) => v != KnzCardVariant.dashed,
        ))
          _Group(
            label: switch (variant) {
              KnzCardVariant.outlined => 'S rámečkem',
              KnzCardVariant.tinted => 'Tónovaná',
              KnzCardVariant.solid => 'Plná',
              KnzCardVariant.dashed => 'Čárkovaná',
            },
            child: _Grid(
              children: [
                for (final (sentiment, caption) in _sentiments)
                  _Sample(
                    caption: caption,
                    child: KnzCard(
                      sentiment: sentiment,
                      variant: variant,
                      child: _CardContent(
                        sentiment: sentiment,
                        onSolid: variant == KnzCardVariant.solid,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        _Group(
          label: 'Čárkovaná a s odkazem',
          child: _Grid(
            children: [
              _Sample(
                caption: 'dashed · zamčený klíč',
                child: KnzCard(
                  variant: KnzCardVariant.dashed,
                  radius: KnzRadius.md,
                  child: Row(
                    children: [
                      const KnzIcon(
                        KnzIcons.lock,
                        size: 16,
                        color: KnzColors.iconSubtle,
                      ),
                      const SizedBox(width: KnzSpace.s8),
                      Text(
                        'Okolí',
                        style: KnzText.caption.copyWith(
                          color: KnzColors.iconMuted,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              _Sample(
                caption: 'onPressed · řádek s odkazem',
                child: KnzCard(
                  onPressed: _noop,
                  padding: const EdgeInsets.symmetric(
                    horizontal: KnzSpace.s16,
                    vertical: KnzSpace.s14,
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: KnzSize.iconTile,
                        height: KnzSize.iconTile,
                        decoration: BoxDecoration(
                          color: KnzColors.exploreTint,
                          borderRadius: BorderRadius.circular(KnzRadius.md),
                        ),
                        alignment: Alignment.center,
                        child: const KnzIcon(
                          KnzIcons.compass,
                          color: KnzColors.exploreText,
                        ),
                      ),
                      const SizedBox(width: KnzSpace.s14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Luštit dál', style: KnzText.cardTitle),
                            Text(
                              'Další místa bez omezení',
                              style: KnzText.bodySm.copyWith(
                                color: KnzColors.textMuted,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const KnzIcon(
                        KnzIcons.next,
                        size: 22,
                        color: KnzColors.iconSubtle,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _CardContent extends StatelessWidget {
  const _CardContent({required this.sentiment, required this.onSolid});

  final KnzSentiment sentiment;
  final bool onSolid;

  @override
  Widget build(BuildContext context) {
    final c = sentiment.colors;
    final labelColor = onSolid ? c.onSolid : c.ink;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            KnzIcon(KnzIcons.key, size: 16, color: labelColor),
            const SizedBox(width: KnzSpace.s6),
            Flexible(
              child: Text(
                'KLÍČ 1 · HÁDANKA',
                style: KnzText.label.copyWith(color: labelColor),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: KnzSpace.s6),
        Text(
          'Ukázkový text karty.',
          style: KnzText.clue.copyWith(
            color: onSolid ? c.onSolid : KnzColors.text,
          ),
        ),
      ],
    );
  }
}

class _ProgressSection extends StatelessWidget {
  const _ProgressSection();

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'Postup',
      description:
          'Pruh postupu oblasti a ukazatel pokusů. I malý postup je vidět.',
      children: [
        _Group(
          label: 'Pruh v barvě sentimentu',
          child: _Grid(
            minWidth: 320,
            children: [
              for (final (i, (sentiment, caption)) in _sentiments.indexed)
                _Sample(
                  caption: caption,
                  child: KnzProgressRow(
                    label: 'Oblast ${i + 1}',
                    count: [9, 3, 40, 148, 1, 0][i],
                    total: 148,
                    sentiment: sentiment,
                    height: 12,
                  ),
                ),
            ],
          ),
        ),
        const _Group(
          label: 'Výšky',
          child: _Grid(
            minWidth: 320,
            children: [
              _Sample(
                caption: '10 px · Domů',
                child: KnzProgressBar(value: 0.35, semanticLabel: 'Ukázka'),
              ),
              _Sample(
                caption: '12 px · Moje mapa',
                child: KnzProgressBar(
                  value: 0.35,
                  height: 12,
                  semanticLabel: 'Ukázka',
                ),
              ),
            ],
          ),
        ),
        _Group(
          label: 'Odznaky',
          child: Wrap(
            spacing: KnzSpace.s8,
            runSpacing: KnzSpace.s16,
            children: [
              for (final (label, icon, sentiment, count, goal) in [
                ('První trefa', KnzIcons.place, KnzSentiment.primary, 1, 1),
                ('Výletník', KnzIcons.navigate, KnzSentiment.accent, 3, 1),
                (
                  'Celé Sokolovsko',
                  KnzIcons.map,
                  KnzSentiment.explore,
                  131,
                  131,
                ),
                ('Celé Chebsko', KnzIcons.map, KnzSentiment.primary, 9, 148),
              ])
                SizedBox(
                  width: 84,
                  child: KnzBadge(
                    label: label,
                    icon: icon,
                    sentiment: sentiment,
                    count: count,
                    goal: goal,
                  ),
                ),
            ],
          ),
        ),
        const _Group(
          label: 'Pokusy',
          child: _Grid(
            minWidth: 300,
            children: [
              _Sample(
                caption: 'pokus 1 z 5',
                child: KnzAttemptProgress(missed: 0, total: 5),
              ),
              _Sample(
                caption: 'pokus 3 z 5',
                child: KnzAttemptProgress(missed: 2, total: 5),
              ),
              _Sample(
                caption: 'všech 5 vyčerpáno',
                child: KnzAttemptProgress(missed: 5, total: 5),
              ),
              _Sample(
                caption: 'explore · Luštit dál, 12 px',
                child: KnzAttemptProgress(
                  missed: 1,
                  total: 5,
                  sentiment: KnzSentiment.explore,
                  height: 12,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _PillsSection extends StatelessWidget {
  const _PillsSection();

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'Štítky',
      description: 'Tónované pro typ místa, plné pro stav.',
      children: [
        for (final tinted in [true, false])
          _Group(
            label: tinted ? 'Tónované' : 'Plné',
            child: Wrap(
              spacing: KnzSpace.s8,
              runSpacing: KnzSpace.s8,
              children: [
                for (final (sentiment, _) in _sentiments)
                  KnzPill(
                    label: sentiment.name,
                    sentiment: sentiment,
                    tinted: tinted,
                    icon: tinted ? null : KnzIcons.done,
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
