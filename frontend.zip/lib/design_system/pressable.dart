import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

/// The interaction state of a [KnzPressable].
@immutable
class KnzPressState {
  const KnzPressState({
    required this.enabled,
    required this.pressed,
    required this.hovered,
    required this.focused,
  });

  final bool enabled;
  final bool pressed;
  final bool hovered;

  /// Focused from the keyboard (`:focus-visible`), not by a tap.
  final bool focused;
}

/// Tap, hover, keyboard focus and activation for the 3D surfaces.
///
/// Disabled when [onPressed] is null. Enter and Space activate it.
class KnzPressable extends StatefulWidget {
  const KnzPressable({
    super.key,
    required this.onPressed,
    required this.builder,
    this.semanticLabel,
    this.isLink = false,
  });

  final VoidCallback? onPressed;
  final Widget Function(BuildContext context, KnzPressState state) builder;

  /// Overrides the label read from the child, for icon-only controls.
  final String? semanticLabel;

  /// Announce it as a link rather than a button (a card that navigates).
  final bool isLink;

  @override
  State<KnzPressable> createState() => _KnzPressableState();
}

class _KnzPressableState extends State<KnzPressable> {
  bool _pressed = false;
  bool _hovered = false;
  bool _focused = false;

  bool get _enabled => widget.onPressed != null;

  void _setPressed(bool value) {
    if (_pressed != value) setState(() => _pressed = value);
  }

  @override
  void didUpdateWidget(KnzPressable old) {
    super.didUpdateWidget(old);
    if (!_enabled) _pressed = false;
  }

  @override
  Widget build(BuildContext context) {
    final focusVisible =
        _focused &&
        FocusManager.instance.highlightMode == FocusHighlightMode.traditional;
    return Semantics(
      button: !widget.isLink,
      link: widget.isLink,
      enabled: _enabled,
      label: widget.semanticLabel,
      excludeSemantics: widget.semanticLabel != null,
      child: FocusableActionDetector(
        enabled: _enabled,
        mouseCursor: _enabled
            ? SystemMouseCursors.click
            : SystemMouseCursors.basic,
        onShowHoverHighlight: (value) => setState(() => _hovered = value),
        onShowFocusHighlight: (value) => setState(() => _focused = value),
        shortcuts: const {
          SingleActivator(LogicalKeyboardKey.enter): ActivateIntent(),
          SingleActivator(LogicalKeyboardKey.space): ActivateIntent(),
        },
        actions: {
          ActivateIntent: CallbackAction<ActivateIntent>(
            onInvoke: (_) {
              widget.onPressed?.call();
              return null;
            },
          ),
        },
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: _enabled ? (_) => _setPressed(true) : null,
          onTapUp: _enabled ? (_) => _setPressed(false) : null,
          onTapCancel: _enabled ? () => _setPressed(false) : null,
          onTap: widget.onPressed,
          child: widget.builder(
            context,
            KnzPressState(
              enabled: _enabled,
              pressed: _pressed,
              hovered: _hovered && _enabled,
              focused: focusVisible,
            ),
          ),
        ),
      ),
    );
  }
}
