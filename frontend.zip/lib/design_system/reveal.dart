import 'package:flutter/widgets.dart';

import 'tokens.dart';

/// Shows [child] as [animation] runs from 0 to 1: it fades in, rises a
/// little and settles from a slightly smaller size with a small overshoot.
/// Used for a clue or the compass that a guess has just unlocked.
///
/// The tree stays the same at every value, so the child keeps its state
/// when the reveal ends.
class KnzReveal extends StatelessWidget {
  const KnzReveal({super.key, required this.animation, required this.child});

  final Animation<double> animation;
  final Widget child;

  /// How far the child rises, in logical pixels.
  static const _rise = KnzSpace.s12;

  /// The size the child starts from.
  static const _startScale = 0.94;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      child: child,
      builder: (context, child) {
        final t = animation.value.clamp(0.0, 1.0);
        final ease = KnzMotion.easeOut.transform(t);
        final scale = KnzMotion.bounce.transform(t);
        return Opacity(
          opacity: ease,
          child: Transform.translate(
            offset: Offset(0, _rise * (1 - ease)),
            child: Transform.scale(
              scale: _startScale + (1 - _startScale) * scale,
              child: child,
            ),
          ),
        );
      },
    );
  }
}
