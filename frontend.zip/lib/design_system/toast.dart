import 'package:flutter/material.dart';

import 'tokens.dart';

/// A short factual message at the bottom of the screen (`components.md`,
/// Toast): white text on an ink pill, no shadow.
abstract final class KnzToast {
  /// Shows [message], replacing any toast already on screen.
  ///
  /// [above] is the height of a footer the toast must not cover, such as
  /// the main action of a game screen.
  static void show(BuildContext context, String message, {double above = 0}) {
    ScaffoldMessenger.maybeOf(context)
      ?..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            message,
            style: KnzText.weight(
              KnzText.bodySm,
              800,
            ).copyWith(color: KnzColors.textOnPrimary),
          ),
          behavior: SnackBarBehavior.floating,
          backgroundColor: KnzColors.text,
          elevation: 0,
          margin: EdgeInsets.fromLTRB(
            KnzSize.screenGutter,
            0,
            KnzSize.screenGutter,
            KnzSpace.s12 + above,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(KnzRadius.md),
          ),
        ),
      );
  }
}
