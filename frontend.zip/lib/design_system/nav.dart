import 'dart:math' as math;

import 'package:flutter/widgets.dart';

import 'icon.dart';
import 'pressable.dart';
import 'tokens.dart';

/// One item of a [KnzBottomNav].
@immutable
class KnzNavItem {
  const KnzNavItem({required this.icon, required this.label});

  final KnzIcons icon;

  /// One word; shown in CAPITAL LETTERS ("Dnes", "Minihry", "Profil").
  final String label;
}

/// The bottom navigation of the main screens (`components.md`, BottomNav).
///
/// The active item has its icon in a tinted pill and is announced as
/// selected (`aria-current="page"`).
class KnzBottomNav extends StatelessWidget {
  const KnzBottomNav({
    super.key,
    required this.items,
    required this.currentIndex,
    required this.onSelected,
  });

  final List<KnzNavItem> items;
  final int currentIndex;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.paddingOf(context).bottom;
    return DecoratedBox(
      decoration: const BoxDecoration(
        color: KnzColors.surface,
        border: Border(
          top: BorderSide(color: KnzColors.border, width: KnzDepth.border),
        ),
      ),
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          KnzSpace.s14,
          KnzSpace.s10,
          KnzSpace.s14,
          math.max(KnzSpace.s10 + bottomInset, 22),
        ),
        child: Row(
          children: [
            for (var i = 0; i < items.length; i++)
              Expanded(
                child: _NavButton(
                  item: items[i],
                  active: i == currentIndex,
                  onPressed: () => onSelected(i),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  const _NavButton({
    required this.item,
    required this.active,
    required this.onPressed,
  });

  final KnzNavItem item;
  final bool active;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final color = active ? KnzColors.primary : KnzColors.textMuted;
    return Semantics(
      selected: active,
      child: KnzPressable(
        onPressed: onPressed,
        semanticLabel: item.label,
        builder: (context, state) => Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: KnzSpace.s18,
                vertical: KnzSpace.s6,
              ),
              decoration: BoxDecoration(
                color: active
                    ? KnzColors.primaryTint
                    : (state.hovered ? KnzColors.surfaceSubtle : null),
                borderRadius: BorderRadius.circular(KnzRadius.md),
                // A transparent frame on inactive items, so nothing shifts.
                border: Border.all(
                  color: active
                      ? KnzPalette.blue200
                      : KnzColors.surface.withValues(alpha: 0),
                  width: KnzDepth.border,
                ),
                boxShadow: state.focused ? KnzShadows.focus : null,
              ),
              child: KnzIcon(
                item.icon,
                size: KnzSize.iconNav,
                color: active ? KnzColors.primary : KnzColors.iconMuted,
              ),
            ),
            const SizedBox(height: KnzSpace.s6),
            Text(
              item.label.toUpperCase(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: KnzText.nav.copyWith(color: color),
            ),
          ],
        ),
      ),
    );
  }
}
