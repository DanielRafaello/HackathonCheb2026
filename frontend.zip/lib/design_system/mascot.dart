import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'edge_box.dart';
import 'mascot_motion.dart';
import 'tokens.dart';

/// Vřídlík's moods (`design-system/assets/mascot/`).
enum KnzMood {
  /// Hello: home, sign-in.
  wave('mascot-wave'),

  /// While guessing.
  think('mascot-think'),

  /// A hit, a visit.
  cheer('mascot-cheer'),

  /// A failed round.
  sad('mascot-sad'),

  /// The default.
  happy('mascot-happy');

  const KnzMood(this.file);

  final String file;

  String get asset => 'design-system/assets/mascot/$file.svg';
}

/// Vřídlík, [width] wide. The height is always width × 7/6; the mascot is
/// never distorted or recoloured. Decorative: the speech bubble carries the
/// text.
///
/// Vřídlík moves by its [mood] (`DESIGN.md`, Mascot motion) unless [animate]
/// is false or the platform asks to reduce motion; then it stands still as
/// drawn. While it moves, each layer of the drawing is rasterised once into
/// an image and a frame only places the images, at about 30 fps.
class KnzMascot extends StatefulWidget {
  const KnzMascot({
    super.key,
    this.mood = KnzMood.happy,
    this.width = 88,
    this.animate = true,
  });

  final KnzMood mood;
  final double width;
  final bool animate;

  @override
  State<KnzMascot> createState() => _KnzMascotState();
}

class _KnzMascotState extends State<KnzMascot>
    with SingleTickerProviderStateMixin {
  late final Ticker _ticker = createTicker(_tick);
  final _time = ValueNotifier<double>(0);
  List<_LoadedLayer>? _layers;
  _LayerImages? _images;

  /// Unmutes the ticker when the next frame is due.
  Timer? _wake;

  /// The shortest time between two frames: about 30 fps, which is enough for
  /// Vřídlík's slow moves. On the web every frame redraws the whole page.
  /// A little less than 1/30 s, so that a vsync just after it is not missed.
  static const _frameTime = Duration(milliseconds: 29);

  /// Layers are rasterised a little larger than they are drawn, so that the
  /// parts that grow while they move stay sharp.
  static const _supersample = 1.25;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _sync();
  }

  @override
  void didUpdateWidget(KnzMascot oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.mood != widget.mood) {
      _layers = null;
      _dropImages();
      _stop();
    }
    _sync();
  }

  bool get _moving =>
      widget.animate &&
      !(MediaQuery.maybeDisableAnimationsOf(context) ?? false);

  /// Loads the layers of the current mood and starts the clock once they
  /// are there; stops it when Vřídlík should stand still.
  void _sync() {
    if (!_moving) {
      _stop();
      _dropImages();
      return;
    }
    if (_layers != null) {
      if (!_ticker.isActive) _start();
      return;
    }
    final mood = widget.mood;
    _MascotLayers.of(mood).then((layers) {
      if (!mounted || widget.mood != mood || !_moving) return;
      setState(() => _layers = layers);
      _start();
    }, onError: (Object _) {}); // Stays the static drawing.
  }

  void _start() {
    _stop();
    _time.value = 0;
    _ticker.start();
  }

  void _stop() {
    _wake?.cancel();
    _wake = null;
    _ticker.stop();
    _unmute();
  }

  /// Gives the ticker back to [TickerMode].
  void _unmute() {
    _ticker.muted = !TickerMode.getValuesNotifier(context).value.enabled;
  }

  void _tick(Duration elapsed) {
    _time.value = elapsed.inMicroseconds / Duration.microsecondsPerSecond;
    // Ask for no frames until the next one is due. A muted ticker keeps its
    // clock, and the pose depends on the time alone.
    _ticker.muted = true;
    _wake?.cancel();
    _wake = Timer(_frameTime, () {
      _wake = null;
      if (mounted) _unmute();
    });
  }

  void _dropImages() {
    _images?.dispose();
    _images = null;
  }

  @override
  void dispose() {
    _wake?.cancel();
    _ticker.dispose();
    _time.dispose();
    _dropImages();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = Size(widget.width, widget.width * 7 / 6);
    final layers = _layers;
    if (layers == null || !_moving) {
      return SvgPicture.asset(
        widget.mood.asset,
        width: size.width,
        height: size.height,
        excludeFromSemantics: true,
      );
    }
    final scale =
        size.width /
        _viewBox.width *
        (MediaQuery.maybeDevicePixelRatioOf(context) ?? 1) *
        _supersample;
    var images = _images;
    if (images == null || images.layers != layers || images.scale != scale) {
      _dropImages();
      images = _images = _LayerImages(layers, scale);
    }
    return RepaintBoundary(
      child: CustomPaint(
        size: size,
        painter: _MascotPainter(widget.mood, images, _time),
      ),
    );
  }
}

/// The viewBox of every mood's SVG.
const _viewBox = Rect.fromLTWH(0, 0, 120, 140);

Rect _divide(Rect rect, double by) => Rect.fromLTRB(
  rect.left / by,
  rect.top / by,
  rect.right / by,
  rect.bottom / by,
);

class _LoadedLayer {
  const _LoadedLayer(this.part, this.picture, this.bounds);

  final MascotPart part;
  final ui.Picture picture;

  /// Where the layer has ink, in viewBox units; null when it has none.
  final Rect? bounds;
}

/// The layers of each mood, decoded once and kept for the life of the app
/// (five small drawings), each with the area it covers.
abstract final class _MascotLayers {
  static final _cache = <KnzMood, Future<List<_LoadedLayer>>>{};

  static Future<List<_LoadedLayer>> of(KnzMood mood) =>
      _cache[mood] ??= _load(mood).catchError((Object error, StackTrace stack) {
        _cache.remove(mood); // Try again next time.
        Error.throwWithStackTrace(error, stack);
      });

  static Future<List<_LoadedLayer>> _load(KnzMood mood) async {
    final svg = await rootBundle.loadString(mood.asset);
    final layers = mascotLayers(svg, mood);
    return [for (final layer in layers) await _loadLayer(layer)];
  }

  static Future<_LoadedLayer> _loadLayer(MascotLayer layer) async {
    final picture = (await vg.loadPicture(
      SvgStringLoader(layer.svg),
      null,
    )).picture;
    return _LoadedLayer(layer.part, picture, await _inkBounds(picture));
  }

  /// Where [_inkBounds] looks for ink: the viewBox with a margin, in case a
  /// drawing reaches past it.
  static final _probeArea = _viewBox.inflate(20);
  static const _probeScale = 2.0;

  /// The area [picture] covers, found once by drawing it small and reading
  /// the pixels back. When that fails, the whole [_probeArea].
  static Future<Rect?> _inkBounds(ui.Picture picture) async {
    final width = (_probeArea.width * _probeScale).ceil();
    final height = (_probeArea.height * _probeScale).ceil();
    final recorder = ui.PictureRecorder();
    Canvas(recorder)
      ..scale(_probeScale)
      ..translate(-_probeArea.left, -_probeArea.top)
      ..drawPicture(picture);
    final probe = recorder.endRecording();
    ui.Image? image;
    try {
      image = await probe.toImage(width, height);
      final data = await image.toByteData();
      if (data == null) return _probeArea;
      final rgba = data.buffer.asUint8List(
        data.offsetInBytes,
        data.lengthInBytes,
      );
      var left = width, top = height, right = -1, bottom = -1;
      for (var y = 0; y < height; y++) {
        for (var x = 0; x < width; x++) {
          if (rgba[(y * width + x) * 4 + 3] == 0) continue;
          if (x < left) left = x;
          if (x > right) right = x;
          if (y < top) top = y;
          bottom = y;
        }
      }
      if (right < 0) return null;
      return _divide(
        Rect.fromLTRB(
          left.toDouble(),
          top.toDouble(),
          right + 1.0,
          bottom + 1.0,
        ),
        _probeScale,
      ).shift(_probeArea.topLeft);
    } on Object {
      return _probeArea;
    } finally {
      image?.dispose();
      probe.dispose();
    }
  }
}

/// One layer rasterised: [image] covers [rect] of the viewBox.
class _LayerImage {
  const _LayerImage(this.picture, this.image, this.rect);

  final ui.Picture picture;
  final ui.Image image;
  final Rect rect;
}

/// The layers of one mood rasterised once at [scale] device pixels per
/// viewBox unit, so that a frame only draws images.
class _LayerImages {
  _LayerImages(this.layers, this.scale)
    : images = [for (final layer in layers) _rasterise(layer, scale)];

  final List<_LoadedLayer> layers;
  final double scale;

  /// One for each of [layers]; null for a layer without ink.
  final List<_LayerImage?> images;

  static _LayerImage? _rasterise(_LoadedLayer layer, double scale) {
    final bounds = layer.bounds;
    if (bounds == null) return null;
    // Whole pixels, so that the image is not stretched, and a pixel of
    // margin for the anti-aliased edge.
    final pixels = Rect.fromLTRB(
      (bounds.left * scale).floorToDouble() - 1,
      (bounds.top * scale).floorToDouble() - 1,
      (bounds.right * scale).ceilToDouble() + 1,
      (bounds.bottom * scale).ceilToDouble() + 1,
    );
    final recorder = ui.PictureRecorder();
    Canvas(recorder)
      ..translate(-pixels.left, -pixels.top)
      ..scale(scale)
      ..drawPicture(layer.picture);
    final picture = recorder.endRecording();
    final image = picture.toImageSync(
      pixels.width.toInt(),
      pixels.height.toInt(),
    );
    return _LayerImage(picture, image, _divide(pixels, scale));
  }

  void dispose() {
    for (final layer in images) {
      layer?.image.dispose();
      layer?.picture.dispose();
    }
  }
}

/// Draws each layer's image where the pose puts it. The opacity goes into
/// the paint, so no frame needs an offscreen layer.
class _MascotPainter extends CustomPainter {
  _MascotPainter(this.mood, this.images, this.time) : super(repaint: time);

  final KnzMood mood;
  final _LayerImages images;
  final ValueListenable<double> time;

  static void _apply(Canvas canvas, MascotTransform move, Offset pivot) {
    canvas
      ..translate(pivot.dx + move.dx, pivot.dy + move.dy)
      ..rotate(move.rotation)
      ..scale(move.scaleX, move.scaleY)
      ..translate(-pivot.dx, -pivot.dy);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final pose = MascotPose.at(mood, time.value);
    final paint = Paint()..filterQuality = FilterQuality.medium;
    canvas
      ..save()
      ..scale(size.width / _viewBox.width, size.height / _viewBox.height);
    for (var i = 0; i < images.layers.length; i++) {
      final layer = images.images[i];
      if (layer == null) continue;
      final part = images.layers[i].part;
      final move = pose[part];
      if (move.opacity <= 0 || move.scaleX == 0 || move.scaleY == 0) continue;
      canvas.save();
      if (part != MascotPart.shadow) {
        _apply(canvas, pose.root, MascotPose.rootPivot);
      }
      _apply(canvas, move, MascotPose.pivot(mood, part));
      paint.color = Color.fromRGBO(0, 0, 0, math.min(move.opacity, 1));
      final image = layer.image;
      canvas.drawImageRect(
        image,
        Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
        layer.rect,
        paint,
      );
      canvas.restore();
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(_MascotPainter old) =>
      old.mood != mood || old.images != images || old.time != time;
}

/// Vřídlík with a speech bubble (`components.md`, SpeechBubble). The mascot
/// speaks; the rest of the UI stays factual.
class KnzSpeechBubble extends StatelessWidget {
  const KnzSpeechBubble({
    super.key,
    this.text,
    this.child,
    this.mood = KnzMood.happy,
    this.mascotWidth = 84,
    this.raised = false,
  }) : assert((text == null) != (child == null), 'Give text or child.');

  /// What Vřídlík says, in `body-lg`.
  final String? text;

  /// Other content for the bubble, for example a clue.
  final Widget? child;
  final KnzMood mood;

  /// A 4 px bottom edge, for a clue in the bubble.
  final bool raised;

  /// 72–88 px.
  final double mascotWidth;

  static const _tail = 14.0;

  @override
  Widget build(BuildContext context) {
    final bubble = KnzEdgeBox(
      color: KnzColors.surface,
      edgeColor: KnzColors.border,
      radius: KnzRadius.xl,
      frame: KnzDepth.border,
      depth: raised ? KnzDepth.md : KnzDepth.border,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s14,
          vertical: KnzSpace.s12,
        ),
        child: child ?? Text(text!, style: KnzText.bodyLg),
      ),
    );
    return Row(
      children: [
        KnzMascot(mood: mood, width: mascotWidth),
        const SizedBox(width: KnzSpace.s12),
        Expanded(
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              bubble,
              // The tail: a square turned by 45° with a frame on its left
              // and bottom, pointing at the mascot's mouth.
              Positioned(
                left: -9,
                top: 0,
                bottom: 0,
                width: _tail,
                child: Center(
                  child: Transform.rotate(
                    angle: math.pi / 4,
                    child: Container(
                      width: _tail,
                      height: _tail,
                      decoration: const BoxDecoration(
                        color: KnzColors.surface,
                        border: Border(
                          left: BorderSide(
                            color: KnzColors.border,
                            width: KnzDepth.border,
                          ),
                          bottom: BorderSide(
                            color: KnzColors.border,
                            width: KnzDepth.border,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
