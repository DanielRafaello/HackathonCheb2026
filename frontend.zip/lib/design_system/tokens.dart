import 'package:flutter/widgets.dart';

// The design tokens of `design-system/tokens.json` as Dart constants.
//
// This file mirrors `design-system/tokens.css` (`--knz-*`). When a token
// changes, change all three files. This is the only place in `lib/` where
// colour values and sizes are written as literals; widgets use the names.

/// Primitive colours. Use them only in illustrations; components use
/// [KnzColors].
abstract final class KnzPalette {
  static const blue50 = Color(0xFFE6EEFC);
  static const blue100 = Color(0xFFDCE6FB);
  static const blue200 = Color(0xFF9DB8EE);
  static const blue300 = Color(0xFF7AA0F0);
  static const blue400 = Color(0xFF5A84E4);
  static const blue450 = Color(0xFF3D69D2);
  static const blue500 = Color(0xFF2B59C3);
  static const blue600 = Color(0xFF244CA8);
  static const blue700 = Color(0xFF1D3F91);
  static const blueOn = Color(0xFFCFE0FF);
  static const gold50 = Color(0xFFFFF8E1);
  static const gold100 = Color(0xFFF3E6BF);
  static const gold200 = Color(0xFFF1D98A);
  static const gold500 = Color(0xFFFFC531);
  static const gold600 = Color(0xFFE0A100);
  static const gold700 = Color(0xFFB98200);
  static const gold800 = Color(0xFF8A6100);
  static const gold900 = Color(0xFF6B5313);
  static const red50 = Color(0xFFFFEDEA);
  static const red100 = Color(0xFFFDE6E2);
  static const red200 = Color(0xFFF5C9C2);
  static const red300 = Color(0xFFF08A7E);
  static const red500 = Color(0xFFD63B2C);
  static const red700 = Color(0xFFA62A1D);
  static const red900 = Color(0xFF7A3A31);
  static const teal50 = Color(0xFFF2FBFC);
  static const teal100 = Color(0xFFDDF5F7);
  static const teal200 = Color(0xFF9BE4EB);
  static const teal300 = Color(0xFF7FCFDB);
  static const teal500 = Color(0xFF1FB2C1);
  static const teal600 = Color(0xFF148A97);
  static const teal800 = Color(0xFF0F6E79);
  static const green50 = Color(0xFFE7F5EB);
  static const green500 = Color(0xFF3BAA57);
  static const green600 = Color(0xFF2A8443);
  static const green700 = Color(0xFF23803D);
  static const green800 = Color(0xFF1D6331);
  static const ink950 = Color(0xFF0E1529);
  static const ink900 = Color(0xFF1E2A46);
  static const ink700 = Color(0xFF46506A);
  static const ink600 = Color(0xFF5A6580);
  static const ink500 = Color(0xFF6B7690);
  static const ink450 = Color(0xFF7C879E);
  static const ink400 = Color(0xFF8A94A8);
  static const ink350 = Color(0xFF9AA4B8);
  static const ink300 = Color(0xFFCDD5E1);
  static const ink250 = Color(0xFFD3DAE5);
  static const ink200 = Color(0xFFE2E7EF);
  static const ink150 = Color(0xFFE5EAF1);
  static const ink100 = Color(0xFFEEF1F6);
  static const ink75 = Color(0xFFF2F5F9);
  static const ink50 = Color(0xFFF5F8FC);
  static const ink0 = Color(0xFFFFFFFF);
  static const raisedMd = Color(0xFFB9C6DE);
}

/// Semantic colours. Colour carries the game state: blue = main action and
/// guessed, gold = stars and visited, red = guess and compass, turquoise =
/// free play, green = hit.
abstract final class KnzColors {
  static const text = KnzPalette.ink900;
  static const textSecondary = KnzPalette.ink700;
  static const textMuted = KnzPalette.ink600;
  static const textDisabled = KnzPalette.ink500;
  static const textPlaceholder = KnzPalette.ink400;
  static const textOnPrimary = KnzPalette.ink0;
  static const textLink = KnzPalette.blue500;
  static const textLinkHover = KnzPalette.blue700;
  static const iconMuted = KnzPalette.ink450;
  static const iconSubtle = KnzPalette.ink350;
  static const surface = KnzPalette.ink0;
  static const surfaceSubtle = KnzPalette.ink75;
  static const surfaceInput = KnzPalette.ink50;
  static const surfaceDisabled = KnzPalette.ink150;
  static const track = KnzPalette.ink100;
  static const border = KnzPalette.ink200;
  static const borderStrong = KnzPalette.ink250;
  static const focusRing = KnzPalette.blue100;

  static const primary = KnzPalette.blue500;
  static const primaryEdge = KnzPalette.blue700;
  static const primaryTint = KnzPalette.blue50;
  static const accent = KnzPalette.gold500;
  static const accentEdge = KnzPalette.gold600;
  static const accentText = KnzPalette.gold700;
  static const accentTint = KnzPalette.gold50;
  static const danger = KnzPalette.red500;
  static const dangerEdge = KnzPalette.red700;
  static const dangerTint = KnzPalette.red50;
  static const dangerSoft = KnzPalette.red300;
  static const success = KnzPalette.green500;
  static const successStrong = KnzPalette.green600;
  static const successEdge = KnzPalette.green800;
  static const successText = KnzPalette.green700;
  static const successTint = KnzPalette.green50;
  static const explore = KnzPalette.teal500;
  static const exploreEdge = KnzPalette.teal600;
  static const exploreText = KnzPalette.teal800;
  static const exploreTint = KnzPalette.teal100;

  static const stateGuessed = KnzPalette.blue500;
  static const stateVisited = KnzPalette.gold500;
  static const stateUnknown = KnzPalette.ink350;
  static const stateTip = KnzPalette.red500;
  static const stateHit = KnzPalette.green500;
}

/// Spacing scale (`--knz-space-*`).
abstract final class KnzSpace {
  static const s2 = 2.0;
  static const s4 = 4.0;
  static const s6 = 6.0;
  static const s8 = 8.0;
  static const s10 = 10.0;
  static const s12 = 12.0;
  static const s14 = 14.0;
  static const s16 = 16.0;
  static const s18 = 18.0;
  static const s20 = 20.0;
  static const s24 = 24.0;
  static const s28 = 28.0;
}

/// Corner radii (`--knz-radius-*`).
abstract final class KnzRadius {
  static const xs = 11.0;
  static const sm = 12.0;
  static const md = 14.0;
  static const lg = 16.0;
  static const xl = 18.0;
  static const xl2 = 20.0;
  static const xl3 = 22.0;
  static const xl4 = 24.0;
  static const sheet = 30.0;
  static const hero = 36.0;
  static const pill = 999.0;
}

/// Frame width and the 3D bottom edge (`--knz-border`, `--knz-depth-*`).
abstract final class KnzDepth {
  static const border = 2.0;
  static const sm = 3.0;
  static const md = 4.0;
  static const lg = 5.0;
  static const xl = 6.0;
}

/// Shadows. Only solid offsets and rings, never blur.
abstract final class KnzShadows {
  static const focus = [BoxShadow(color: KnzPalette.blue100, spreadRadius: 4)];
  static const raisedSm = [
    BoxShadow(color: KnzPalette.ink250, offset: Offset(0, 2)),
  ];
  static const raisedMd = [
    BoxShadow(color: KnzPalette.raisedMd, offset: Offset(0, 3)),
  ];
}

/// Component sizes (`--knz-size-*`).
abstract final class KnzSize {
  static const touch = 44.0;
  static const button = 52.0;
  static const buttonCta = 54.0;
  static const buttonSocial = 50.0;
  static const input = 50.0;
  static const iconTile = 48.0;
  static const iconNav = 26.0;
  static const progressSegment = 14.0;
  static const progressBar = 10.0;
  static const screenWidth = 390.0;
  static const screenGutter = 20.0;

  /// The lobby invite QR code **(added)**, big enough to scan from a phone
  /// held at arm's length.
  static const qrCode = 168.0;
}

/// Motion (`--knz-duration-*`). Callers turn it off when the platform asks
/// for reduced motion; see [KnzMotion.of].
abstract final class KnzMotion {
  static const fast = Duration(milliseconds: 120);
  static const base = Duration(milliseconds: 200);

  /// Panels and cards that enter or leave the screen.
  static const slow = Duration(milliseconds: 320);

  /// `--knz-ease-out`: things that enter, and leave when played backwards.
  static const easeOut = Curves.easeOutCubic;

  /// `--knz-ease-in-out`: things that move or change size on screen.
  static const easeInOut = Curves.easeInOutCubic;

  /// `--knz-ease-bounce`: a small overshoot for things that pop in.
  static const bounce = Cubic(0.34, 1.56, 0.64, 1);

  /// [duration], or zero when the platform asks to reduce motion.
  static Duration of(BuildContext context, Duration duration) =>
      MediaQuery.maybeDisableAnimationsOf(context) ?? false
      ? Duration.zero
      : duration;
}

/// Typography roles (`.knz-text-*`). Nunito 700–900 only.
///
/// Nunito is bundled as a variable font, so every style sets the `wght`
/// axis as well as [TextStyle.fontWeight].
abstract final class KnzText {
  static const fontFamily = 'Nunito';
  static const _fallback = ['Varela Round', 'sans-serif'];

  static TextStyle _role(
    double size,
    int weight, {
    double? height,
    double tracking = 0,
  }) => TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: _fallback,
    fontSize: size,
    fontWeight: FontWeight.values[weight ~/ 100 - 1],
    fontVariations: [FontVariation.weight(weight.toDouble())],
    height: height,
    letterSpacing: tracking,
    color: KnzColors.text,
  );

  static final display = _role(32, 900, height: 1.1, tracking: -0.5);
  static final titleXl = _role(28, 900, height: 1.15, tracking: -0.4);
  static final titleLg = _role(25, 900, height: 1.15, tracking: -0.3);
  static final titleMd = _role(22, 900, height: 1.2);
  static final titleSm = _role(18, 900, height: 1.2);
  static final cardTitle = _role(17, 900, height: 1.25);
  static final clue = _role(19, 800, height: 1.3);
  static final bodyLg = _role(16, 800, height: 1.35);
  static final body = _role(15, 700, height: 1.4);
  static final bodySm = _role(14, 700, height: 1.4);
  static final caption = _role(13, 800, height: 1.3);
  static final micro = _role(12, 800, height: 1.3);

  // The roles below are written in CAPITAL LETTERS; pass the text in
  // capitals (Flutter has no text-transform).
  static final overline = _role(13, 900, height: 1.3, tracking: 1.2);
  static final label = _role(12, 900, height: 1.3, tracking: 1);
  static final badge = _role(11, 900, height: 1.3, tracking: 0.6);
  static final button = _role(17, 900, height: 1, tracking: 1);
  static final buttonSm = _role(15, 900, height: 1, tracking: 1);
  static final nav = _role(12, 900, height: 1, tracking: 0.4);

  /// [style] with a different weight, keeping the variable-font axis in step.
  static TextStyle weight(TextStyle style, int weight) => style.copyWith(
    fontWeight: FontWeight.values[weight ~/ 100 - 1],
    fontVariations: [FontVariation.weight(weight.toDouble())],
  );
}
