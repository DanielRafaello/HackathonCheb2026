import 'package:flutter/material.dart';

import 'icon.dart';
import 'tokens.dart';

/// A form field with a label above it (`components.md`, TextField).
///
/// Works inside a [Form]: [validator] errors are shown like [errorText].
/// With [password], the field hides its text and gets an eye button.
class KnzTextField extends StatefulWidget {
  const KnzTextField({
    super.key,
    required this.label,
    this.controller,
    this.placeholder,
    this.errorText,
    this.validator,
    this.enabled = true,
    this.password = false,
    this.labelLink,
    this.keyboardType,
    this.textInputAction,
    this.autofillHints,
    this.onChanged,
    this.onSubmitted,
  });

  final String label;
  final TextEditingController? controller;
  final String? placeholder;

  /// An error from outside the form, such as the backend.
  final String? errorText;
  final FormFieldValidator<String>? validator;
  final bool enabled;
  final bool password;

  /// A link to the right of the label, such as "Zapomenuté heslo?".
  final ({String label, VoidCallback onPressed})? labelLink;

  final TextInputType? keyboardType;
  final TextInputAction? textInputAction;
  final Iterable<String>? autofillHints;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;

  @override
  State<KnzTextField> createState() => _KnzTextFieldState();
}

class _KnzTextFieldState extends State<KnzTextField> {
  final _focusNode = FocusNode();
  bool _obscured = true;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FormField<String>(
      initialValue: widget.controller?.text,
      validator: widget.validator == null
          ? null
          : (_) => widget.validator!(widget.controller?.text),
      enabled: widget.enabled,
      builder: (field) {
        final error = widget.errorText ?? field.errorText;
        return _build(context, field, error);
      },
    );
  }

  Widget _build(
    BuildContext context,
    FormFieldState<String> field,
    String? error,
  ) {
    final focused = _focusNode.hasFocus && widget.enabled;
    final frameColor = !widget.enabled
        ? KnzColors.border
        : error != null
        ? KnzColors.danger
        : focused
        ? KnzColors.primary
        : KnzColors.borderStrong;
    final background = !widget.enabled
        ? KnzColors.surfaceDisabled
        : focused
        ? KnzColors.surface
        : KnzColors.surfaceInput;
    final link = widget.labelLink;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Expanded(
              child: ExcludeSemantics(
                child: Text(
                  widget.label,
                  style: KnzText.weight(
                    KnzText.caption,
                    900,
                  ).copyWith(color: KnzColors.textSecondary),
                ),
              ),
            ),
            if (link != null)
              GestureDetector(
                onTap: link.onPressed,
                child: Semantics(
                  link: true,
                  child: Text(
                    link.label,
                    style: KnzText.caption.copyWith(color: KnzColors.textLink),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 5),
        AnimatedContainer(
          duration: KnzMotion.of(context, KnzMotion.fast),
          height: KnzSize.input,
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(KnzRadius.md),
            border: Border.all(color: frameColor, width: KnzDepth.border),
            boxShadow: focused ? KnzShadows.focus : null,
          ),
          padding: EdgeInsets.only(
            left: KnzSpace.s14 - KnzDepth.border,
            right: widget.password ? 0 : KnzSpace.s14 - KnzDepth.border,
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: widget.controller,
                  focusNode: _focusNode,
                  enabled: widget.enabled,
                  obscureText: widget.password && _obscured,
                  keyboardType: widget.keyboardType,
                  textInputAction: widget.textInputAction,
                  autofillHints: widget.autofillHints,
                  cursorColor: KnzColors.primary,
                  style: KnzText.weight(KnzText.bodyLg, 700).copyWith(
                    color: widget.enabled
                        ? KnzColors.text
                        : KnzColors.textDisabled,
                  ),
                  // The frame is drawn above; override the app's input
                  // theme so no Material fill or border shows inside it.
                  decoration: InputDecoration(
                    isCollapsed: true,
                    contentPadding: EdgeInsets.zero,
                    filled: false,
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    disabledBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    focusedErrorBorder: InputBorder.none,
                    hintText: widget.placeholder,
                    hintStyle: KnzText.weight(
                      KnzText.bodyLg,
                      700,
                    ).copyWith(color: KnzColors.textPlaceholder),
                  ),
                  onChanged: (value) {
                    field.didChange(value);
                    widget.onChanged?.call(value);
                  },
                  onSubmitted: widget.onSubmitted,
                ),
              ),
              if (widget.password)
                _EyeButton(
                  obscured: _obscured,
                  enabled: widget.enabled,
                  onPressed: () => setState(() => _obscured = !_obscured),
                ),
            ],
          ),
        ),
        if (error != null) ...[
          const SizedBox(height: KnzSpace.s6),
          Semantics(
            liveRegion: true,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const KnzIcon(
                  KnzIcons.info,
                  size: 16,
                  color: KnzColors.dangerEdge,
                ),
                const SizedBox(width: KnzSpace.s6),
                Expanded(
                  child: Text(
                    error,
                    style: KnzText.caption.copyWith(
                      color: KnzColors.dangerEdge,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    ).withLabel(widget.label);
  }
}

extension on Widget {
  /// Reads the visible label to screen readers as the field's label.
  Widget withLabel(String label) =>
      Semantics(label: label, container: true, child: this);
}

class _EyeButton extends StatelessWidget {
  const _EyeButton({
    required this.obscured,
    required this.enabled,
    required this.onPressed,
  });

  final bool obscured;
  final bool enabled;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: obscured ? 'Zobrazit heslo' : 'Skrýt heslo',
      excludeSemantics: true,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: enabled ? onPressed : null,
        child: SizedBox.square(
          dimension: KnzSize.touch,
          child: Center(
            child: KnzIcon(
              KnzIcons.eye,
              size: 22,
              color: obscured ? KnzColors.iconMuted : KnzColors.primary,
            ),
          ),
        ),
      ),
    );
  }
}
