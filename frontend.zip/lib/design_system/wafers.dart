import 'package:flutter/widgets.dart';

import 'czech.dart';
import 'icon.dart';
import 'sentiment.dart';
import 'tokens.dart';

/// Wafers (oplatky), the game's currency (`components.md`, WaferPill): the
/// wafer icon and an amount on the accent tint. [earned] shows what a hit
/// or a visit just added ("+10 oplatek"), otherwise it is the balance
/// ("112 oplatek"). [compact] shows the number only, in the Home header
/// next to the place count; the screen reader still hears "oplatek".
class KnzWaferPill extends StatelessWidget {
  const KnzWaferPill({
    super.key,
    required this.wafers,
    this.earned = false,
    this.compact = false,
  });

  final int wafers;
  final bool earned;
  final bool compact;

  /// "10 oplatek", "2 oplatky", "1 oplatka", with a no-break space.
  static String count(int wafers) =>
      '${Czech.number(wafers)}\u00A0'
      '${Czech.plural(wafers, 'oplatka', 'oplatky', 'oplatek')}';

  @override
  Widget build(BuildContext context) {
    final gold = KnzSentiment.accent.colors;
    final amount = count(wafers);
    return Semantics(
      container: true,
      label: earned ? 'Získáváš $amount' : 'Máš $amount',
      excludeSemantics: true,
      child: Container(
        constraints: BoxConstraints(minHeight: compact ? KnzSize.touch : 0),
        alignment: compact ? Alignment.center : null,
        padding: const EdgeInsets.fromLTRB(
          KnzSpace.s8,
          KnzSpace.s6,
          KnzSpace.s14,
          KnzSpace.s6,
        ),
        decoration: BoxDecoration(
          color: gold.tint,
          border: Border.all(color: gold.line, width: KnzDepth.border),
          borderRadius: BorderRadius.circular(KnzRadius.pill),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const KnzIcon(KnzIcons.wafer, size: 24),
            const SizedBox(width: KnzSpace.s6),
            Text(
              compact
                  ? Czech.number(wafers)
                  : earned
                  ? '+$amount'
                  : amount,
              style: KnzText.weight(
                KnzText.bodyLg,
                900,
              ).copyWith(color: gold.onTint),
            ),
          ],
        ),
      ),
    );
  }
}
