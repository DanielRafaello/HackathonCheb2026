/// The game's calendar in Europe/Prague, where the place of the day changes
/// at midnight (PRODUCT_SPECIFICATION.md).
///
/// The app has no time zone database, so this applies the EU summer time
/// rule directly: CEST (UTC+2) from 01:00 UTC on the last Sunday in March to
/// 01:00 UTC on the last Sunday in October, CET (UTC+1) otherwise.
abstract final class GameDay {
  /// The wall-clock time in Prague at [instant], as a UTC [DateTime] whose
  /// fields read as Prague time.
  static DateTime wallClock(DateTime instant) {
    final utc = instant.toUtc();
    return utc.add(Duration(hours: _isSummerTime(utc) ? 2 : 1));
  }

  /// The game day at [instant]: the Prague date, at midnight UTC.
  static DateTime of(DateTime instant) {
    final local = wallClock(instant);
    return DateTime.utc(local.year, local.month, local.day);
  }

  static bool _isSummerTime(DateTime utc) {
    final start = _lastSunday(utc.year, 3).add(const Duration(hours: 1));
    final end = _lastSunday(utc.year, 10).add(const Duration(hours: 1));
    return !utc.isBefore(start) && utc.isBefore(end);
  }

  static DateTime _lastSunday(int year, int month) {
    // Day 0 of the next month is the last day of this one.
    final last = DateTime.utc(year, month + 1, 0);
    return last.subtract(Duration(days: last.weekday % DateTime.daysPerWeek));
  }
}
