import '../design_system/design_system.dart';

/// The three areas of the region (PRODUCT_SPECIFICATION.md, glossary). Each
/// is one district (okres) of the Karlovy Vary Region.
enum Area {
  chebsko('Chebsko', 'CZ0411', KnzSentiment.primary),
  sokolovsko('Sokolovsko', 'CZ0413', KnzSentiment.explore),
  karlovarsko('Karlovarsko', 'CZ0412', KnzSentiment.accent);

  const Area(this.label, this.districtCode, this.sentiment);

  final String label;

  /// The district code that the Game API sends with every place.
  final String districtCode;

  /// The area's colour on my map (`DESIGN.md`, Colors).
  final KnzSentiment sentiment;

  /// The area of the district [code], or null for an unknown code.
  static Area? ofDistrict(String code) {
    for (final area in values) {
      if (area.districtCode == code) return area;
    }
    return null;
  }
}
