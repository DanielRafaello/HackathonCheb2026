import '../config/game_config.dart';
import '../game/area.dart';
import '../my_map/my_map_place.dart';
import 'device_location.dart';
import 'dummy_place_source.dart';

/// The place card demo at `/place/demo` (debug and profile builds only):
/// the card over a built-in sample place, with no sign-in and no backend.
///
/// - `?visited=1` opens the place as visited.
/// - `?gps=here|far|off|denied` sets what the fake GPS reports when the
///   player taps JSEM TU! ([DemoGps]).
///
/// TODO: remove once the Game API serves `GET /locations/{id}` and the
/// visit (BACKEND_SPECIFICATION.md section 4).
abstract final class PlaceDemo {
  /// The castle from the design's place card.
  static const latitude = 50.0807;
  static const longitude = 12.8389;

  /// The source for one demo: the sample place, guessed a day before
  /// [clock], and visited too when [visited].
  static DummyPlaceSource source({
    required bool visited,
    GameConfig config = GameConfig.defaults,
    DateTime Function() clock = DateTime.now,
  }) => DummyPlaceSource(
    places: () async {
      final now = clock();
      return [
        MyMapPlace(
          id: 0,
          name: 'Hrad a zámek Bečov nad Teplou',
          latitude: latitude,
          longitude: longitude,
          area: Area.karlovarsko,
          guessedAt: now.subtract(const Duration(days: 1)),
          visitedAt: visited ? now : null,
        ),
      ];
    },
    config: config,
    clock: clock,
  );
}

/// What the demo's fake GPS reports (`?gps=`).
enum DemoGps {
  /// 40 m from the place: the visit succeeds.
  here,

  /// 31 km away: "Ještě nejsi na místě".
  far,

  /// The location service is off.
  off,

  /// The player declined the permission.
  denied;

  /// [value] from the URL; [here] when it is missing or unknown.
  static DemoGps parse(String? value) =>
      values.firstWhere((gps) => gps.name == value, orElse: () => DemoGps.here);
}

/// A fake [LocationReader] for the demo: a position [DemoGps.here] or
/// [DemoGps.far] north of the sample place, or a location problem.
class DemoLocation implements LocationReader {
  const DemoLocation(
    this.gps, {
    this.clock = DateTime.now,
    this.delay = const Duration(milliseconds: 700),
  });

  final DemoGps gps;
  final DateTime Function() clock;

  /// How long [locate] pretends to search, so that "Hledám tě…" shows.
  final Duration delay;

  static const _metersPerDegree = 111195.0;

  @override
  Future<DevicePosition> locate() async {
    await Future<void>.delayed(delay);
    return switch (gps) {
      DemoGps.here => _north(40),
      DemoGps.far => _north(31000),
      DemoGps.off => throw const LocationException(
        LocationProblem.serviceDisabled,
      ),
      DemoGps.denied => throw const LocationException(LocationProblem.denied),
    };
  }

  @override
  Future<DevicePosition?> locateIfAllowed() async => switch (gps) {
    DemoGps.here => _north(40),
    DemoGps.far => _north(31000),
    DemoGps.off || DemoGps.denied => null,
  };

  @override
  bool canOpenSettings(LocationProblem problem) => false;

  @override
  Future<void> openSettings(LocationProblem problem) async {}

  DevicePosition _north(double meters) => DevicePosition(
    latitude: PlaceDemo.latitude + meters / _metersPerDegree,
    longitude: PlaceDemo.longitude,
    accuracyMeters: 12,
    timestamp: clock(),
  );
}
