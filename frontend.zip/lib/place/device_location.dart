import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

/// One reading of the device position. The app sends it for a visit and
/// never stores it.
class DevicePosition {
  const DevicePosition({
    required this.latitude,
    required this.longitude,
    required this.accuracyMeters,
    required this.timestamp,
  });

  final double latitude;
  final double longitude;
  final double accuracyMeters;
  final DateTime timestamp;

  /// The great-circle distance to a point, in metres.
  double distanceTo(double latitude, double longitude) =>
      distanceMeters(this.latitude, this.longitude, latitude, longitude);
}

/// The haversine distance between two points, in metres.
double distanceMeters(double lat1, double lon1, double lat2, double lon2) {
  const earthRadius = 6371000.0;
  double rad(double degrees) => degrees * math.pi / 180;
  final dLat = rad(lat2 - lat1);
  final dLon = rad(lon2 - lon1);
  final a =
      math.pow(math.sin(dLat / 2), 2) +
      math.cos(rad(lat1)) *
          math.cos(rad(lat2)) *
          math.pow(math.sin(dLon / 2), 2);
  return 2 * earthRadius * math.asin(math.sqrt(a));
}

/// Why the position is not available (FRONTEND_SPECIFICATION.md section 5).
enum LocationProblem {
  /// The device location service is off.
  serviceDisabled,

  /// The player declined the permission; the app may ask again.
  denied,

  /// The player declined for good; only the settings can change it.
  deniedForever,

  /// The device could not tell its position, including the web over HTTP.
  unavailable,

  timeout,
}

class LocationException implements Exception {
  const LocationException(this.problem);

  final LocationProblem problem;

  @override
  String toString() => 'LocationException($problem)';
}

/// The device position, behind an interface so that tests can fake it.
abstract interface class LocationReader {
  /// The current position with high accuracy. Asks for "while in use"
  /// permission when needed, so call it only when the player starts a
  /// visit. Throws [LocationException].
  Future<DevicePosition> locate();

  /// The position when the permission is already granted, or null. Never
  /// asks for permission.
  Future<DevicePosition?> locateIfAllowed();

  /// Whether [openSettings] can help with [problem] on this platform.
  bool canOpenSettings(LocationProblem problem);

  /// Opens the system settings that fix [problem].
  Future<void> openSettings(LocationProblem problem);
}

/// [LocationReader] over the geolocator plugin, which also covers the
/// browser Geolocation API.
class DeviceLocation implements LocationReader {
  const DeviceLocation();

  static const _timeLimit = Duration(seconds: 20);

  @override
  Future<DevicePosition> locate() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw const LocationException(LocationProblem.serviceDisabled);
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    switch (permission) {
      case LocationPermission.denied:
        throw const LocationException(LocationProblem.denied);
      case LocationPermission.deniedForever:
        throw const LocationException(LocationProblem.deniedForever);
      case LocationPermission.whileInUse ||
          LocationPermission.always ||
          LocationPermission.unableToDetermine:
        break;
    }
    try {
      return _of(
        await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.best,
            timeLimit: _timeLimit,
          ),
        ),
      );
    } on TimeoutException {
      throw const LocationException(LocationProblem.timeout);
    } on LocationServiceDisabledException {
      throw const LocationException(LocationProblem.serviceDisabled);
    } on PermissionDeniedException {
      throw const LocationException(LocationProblem.denied);
    } on Object {
      throw const LocationException(LocationProblem.unavailable);
    }
  }

  @override
  Future<DevicePosition?> locateIfAllowed() async {
    try {
      final permission = await Geolocator.checkPermission();
      if (permission != LocationPermission.whileInUse &&
          permission != LocationPermission.always) {
        return null;
      }
      return _of(
        await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.medium,
            timeLimit: Duration(seconds: 10),
          ),
        ),
      );
    } on Object {
      return null;
    }
  }

  @override
  bool canOpenSettings(LocationProblem problem) =>
      !kIsWeb &&
      (problem == LocationProblem.serviceDisabled ||
          problem == LocationProblem.deniedForever);

  @override
  Future<void> openSettings(LocationProblem problem) async {
    if (problem == LocationProblem.serviceDisabled) {
      await Geolocator.openLocationSettings();
    } else {
      await Geolocator.openAppSettings();
    }
  }

  static DevicePosition _of(Position p) => DevicePosition(
    latitude: p.latitude,
    longitude: p.longitude,
    accuracyMeters: p.accuracy,
    timestamp: p.timestamp,
  );
}
