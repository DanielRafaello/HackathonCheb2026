import 'package:flutter/foundation.dart';
import 'package:url_launcher/url_launcher.dart';

/// The directions from the player's current position to a place, in the
/// platform's maps app: Apple Maps on iOS and macOS, Google Maps elsewhere.
/// On the web the browser's platform decides, so Safari on an iPhone opens
/// Apple Maps too. Neither link names an origin, so the maps app starts
/// from the current position.
Uri directionsUri(
  double latitude,
  double longitude, {
  TargetPlatform? platform,
}) {
  final destination = '$latitude,$longitude';
  return switch (platform ?? defaultTargetPlatform) {
    TargetPlatform.iOS || TargetPlatform.macOS => Uri.https(
      'maps.apple.com',
      '/',
      {'daddr': destination, 'dirflg': 'd'},
    ),
    _ => Uri.https('www.google.com', '/maps/dir/', {
      'api': '1',
      'destination': destination,
    }),
  };
}

/// Opens [directionsUri] outside the app; false when nothing could open it.
Future<bool> openDirections(double latitude, double longitude) async {
  try {
    return await launchUrl(
      directionsUri(latitude, longitude),
      mode: LaunchMode.externalApplication,
    );
  } on Object {
    return false;
  }
}
