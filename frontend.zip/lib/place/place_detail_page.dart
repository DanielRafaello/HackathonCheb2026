import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../config/game_config.dart';
import '../design_system/design_system.dart';
import 'device_location.dart';
import 'place_detail.dart';
import 'place_widgets.dart';
import 'visit_result_page.dart';
import 'visit_sheets.dart';

/// Place card (`08`, `components.md` PlaceDetail) of a guessed or visited
/// place, opened from my map.
///
/// NAVIGOVAT opens the directions in a maps app. JSEM TU! starts a
/// visit: it reads the position (asking for permission only now), sends it
/// for evaluation, and shows the facts, or how far the place still is. A
/// visited place can be rated with 1–5 stars.
class PlaceDetailPage extends StatefulWidget {
  const PlaceDetailPage({
    super.key,
    required this.placeId,
    required this.source,
    required this.location,
    required this.openDirections,
    required this.onClose,
    this.config = GameConfig.defaults,
    this.clock = DateTime.now,
  });

  final int placeId;
  final PlaceSource source;
  final LocationReader location;

  /// Opens the directions to a point; false when nothing could open them.
  final Future<bool> Function(double latitude, double longitude) openDirections;

  /// Back to my map: the back button, or "Zobrazit" after a visit.
  final VoidCallback onClose;
  final GameConfig config;
  final DateTime Function() clock;

  @override
  State<PlaceDetailPage> createState() => _PlaceDetailPageState();
}

class _PlaceDetailPageState extends State<PlaceDetailPage> {
  late Future<PlaceDetail> _detail;

  /// The position for "31 km od tebe", only when the permission is
  /// already granted. Kept in memory while the card is open.
  DevicePosition? _here;
  bool _visiting = false;
  bool _rating = false;

  @override
  void initState() {
    super.initState();
    _detail = widget.source.load(widget.placeId);
    widget.location.locateIfAllowed().then((position) {
      if (mounted && position != null) setState(() => _here = position);
    });
  }

  Future<void> _navigate(PlaceDetail place) async {
    final opened = await widget.openDirections(place.latitude, place.longitude);
    if (!opened && mounted) {
      KnzToast.show(context, 'Navigaci se nepodařilo otevřít.');
    }
  }

  Future<void> _rate(PlaceDetail place, int stars) async {
    setState(() => _rating = true);
    try {
      final rated = await widget.source.rate(place.id, stars);
      if (!mounted) return;
      setState(() {
        _detail = Future.value(rated);
      });
      KnzToast.show(context, 'Díky! Hodnocení je uložené.');
    } on Object {
      if (mounted) {
        KnzToast.show(
          context,
          'Hodnocení se nepodařilo uložit. Zkontroluj připojení.',
        );
      }
    } finally {
      if (mounted) setState(() => _rating = false);
    }
  }

  Future<void> _visit(PlaceDetail place) async {
    setState(() => _visiting = true);
    try {
      var again = true;
      while (again && mounted) {
        again = await _tryVisit(place);
      }
    } finally {
      if (mounted) setState(() => _visiting = false);
    }
  }

  /// One attempt at a visit; true when the player wants to try again.
  Future<bool> _tryVisit(PlaceDetail place) async {
    final DevicePosition position;
    try {
      position = await widget.location.locate();
    } on LocationException catch (e) {
      if (!mounted) return false;
      final action = await showLocationProblemSheet(
        context,
        problem: e.problem,
        canOpenSettings: widget.location.canOpenSettings(e.problem),
      );
      if (action == VisitSheetAction.openSettings) {
        await widget.location.openSettings(e.problem);
      }
      return action == VisitSheetAction.retry;
    }
    if (mounted) setState(() => _here = position);

    final VisitOutcome outcome;
    try {
      outcome = await widget.source.visit(place.id, position);
    } on Object {
      if (mounted) {
        KnzToast.show(
          context,
          'Místo se nepodařilo uložit. Zkontroluj připojení.',
        );
      }
      return false;
    }
    if (!mounted) return false;

    switch (outcome) {
      case VisitConfirmed confirmed:
        setState(() {
          _detail = Future.value(confirmed.place);
        });
        final showMap = await Navigator.of(context).push<bool>(
          MaterialPageRoute(
            builder: (context) => VisitResultPage(
              visit: confirmed,
              maxRating: widget.config.maxRating,
              onRate: (stars) async {
                final rated = await widget.source.rate(place.id, stars);
                // The card under the result shows the rating too.
                if (mounted) {
                  setState(() {
                    _detail = Future.value(rated);
                  });
                }
                return rated;
              },
            ),
          ),
        );
        if (showMap ?? false) widget.onClose();
        return false;
      case VisitTooFar tooFar:
        final action = await showTooFarSheet(
          context,
          distanceMeters: tooFar.distanceMeters,
          position: position,
          visitRadiusMeters: widget.config.visitRadiusMeters,
          now: widget.clock(),
        );
        if (action == VisitSheetAction.navigate) await _navigate(place);
        return action == VisitSheetAction.retry;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KnzColors.surface,
      body: FutureBuilder(
        future: _detail,
        builder: (context, snapshot) {
          final place = snapshot.data;
          if (place != null) return _content(place);
          return _Status(failed: snapshot.hasError, onBack: widget.onClose);
        },
      ),
    );
  }

  Widget _content(PlaceDetail place) {
    final here = _here;
    final guessedAt = place.guessedAt;
    final visitedAt = place.visitedAt;
    final category = place.category;
    final description = place.description;
    final source = place.source;
    final averageRating = place.averageRating;
    final facts = place.facts ?? const <String>[];
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                _Header(
                  place: place,
                  maxStars: widget.config.maxStars,
                  onBack: widget.onClose,
                ),
                _Body(
                  children: [
                    // What the client does not know about the place is
                    // left out rather than made up (copy.md).
                    if (category != null) ...[
                      Align(
                        alignment: Alignment.centerLeft,
                        child: KnzPill(label: category),
                      ),
                      const SizedBox(height: KnzSpace.s10),
                    ],
                    Semantics(
                      header: true,
                      child: Text(place.name, style: KnzText.titleLg),
                    ),
                    if (description != null) ...[
                      const SizedBox(height: KnzSpace.s6),
                      Text(
                        description,
                        style: KnzText.bodyLg.copyWith(
                          color: KnzColors.textSecondary,
                        ),
                      ),
                    ],
                    const SizedBox(height: KnzSpace.s14),
                    Wrap(
                      spacing: KnzSpace.s8,
                      runSpacing: KnzSpace.s8,
                      children: [
                        if (here != null)
                          PlaceInfoChip(
                            icon: KnzIcons.navigate,
                            label:
                                '${Czech.distance(here.distanceTo(place.latitude, place.longitude))} '
                                'od\u00A0tebe',
                          ),
                        if (guessedAt != null)
                          PlaceInfoChip(
                            icon: KnzIcons.calendar,
                            label: 'uhodnuto ${Czech.dayMonth(guessedAt)}',
                          ),
                        if (visitedAt != null)
                          PlaceInfoChip(
                            icon: KnzIcons.flag,
                            label: 'navštíveno ${Czech.dayMonth(visitedAt)}',
                            visited: true,
                          ),
                        if (averageRating != null && place.ratingCount > 0)
                          PlaceInfoChip(
                            icon: KnzIcons.star,
                            label:
                                '${Czech.decimal(averageRating, 1)} · '
                                '${Czech.count(place.ratingCount, 'hodnocení', 'hodnocení', 'hodnocení')}',
                          )
                        else
                          const PlaceInfoChip(
                            icon: KnzIcons.starEmpty,
                            label: 'zatím bez hodnocení',
                          ),
                        PlaceInfoChip(
                          icon: KnzIcons.place,
                          label: Czech.coordinates(
                            place.latitude,
                            place.longitude,
                          ),
                        ),
                      ],
                    ),
                    if (!place.isVisited) ...[
                      const SizedBox(height: KnzSpace.s16),
                      _VisitPrompt(
                        visitRadiusMeters: widget.config.visitRadiusMeters,
                        factCount: place.factCount,
                      ),
                    ] else if (facts.isNotEmpty) ...[
                      const SizedBox(height: KnzSpace.s16),
                      _FactsCard(facts: facts),
                    ],
                    // Only a visited place can be rated
                    // (PRODUCT_SPECIFICATION.md, Rating).
                    if (place.isVisited) ...[
                      const SizedBox(height: KnzSpace.s16),
                      PlaceRatingCard(
                        rating: place.rating,
                        maxStars: widget.config.maxRating,
                        onRate: _rating ? null : (stars) => _rate(place, stars),
                      ),
                    ],
                    if (source != null) ...[
                      const SizedBox(height: KnzSpace.s14),
                      Text(
                        source,
                        style: KnzText.weight(
                          KnzText.micro,
                          700,
                        ).copyWith(color: KnzColors.textMuted),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
        _Footer(
          children: [
            Expanded(
              flex: 4,
              child: KnzButton(
                label: 'Navigovat',
                icon: KnzIcons.navigate,
                variant: KnzButtonVariant.secondary,
                size: KnzButtonSize.cta,
                compact: true,
                onPressed: () => _navigate(place),
              ),
            ),
            const SizedBox(width: KnzSpace.s10),
            Expanded(
              flex: place.isVisited ? 4 : 5,
              child: place.isVisited
                  ? KnzButton(
                      label: 'Sdílet',
                      icon: KnzIcons.share,
                      variant: KnzButtonVariant.secondary,
                      size: KnzButtonSize.cta,
                      compact: true,
                      // TODO: share once the sharing plugin and the share
                      // text are decided (FRONTEND_SPECIFICATION.md 4).
                      onPressed: () =>
                          KnzToast.show(context, 'Sdílení brzy přidáme.'),
                    )
                  : KnzButton(
                      label: _visiting ? 'Hledám tě…' : 'Jsem tu!',
                      icon: KnzIcons.flag,
                      size: KnzButtonSize.cta,
                      compact: true,
                      onPressed: _visiting ? null : () => _visit(place),
                    ),
            ),
          ],
        ),
      ],
    );
  }
}

/// The illustration with the back button and the status label.
class _Header extends StatelessWidget {
  const _Header({
    required this.place,
    required this.maxStars,
    required this.onBack,
  });

  final PlaceDetail place;
  final int maxStars;
  final VoidCallback onBack;

  static const _height = 250.0;

  /// The body slides over the illustration by this much.
  static const overlap = 26.0;

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.paddingOf(context).top;
    return SizedBox(
      height: top + _height - overlap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            height: top + _height,
            child: ExcludeSemantics(
              child: SvgPicture.asset(
                'design-system/assets/illustrations/place-castle.svg',
                fit: BoxFit.cover,
                alignment: Alignment.bottomCenter,
              ),
            ),
          ),
          Positioned(
            top: top + KnzSpace.s16,
            left: KnzSpace.s16,
            child: KnzIconButton(
              icon: KnzIcons.back,
              semanticLabel: 'Zpět na mapu',
              raised: true,
              onPressed: onBack,
            ),
          ),
          Positioned(
            top: top + KnzSpace.s20,
            right: KnzSpace.s16,
            child: PlaceStatusLabel(
              visited: place.isVisited,
              guessed: place.isGuessed,
              stars: place.stars,
              maxStars: maxStars,
            ),
          ),
        ],
      ),
    );
  }
}

/// The white sheet that slides over the illustration.
class _Body extends StatelessWidget {
  const _Body({required this.children});

  final List<Widget> children;

  static const _corner = Radius.circular(28);

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        color: KnzColors.surface,
        borderRadius: BorderRadius.vertical(top: _corner),
      ),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              KnzSize.screenGutter,
              KnzSpace.s20,
              KnzSize.screenGutter,
              KnzSpace.s16,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: children,
            ),
          ),
        ),
      ),
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              KnzSize.screenGutter,
              KnzSpace.s14,
              KnzSize.screenGutter,
              KnzSpace.s20,
            ),
            child: Row(children: children),
          ),
        ),
      ),
    );
  }
}

/// "Navštiv ho naživo" with the locked facts (`components.md`, VisitPrompt).
/// Without facts to unlock, it only invites the visit.
class _VisitPrompt extends StatelessWidget {
  const _VisitPrompt({
    required this.visitRadiusMeters,
    required this.factCount,
  });

  final int visitRadiusMeters;
  final int factCount;

  @override
  Widget build(BuildContext context) {
    final gold = KnzSentiment.accent.colors;
    final facts = Czech.count(
      factCount,
      'zajímavost',
      'zajímavosti',
      'zajímavostí',
    );
    final radius = Czech.distance(visitRadiusMeters.toDouble());
    final invitation = factCount == 0
        ? 'Až budeš do $radius, ulož si ho na mapu.'
        : 'Až budeš do $radius, ulož ho na mapu '
              'a\u00A0odemkneš $facts.';
    return KnzEdgeBox(
      color: gold.tint,
      edgeColor: gold.edge,
      radius: KnzRadius.xl2,
      frame: KnzDepth.border,
      dashed: true,
      child: Padding(
        padding: const EdgeInsets.all(KnzSpace.s14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: gold.solid,
                    borderRadius: BorderRadius.circular(KnzRadius.sm),
                  ),
                  child: KnzIcon(KnzIcons.place, color: gold.onSolid),
                ),
                const SizedBox(width: KnzSpace.s12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Navštiv ho naživo', style: KnzText.cardTitle),
                      const SizedBox(height: KnzSpace.s2),
                      Text(
                        invitation,
                        style: KnzText.weight(
                          KnzText.bodySm,
                          800,
                        ).copyWith(color: gold.onTint),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (factCount > 0) ...[
              const SizedBox(height: KnzSpace.s14),
              Semantics(
                label: 'Zamčené zajímavosti: $factCount',
                excludeSemantics: true,
                child: Row(
                  children: [
                    for (var i = 0; i < factCount; i++) ...[
                      if (i > 0) const SizedBox(width: KnzSpace.s8),
                      const Expanded(child: _LockedFact()),
                    ],
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _LockedFact extends StatelessWidget {
  const _LockedFact();

  @override
  Widget build(BuildContext context) {
    return KnzEdgeBox(
      color: KnzColors.surface,
      edgeColor: KnzPalette.gold200,
      radius: KnzRadius.md,
      depth: KnzDepth.sm,
      child: SizedBox(
        height: 64,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const KnzIcon(KnzIcons.lock, size: 20, color: KnzPalette.gold700),
            const SizedBox(height: KnzSpace.s8),
            FractionallySizedBox(
              widthFactor: 0.6,
              child: Container(
                height: KnzSpace.s6,
                decoration: BoxDecoration(
                  color: KnzPalette.gold100,
                  borderRadius: BorderRadius.circular(KnzRadius.pill),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// "Tvoje zajímavosti" after a visit.
class _FactsCard extends StatelessWidget {
  const _FactsCard({required this.facts});

  final List<String> facts;

  @override
  Widget build(BuildContext context) {
    final gold = KnzSentiment.accent.colors;
    return KnzEdgeBox(
      color: gold.tint,
      edgeColor: KnzPalette.gold200,
      radius: KnzRadius.xl2,
      frame: KnzDepth.sm,
      depth: KnzDepth.lg,
      child: Padding(
        padding: const EdgeInsets.all(KnzSpace.s16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Semantics(
                    header: true,
                    child: Text('Tvoje zajímavosti', style: KnzText.cardTitle),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: KnzSpace.s10,
                    vertical: KnzSpace.s2,
                  ),
                  decoration: BoxDecoration(
                    color: gold.solid,
                    borderRadius: BorderRadius.circular(KnzRadius.pill),
                  ),
                  child: Text(
                    Czech.fraction(facts.length, facts.length),
                    style: KnzText.weight(KnzText.caption, 900),
                  ),
                ),
              ],
            ),
            for (final (i, fact) in facts.indexed) ...[
              const SizedBox(height: KnzSpace.s12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FactNumber(i + 1, size: 26),
                  const SizedBox(width: KnzSpace.s12),
                  Expanded(child: Text(fact, style: KnzText.body)),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// Loading, or the card failed to load.
class _Status extends StatelessWidget {
  const _Status({required this.failed, required this.onBack});

  final bool failed;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(KnzSize.screenGutter),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            KnzIconButton(
              icon: KnzIcons.back,
              semanticLabel: 'Zpět na mapu',
              color: KnzColors.iconMuted,
              onPressed: onBack,
            ),
            const Spacer(),
            if (failed)
              const KnzSpeechBubble(
                mood: KnzMood.sad,
                text: 'Tohle místo se mi nepodařilo načíst. Zkus to za chvíli.',
              )
            else
              const Center(
                child: CircularProgressIndicator(color: KnzColors.primary),
              ),
            const Spacer(flex: 2),
          ],
        ),
      ),
    );
  }
}
