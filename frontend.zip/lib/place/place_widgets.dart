import 'package:flutter/widgets.dart';

import '../design_system/design_system.dart';
import 'place_detail.dart';

/// The status label over the place illustration (`components.md`, Pill /
/// Chip, status label): "UHODNUTO · 4 HVĚZDY" in blue, "NAVŠTÍVENO" in ink
/// with the gold flag, "NEOBJEVENO" in gray for a place in the fog.
class PlaceStatusLabel extends StatelessWidget {
  const PlaceStatusLabel({
    super.key,
    required this.visited,
    this.guessed = true,
    this.stars,
    this.maxStars,
  });

  final bool visited;

  /// Whether the player guessed the place; neither guessed nor [visited]
  /// means in the fog.
  final bool guessed;

  /// Stars for the hit; null when the place was not guessed.
  final int? stars;
  final int? maxStars;

  @override
  Widget build(BuildContext context) {
    final inFog = !visited && !guessed;
    final sentiment = visited ? KnzSentiment.neutral : KnzSentiment.primary;
    final c = sentiment.colors;
    final solid = inFog ? KnzColors.textSecondary : c.solid;
    final status = visited
        ? 'Navštíveno'
        : inFog
        ? 'Neobjeveno'
        : 'Uhodnuto';
    final stars = this.stars;
    final label = stars == null
        ? status
        : '$status\u00A0· ${Czech.count(stars, 'hvězda', 'hvězdy', 'hvězd')}';
    final spoken = stars == null || maxStars == null
        ? status
        : '$status, ${Czech.fraction(stars, maxStars!)} hvězd';
    return Semantics(
      label: spoken,
      excludeSemantics: true,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s14,
          vertical: KnzSpace.s6,
        ),
        decoration: BoxDecoration(
          color: solid,
          borderRadius: BorderRadius.circular(KnzRadius.pill),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            KnzIcon(
              visited
                  ? KnzIcons.flagOnDark
                  : inFog
                  ? KnzIcons.place
                  : KnzIcons.done,
              size: 16,
              color: c.onSolid,
            ),
            const SizedBox(width: KnzSpace.s6),
            Text(
              label.toUpperCase(),
              style: KnzText.overline.copyWith(color: c.onSolid),
            ),
          ],
        ),
      ),
    );
  }
}

/// An info chip (`components.md`, Pill / Chip): "31 km od tebe",
/// "uhodnuto 9. 10.". The [visited] variant is gold with the flag.
class PlaceInfoChip extends StatelessWidget {
  const PlaceInfoChip({
    super.key,
    required this.icon,
    required this.label,
    this.visited = false,
  });

  final KnzIcons icon;
  final String label;
  final bool visited;

  @override
  Widget build(BuildContext context) {
    final accent = KnzSentiment.accent.colors;
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: KnzSpace.s12,
        vertical: KnzSpace.s6,
      ),
      decoration: BoxDecoration(
        color: visited ? accent.tint : KnzColors.surfaceSubtle,
        borderRadius: BorderRadius.circular(KnzRadius.sm),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          KnzIcon(icon, size: 16, color: KnzColors.textMuted),
          const SizedBox(width: KnzSpace.s8),
          // A long label, such as the coordinates, wraps on a narrow
          // screen.
          Flexible(
            child: Text(
              label,
              style: KnzText.caption.copyWith(
                color: visited ? accent.onTint : KnzColors.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// The gold circle with a fact's number.
class FactNumber extends StatelessWidget {
  const FactNumber(this.number, {super.key, this.size = 30});

  final int number;
  final double size;

  @override
  Widget build(BuildContext context) {
    return ExcludeSemantics(
      child: Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: const BoxDecoration(
          color: KnzColors.accent,
          shape: BoxShape.circle,
        ),
        child: Text('$number', style: KnzText.weight(KnzText.body, 900)),
      ),
    );
  }
}

/// A fact in its own card (`components.md`, FactItem; On the spot).
class FactItem extends StatelessWidget {
  const FactItem({super.key, required this.number, required this.text});

  final int number;
  final String text;

  @override
  Widget build(BuildContext context) {
    return KnzEdgeBox(
      color: KnzColors.surface,
      edgeColor: KnzColors.border,
      radius: KnzRadius.xl,
      frame: KnzDepth.border,
      depth: KnzDepth.md,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s14,
          vertical: KnzSpace.s12,
        ),
        child: Row(
          children: [
            FactNumber(number),
            const SizedBox(width: KnzSpace.s12),
            Expanded(child: Text(text, style: KnzText.body)),
          ],
        ),
      ),
    );
  }
}

/// One nearby tip (`components.md`, NearbyTip): a tile tinted by its kind.
/// A spring always carries the warning that its water is not monitored.
class NearbyTipTile extends StatelessWidget {
  const NearbyTipTile({super.key, required this.tip});

  final NearbyTip tip;

  @override
  Widget build(BuildContext context) {
    final (icon, heading, background, ink) = switch (tip.kind) {
      NearbyTipKind.spring => (
        KnzIcons.spring,
        'Pramen',
        KnzColors.exploreTint,
        KnzColors.exploreText,
      ),
      NearbyTipKind.swimming => (
        KnzIcons.swimming,
        'Koupání',
        KnzColors.primaryTint,
        KnzColors.primaryEdge,
      ),
      NearbyTipKind.whenItRains => (
        KnzIcons.cinema,
        'Když prší',
        KnzPalette.red100,
        KnzColors.dangerEdge,
      ),
    };
    return Container(
      padding: const EdgeInsets.all(KnzSpace.s12),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(KnzRadius.lg),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KnzIcon(icon, size: 26, color: ink),
          const SizedBox(height: KnzSpace.s8),
          Text(heading, style: KnzText.cardTitle.copyWith(color: ink)),
          const SizedBox(height: KnzSpace.s4),
          Text(
            '${tip.name}\u00A0· ${Czech.distance(tip.distanceMeters)}',
            style: KnzText.caption,
          ),
          if (tip.kind == NearbyTipKind.spring) ...[
            const SizedBox(height: KnzSpace.s4),
            Text(
              'Voda není hygienicky sledovaná.',
              style: KnzText.weight(
                KnzText.micro,
                700,
              ).copyWith(color: KnzColors.textSecondary),
            ),
          ],
        ],
      ),
    );
  }
}

/// "Jak se ti tu líbilo?" with the stars to rate a visited place
/// (`components.md`, RatingCard), on the place card and On the spot.
/// Tapping a star saves the rating at once; tapping another one changes it.
class PlaceRatingCard extends StatelessWidget {
  const PlaceRatingCard({
    super.key,
    required this.rating,
    required this.maxStars,
    required this.onRate,
  });

  final int? rating;
  final int maxStars;

  /// Null while a rating is being saved.
  final ValueChanged<int>? onRate;

  @override
  Widget build(BuildContext context) {
    final rating = this.rating;
    return KnzCard(
      sentiment: KnzSentiment.accent,
      variant: KnzCardVariant.tinted,
      padding: const EdgeInsets.fromLTRB(
        KnzSpace.s16,
        KnzSpace.s16,
        KnzSpace.s16,
        KnzSpace.s10,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Semantics(
            header: true,
            child: Text('Jak se ti tu líbilo?', style: KnzText.cardTitle),
          ),
          const SizedBox(height: KnzSpace.s4),
          Text(
            rating == null
                ? 'Ohodnoť místo hvězdami. Ostatním poradíš, jestli stojí '
                      'za\u00A0výlet.'
                : 'Tvoje hodnocení: '
                      '${Czech.count(rating, 'hvězda', 'hvězdy', 'hvězd')}. '
                      'Změnit ho můžeš kdykoli.',
            style: KnzText.body.copyWith(color: KnzColors.textSecondary),
          ),
          const SizedBox(height: KnzSpace.s6),
          Center(
            child: KnzStarPicker(
              stars: rating,
              max: maxStars,
              onChanged: onRate,
            ),
          ),
        ],
      ),
    );
  }
}
