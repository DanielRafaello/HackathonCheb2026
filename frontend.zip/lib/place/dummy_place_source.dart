import '../config/game_config.dart';
import '../my_map/my_map_place.dart';
import 'device_location.dart';
import 'place_detail.dart';

/// A stand-in for the place card and visit endpoints, which the Game API
/// does not have yet.
///
/// The name, position and status of each place come from my map
/// (`GET /locations`). The texts are the illustrative ones from the design,
/// the same for every place. The visit is evaluated here against the visit
/// radius and kept in memory until the app restarts, so the place shows as
/// visited on my map too ([myMap]).
///
/// TODO: replace with the Game API once it serves place cards and visits.
class DummyPlaceSource implements PlaceSource {
  DummyPlaceSource({
    required this.places,
    this.config = GameConfig.defaults,
    this.clock = DateTime.now,
  });

  /// Loads my map (`GET /locations`).
  final Future<List<MyMapPlace>> Function() places;
  final GameConfig config;
  final DateTime Function() clock;

  /// Visits made in this session, by place.
  final _visits = <int, DateTime>{};

  /// Ratings made in this session, by place.
  final _ratings = <int, int>{};

  static const _category = 'Národní kulturní památka · Hrad a zámek';
  static const _description =
      'V\u00A0kapli tu našli relikviář sv.\u00A0Maura, jeden '
      'z\u00A0nejcennějších pokladů u\u00A0nás.';
  static const _source =
      'Zdroj dat: datazapad.cz, Národní kulturní památky · licence CC\u00A0BY';
  static const _stars = 4;
  static const _facts = [
    'Relikviář sv.\u00A0Maura patří k\u00A0nejcennějším movitým památkám '
        'v\u00A0Česku.',
    'Byl ukrytý pod podlahou zámecké kaple. Kriminalisté ho našli '
        'v\u00A0roce 1985.',
    'Areál tvoří středověký hrad a\u00A0barokní zámek nad údolím Teplé.',
  ];

  /// Names are placeholders (`copy.md`: never invent a missing value).
  static const _nearby = [
    NearbyTip(
      kind: NearbyTipKind.spring,
      name: '[název]',
      distanceMeters: 1400,
    ),
    NearbyTip(
      kind: NearbyTipKind.swimming,
      name: '[název]',
      distanceMeters: 6000,
    ),
    NearbyTip(
      kind: NearbyTipKind.whenItRains,
      name: 'Kino [název]',
      distanceMeters: 16000,
    ),
  ];
  static const _nearbySource =
      'Zdroj dat: datazapad.cz · přístupné prameny, koupací místa, kina · '
      'CC0 / CC\u00A0BY';

  /// My map with this session's visits applied.
  Future<List<MyMapPlace>> myMap() async => [
    for (final place in await places()) _withVisit(place),
  ];

  @override
  Future<PlaceDetail> load(int placeId) async {
    final place = await _place(placeId);
    final visitedAt = place.visitedAt;
    final detail = PlaceDetail(
      id: place.id,
      name: place.name,
      latitude: place.latitude,
      longitude: place.longitude,
      category: _category,
      description: _description,
      source: _source,
      factCount: _facts.length,
      stars: place.isGuessed ? _stars : null,
      guessedAt: place.guessedAt,
      visitedAt: visitedAt,
      facts: visitedAt == null ? null : _facts,
      rating: place.rating,
      averageRating: place.averageRating,
      ratingCount: place.ratingCount ?? 0,
    );
    final rating = _ratings[placeId];
    return rating == null ? detail : detail.rated(rating);
  }

  @override
  Future<PlaceDetail> rate(int placeId, int stars) async {
    final detail = await load(placeId);
    if (!detail.isVisited) throw StateError('Only a visited place is rated.');
    _ratings[placeId] = stars;
    return detail.rated(stars);
  }

  @override
  Future<VisitOutcome> visit(int placeId, DevicePosition position) async {
    final detail = await load(placeId);
    final distance = position.distanceTo(detail.latitude, detail.longitude);
    if (distance > config.visitRadiusMeters) {
      return VisitTooFar(distanceMeters: distance);
    }
    final at = detail.visitedAt ?? clock();
    _visits.putIfAbsent(placeId, () => at);
    return VisitConfirmed(
      distanceMeters: distance,
      place: detail.visited(at, _facts),
      nearby: _nearby,
      nearbySource: _nearbySource,
    );
  }

  Future<MyMapPlace> _place(int placeId) async {
    for (final place in await myMap()) {
      if (place.id == placeId) return place;
    }
    throw PlaceNotFound(placeId);
  }

  MyMapPlace _withVisit(MyMapPlace place) {
    final visitedAt = _visits[place.id];
    if (visitedAt == null || place.isVisited) return place;
    return place.withVisit(visitedAt);
  }
}
