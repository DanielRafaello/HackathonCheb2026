import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../design_system/design_system.dart';
import 'place_detail.dart';
import 'place_widgets.dart';

/// On the spot (`09`): the visit is confirmed. Shows the wafers it earned,
/// what the place is about with its data source, the stars to rate it, and
/// the unlocked facts and nearby tips, when there are any.
///
/// Pops with true when the player wants to see my map, otherwise with
/// false.
class VisitResultPage extends StatefulWidget {
  const VisitResultPage({
    super.key,
    required this.visit,
    this.onRate,
    this.maxRating = 5,
  });

  final VisitConfirmed visit;

  /// Saves the player's 1–5 rating and returns the card with it; without
  /// it the page asks for no rating.
  final Future<PlaceDetail> Function(int stars)? onRate;
  final int maxRating;

  @override
  State<VisitResultPage> createState() => _VisitResultPageState();
}

class _VisitResultPageState extends State<VisitResultPage> {
  late PlaceDetail _place = widget.visit.place;
  bool _rating = false;

  Future<void> _rate(int stars) async {
    final onRate = widget.onRate;
    if (onRate == null) return;
    setState(() => _rating = true);
    try {
      final rated = await onRate(stars);
      if (!mounted) return;
      setState(() => _place = rated);
      KnzToast.show(context, 'Díky! Hodnocení je uložené.');
    } on Object {
      if (mounted) {
        KnzToast.show(
          context,
          'Hodnocení se nepodařilo uložit. Zkontroluj připojení.',
        );
      }
    } finally {
      if (mounted) setState(() => _rating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final visit = widget.visit;
    final place = _place;
    final facts = place.facts ?? const <String>[];
    final nearbySource = visit.nearbySource;
    final description = place.description;
    final source = place.source;
    return Scaffold(
      backgroundColor: KnzColors.surface,
      body: Column(
        children: [
          _Hero(
            name: place.name,
            distanceMeters: visit.distanceMeters,
            onClose: () => Navigator.pop(context, false),
          ),
          Expanded(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(
                    KnzSize.screenGutter,
                    KnzSpace.s24,
                    KnzSize.screenGutter,
                    KnzSpace.s16,
                  ),
                  children: [
                    if (visit.wafersEarned > 0) ...[
                      Center(
                        child: KnzWaferPill(
                          wafers: visit.wafersEarned,
                          earned: true,
                        ),
                      ),
                      const SizedBox(height: KnzSpace.s20),
                    ],
                    // What the client does not know is left out (copy.md).
                    if (description != null) ...[
                      Semantics(
                        header: true,
                        child: Text('O\u00A0místě', style: KnzText.titleSm),
                      ),
                      const SizedBox(height: KnzSpace.s6),
                      Text(
                        description,
                        style: KnzText.bodyLg.copyWith(
                          color: KnzColors.textSecondary,
                        ),
                      ),
                      if (source != null) ...[
                        const SizedBox(height: KnzSpace.s8),
                        Text(
                          source,
                          style: KnzText.weight(
                            KnzText.micro,
                            700,
                          ).copyWith(color: KnzColors.textMuted),
                        ),
                      ],
                      const SizedBox(height: KnzSpace.s20),
                    ],
                    if (widget.onRate != null) ...[
                      PlaceRatingCard(
                        rating: place.rating,
                        maxStars: widget.maxRating,
                        onRate: _rating ? null : _rate,
                      ),
                      const SizedBox(height: KnzSpace.s24),
                    ],
                    if (facts.isNotEmpty) ...[
                      Semantics(
                        header: true,
                        child: Text(
                          'Máš odemčené ${Czech.count(facts.length, 'zajímavost', 'zajímavosti', 'zajímavostí')}',
                          style: KnzText.titleSm,
                        ),
                      ),
                      const SizedBox(height: KnzSpace.s12),
                      for (final (i, fact) in facts.indexed) ...[
                        if (i > 0) const SizedBox(height: KnzSpace.s10),
                        FactItem(number: i + 1, text: fact),
                      ],
                    ],
                    if (visit.nearby.isNotEmpty) ...[
                      if (facts.isNotEmpty)
                        const SizedBox(height: KnzSpace.s24),
                      Semantics(
                        header: true,
                        child: Text('Tipy poblíž', style: KnzText.titleSm),
                      ),
                      const SizedBox(height: KnzSpace.s12),
                      IntrinsicHeight(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            for (final (i, tip) in visit.nearby.indexed) ...[
                              if (i > 0) const SizedBox(width: KnzSpace.s8),
                              Expanded(child: NearbyTipTile(tip: tip)),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            top: false,
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(
                    KnzSize.screenGutter,
                    KnzSpace.s8,
                    KnzSize.screenGutter,
                    KnzSpace.s14,
                  ),
                  child: Column(
                    children: [
                      _SavedBanner(
                        onShowMap: () => Navigator.pop(context, true),
                      ),
                      if (nearbySource != null) ...[
                        const SizedBox(height: KnzSpace.s10),
                        Text(
                          nearbySource,
                          textAlign: TextAlign.center,
                          style: KnzText.weight(
                            KnzText.micro,
                            700,
                          ).copyWith(color: KnzColors.textMuted),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// The gold header (`components.md`, HeroHeader: On the spot).
class _Hero extends StatelessWidget {
  const _Hero({
    required this.name,
    required this.distanceMeters,
    required this.onClose,
  });

  final String name;
  final double distanceMeters;
  final VoidCallback onClose;

  static const _corner = Radius.circular(32);

  @override
  Widget build(BuildContext context) {
    final gold = KnzSentiment.accent.colors;
    return DecoratedBox(
      decoration: BoxDecoration(
        color: gold.edge,
        borderRadius: const BorderRadius.vertical(bottom: _corner),
      ),
      child: Padding(
        padding: const EdgeInsets.only(bottom: KnzDepth.xl),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(bottom: _corner),
          child: ColoredBox(
            color: gold.solid,
            child: CustomPaint(
              painter: const _HeroDecor(),
              child: SafeArea(
                bottom: false,
                child: Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                        KnzSpace.s14,
                        KnzSpace.s20,
                        KnzSize.screenGutter,
                        KnzSpace.s24,
                      ),
                      child: Row(
                        children: [
                          const KnzMascot(mood: KnzMood.cheer, width: 110),
                          const SizedBox(width: KnzSpace.s12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const PlaceStatusLabel(visited: true),
                                const SizedBox(height: KnzSpace.s8),
                                Semantics(
                                  header: true,
                                  child: Text(
                                    'Jsi tady!',
                                    style: KnzText.display,
                                  ),
                                ),
                                const SizedBox(height: KnzSpace.s6),
                                Text(name, style: KnzText.cardTitle),
                                const SizedBox(height: KnzSpace.s6),
                                Text(
                                  'GPS: ${Czech.distance(distanceMeters)} '
                                  'od\u00A0cíle',
                                  style: KnzText.caption.copyWith(
                                    color: gold.onTint,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      top: KnzSpace.s6,
                      right: KnzSpace.s6,
                      child: KnzIconButton(
                        icon: KnzIcons.close,
                        semanticLabel: 'Zavřít',
                        color: gold.onTint,
                        onPressed: onClose,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// A pale sun in the corner and a few pale stars on the gold header.
class _HeroDecor extends CustomPainter {
  const _HeroDecor();

  @override
  void paint(Canvas canvas, Size size) {
    final pale = Paint()..color = KnzPalette.gold200.withValues(alpha: 0.7);
    canvas.drawCircle(const Offset(0, 24), 64, pale);
    _star(canvas, Offset(size.width * 0.84, size.height * 0.3), 16, pale);
    _star(canvas, Offset(size.width * 0.92, size.height * 0.72), 11, pale);
    _star(canvas, Offset(size.width * 0.74, size.height * 0.94), 10, pale);
  }

  static void _star(Canvas canvas, Offset centre, double radius, Paint p) {
    final path = Path();
    for (var i = 0; i < 10; i++) {
      final r = i.isEven ? radius : radius * 0.45;
      final angle = -math.pi / 2 + i * math.pi / 5;
      final point = centre + Offset(math.cos(angle), math.sin(angle)) * r;
      i == 0
          ? path.moveTo(point.dx, point.dy)
          : path.lineTo(point.dx, point.dy);
    }
    canvas.drawPath(path..close(), p);
  }

  @override
  bool shouldRepaint(_HeroDecor old) => false;
}

/// "Uloženo na tvou mapu" with a link to my map.
class _SavedBanner extends StatelessWidget {
  const _SavedBanner({required this.onShowMap});

  final VoidCallback onShowMap;

  @override
  Widget build(BuildContext context) {
    final green = KnzSentiment.success.colors;
    return Container(
      padding: const EdgeInsets.only(left: KnzSpace.s16, right: KnzSpace.s6),
      constraints: const BoxConstraints(minHeight: KnzSize.button),
      decoration: BoxDecoration(
        color: green.tint,
        borderRadius: BorderRadius.circular(KnzRadius.lg),
      ),
      child: Row(
        children: [
          KnzIcon(KnzIcons.done, size: 22, color: green.ink),
          const SizedBox(width: KnzSpace.s10),
          Expanded(
            child: Text(
              'Uloženo na tvou mapu',
              style: KnzText.cardTitle.copyWith(color: green.onTint),
            ),
          ),
          KnzPressable(
            onPressed: onShowMap,
            isLink: true,
            semanticLabel: 'Zobrazit mapu',
            builder: (context, state) => Container(
              height: KnzSize.touch,
              padding: const EdgeInsets.symmetric(horizontal: KnzSpace.s10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(KnzRadius.sm),
                color: state.hovered || state.pressed
                    ? KnzColors.surface.withValues(alpha: 0.5)
                    : null,
                boxShadow: state.focused ? KnzShadows.focus : null,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Zobrazit',
                    style: KnzText.weight(
                      KnzText.body,
                      900,
                    ).copyWith(color: green.onTint),
                  ),
                  KnzIcon(KnzIcons.next, size: 16, color: green.onTint),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
