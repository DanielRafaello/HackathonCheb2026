import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../design_system/design_system.dart';
import 'device_location.dart';

/// What the player chose in a visit sheet.
enum VisitSheetAction { close, retry, navigate, openSettings }

/// "Ještě nejsi na místě": the player is outside the visit radius. Shows
/// the distance, a sketch of the way, and how fresh and accurate the
/// position is.
Future<VisitSheetAction> showTooFarSheet(
  BuildContext context, {
  required double distanceMeters,
  required DevicePosition position,
  required int visitRadiusMeters,
  required DateTime now,
}) => _showSheet(
  context,
  (context) => Column(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      _SheetHeader(
        mood: KnzMood.think,
        title: 'Ještě nejsi na místě',
        text:
            'Na mapu si ho uložíš, až budeš do '
            '${Czech.distance(visitRadiusMeters.toDouble())} od\u00A0něj.',
      ),
      const SizedBox(height: KnzSpace.s16),
      _WaySketch(
        distanceMeters: distanceMeters,
        visitRadiusMeters: visitRadiusMeters,
      ),
      const SizedBox(height: KnzSpace.s14),
      _PositionNote(position: position, now: now),
      const SizedBox(height: KnzSpace.s16),
      KnzButton(
        label: 'Navigovat na místo',
        icon: KnzIcons.navigate,
        size: KnzButtonSize.cta,
        onPressed: () => Navigator.pop(context, VisitSheetAction.navigate),
      ),
      const SizedBox(height: KnzSpace.s12),
      KnzButton(
        label: 'Jsem tu, zkusit znovu',
        variant: KnzButtonVariant.secondary,
        size: KnzButtonSize.cta,
        onPressed: () => Navigator.pop(context, VisitSheetAction.retry),
      ),
    ],
  ),
);

/// The position is not available: the location service is off, the
/// permission is denied, or the device cannot tell where it is.
Future<VisitSheetAction> showLocationProblemSheet(
  BuildContext context, {
  required LocationProblem problem,
  required bool canOpenSettings,
}) {
  final (title, text) = switch (problem) {
    LocationProblem.serviceDisabled => (
      'Poloha je vypnutá',
      'Zapni si v\u00A0telefonu polohu a\u00A0zkus to znovu.',
    ),
    LocationProblem.denied => (
      'Bez polohy to nepůjde',
      'Místo uložíš, jen když aplikaci povolíš polohu. Použije ji jen '
          'teď a\u00A0nikam ji neukládá.',
    ),
    LocationProblem.deniedForever => (
      'Bez polohy to nepůjde',
      kIsWeb
          ? 'Povol stránce polohu v\u00A0nastavení prohlížeče a\u00A0zkus '
                'to znovu.'
          : 'Povol aplikaci polohu v\u00A0nastavení telefonu a\u00A0zkus to '
                'znovu.',
    ),
    LocationProblem.unavailable => (
      'Polohu se nepodařilo zjistit',
      'Zkus to znovu pod širým nebem, kde telefon lépe chytí signál.',
    ),
    LocationProblem.timeout => (
      'Hledání polohy trvá moc dlouho',
      'Zkus to znovu pod širým nebem, kde telefon lépe chytí signál.',
    ),
  };
  return _showSheet(
    context,
    (context) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _SheetHeader(mood: KnzMood.sad, title: title, text: text),
        const SizedBox(height: KnzSpace.s20),
        if (canOpenSettings) ...[
          KnzButton(
            label: 'Otevřít nastavení',
            size: KnzButtonSize.cta,
            onPressed: () =>
                Navigator.pop(context, VisitSheetAction.openSettings),
          ),
          const SizedBox(height: KnzSpace.s12),
        ],
        KnzButton(
          label: 'Zkusit znovu',
          variant: canOpenSettings
              ? KnzButtonVariant.secondary
              : KnzButtonVariant.solid,
          size: KnzButtonSize.cta,
          onPressed: () => Navigator.pop(context, VisitSheetAction.retry),
        ),
      ],
    ),
  );
}

Future<VisitSheetAction> _showSheet(
  BuildContext context,
  WidgetBuilder content,
) async {
  final action = await showModalBottomSheet<VisitSheetAction>(
    context: context,
    isScrollControlled: true,
    backgroundColor: KnzColors.surface,
    barrierColor: KnzColors.text.withValues(alpha: 0.55),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(
        top: Radius.circular(KnzRadius.sheet),
      ),
    ),
    builder: (context) => SafeArea(
      top: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(
          KnzSize.screenGutter,
          KnzSpace.s10,
          KnzSize.screenGutter,
          KnzSpace.s20,
        ),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const _Handle(),
                const SizedBox(height: KnzSpace.s14),
                Stack(
                  children: [
                    content(context),
                    Positioned(
                      top: 0,
                      right: -KnzSpace.s10,
                      child: KnzIconButton(
                        icon: KnzIcons.close,
                        semanticLabel: 'Zavřít',
                        color: KnzColors.textSecondary,
                        onPressed: () =>
                            Navigator.pop(context, VisitSheetAction.close),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
  return action ?? VisitSheetAction.close;
}

class _Handle extends StatelessWidget {
  const _Handle();

  @override
  Widget build(BuildContext context) => Center(
    child: Container(
      width: 44,
      height: KnzSpace.s6,
      decoration: BoxDecoration(
        color: KnzColors.borderStrong,
        borderRadius: BorderRadius.circular(KnzRadius.pill),
      ),
    ),
  );
}

/// Vřídlík beside the heading; the close button sits in the free corner.
class _SheetHeader extends StatelessWidget {
  const _SheetHeader({
    required this.mood,
    required this.title,
    required this.text,
  });

  final KnzMood mood;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        KnzMascot(mood: mood, width: 96),
        const SizedBox(width: KnzSpace.s14),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(
              top: KnzSpace.s14,
              right: KnzSpace.s28,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Semantics(
                  header: true,
                  child: Text(title, style: KnzText.titleMd),
                ),
                const SizedBox(height: KnzSpace.s6),
                Text(
                  text,
                  style: KnzText.bodyLg.copyWith(
                    color: KnzColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// "Poloha zjištěna právě teď · přesnost ±12 m".
class _PositionNote extends StatelessWidget {
  const _PositionNote({required this.position, required this.now});

  final DevicePosition position;
  final DateTime now;

  @override
  Widget build(BuildContext context) {
    final minutes = now.difference(position.timestamp).inMinutes;
    final when = minutes < 1
        ? 'právě teď'
        : 'před ${Czech.count(minutes, 'minutou', 'minutami', 'minutami')}';
    final accuracy = Czech.distance(position.accuracyMeters);
    return Row(
      children: [
        const KnzIcon(KnzIcons.locate, size: 18, color: KnzColors.textMuted),
        const SizedBox(width: KnzSpace.s8),
        Expanded(
          child: Text(
            'Poloha zjištěna $when\u00A0· přesnost ±$accuracy',
            style: KnzText.weight(
              KnzText.bodySm,
              800,
            ).copyWith(color: KnzColors.textMuted),
          ),
        ),
      ],
    );
  }
}

/// A schematic sketch of the way from the player ("TY") to the place with
/// the visit radius around it. Not to scale and not a map.
class _WaySketch extends StatelessWidget {
  const _WaySketch({
    required this.distanceMeters,
    required this.visitRadiusMeters,
  });

  final double distanceMeters;
  final int visitRadiusMeters;

  static const _height = 150.0;
  static const _you = Alignment(-0.64, 0.4);
  static const _place = Alignment(0.64, -0.2);

  @override
  Widget build(BuildContext context) {
    final distance = Czech.distance(distanceMeters);
    final radius = Czech.distance(visitRadiusMeters.toDouble());
    return Semantics(
      image: true,
      label:
          'Plánek: k\u00A0místu ti zbývá $distance, uložit ho jde do $radius.',
      excludeSemantics: true,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(KnzRadius.xl3),
        child: SizedBox(
          height: _height,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final size = constraints.biggest;
              final you = _you.alongSize(size);
              final place = _place.alongSize(size);
              return Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned.fill(
                    child: CustomPaint(
                      painter: _WayPainter(you: you, place: place),
                    ),
                  ),
                  Positioned(
                    left: you.dx - 20,
                    top: you.dy + 16,
                    width: 40,
                    child: Text(
                      'TY',
                      textAlign: TextAlign.center,
                      style: KnzText.label.copyWith(
                        color: KnzColors.primaryEdge,
                      ),
                    ),
                  ),
                  Positioned(
                    left: place.dx - 24,
                    top: place.dy - 24,
                    child: SvgPicture.asset(
                      'design-system/assets/map/marker-target.svg',
                      width: 48,
                      height: 48,
                    ),
                  ),
                  Positioned(
                    left: place.dx - 40,
                    top: place.dy + 34,
                    width: 80,
                    child: Text(
                      radius,
                      textAlign: TextAlign.center,
                      style: KnzText.micro.copyWith(
                        color: KnzColors.accentText,
                      ),
                    ),
                  ),
                  Positioned(
                    top: KnzSpace.s10,
                    left: 0,
                    right: 0,
                    child: Center(child: _DistancePill(label: distance)),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _DistancePill extends StatelessWidget {
  const _DistancePill({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(
      horizontal: KnzSpace.s14,
      vertical: KnzSpace.s6,
    ),
    decoration: BoxDecoration(
      color: KnzColors.surface,
      borderRadius: BorderRadius.circular(KnzRadius.pill),
      boxShadow: KnzShadows.raisedSm,
    ),
    child: Text(label, style: KnzText.cardTitle),
  );
}

/// Flat landscape (`DESIGN.md`, Illustrations): meadow, river, bushes, the
/// dotted way and the dashed visit radius.
class _WayPainter extends CustomPainter {
  const _WayPainter({required this.you, required this.place});

  final Offset you;
  final Offset place;

  /// The sketch recorded for the last size and positions; the mascot in
  /// the sheet animates next to it.
  static final _cache = KnzPictureCache();

  @override
  void paint(Canvas canvas, Size size) =>
      _cache.paint(canvas, (size, you, place), (canvas) => _draw(canvas, size));

  void _draw(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    canvas.drawRect(Offset.zero & size, Paint()..color = KnzPalette.green50);

    // A lower meadow.
    canvas.drawPath(
      Path()
        ..moveTo(0, h * 0.82)
        ..cubicTo(w * 0.3, h * 0.66, w * 0.6, h * 0.9, w, h * 0.72)
        ..lineTo(w, h)
        ..lineTo(0, h)
        ..close(),
      Paint()..color = KnzPalette.green500.withValues(alpha: 0.12),
    );

    // The river across the top.
    canvas.drawPath(
      Path()
        ..moveTo(0, h * 0.26)
        ..cubicTo(w * 0.3, h * 0.18, w * 0.55, h * 0.3, w, h * 0.16),
      Paint()
        ..color = KnzPalette.teal200
        ..style = PaintingStyle.stroke
        ..strokeWidth = 10,
    );

    final bush = Paint()..color = KnzPalette.green500.withValues(alpha: 0.3);
    canvas
      ..drawCircle(Offset(w * 0.34, h * 0.62), 13, bush)
      ..drawCircle(Offset(w * 0.39, h * 0.67), 10, bush)
      ..drawCircle(Offset(w * 0.65, h * 0.42), 12, bush);

    // The dotted way.
    final way = Path()
      ..moveTo(you.dx, you.dy)
      ..cubicTo(
        you.dx + (place.dx - you.dx) * 0.35,
        you.dy - h * 0.45,
        place.dx - (place.dx - you.dx) * 0.3,
        place.dy + h * 0.3,
        place.dx,
        place.dy,
      );
    // The dots stay circles (a path of ovals antialiases their edges
    // differently); the cache records them only once.
    final dot = Paint()..color = KnzColors.primary;
    for (final metric in way.computeMetrics()) {
      for (var d = 14.0; d < metric.length - 26; d += 11) {
        canvas.drawCircle(metric.getTangentForOffset(d)!.position, 2.6, dot);
      }
    }

    // The visit radius: a gold area with a dashed rim.
    const radius = 32.0;
    canvas.drawCircle(
      place,
      radius,
      Paint()..color = KnzColors.accent.withValues(alpha: 0.18),
    );
    const dashes = 18;
    final circle = Rect.fromCircle(center: place, radius: radius);
    final rim = Path();
    for (var i = 0; i < dashes; i++) {
      rim.addArc(circle, i * 2 * math.pi / dashes, math.pi / dashes);
    }
    canvas.drawPath(
      rim,
      Paint()
        ..color = KnzColors.accentEdge
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.4,
    );

    // The player: a blue dot in a white ring with a soft halo.
    canvas
      ..drawCircle(you, 16, Paint()..color = KnzPalette.ink300)
      ..drawCircle(you, 11, Paint()..color = KnzColors.surface)
      ..drawCircle(you, 7.5, Paint()..color = KnzColors.primary);
  }

  @override
  bool shouldRepaint(_WayPainter old) => old.you != you || old.place != place;
}
