import 'device_location.dart';

/// The place card. A place in the fog has a card too, so that the player
/// can browse the region before guessing it.
class PlaceDetail {
  const PlaceDetail({
    required this.id,
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.factCount,
    this.category,
    this.description,
    this.source,
    this.stars,
    this.guessedAt,
    this.visitedAt,
    this.facts,
    this.rating,
    this.averageRating,
    this.ratingCount = 0,
  });

  final int id;
  final String name;
  final double latitude;
  final double longitude;

  /// The place type label, parts separated by " · ":
  /// "Národní kulturní památka · Hrad a zámek". Null when the client does
  /// not know it, for a place guessed on another device.
  final String? category;

  /// One sentence about what makes the place interesting, or null when the
  /// client does not know it.
  final String? description;

  /// The data source and licence, shown on every place card whose source
  /// the client knows.
  final String? source;

  /// How many facts a visit unlocks; 0 while the backend serves none.
  final int factCount;

  /// Stars for the hit, or null when the place was not guessed or the
  /// backend does not keep stars per place.
  final int? stars;

  final DateTime? guessedAt;
  final DateTime? visitedAt;

  /// The facts; null until the player visits the place.
  final List<String>? facts;

  /// The player's own rating, 1–5, or null when they have not rated it.
  final int? rating;

  /// The average rating of all players, or null when nobody rated it.
  final double? averageRating;

  /// How many players rated the place.
  final int ratingCount;

  bool get isGuessed => guessedAt != null;
  bool get isVisited => visitedAt != null;

  /// This card rated [stars] by the player, for a rating kept on the
  /// client: the player's rating counts once in the average.
  PlaceDetail rated(int stars) {
    final others = (averageRating ?? 0) * ratingCount - (rating ?? 0);
    final count = ratingCount + (rating == null ? 1 : 0);
    return PlaceDetail(
      id: id,
      name: name,
      latitude: latitude,
      longitude: longitude,
      category: category,
      description: description,
      source: source,
      factCount: factCount,
      stars: this.stars,
      guessedAt: guessedAt,
      visitedAt: visitedAt,
      facts: facts,
      rating: stars,
      averageRating: (others + stars) / count,
      ratingCount: count,
    );
  }

  PlaceDetail visited(DateTime at, List<String> facts) => PlaceDetail(
    id: id,
    name: name,
    latitude: latitude,
    longitude: longitude,
    category: category,
    description: description,
    source: source,
    factCount: facts.length,
    stars: stars,
    guessedAt: guessedAt,
    visitedAt: at,
    facts: facts,
    rating: rating,
    averageRating: averageRating,
    ratingCount: ratingCount,
  );
}

enum NearbyTipKind { spring, swimming, whenItRains }

/// A nearby tip that a visit unlocks: a spring, a place to swim, or
/// something for a rainy day.
class NearbyTip {
  const NearbyTip({
    required this.kind,
    required this.name,
    required this.distanceMeters,
  });

  final NearbyTipKind kind;
  final String name;
  final double distanceMeters;
}

/// What a visit came to.
sealed class VisitOutcome {
  const VisitOutcome({required this.distanceMeters});

  /// From the player's position to the place.
  final double distanceMeters;
}

/// The player stands within the visit radius: the place is visited.
class VisitConfirmed extends VisitOutcome {
  const VisitConfirmed({
    required super.distanceMeters,
    required this.place,
    this.nearby = const [],
    this.nearbySource,
    this.wafersEarned = 0,
  });

  /// The place card with the visit and the facts.
  final PlaceDetail place;

  /// Empty while the backend serves no nearby tips.
  final List<NearbyTip> nearby;

  /// The data source and licences of the nearby tips; null without tips.
  final String? nearbySource;

  /// Wafers the backend added for the visit: 50 for the first visit of the
  /// place, 0 for a repeated one or without an account.
  final int wafersEarned;
}

/// The player is outside the visit radius; nothing is recorded.
class VisitTooFar extends VisitOutcome {
  const VisitTooFar({required super.distanceMeters});
}

/// The place card and the visit.
abstract interface class PlaceSource {
  /// The card of a place, in the fog or not. Throws [PlaceNotFound] for a
  /// place the backend does not list.
  Future<PlaceDetail> load(int placeId);

  /// Records a visit from the player's [position], when it is within the
  /// visit radius. The client keeps neither the position nor the distance.
  Future<VisitOutcome> visit(int placeId, DevicePosition position);

  /// Rates a visited place with 1–5 [stars] and returns the card with the
  /// new rating, average and count. Rating again replaces the rating.
  Future<PlaceDetail> rate(int placeId, int stars);
}

class PlaceNotFound implements Exception {
  const PlaceNotFound(this.placeId);

  final int placeId;

  @override
  String toString() => 'PlaceNotFound($placeId)';
}
