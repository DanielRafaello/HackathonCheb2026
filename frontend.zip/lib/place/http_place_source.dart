import '../config/game_config.dart';
import '../my_map/locations_api.dart';
import '../my_map/my_map_place.dart';
import '../progress/place_card_cache.dart';
import '../progress/revealed_place.dart';
import 'device_location.dart';
import 'place_detail.dart';

/// The place card and the visit over the Game API, for a signed-in player.
///
/// The name, position, progress and ratings of a place come from
/// `GET /locations`, for places in the fog too.
/// The category, description and data source come from the
/// [PlaceCardCache], which holds the cards the player revealed on this
/// device, or else from `GET /locations/{id}/description` for a place
/// guessed or visited elsewhere; that card goes into the cache too. A place
/// in the fog asks for nothing: its texts stay hidden. The backend keeps no
/// facts, nearby tips or stars per place, so the card has none.
///
/// The visit radius is checked here: `POST /locations/{id}/progress`
/// records the player's action without a GPS check (FRONTEND_API_GUIDE,
/// "Mark progress"), so the client must not send a visit from afar. The
/// position is used for the distance and dropped.
class HttpPlaceSource implements PlaceSource {
  HttpPlaceSource({
    required this._api,
    required this._cache,
    this.config = GameConfig.defaults,
    this.clock = DateTime.now,
  });

  final LocationsApi _api;
  final PlaceCardCache _cache;
  final GameConfig config;
  final DateTime Function() clock;

  @override
  Future<PlaceDetail> load(int placeId) async {
    for (final place in await _api.list()) {
      // Places in the fog open too, so that the player can browse the
      // region; their card has the name and position only.
      if (place.id == placeId) return _detail(place);
    }
    throw PlaceNotFound(placeId);
  }

  @override
  Future<VisitOutcome> visit(int placeId, DevicePosition position) async {
    final before = await load(placeId);
    final distance = position.distanceTo(before.latitude, before.longitude);
    if (distance > config.visitRadiusMeters) {
      return VisitTooFar(distanceMeters: distance);
    }
    final (:place, :wafersEarned) = await _api.markVisited(placeId);
    final after = await _detail(
      place.isVisited ? place : place.withVisit(clock()),
    );
    return VisitConfirmed(
      distanceMeters: distance,
      place: after,
      wafersEarned: wafersEarned,
    );
  }

  @override
  Future<PlaceDetail> rate(int placeId, int stars) async =>
      _detail(await _api.rate(placeId, stars));

  Future<PlaceDetail> _detail(MyMapPlace place) async {
    final card = await _card(place);
    return PlaceDetail(
      id: place.id,
      name: place.name,
      latitude: place.latitude,
      longitude: place.longitude,
      category: _text(card?.category),
      description: _text(card?.description),
      source: card == null ? null : sourceLine(card),
      factCount: 0,
      guessedAt: place.guessedAt,
      visitedAt: place.visitedAt,
      facts: place.isVisited ? const [] : null,
      rating: place.rating,
      averageRating: place.averageRating,
      ratingCount: place.ratingCount ?? 0,
    );
  }

  /// The kept card of a guessed or visited place, or the backend's one;
  /// null for a place in the fog or when the backend cannot say. The card
  /// then shows what `GET /locations` carries.
  Future<RevealedPlace?> _card(MyMapPlace place) async {
    final kept = await _cache.read(place.id);
    if (kept != null || place.isUnknown) return kept;
    try {
      final card = await _api.description(place.id);
      await _cache.write(card);
      return card;
    } on LocationsApiException {
      return null;
    }
  }

  /// The source line of a card: "datazapad.cz · CC BY", or whichever of
  /// the label and the licence the backend sent; null when neither.
  static String? sourceLine(RevealedPlace card) {
    final source = card.source;
    if (source == null) return null;
    final parts = [
      source.label,
      _text(source.licenseCode),
    ].whereType<String>().toList();
    return parts.isEmpty ? null : parts.join(' · ');
  }

  static String? _text(String? value) {
    final trimmed = value?.trim();
    return trimmed == null || trimmed.isEmpty ? null : trimmed;
  }
}
