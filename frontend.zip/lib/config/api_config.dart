import 'package:flutter/foundation.dart';

/// Where the Game API lives.
class ApiConfig {
  const ApiConfig({required this.baseUrl});

  /// The deployed backend, which Traefik serves under `/api` on the same
  /// host as the web app.
  static final production = Uri.parse('https://aether217.zcu.cz/api');

  /// The backend from `../backend` started with `docker compose up`. It
  /// serves the API at the root, without `/api`.
  static final local = Uri.parse('http://localhost:8080');

  /// The development machine's `localhost` as the Android emulator sees it.
  static final localFromAndroidEmulator = Uri.parse('http://10.0.2.2:8080');

  /// Reads the base URL from `--dart-define=API_BASE_URL=<url>`.
  ///
  /// Without it, a debug build (`flutter run`) calls the local backend and
  /// a profile or release build calls the deployed one ([defaultBaseUrl]).
  factory ApiConfig.fromEnvironment() {
    const defined = String.fromEnvironment('API_BASE_URL');
    return ApiConfig(
      baseUrl: defined.isNotEmpty
          ? Uri.parse(defined)
          : defaultBaseUrl(
              debug: kDebugMode,
              web: kIsWeb,
              platform: defaultTargetPlatform,
            ),
    );
  }

  /// The base URL when none is defined: the local backend in a debug build,
  /// reached through `10.0.2.2` from an Android emulator, otherwise
  /// production. A physical Android phone needs
  /// `adb reverse tcp:8080 tcp:8080` and `API_BASE_URL=http://localhost:8080`.
  static Uri defaultBaseUrl({
    required bool debug,
    required bool web,
    required TargetPlatform platform,
  }) {
    if (!debug) return production;
    if (!web && platform == TargetPlatform.android) {
      return localFromAndroidEmulator;
    }
    return local;
  }

  final Uri baseUrl;

  /// The URL of an endpoint, for example `resolve('auth/login')`.
  Uri resolve(String path) => baseUrl.replace(
    path: '${baseUrl.path.replaceAll(RegExp(r'/+$'), '')}/$path',
  );
}
