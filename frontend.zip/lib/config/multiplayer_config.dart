import 'package:flutter/foundation.dart';

/// Where the multiplayer socket server lives, and where invite links lead.
///
/// The game's settings (players, places, the timer, the penalty distance)
/// are not here: the server owns them and sends them in its `welcome`
/// message.
class MultiplayerConfig {
  const MultiplayerConfig({required this.url, this._inviteBaseUrl});

  /// The deployed socket server, which Traefik serves under `/ws` on the
  /// same host as the web app. The web app is served over HTTPS, so the
  /// socket must be `wss://`.
  static final production = Uri.parse('wss://aether217.zcu.cz/ws');

  /// The socket server from `../backend/multiplayer` started locally.
  static final local = Uri.parse('ws://localhost:8090/ws');

  /// The development machine's `localhost` as the Android emulator sees it.
  static final localFromAndroidEmulator = Uri.parse('ws://10.0.2.2:8090/ws');

  /// The deployed web app, the base of invite links from the phone apps.
  static final productionWeb = Uri.parse('https://aether217.zcu.cz');

  /// Reads the URL from `--dart-define=MULTIPLAYER_URL=<url>`.
  ///
  /// Without it, a debug build (`flutter run`) connects to the local server
  /// and a profile or release build to the deployed one ([defaultUrl]).
  /// Invite links lead to the web app the page runs in, and from the phone
  /// apps to the deployed web app.
  factory MultiplayerConfig.fromEnvironment() {
    const defined = String.fromEnvironment('MULTIPLAYER_URL');
    return MultiplayerConfig(
      url: defined.isNotEmpty
          ? Uri.parse(defined)
          : defaultUrl(
              debug: kDebugMode,
              web: kIsWeb,
              platform: defaultTargetPlatform,
            ),
      inviteBaseUrl: kIsWeb ? Uri.base.replace(path: '', query: '') : null,
    );
  }

  /// The URL when none is defined: the local server in a debug build,
  /// reached through `10.0.2.2` from an Android emulator, otherwise
  /// production.
  static Uri defaultUrl({
    required bool debug,
    required bool web,
    required TargetPlatform platform,
  }) {
    if (!debug) return production;
    if (!web && platform == TargetPlatform.android) {
      return localFromAndroidEmulator;
    }
    return local;
  }

  /// The socket server's WebSocket endpoint.
  final Uri url;

  final Uri? _inviteBaseUrl;

  /// The link that opens lobby [code] in the web app:
  /// `https://aether217.zcu.cz/multiplayer/K7M2QX`.
  Uri inviteLink(String code) {
    final base = _inviteBaseUrl ?? productionWeb;
    return Uri(
      scheme: base.scheme,
      host: base.host,
      port: base.hasPort ? base.port : null,
      path: '/multiplayer/$code',
    );
  }
}
