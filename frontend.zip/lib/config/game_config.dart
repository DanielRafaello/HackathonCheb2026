/// The game constants of PRODUCT_SPECIFICATION.md (configuration). Widgets
/// read them from here and never write them as literals.
class GameConfig {
  const GameConfig({
    required this.maxStars,
    required this.maxRating,
    required this.placeOfTheDayClues,
    required this.freePlayClues,
    required this.hitRadiusMeters,
    required this.visitRadiusMeters,
    required this.timeZone,
  });

  /// The values of the product specification.
  static const defaults = GameConfig(
    maxStars: 5,
    maxRating: 5,
    placeOfTheDayClues: 4,
    freePlayClues: 3,
    hitRadiusMeters: 3000,
    visitRadiusMeters: 1000,
    timeZone: 'Europe/Prague',
  );

  /// Stars for a hit on the first guess. A round has no guess limit; each
  /// wrong guess costs one star down to one (PRODUCT_SPECIFICATION.md,
  /// story 16).
  final int maxStars;

  /// Stars of the best rating of a visited place (PRODUCT_SPECIFICATION.md,
  /// Rating). Not the stars of a round.
  final int maxRating;

  /// Clues of the place of the day: riddle, place type, numbers, and a
  /// second detail (PRODUCT_SPECIFICATION.md, Clue Progression). The
  /// compass comes after them.
  final int placeOfTheDayClues;

  /// Clues of a place in free play.
  final int freePlayClues;

  final int hitRadiusMeters;
  final int visitRadiusMeters;

  /// The place of the day changes at midnight in this time zone. Only
  /// Europe/Prague is supported (`lib/game/game_day.dart`).
  final String timeZone;

  /// The most stars a hit can still earn after [wrongGuesses]: one fewer
  /// per wrong guess, never fewer than one (PRODUCT_SPECIFICATION.md,
  /// story 16). The backend awards the stars; the client only shows them.
  int starsAvailable(int wrongGuesses) =>
      (maxStars - wrongGuesses).clamp(1, maxStars);

  /// Clues unlocked after [wrongGuesses], out of [clueCount]: the first
  /// from the start, one more per wrong guess.
  int cluesUnlocked(int wrongGuesses, int clueCount) =>
      (1 + wrongGuesses).clamp(0, clueCount);

  /// The compass points to the target once a guess with every clue
  /// unlocked has missed: from the [placeOfTheDayClues]th wrong guess on,
  /// for as long as the round goes (PRODUCT_SPECIFICATION.md, story 25).
  bool compassActive(int wrongGuesses) => wrongGuesses >= placeOfTheDayClues;
}
