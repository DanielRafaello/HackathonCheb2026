import 'package:maplibre_gl/maplibre_gl.dart';

/// Map settings: where the tiles and fonts come from and the area the camera
/// may show.
///
/// The base map is the regional extract that `tools/map/build_tiles.sh`
/// builds into one PMTiles archive. The app bundles the archive as an asset
/// (FRONTEND_SPECIFICATION.md section 3).
class MapConfig {
  const MapConfig({
    required this.tilesAsset,
    required this.glyphsUrl,
    required this.initialCamera,
    required this.cameraBounds,
    required this.minZoom,
    required this.maxZoom,
  });

  /// Reads the glyph URL from `--dart-define=MAP_GLYPHS_URL=<url template>`.
  ///
  /// TODO(frontend): where the label fonts are hosted is part of the open
  /// web hosting decision (FRONTEND_SPECIFICATION.md section 10).
  factory MapConfig.fromEnvironment() => MapConfig(
    tilesAsset: 'assets/map/kvk.pmtiles',
    glyphsUrl: const String.fromEnvironment(
      'MAP_GLYPHS_URL',
      defaultValue: 'https://fonts.openmaptiles.org/{fontstack}/{range}.pbf',
    ),
    initialCamera: const CameraPosition(
      target: LatLng(50.15, 12.75),
      zoom: 8.6,
    ),
    // The Karlovy Vary Region with a margin around it. The tile set covers
    // the bounding box 11.9–13.6 E, 49.7–50.6 N (tools/map/config.json).
    cameraBounds: LatLngBounds(
      southwest: const LatLng(49.75, 11.90),
      northeast: const LatLng(50.60, 13.50),
    ),
    minZoom: 7,
    maxZoom: 14,
  );

  /// This configuration with another start camera, camera bounds, or zoom
  /// range.
  MapConfig copyWith({
    CameraPosition? initialCamera,
    LatLngBounds? cameraBounds,
    double? minZoom,
    double? maxZoom,
  }) => MapConfig(
    tilesAsset: tilesAsset,
    glyphsUrl: glyphsUrl,
    initialCamera: initialCamera ?? this.initialCamera,
    cameraBounds: cameraBounds ?? this.cameraBounds,
    minZoom: minZoom ?? this.minZoom,
    maxZoom: maxZoom ?? this.maxZoom,
  );

  /// Asset key of the PMTiles archive with the region's vector tiles.
  /// Copy a new build there from `build/map/kvk.pmtiles`.
  final String tilesAsset;

  /// Template of the glyph (font) URL for map labels, with `{fontstack}` and
  /// `{range}` placeholders.
  final String glyphsUrl;

  final CameraPosition initialCamera;
  final LatLngBounds cameraBounds;
  final double minZoom;
  final double maxZoom;
}
