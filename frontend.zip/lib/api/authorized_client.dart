import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../account/session.dart';
import '../config/api_config.dart';

/// Why an authorized request never reached a usable answer.
enum ApiTransportError {
  /// No connection, or the request did not reach the backend.
  network,

  /// The backend did not answer within [AuthorizedClient.timeout].
  timeout,

  /// There is no signed-in session, or the backend rejected the JWT and the
  /// refresh token could not buy a new one. The session has been ended.
  unauthorized,
}

class ApiTransportException implements Exception {
  const ApiTransportException(this.error);

  final ApiTransportError error;

  @override
  String toString() => 'ApiTransportException($error)';
}

/// Sends the signed-in player's requests to the Game API.
///
/// It adds `Authorization: Bearer <JWT>` from the [Session], and when the
/// backend answers 401 it refreshes the JWT once and retries the request
/// once (FRONTEND_API_GUIDE, "Refresh an expired access token"). Several
/// requests failing together share one refresh, which [Session.refresh]
/// guarantees. Every other status comes back to the caller, which knows
/// what the endpoint's errors mean.
///
/// Throws [ApiTransportException], never anything else, when no response
/// could be had.
class AuthorizedClient {
  AuthorizedClient({
    required this.config,
    required this._session,
    http.Client? client,
    this.timeout = const Duration(seconds: 15),
  }) : _client = client ?? http.Client();

  final ApiConfig config;
  final Session _session;
  final http.Client _client;

  /// How long one request may take before it counts as lost.
  final Duration timeout;

  Future<http.Response> get(String path) => _authorized(
    (headers) => _client.get(config.resolve(path), headers: headers),
  );

  Future<http.Response> post(String path, Object? body) => _authorized(
    (headers) => _client.post(
      config.resolve(path),
      headers: {...headers, 'Content-Type': 'application/json'},
      body: jsonEncode(body),
    ),
  );

  Future<http.Response> put(String path, Object? body) => _authorized(
    (headers) => _client.put(
      config.resolve(path),
      headers: {...headers, 'Content-Type': 'application/json'},
      body: jsonEncode(body),
    ),
  );

  Future<http.Response> _authorized(
    Future<http.Response> Function(Map<String, String> headers) request,
  ) async {
    final token = _session.token;
    if (token == null) {
      throw const ApiTransportException(ApiTransportError.unauthorized);
    }
    final first = await _send(request, token);
    if (first.statusCode != 401) return first;

    // The JWT is short-lived; an expired one is the usual case. A rejected
    // refresh token ends the session, and the player is sent to sign-in.
    final fresh = await _session.refresh() ? _session.token : null;
    if (fresh == null) {
      throw const ApiTransportException(ApiTransportError.unauthorized);
    }
    final second = await _send(request, fresh);
    if (second.statusCode == 401) {
      // Never a third try (FRONTEND_API_GUIDE).
      throw const ApiTransportException(ApiTransportError.unauthorized);
    }
    return second;
  }

  Future<http.Response> _send(
    Future<http.Response> Function(Map<String, String> headers) request,
    String token,
  ) async {
    try {
      return await request({
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      }).timeout(timeout);
    } on TimeoutException {
      throw const ApiTransportException(ApiTransportError.timeout);
    } on Exception {
      throw const ApiTransportException(ApiTransportError.network);
    }
  }
}

/// The JSON body of [response], or an empty map when it is not a JSON
/// object. The backend's error bodies are objects too
/// (`{ error, status, message, errors? }`).
Map<String, dynamic> jsonBody(http.Response response) {
  try {
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    return decoded is Map<String, dynamic> ? decoded : const {};
  } on Object {
    return const {};
  }
}

/// `Retry-After` of a 429 response as a duration, when it is in seconds.
Duration? retryAfter(http.Response response) {
  final seconds = int.tryParse(response.headers['retry-after'] ?? '');
  return seconds == null ? null : Duration(seconds: seconds);
}
