import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'account/register_page.dart';
import 'account/session.dart';
import 'account/sign_in_page.dart';
import 'api/authorized_client.dart';
import 'app_routes.dart';
import 'config/game_config.dart';
import 'config/map_config.dart';
import 'config/multiplayer_config.dart';
import 'design_system/design_system_page.dart';
import 'home/account_home_summary.dart';
import 'home/app_shell.dart';
import 'home/game_modes_page.dart';
import 'home/home_page.dart';
import 'home/placeholder_pages.dart';
import 'multiplayer/multiplayer_connection.dart';
import 'multiplayer/multiplayer_page.dart';
import 'multiplayer/multiplayer_store.dart';
import 'my_map/locations_api.dart';
import 'my_map/my_map_page.dart';
import 'my_map/places_map.dart';
import 'place/device_location.dart';
import 'place/directions.dart';
import 'place/http_place_source.dart';
import 'place/place_demo.dart';
import 'place/place_detail_page.dart';
import 'profile/profile_api.dart';
import 'profile/profile_page.dart';
import 'progress/place_card_cache.dart';
import 'round/active_round_store.dart';
import 'round/fake_round_api.dart';
import 'round/guess_map.dart';
import 'round/http_round_api.dart';
import 'round/place_of_the_day_page.dart';
import 'round/round_api.dart';

/// The sign-in guard: where [location] leads for the current [session], or
/// null to stay.
///
/// - While the session from the previous start is restoring, everything
///   waits on the loading page.
/// - A player who has neither signed in nor chosen to play as a guest goes
///   to sign-in; `from` remembers the location for after sign-in.
/// - A signed-in player on an account page goes on to `from` or Home. A
///   guest may open the account pages to sign in.
///
/// The router runs it on every navigation and whenever the session changes.
String? sessionRedirect(Session session, Uri location) {
  final path = location.path;
  if (path == AppRoutes.designSystem) return null;
  if (!kReleaseMode && path == AppRoutes.placeDemo) return null;
  final from = location.queryParameters['from'];

  if (!session.isRestored) {
    return path == AppRoutes.loading
        ? null
        : _withFrom(AppRoutes.loading, location);
  }
  if (path == AppRoutes.loading) {
    return session.hasEntered
        ? AppRoutes.after(from)
        : _withFrom(AppRoutes.signIn, Uri.parse(AppRoutes.after(from)));
  }

  final onAccountPage = path == AppRoutes.signIn || path == AppRoutes.register;
  if (!session.hasEntered && !onAccountPage) {
    return _withFrom(AppRoutes.signIn, location);
  }
  if (session.isSignedIn && onAccountPage) return AppRoutes.after(from);
  return null;
}

/// [target] remembering [location], unless it is just Home.
String _withFrom(String target, Uri location) {
  final from = location.toString();
  if (from == AppRoutes.home) return target;
  return Uri(path: target, queryParameters: {'from': from}).toString();
}

/// The app's routes.
///
/// A signed-in player plays over the Game API ([client]); a guest plays the
/// place of the day in demo mode over [FakeRoundApi], since the backend
/// keeps rounds and progress only for accounts. [roundApi] replaces both,
/// for tests.
///
/// Multiplayer connects to [multiplayerConfig] ([multiplayerConnector]
/// replaces the WebSocket, for tests). [mapBuilder] replaces the blind
/// map of the place of the day and multiplayer, for tests.
GoRouter createRouter({
  required Session session,
  required MapConfig mapConfig,
  required AuthorizedClient client,
  required LocationsApi locationsApi,
  PlaceCardCache? placeCardCache,
  RoundApi? roundApi,
  ActiveRoundStore? roundStore,
  GameConfig gameConfig = GameConfig.defaults,
  DateTime Function() clock = DateTime.now,
  LocationReader location = const DeviceLocation(),
  Future<bool> Function(double latitude, double longitude) directions =
      openDirections,
  String initialLocation = AppRoutes.home,
  MultiplayerConfig? multiplayerConfig,
  MultiplayerConnector? multiplayerConnector,
  MultiplayerStore? multiplayerStore,
  GuessMapBuilder? mapBuilder,
}) {
  final multiplayer = multiplayerConfig ?? MultiplayerConfig.fromEnvironment();
  final multiplayerSeats =
      multiplayerStore ?? SharedPreferencesMultiplayerStore();
  final guessMap =
      mapBuilder ??
      (view) => GuessMap(
        config: mapConfig,
        pin: view.pin,
        lastGuess: view.lastGuess,
        enabled: view.enabled,
        onPin: view.onPin,
        interactive: view.interactive,
      );
  Widget multiplayerPage(BuildContext context, String? code) => MultiplayerPage(
    key: ValueKey(code),
    config: multiplayer,
    session: session,
    mapBuilder: guessMap,
    joinCode: code,
    connect: multiplayerConnector,
    store: multiplayerSeats,
    clock: clock,
    onClose: () =>
        context.canPop() ? context.pop() : context.go(AppRoutes.freePlay),
  );

  final cache = placeCardCache ?? MemoryPlaceCardCache();
  final demoRounds = FakeRoundApi(config: gameConfig, clock: clock);
  final profileApi = ProfileApi(client: client);
  final accountRounds = HttpRoundApi(
    client: client,
    cache: cache,
    config: gameConfig,
  );
  RoundApi rounds() =>
      roundApi ?? (session.isSignedIn ? accountRounds : demoRounds);
  final activeRound = roundStore ?? MemoryActiveRoundStore();

  final places = HttpPlaceSource(
    api: locationsApi,
    cache: cache,
    config: gameConfig,
    clock: clock,
  );
  final homeSummary = AccountHomeSummary(
    locations: locationsApi,
    client: client,
  );

  // The cached cards belong to the account that guessed the places; they
  // go when it signs out or its session is rejected.
  var wasSignedIn = session.isSignedIn;
  session.addListener(() {
    if (wasSignedIn && !session.isSignedIn) cache.clear();
    wasSignedIn = session.isSignedIn;
  });

  return GoRouter(
    initialLocation: initialLocation,
    refreshListenable: session,
    redirect: (context, state) => sessionRedirect(session, state.uri),
    routes: [
      GoRoute(
        path: AppRoutes.loading,
        builder: (context, state) => const LoadingPage(),
      ),
      GoRoute(
        path: AppRoutes.signIn,
        builder: (context, state) => SignInPage(
          session: session,
          from: state.uri.queryParameters['from'],
        ),
      ),
      GoRoute(
        path: AppRoutes.register,
        builder: (context, state) => RegisterPage(
          session: session,
          from: state.uri.queryParameters['from'],
        ),
      ),
      GoRoute(
        path: AppRoutes.placeOfTheDay,
        builder: (context, state) => PlaceOfTheDayPage(
          api: rounds(),
          store: activeRound,
          config: gameConfig,
          clock: clock,
          mapBuilder: guessMap,
          onClose: () =>
              context.canPop() ? context.pop() : context.go(AppRoutes.home),
        ),
      ),
      GoRoute(
        path: AppRoutes.multiplayer,
        builder: (context, state) => multiplayerPage(context, null),
      ),
      GoRoute(
        path: AppRoutes.multiplayerLobbyPattern,
        builder: (context, state) =>
            multiplayerPage(context, state.pathParameters['code']),
      ),
      // Before the place pattern, which would take "demo" for an id.
      if (!kReleaseMode)
        GoRoute(
          path: AppRoutes.placeDemo,
          builder: (context, state) {
            final query = state.uri.queryParameters;
            return PlaceDetailPage(
              key: ValueKey(state.uri.toString()),
              placeId: 0,
              source: PlaceDemo.source(
                visited: query['visited'] == '1',
                config: gameConfig,
                clock: clock,
              ),
              location: DemoLocation(DemoGps.parse(query['gps']), clock: clock),
              openDirections: directions,
              config: gameConfig,
              clock: clock,
              onClose: () =>
                  context.canPop() ? context.pop() : context.go(AppRoutes.home),
            );
          },
        ),
      GoRoute(
        path: AppRoutes.placePattern,
        builder: (context, state) {
          final id = int.tryParse(state.pathParameters['id'] ?? '') ?? -1;
          return PlaceDetailPage(
            key: ValueKey(id),
            placeId: id,
            source: places,
            location: location,
            openDirections: directions,
            config: gameConfig,
            clock: clock,
            onClose: () =>
                context.canPop() ? context.pop() : context.go(AppRoutes.myMap),
          );
        },
      ),
      GoRoute(
        path: AppRoutes.designSystem,
        builder: (context, state) => const DesignSystemPage(),
      ),
      ShellRoute(
        builder: (context, state, child) =>
            AppShell(location: state.uri.path, child: child),
        routes: [
          GoRoute(
            path: AppRoutes.home,
            pageBuilder: (context, state) => NoTransitionPage(
              child: ListenableBuilder(
                listenable: session,
                builder: (context, _) => HomePage(
                  // A guest's progress lives nowhere yet (demo mode), so
                  // Home shows an empty summary for them.
                  load: session.isSignedIn ? homeSummary.load : null,
                  config: gameConfig,
                  now: clock(),
                ),
              ),
            ),
          ),
          GoRoute(
            path: AppRoutes.freePlay,
            pageBuilder: (context, state) =>
                const NoTransitionPage(child: GameModesPage()),
          ),
          GoRoute(
            path: AppRoutes.myMap,
            pageBuilder: (context, state) => NoTransitionPage(
              child: ListenableBuilder(
                listenable: session,
                builder: (context, _) => MyMapPage(
                  account: session.account,
                  load: locationsApi.list,
                  mapBuilder: (shown, onTap) => PlacesMap(
                    config: mapConfig,
                    places: shown,
                    onPlaceTap: onTap,
                  ),
                  onOpenPlace: (place) =>
                      context.push<void>(AppRoutes.place(place.id)),
                  onSignIn: () => _signIn(context, AppRoutes.myMap),
                ),
              ),
            ),
          ),
          GoRoute(
            path: AppRoutes.profile,
            pageBuilder: (context, state) => NoTransitionPage(
              child: ListenableBuilder(
                listenable: session,
                builder: (context, _) => ProfilePage(
                  account: session.account,
                  load: locationsApi.list,
                  loadLevel: profileApi.level,
                  onOpenMap: () => context.go(AppRoutes.myMap),
                  onOpenPlace: (place) =>
                      context.push<void>(AppRoutes.place(place.id)),
                  config: gameConfig,
                  onSignIn: () => _signIn(context, AppRoutes.profile),
                  onSignOut: session.signOut,
                ),
              ),
            ),
          ),
        ],
      ),
    ],
  );
}

/// Opens sign-in, coming back to [from] afterwards.
void _signIn(BuildContext context, String from) => context.push(
  Uri(path: AppRoutes.signIn, queryParameters: {'from': from}).toString(),
);
