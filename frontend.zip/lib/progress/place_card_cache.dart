import 'revealed_place.dart';

/// Keeps the revealed cards of places the player has guessed on this
/// device, so the place card can show the description and the data source
/// that `GET /locations` does not carry (API_SPECIFICATION.md 4.1).
///
/// Only guessed places go in (PRODUCT_SPECIFICATION.md: the client never
/// holds the texts of a place the player has not guessed). Implementations
/// never throw: when the storage fails, the card simply shows less.
abstract interface class PlaceCardCache {
  Future<RevealedPlace?> read(int placeId);

  Future<void> write(RevealedPlace place);

  /// Forgets every card, for sign-out.
  Future<void> clear();
}

/// Keeps the cards for as long as the app runs. For tests and as the
/// fallback when persistent storage is unavailable.
class MemoryPlaceCardCache implements PlaceCardCache {
  final _cards = <int, RevealedPlace>{};

  @override
  Future<RevealedPlace?> read(int placeId) async => _cards[placeId];

  @override
  Future<void> write(RevealedPlace place) async => _cards[place.id] = place;

  @override
  Future<void> clear() async => _cards.clear();
}
