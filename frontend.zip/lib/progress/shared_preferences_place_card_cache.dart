import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'place_card_cache.dart';
import 'revealed_place.dart';

/// [PlaceCardCache] in the platform's preferences: one JSON document per
/// place under `knz.placeCard.v1.<id>`, with the ids in an index for
/// [clear].
///
/// Never throws: in a private browser window, or when the storage is full
/// or broken, a read gives null and a write is dropped, and the place card
/// simply shows less (CLAUDE.md, Platforms: Storage).
class SharedPreferencesPlaceCardCache implements PlaceCardCache {
  SharedPreferencesPlaceCardCache({
    this._preferences = SharedPreferences.getInstance,
  });

  final Future<SharedPreferences> Function() _preferences;

  /// The version is part of the key: a new card shape gets new keys and
  /// leaves the old ones unread.
  static const keyPrefix = 'knz.placeCard.v1.';
  static const indexKey = '${keyPrefix}index';

  static String keyOf(int placeId) => '$keyPrefix$placeId';

  @override
  Future<RevealedPlace?> read(int placeId) async {
    try {
      final json = (await _preferences()).getString(keyOf(placeId));
      if (json == null) return null;
      return RevealedPlace.fromJson(jsonDecode(json) as Map<String, dynamic>);
    } on Object {
      return null;
    }
  }

  @override
  Future<void> write(RevealedPlace place) async {
    try {
      final preferences = await _preferences();
      final index = preferences.getStringList(indexKey) ?? const [];
      final id = '${place.id}';
      await preferences.setString(keyOf(place.id), jsonEncode(place.toJson()));
      if (!index.contains(id)) {
        await preferences.setStringList(indexKey, [...index, id]);
      }
    } on Object {
      // The card stays in memory for this session only.
    }
  }

  @override
  Future<void> clear() async {
    try {
      final preferences = await _preferences();
      for (final id in preferences.getStringList(indexKey) ?? const []) {
        await preferences.remove('$keyPrefix$id');
      }
      await preferences.remove(indexKey);
    } on Object {
      // Nothing to forget, or no way to.
    }
  }
}
