/// What the backend reveals about a place once the player has hit it: the
/// `location` object of a `guessed` round (API_SPECIFICATION.md 5.3).
///
/// The client may hold it only for a place the player has guessed
/// (PRODUCT_SPECIFICATION.md). A round has no guess limit, so no other
/// round reveals its place.
class RevealedPlace {
  const RevealedPlace({
    required this.id,
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.category,
    required this.description,
    this.contentSourceUrl,
    this.source,
  });

  /// Throws [FormatException] when [json] is not a revealed location.
  factory RevealedPlace.fromJson(Map<String, dynamic> json) {
    final source = json['source'];
    return RevealedPlace(
      id: (json['id'] as num).toInt(),
      name: json['name'] as String,
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      category: json['category'] as String? ?? '',
      description: json['description'] as String? ?? '',
      contentSourceUrl: json['content_source_url'] as String?,
      source: source is Map<String, dynamic>
          ? PlaceSourceInfo.fromJson(source)
          : null,
    );
  }

  final int id;
  final String name;
  final double latitude;
  final double longitude;

  /// The backend's category: "Hrady, tvrze a zříceniny".
  final String category;
  final String description;

  /// The public page the description was prepared from, if any.
  final String? contentSourceUrl;

  /// The dataset the place comes from and its licence, when the backend
  /// knows them.
  final PlaceSourceInfo? source;

  /// A spring's card always warns about its water
  /// (PRODUCT_SPECIFICATION.md). The current catalog has no spring
  /// category; this keeps the warning for the day it gets one.
  bool get isSpring => category.toLowerCase().contains('pramen');

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'latitude': latitude,
    'longitude': longitude,
    'category': category,
    'description': description,
    'content_source_url': contentSourceUrl,
    'source': source?.toJson(),
  };
}

/// The dataset provenance of a place (`location.source`).
class PlaceSourceInfo {
  const PlaceSourceInfo({
    this.title,
    this.publisher,
    this.portalUrl,
    this.licenseCode,
    this.licenseUrl,
    this.attributionText,
  });

  factory PlaceSourceInfo.fromJson(Map<String, dynamic> json) =>
      PlaceSourceInfo(
        title: json['title'] as String?,
        publisher: json['publisher'] as String?,
        portalUrl: json['portal_url'] as String?,
        licenseCode: json['license_code'] as String?,
        licenseUrl: json['license_url'] as String?,
        attributionText: json['attribution_text'] as String?,
      );

  final String? title;
  final String? publisher;
  final String? portalUrl;
  final String? licenseCode;
  final String? licenseUrl;
  final String? attributionText;

  /// The source as a place card names it: the attribution text when the
  /// publisher requires one, otherwise the publisher or the dataset title.
  /// Null when nothing is known; the UI then shows no source line rather
  /// than an invented one (copy.md).
  String? get label {
    for (final candidate in [attributionText, publisher, title]) {
      if (candidate != null && candidate.trim().isNotEmpty) {
        return candidate.trim();
      }
    }
    return null;
  }

  Map<String, dynamic> toJson() => {
    'title': title,
    'publisher': publisher,
    'portal_url': portalUrl,
    'license_url': licenseUrl,
    'license_code': licenseCode,
    'attribution_text': attributionText,
  };
}
