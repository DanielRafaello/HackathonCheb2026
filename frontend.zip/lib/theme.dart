import 'package:flutter/material.dart';

/// The app's look, in the colours of the game map (`lib/map/map_style.dart`).
abstract final class AppTheme {
  /// The forest green of the map's region border, darkened for contrast.
  static const forest = Color(0xFF4A7A2C);

  /// The meadow green of the region fill.
  static const meadow = Color(0xFFDCECC8);

  /// The slate of the map labels.
  static const ink = Color(0xFF3B4256);

  /// The map background outside the region.
  static const mist = Color(0xFFE7EBF3);

  static ThemeData get light {
    final scheme = ColorScheme.fromSeed(
      seedColor: forest,
      primary: forest,
      surface: Colors.white,
      onSurface: ink,
    );
    final base = ThemeData(colorScheme: scheme, scaffoldBackgroundColor: mist);
    return base.copyWith(
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFFF5F7FA),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 16,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFDDE2EC)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: forest, width: 2),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: base.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
