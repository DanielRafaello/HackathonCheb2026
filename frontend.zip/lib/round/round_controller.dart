import 'dart:async';

import 'package:flutter/foundation.dart';

import '../config/game_config.dart';
import '../game/game_day.dart';
import 'active_round_store.dart';
import 'round.dart';
import 'round_api.dart';

enum RoundPhase {
  /// Asking the backend for today's round.
  loading,

  /// The round could not be loaded; [RoundController.loadError] says why.
  loadFailed,

  /// Every place is guessed; there is no place of the day.
  allGuessed,

  /// The round is open: place a pin and confirm it.
  playing,

  /// The round ended with a hit, the only way it ends.
  finished,
}

/// Something to tell the player in a toast. The round goes on.
enum RoundNoticeKind {
  /// The guess lies outside the region and did not count.
  outsideRegion,
  network,
  timeout,
  server,
  unauthorized,
  rateLimited,

  /// The day ended during the round; today's round has been loaded.
  dayChanged,

  /// The round ended elsewhere, for example on another device.
  finishedElsewhere,

  /// The backend no longer knows the round; it has been loaded again.
  roundLost,
}

class RoundNotice {
  const RoundNotice(this.kind, {this.retryAfter});

  final RoundNoticeKind kind;

  /// For [RoundNoticeKind.rateLimited], when the backend said.
  final Duration? retryAfter;
}

/// What a wrong guess changed, for the panel after it.
class MissFeedback {
  const MissFeedback({
    required this.wrongGuesses,
    required this.starsAvailable,
    this.newClue,
    this.newClueNumber,
    this.compass,
    this.compassIsNew = false,
    this.compassNext = false,
  });

  final int wrongGuesses;

  /// The most stars a hit can still earn.
  final int starsAvailable;

  /// The clue this guess unlocked, if any, and its number from 1.
  final Clue? newClue;
  final int? newClueNumber;

  /// The compass from this guess, once it is active.
  final Compass? compass;

  /// This guess turned the compass on.
  final bool compassIsNew;

  /// Every clue is unlocked and the compass is not on yet: the next miss
  /// turns it on.
  final bool compassNext;
}

/// Runs one place-of-the-day round for the screen.
///
/// A round has no guess limit and ends only with a hit. The player can
/// leave at any time; the backend keeps the round, and [load] continues it
/// with the clues and the compass where the player left them.
///
/// The backend decides everything: whether a guess hits, which clues are
/// unlocked, where the compass points, and how many stars a hit earns. The
/// controller only keeps the player's unconfirmed pin, sends one guess at a
/// time, and turns failures into states and notices. Answers that arrive
/// after a newer load are dropped.
class RoundController extends ChangeNotifier {
  RoundController({
    required this._api,
    required this._store,
    this.config = GameConfig.defaults,
    this._clock = DateTime.now,
  });

  final RoundApi _api;
  final ActiveRoundStore _store;
  final GameConfig config;
  final DateTime Function() _clock;

  final _notices = StreamController<RoundNotice>.broadcast();

  /// Counts loads; an answer from an older load is stale.
  int _generation = 0;
  bool _disposed = false;

  RoundPhase _phase = RoundPhase.loading;
  RoundPhase get phase => _phase;

  RoundErrorKind? _loadError;

  /// Why the last load failed.
  RoundErrorKind? get loadError => _loadError;

  RoundState? _round;
  RoundState? get round => _round;

  GeoPoint? _pin;

  /// The player's unconfirmed guess.
  GeoPoint? get pin => _pin;

  bool _submitting = false;

  /// A guess is on its way to the backend.
  bool get submitting => _submitting;

  MissFeedback? _miss;

  /// Set after a wrong guess until the player goes on with
  /// [dismissMiss].
  MissFeedback? get miss => _miss;

  /// Toasts for the screen.
  Stream<RoundNotice> get notices => _notices.stream;

  /// The most stars a hit can still earn.
  int get starsAvailable => config.starsAvailable(_round?.wrongGuesses ?? 0);

  /// The player may move the pin and confirm it.
  bool get canGuess =>
      _phase == RoundPhase.playing && !_submitting && _miss == null;

  /// Loads today's round, continuing the saved one when it is still
  /// today's. Safe to call again at any time, for example to retry.
  Future<void> load() async {
    final generation = ++_generation;
    _phase = RoundPhase.loading;
    _loadError = null;
    _submitting = false;
    _miss = null;
    _pin = null;
    _notify();

    String? saved;
    try {
      saved = await _store.readDailyToken();
    } on Object catch (error) {
      // Without the token the backend starts or finds today's round anyway.
      debugPrint('Saved round unavailable: $error');
    }
    if (_isStale(generation)) return;

    try {
      final daily = await _api.placeOfTheDay(resumeToken: saved);
      if (_isStale(generation)) return;
      switch (daily) {
        case AllPlacesGuessed():
          _round = null;
          _phase = RoundPhase.allGuessed;
          unawaited(_forgetToken());
        case DailyRoundReady(:final round):
          _adopt(round);
      }
    } on RoundApiException catch (error) {
      if (_isStale(generation)) return;
      _fail(error.kind);
    } on Object catch (error) {
      if (_isStale(generation)) return;
      debugPrint('Place of the day failed to load: $error');
      _fail(RoundErrorKind.server);
    }
    _notify();
  }

  void _fail(RoundErrorKind kind) {
    _round = null;
    _phase = RoundPhase.loadFailed;
    _loadError = kind;
  }

  /// Puts the unconfirmed pin at [position], or moves it there.
  void placePin(GeoPoint position) {
    if (!canGuess || !position.isValid) return;
    _pin = position;
    _notify();
  }

  /// Sends the pin as a guess. Does nothing without a pin or while another
  /// guess is on its way, so a double tap counts once.
  Future<void> confirmGuess() async {
    final round = _round;
    final pin = _pin;
    if (!canGuess || round == null || pin == null) return;
    final generation = _generation;
    _submitting = true;
    _notify();

    try {
      final outcome = await _api.guess(round.token, pin);
      if (_isStale(generation)) return;
      switch (outcome) {
        case GuessOutsideRegion():
          // Not counted: the pin stays for the player to move.
          _notice(const RoundNotice(RoundNoticeKind.outsideRegion));
        case GuessMissed(round: final next):
          _pin = null;
          _miss = _missFeedback(round, next);
          _adopt(next);
        case GuessHit(round: final next):
          if (!next.isFinished) {
            throw const RoundApiException(RoundErrorKind.server);
          }
          _pin = null;
          _adopt(next);
      }
    } on RoundApiException catch (error) {
      if (_isStale(generation)) return;
      await _onGuessFailed(error, round, pin, generation);
    } on Object catch (error) {
      if (_isStale(generation)) return;
      debugPrint('Guess failed: $error');
      _notice(const RoundNotice(RoundNoticeKind.server));
    } finally {
      if (!_isStale(generation)) {
        _submitting = false;
        _notify();
      }
    }
  }

  Future<void> _onGuessFailed(
    RoundApiException error,
    RoundState round,
    GeoPoint pin,
    int generation,
  ) async {
    switch (error.kind) {
      case RoundErrorKind.roundExpired:
        _notice(const RoundNotice(RoundNoticeKind.dayChanged));
        unawaited(load());
      case RoundErrorKind.roundFinished:
        _notice(const RoundNotice(RoundNoticeKind.finishedElsewhere));
        unawaited(load());
      case RoundErrorKind.roundNotFound:
        _notice(const RoundNotice(RoundNoticeKind.roundLost));
        unawaited(_forgetToken().then((_) => load()));
      case RoundErrorKind.network || RoundErrorKind.timeout:
        // The guess may have landed although its answer was lost, and a
        // guess is never sent again on its own (FRONTEND_API_GUIDE.md,
        // "Submit a guess"). Ask the backend what it knows.
        if (await _adoptLandedGuess(round, pin, generation)) return;
        if (_isStale(generation)) return;
        _notice(
          RoundNotice(
            error.kind == RoundErrorKind.network
                ? RoundNoticeKind.network
                : RoundNoticeKind.timeout,
          ),
        );
      case RoundErrorKind.unauthorized:
        _notice(const RoundNotice(RoundNoticeKind.unauthorized));
      case RoundErrorKind.rateLimited:
        _notice(
          RoundNotice(
            RoundNoticeKind.rateLimited,
            retryAfter: error.retryAfter,
          ),
        );
      case RoundErrorKind.server:
        _notice(const RoundNotice(RoundNoticeKind.server));
    }
  }

  /// Fetches the round after a guess whose answer was lost. When the
  /// backend counted the guess, shows it as the miss or hit it was and
  /// returns true. Otherwise the pin stays for the player to
  /// confirm again.
  Future<bool> _adoptLandedGuess(
    RoundState before,
    GeoPoint pin,
    int generation,
  ) async {
    final RoundState after;
    try {
      after = await _api.refresh(before.token);
    } on RoundApiException catch (error) {
      if (_isStale(generation)) return true;
      switch (error.kind) {
        case RoundErrorKind.roundExpired ||
            RoundErrorKind.roundFinished ||
            RoundErrorKind.roundNotFound:
          // The round itself is gone; this says more than the lost guess.
          await _onGuessFailed(error, before, pin, generation);
          return true;
        default:
          return false;
      }
    } on Object catch (error) {
      debugPrint('Round not refreshed: $error');
      return false;
    }
    if (_isStale(generation)) return true;
    final counted =
        after.wrongGuesses != before.wrongGuesses ||
        after.isFinished != before.isFinished;
    if (!counted) return false;

    _pin = null;
    // The backend returns no coordinates; the one guess it counted since
    // is the pin the player confirmed.
    final landed = after.wrongGuesses - before.wrongGuesses <= 1
        ? after.copyWith(lastGuess: pin)
        : after;
    if (!landed.isFinished) _miss = _missFeedback(before, landed);
    _adopt(landed);
    return true;
  }

  /// Closes the panel after a wrong guess, so the player can guess again.
  void dismissMiss() {
    if (_miss == null) return;
    _miss = null;
    _notify();
  }

  /// Loads the new place of the day when the day has changed since the
  /// round was loaded, for example after the app comes back from the
  /// background at midnight.
  void reloadIfDayChanged() {
    if (_submitting) return;
    final today = GameDay.of(_clock());
    final round = _round;
    final stale = switch (_phase) {
      RoundPhase.playing || RoundPhase.finished => round!.day != today,
      // New places may have been added to the catalog.
      RoundPhase.allGuessed => true,
      RoundPhase.loading || RoundPhase.loadFailed => false,
    };
    if (stale) unawaited(load());
  }

  void _adopt(RoundState round) {
    _round = round;
    _phase = round.isFinished ? RoundPhase.finished : RoundPhase.playing;
    unawaited(_saveToken(round.token));
  }

  MissFeedback _missFeedback(RoundState before, RoundState after) {
    Clue? newClue;
    int? number;
    for (var i = 0; i < after.clues.length; i++) {
      final wasLocked = i >= before.clues.length || !before.clues[i].isUnlocked;
      if (after.clues[i].isUnlocked && wasLocked) {
        newClue = after.clues[i];
        number = i + 1;
        break;
      }
    }
    final compass = after.compass;
    return MissFeedback(
      wrongGuesses: after.wrongGuesses,
      starsAvailable: config.starsAvailable(after.wrongGuesses),
      newClue: newClue,
      newClueNumber: number,
      compass: compass,
      compassIsNew: compass != null && before.compass == null,
      compassNext:
          compass == null &&
          after.clues.every((clue) => clue.isUnlocked) &&
          config.compassActive(after.wrongGuesses + 1),
    );
  }

  Future<void> _saveToken(String token) async {
    try {
      await _store.writeDailyToken(token);
    } on Object catch (error) {
      // The round goes on; only resuming it later needs the token.
      debugPrint('Round token not saved: $error');
    }
  }

  Future<void> _forgetToken() async {
    try {
      await _store.clearDailyToken();
    } on Object catch (error) {
      debugPrint('Round token not cleared: $error');
    }
  }

  bool _isStale(int generation) => _disposed || generation != _generation;

  void _notice(RoundNotice notice) {
    if (!_disposed) _notices.add(notice);
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _notices.close();
    super.dispose();
  }
}
