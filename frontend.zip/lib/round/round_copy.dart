import '../design_system/czech.dart';
import 'round.dart';
import 'round_controller.dart';

/// The Czech texts of a round that depend on data (copy.md).
abstract final class RoundCopy {
  static const _nbsp = ' ';

  static const _directions = [
    'na sever',
    'na severovýchod',
    'na východ',
    'na jihovýchod',
    'na jih',
    'na jihozápad',
    'na západ',
    'na severozápad',
  ];

  /// The compass direction for [bearingDegrees]: "na jihovýchod".
  static String direction(double bearingDegrees) {
    final normalized = bearingDegrees.isFinite ? bearingDegrees % 360 : 0.0;
    return _directions[((normalized + 22.5) ~/ 45) % 8];
  }

  /// A distance as the design writes it: "550 m", "1,2 km", "14 km".
  static String distance(double meters) {
    if (!meters.isFinite || meters < 0) return '–';
    if (meters < 1000) {
      final rounded = (meters / 10).round() * 10;
      return rounded >= 1000 ? '1${_nbsp}km' : '$rounded${_nbsp}m';
    }
    final km = meters / 1000;
    if (km < 10) {
      final tenths = (km * 10).round();
      if (tenths % 10 == 0 || tenths >= 100) {
        return '${(tenths / 10).round()}${_nbsp}km';
      }
      return '${tenths ~/ 10},${tenths % 10}${_nbsp}km';
    }
    return '${km.round()}${_nbsp}km';
  }

  /// The overline above the clues: "MÍSTO DNE · POKUS 3". A round has no
  /// guess limit, so there is no "z 5".
  static String overline(int guessNumber) =>
      'MÍSTO DNE$_nbsp· POKUS $guessNumber';

  /// What a screen reader says for the guess indicator: "Pokus 3", and
  /// "Pokus 6, kompas je zapnutý" once the compass points.
  static String guessProgress(int guessNumber, {required bool compass}) =>
      compass ? 'Pokus $guessNumber, kompas je zapnutý' : 'Pokus $guessNumber';

  /// The label of clue [number]: "KLÍČ 2 · TYP MÍSTA".
  static String clueLabel(int number, ClueKind kind) =>
      'KLÍČ $number$_nbsp· ${kind.title.toUpperCase()}';

  /// "4 z 5 hvězd", for screen readers.
  static String stars(int stars, int max) =>
      '${Czech.fraction(stars, max)} ${Czech.plural(max, 'hvězdy', 'hvězd', 'hvězd')}';

  /// The heading after a hit: "Trefa na 2. pokus!".
  static String hitHeading(int guesses) => 'Trefa na $guesses.${_nbsp}pokus!';

  /// The share text: the date, the guesses, and the stars, never the place
  /// (PRODUCT_SPECIFICATION.md, story 41).
  static String shareText({
    required DateTime day,
    required int guesses,
    required int stars,
    required int maxStars,
  }) {
    final date = '${day.day}.$_nbsp${day.month}.$_nbsp${day.year}';
    final bar = '★' * stars + '☆' * (maxStars - stars).clamp(0, maxStars);
    return 'Kde na západě$_nbsp· Místo dne $date\n'
        'Trefa na $guesses.${_nbsp}pokus, ${RoundCopy.stars(stars, maxStars)}\n'
        '$bar';
  }

  /// The toast for a [notice].
  static String notice(RoundNotice notice) => switch (notice.kind) {
    RoundNoticeKind.outsideRegion =>
      'Tip musí ležet v${_nbsp}Karlovarském kraji. Tenhle se nepočítá.',
    RoundNoticeKind.network =>
      'Tip se nepodařilo odeslat. Zkontroluj připojení a${_nbsp}zkus to znovu.',
    RoundNoticeKind.timeout =>
      'Server neodpověděl včas. Zkus tip potvrdit znovu.',
    RoundNoticeKind.server =>
      'Něco se pokazilo na naší straně. Zkus to za chvíli.',
    RoundNoticeKind.unauthorized => 'Přihlášení vypršelo. Přihlas se znovu.',
    RoundNoticeKind.rateLimited => switch (notice.retryAfter) {
      final wait? when wait.inSeconds > 0 =>
        'Moc tipů najednou. Zkus to znovu za ${Czech.count(wait.inSeconds, 'sekundu', 'sekundy', 'sekund')}.',
      _ => 'Moc tipů najednou. Zkus to znovu za chvíli.',
    },
    RoundNoticeKind.dayChanged => 'Začal nový den, tady je nové místo dne.',
    RoundNoticeKind.finishedElsewhere => 'Tohle kolo už je dohrané.',
    RoundNoticeKind.roundLost => 'Kolo se nepodařilo najít, načítám ho znovu.',
  };

  /// Vřídlík's line when the round could not be loaded.
  static String loadError(RoundErrorKind? kind) => switch (kind) {
    RoundErrorKind.network || RoundErrorKind.timeout =>
      'Místo dne se mi nepodařilo načíst. Zkontroluj připojení a${_nbsp}zkus to znovu.',
    RoundErrorKind.unauthorized =>
      'Tvoje přihlášení vypršelo. Přihlas se znovu a${_nbsp}můžeš hrát dál.',
    RoundErrorKind.rateLimited =>
      'Teď je tu moc rušno. Zkus to prosím za chvíli.',
    _ =>
      'Něco se mi pokazilo a${_nbsp}místo dne nemám. Zkus to prosím za chvíli.',
  };

  /// Where the pin is, by the nearest town: "kousek od Sokolova",
  /// "12 km od Chebu". Null far from every town.
  static String? nearTown(GeoPoint pin) {
    _Town? nearest;
    var best = double.infinity;
    for (final town in _towns) {
      final d = Geo.distanceMeters(pin, town.location);
      if (d < best) {
        best = d;
        nearest = town;
      }
    }
    if (nearest == null || best > 30000) return null;
    if (best < 3000) return 'kousek od ${nearest.genitive}';
    return '${(best / 1000).round()}${_nbsp}km od ${nearest.genitive}';
  }

  /// Towns of the region for the pin label, with the genitive form. Only
  /// public reference points; never places of the game.
  static const _towns = [
    _Town('Karlových Varů', GeoPoint(50.2306, 12.8711)),
    _Town('Chebu', GeoPoint(50.0796, 12.3739)),
    _Town('Sokolova', GeoPoint(50.1814, 12.6402)),
    _Town('Mariánských Lázní', GeoPoint(49.9646, 12.7012)),
    _Town('Ostrova', GeoPoint(50.3059, 12.9393)),
    _Town('Aše', GeoPoint(50.2239, 12.1950)),
    _Town('Františkových Lázní', GeoPoint(50.1205, 12.3517)),
    _Town('Chodova', GeoPoint(50.2413, 12.7454)),
    _Town('Kraslic', GeoPoint(50.3237, 12.5175)),
    _Town('Nejdku', GeoPoint(50.3224, 12.7294)),
    _Town('Jáchymova', GeoPoint(50.3586, 12.9346)),
    _Town('Horního Slavkova', GeoPoint(50.1387, 12.8077)),
    _Town('Lokte', GeoPoint(50.1860, 12.7540)),
    _Town('Toužimi', GeoPoint(50.0606, 12.9850)),
    _Town('Žlutic', GeoPoint(50.0920, 13.1630)),
    _Town('Teplé', GeoPoint(49.9822, 12.8635)),
    _Town('Kynšperka nad Ohří', GeoPoint(50.1190, 12.5297)),
    _Town('Habartova', GeoPoint(50.1830, 12.5506)),
    _Town('Lázní Kynžvart', GeoPoint(50.0103, 12.6247)),
    _Town('Bochova', GeoPoint(50.1500, 13.0440)),
    _Town('Božího Daru', GeoPoint(50.4097, 12.9245)),
    _Town('Hranic', GeoPoint(50.3040, 12.1757)),
  ];
}

class _Town {
  const _Town(this.genitive, this.location);

  final String genitive;
  final GeoPoint location;
}
