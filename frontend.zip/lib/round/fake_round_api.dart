import 'dart:collection';
import 'dart:math' as math;

import '../config/game_config.dart';
import '../game/game_day.dart';
import '../game/region.dart';
import 'round.dart';
import 'round_api.dart';

/// A place the fake backend can pick, with all its clues.
class FakePlace {
  const FakePlace({required this.card, required this.clues});

  final PlaceCard card;

  /// Every clue in unlock order, with its text.
  final List<Clue> clues;
}

/// The demo for a guest ("Zkusit bez účtu"): the round endpoints of the
/// Game API played in memory.
///
/// It plays the backend's part: it picks the place of the day, evaluates
/// guesses, unlocks clues, and points the compass. Like the real backend it
/// is the only side that knows the target; the controller and the screens
/// see only what [RoundApi] returns. It follows the product
/// specification's rules: four clues, unlimited guesses, the compass from
/// the miss after the last clue, and the hit radius of [GameConfig].
class FakeRoundApi implements RoundApi {
  FakeRoundApi({
    List<FakePlace>? places,
    this.config = GameConfig.defaults,
    this._clock = DateTime.now,
    math.Random? random,
    this.latency = const Duration(milliseconds: 350),
    Iterable<int> guessedPlaceIds = const [],
  }) : places = places ?? demoPlaces,
       _random = random ?? math.Random(),
       _guessed = {...guessedPlaceIds};

  final List<FakePlace> places;
  final GameConfig config;

  /// How long every call takes, to show the loading states.
  final Duration latency;

  final DateTime Function() _clock;
  final math.Random _random;

  /// Places the player has hit; they never come back
  /// (PRODUCT_SPECIFICATION.md, story 38).
  final Set<int> _guessed;
  final _rounds = <String, _FakeRound>{};
  final _dailyTokens = <DateTime, String>{};
  final _failures = Queue<RoundApiException>();

  /// The next call fails with [error] instead of answering; queued calls
  /// fail in order. For tests and for trying the error states by hand.
  void failNext(RoundApiException error) => _failures.add(error);

  /// Forgets today's round as if the day had ended on the server.
  void expireAll() {
    for (final round in _rounds.values) {
      round.expired = true;
    }
    _dailyTokens.clear();
  }

  @override
  Future<DailyRound> placeOfTheDay({String? resumeToken}) async {
    await _respond();
    final today = GameDay.of(_clock());
    final saved = _rounds[resumeToken];
    if (saved != null && !saved.expired && saved.day == today) {
      return DailyRoundReady(saved.state(config));
    }
    final token = _dailyTokens[today];
    if (token != null) return DailyRoundReady(_rounds[token]!.state(config));

    final pool = [
      for (final place in places)
        if (!_guessed.contains(place.card.id)) place,
    ];
    if (pool.isEmpty) return const AllPlacesGuessed();
    final round = _FakeRound(
      token: _newToken(),
      day: today,
      place: pool[_random.nextInt(pool.length)],
    );
    _rounds[round.token] = round;
    _dailyTokens[today] = round.token;
    return DailyRoundReady(round.state(config));
  }

  @override
  Future<RoundState> refresh(String token) async {
    await _respond();
    return _find(token).state(config);
  }

  @override
  Future<GuessOutcome> guess(String token, GeoPoint position) async {
    await _respond();
    final round = _find(token);
    if (round.result != null) {
      throw const RoundApiException(RoundErrorKind.roundFinished);
    }
    // The backend would answer 422; the client never sends this.
    if (!position.isValid) {
      throw const RoundApiException(RoundErrorKind.server);
    }
    if (!Region.contains(position)) return const GuessOutsideRegion();

    final target = round.place.card.location;
    final distance = Geo.distanceMeters(position, target);
    round.lastGuess = position;
    if (distance <= config.hitRadiusMeters) {
      round.result = RoundResult(
        stars: config.starsAvailable(round.wrongGuesses),
        guesses: round.wrongGuesses + 1,
        distanceMeters: distance,
        place: round.place.card,
      );
      _guessed.add(round.place.card.id);
      return GuessHit(round.state(config));
    }
    round.wrongGuesses++;
    return GuessMissed(round.state(config));
  }

  /// The round [token], when it exists and belongs to today.
  _FakeRound _find(String token) {
    final round = _rounds[token];
    if (round == null) {
      throw const RoundApiException(RoundErrorKind.roundNotFound);
    }
    if (round.expired || round.day != GameDay.of(_clock())) {
      throw const RoundApiException(RoundErrorKind.roundExpired);
    }
    return round;
  }

  Future<void> _respond() async {
    if (latency > Duration.zero) await Future<void>.delayed(latency);
    if (_failures.isNotEmpty) throw _failures.removeFirst();
  }

  String _newToken() => List.generate(
    16,
    (_) => _random.nextInt(256).toRadixString(16).padLeft(2, '0'),
  ).join();

  /// The demo's places; the real catalog is in the backend.
  ///
  /// The texts are illustrative and not verified (copy.md, Required texts);
  /// they never ship as game content.
  static const demoPlaces = [
    FakePlace(
      card: PlaceCard(
        id: 1,
        name: 'Hrad a zámek Bečov nad Teplou',
        type: 'Národní kulturní památka',
        description:
            'V kapli tu našli relikviář sv. Maura, jeden z nejcennějších '
            'pokladů u nás.',
        location: GeoPoint(50.0839, 12.8386),
        source: 'datazapad.cz',
        licence: 'CC BY',
      ),
      clues: [
        Clue(
          ClueKind.riddle,
          'Vzácný poklad tu desítky let ležel ukrytý pod podlahou kaple.',
        ),
        Clue(ClueKind.placeType, 'Národní kulturní památka, hrad a zámek.'),
        Clue(ClueKind.numbers, 'Ukrytý poklad tu našli v roce 1985.'),
        Clue(ClueKind.detail, 'Hrad stojí na skále nad řekou Teplou.'),
      ],
    ),
    FakePlace(
      card: PlaceCard(
        id: 2,
        name: 'Hrad Loket',
        type: 'Národní kulturní památka',
        description: 'Gotický hrad na skále, kterou ze tří stran obtéká Ohře.',
        location: GeoPoint(50.1859, 12.7541),
        source: 'datazapad.cz',
        licence: 'CC BY',
      ),
      clues: [
        Clue(ClueKind.riddle, 'Řeka tu kolem skály opisuje oblouk jako paže.'),
        Clue(ClueKind.placeType, 'Národní kulturní památka, hrad.'),
        Clue(ClueKind.numbers, 'První zmínka o něm pochází z roku 1234.'),
        Clue(
          ClueKind.detail,
          'Ukazují tu meteorit, kterému se říká Zakletý purkrabí.',
        ),
      ],
    ),
    FakePlace(
      card: PlaceCard(
        id: 3,
        name: 'Vřídlo',
        type: 'Pramen',
        description: 'Nejteplejší a nejsilnější pramen v Karlových Varech.',
        location: GeoPoint(50.2247, 12.8827),
        source: 'datazapad.cz',
        licence: 'CC BY',
        isSpring: true,
      ),
      clues: [
        Clue(
          ClueKind.riddle,
          'Horká voda tu vystřikuje do výšky několika metrů.',
        ),
        Clue(ClueKind.placeType, 'Pramen.'),
        Clue(ClueKind.numbers, 'Voda má při vývěru kolem 73 °C.'),
        Clue(ClueKind.detail, 'Nad pramenem stojí kolonáda z betonu a skla.'),
      ],
    ),
    FakePlace(
      card: PlaceCard(
        id: 4,
        name: 'Soos',
        type: 'Národní přírodní rezervace',
        description: 'Rašeliniště s minerálními prameny a bahenními sopkami.',
        location: GeoPoint(50.1465, 12.4035),
        source: 'datazapad.cz',
        licence: 'CC BY',
      ),
      clues: [
        Clue(ClueKind.riddle, 'Z bahna tu probublává plyn z hlubin Země.'),
        Clue(ClueKind.placeType, 'Národní přírodní rezervace.'),
        Clue(ClueKind.numbers, 'Rezervace má rozlohu přes 200 hektarů.'),
        Clue(ClueKind.detail, 'Krajinou tě provede dřevěný chodník.'),
      ],
    ),
    FakePlace(
      card: PlaceCard(
        id: 5,
        name: 'Chebský hrad',
        type: 'Národní kulturní památka',
        description:
            'Císařská falc na skále nad Ohří, jediná svého druhu u nás.',
        location: GeoPoint(50.0806, 12.3667),
        source: 'datazapad.cz',
        licence: 'CC BY',
      ),
      clues: [
        Clue(
          ClueKind.riddle,
          'Nad hradbami se tyčí černá věž z lávového kamene.',
        ),
        Clue(ClueKind.placeType, 'Národní kulturní památka, hrad.'),
        Clue(ClueKind.numbers, 'Stavět ho začali ve 12. století.'),
        Clue(ClueKind.detail, 'Najdeš tu vzácnou dvoupatrovou kapli.'),
      ],
    ),
  ];
}

class _FakeRound {
  _FakeRound({required this.token, required this.day, required this.place});

  final String token;
  final DateTime day;
  final FakePlace place;
  int wrongGuesses = 0;
  GeoPoint? lastGuess;
  RoundResult? result;
  bool expired = false;

  /// What the backend tells the client: unlocked clues only, and the
  /// compass direction once it is active.
  RoundState state(GameConfig config) {
    final unlocked = config.cluesUnlocked(wrongGuesses, place.clues.length);
    final last = lastGuess;
    return RoundState(
      token: token,
      day: day,
      clues: [
        for (var i = 0; i < place.clues.length; i++)
          i < unlocked ? place.clues[i] : Clue(place.clues[i].kind),
      ],
      wrongGuesses: wrongGuesses,
      lastGuess: last,
      compass:
          result == null && last != null && config.compassActive(wrongGuesses)
          ? Compass(Geo.bearingDegrees(last, place.card.location))
          : null,
      result: result,
    );
  }
}
