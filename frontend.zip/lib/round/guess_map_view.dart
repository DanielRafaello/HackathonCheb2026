import 'package:flutter/widgets.dart';

import 'round.dart';

/// What the blind map shows and reports, for [GuessMapBuilder].
class GuessMapView {
  const GuessMapView({
    required this.pin,
    required this.lastGuess,
    required this.enabled,
    required this.onPin,
    required this.interactive,
  });

  final GeoPoint? pin;
  final GeoPoint? lastGuess;
  final bool enabled;
  final ValueChanged<GeoPoint> onPin;

  /// The full-screen map, where the player zooms, pans, and places the
  /// pin. Otherwise the preview on the round screen, which only shows the
  /// pins.
  final bool interactive;
}

/// Builds the blind map; the app passes `GuessMap`, tests a stand-in.
typedef GuessMapBuilder = Widget Function(GuessMapView view);
