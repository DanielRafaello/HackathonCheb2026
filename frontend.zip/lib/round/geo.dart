import 'dart:math' as math;

/// A point in WGS 84, in decimal degrees.
///
/// The round code keeps its own type instead of MapLibre's `LatLng`, so the
/// game rules and the API do not depend on the map library.
class GeoPoint {
  const GeoPoint(this.latitude, this.longitude);

  final double latitude;
  final double longitude;

  /// Both coordinates are finite numbers within the WGS 84 ranges.
  bool get isValid =>
      latitude.isFinite &&
      longitude.isFinite &&
      latitude.abs() <= 90 &&
      longitude.abs() <= 180;

  @override
  bool operator ==(Object other) =>
      other is GeoPoint &&
      other.latitude == latitude &&
      other.longitude == longitude;

  @override
  int get hashCode => Object.hash(latitude, longitude);

  @override
  String toString() => 'GeoPoint($latitude, $longitude)';
}

/// Distances and directions on the Earth's surface.
abstract final class Geo {
  static const _earthRadiusMeters = 6371008.8;

  static double _rad(double degrees) => degrees * math.pi / 180;

  /// The great-circle distance between [a] and [b] in metres (haversine).
  static double distanceMeters(GeoPoint a, GeoPoint b) {
    final dLat = _rad(b.latitude - a.latitude);
    final dLon = _rad(b.longitude - a.longitude);
    final h =
        math.pow(math.sin(dLat / 2), 2) +
        math.cos(_rad(a.latitude)) *
            math.cos(_rad(b.latitude)) *
            math.pow(math.sin(dLon / 2), 2);
    return 2 * _earthRadiusMeters * math.asin(math.min(1, math.sqrt(h)));
  }

  /// The initial bearing from [from] to [to], in degrees clockwise from
  /// north, 0 ≤ bearing < 360.
  static double bearingDegrees(GeoPoint from, GeoPoint to) {
    final lat1 = _rad(from.latitude);
    final lat2 = _rad(to.latitude);
    final dLon = _rad(to.longitude - from.longitude);
    final y = math.sin(dLon) * math.cos(lat2);
    final x =
        math.cos(lat1) * math.sin(lat2) -
        math.sin(lat1) * math.cos(lat2) * math.cos(dLon);
    final degrees = math.atan2(y, x) * 180 / math.pi;
    return (degrees + 360) % 360;
  }

  /// Whether [point] lies inside [ring], a closed or open polygon ring
  /// (ray casting; fine for the small, simple polygons the game uses).
  static bool contains(List<GeoPoint> ring, GeoPoint point) {
    var inside = false;
    for (var i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      final a = ring[i];
      final b = ring[j];
      final crosses =
          (a.latitude > point.latitude) != (b.latitude > point.latitude) &&
          point.longitude <
              (b.longitude - a.longitude) *
                      (point.latitude - a.latitude) /
                      (b.latitude - a.latitude) +
                  a.longitude;
      if (crosses) inside = !inside;
    }
    return inside;
  }
}
