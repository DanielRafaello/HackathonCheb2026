import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../api/authorized_client.dart';
import '../config/game_config.dart';
import '../game/region.dart';
import '../progress/place_card_cache.dart';
import '../progress/revealed_place.dart';
import 'round.dart';
import 'round_api.dart';

/// The round endpoints of the Game API over HTTP (API_SPECIFICATION.md
/// section 5), for a signed-in player.
///
/// The backend decides everything: it picks the place, evaluates the
/// guess, unlocks the clues, points the compass, and awards the stars. This
/// class only translates its round into [RoundState] and its errors into
/// [RoundApiException]. While a round is open the backend sends nothing
/// that identifies the place, and nothing here keeps anything beyond what
/// it returns; a place the player hit goes into the [PlaceCardCache].
///
/// A round has no guess limit (PRODUCT_SPECIFICATION.md, story 14): it
/// ends only with a hit, so the client ignores the backend's
/// `attempts_remaining` and `max_attempts`.
class HttpRoundApi implements RoundApi {
  HttpRoundApi({
    required this._client,
    required this._cache,
    this.config = GameConfig.defaults,
  });

  final AuthorizedClient _client;
  final PlaceCardCache _cache;
  final GameConfig config;

  /// The backend's clues in unlock order, as far as the client knows them
  /// (API_SPECIFICATION.md 5.1): the first is visible from the start, one
  /// more unlocks per miss. A locked clue is not sent, so the client pads
  /// the list to [GameConfig.placeOfTheDayClues] tiles from this order; a
  /// position past it shows as a plain "Klíč" until it unlocks.
  static const clueOrder = ['distinctive_fact', 'category', 'area_narrowing'];

  @override
  Future<DailyRound> placeOfTheDay({String? resumeToken}) async {
    // `GET rounds/daily` is authoritative after midnight, so the saved
    // token is not needed (FRONTEND_API_GUIDE.md, "Resume a known round").
    final response = await _send(() => _client.get('rounds/daily'));
    if (response.statusCode == 409 &&
        _message(response) == 'round.no_eligible_daily_location') {
      return const AllPlacesGuessed();
    }
    _check(response);
    return DailyRoundReady(await _round(response));
  }

  @override
  Future<RoundState> refresh(String token) async {
    final response = await _send(() => _client.get('rounds/$token'));
    _check(response);
    return _round(response);
  }

  @override
  Future<GuessOutcome> guess(String token, GeoPoint position) async {
    // The backend has no region check of its own (API_SPECIFICATION.md
    // 5.3); a guess outside the region is never sent
    // (PRODUCT_SPECIFICATION.md, story 6).
    if (!position.isValid || !Region.contains(position)) {
      return const GuessOutsideRegion();
    }
    final response = await _send(
      () => _client.post('rounds/$token/guesses', {
        'latitude': position.latitude,
        'longitude': position.longitude,
      }),
    );
    _check(response);
    final round = await _round(response, sent: position);
    final result = round.result;
    if (result == null) return GuessMissed(round);
    // The backend says what the hit earned; the client never computes it.
    final wafers = jsonBody(response)['wafers_earned'];
    return GuessHit(
      round.copyWith(
        result: result.withWafers(wafers is num ? wafers.toInt() : null),
      ),
    );
  }

  Future<http.Response> _send(Future<http.Response> Function() request) async {
    try {
      return await request();
    } on ApiTransportException catch (error) {
      throw RoundApiException(switch (error.error) {
        ApiTransportError.network => RoundErrorKind.network,
        ApiTransportError.timeout => RoundErrorKind.timeout,
        ApiTransportError.unauthorized => RoundErrorKind.unauthorized,
      });
    }
  }

  /// Throws for every answer that is not a round.
  void _check(http.Response response) {
    final status = response.statusCode;
    if (status >= 200 && status < 300) return;
    throw switch (status) {
      401 || 403 => const RoundApiException(RoundErrorKind.unauthorized),
      404 => const RoundApiException(RoundErrorKind.roundNotFound),
      // `round.not_active`: the round has already ended, for example on
      // another device. Any other conflict means the same for a guess.
      409 => const RoundApiException(RoundErrorKind.roundFinished),
      429 => RoundApiException(
        RoundErrorKind.rateLimited,
        retryAfter: retryAfter(response),
      ),
      _ => const RoundApiException(RoundErrorKind.server),
    };
  }

  static String? _message(http.Response response) =>
      jsonBody(response)['message'] as String?;

  /// The `round` of a response as the client sees it. [sent] is the guess
  /// this answer is for; the backend returns no coordinates, so the pin
  /// the client sent is the only `lastGuess` it can show.
  Future<RoundState> _round(http.Response response, {GeoPoint? sent}) async {
    final Map<String, dynamic> json;
    final RoundState round;
    try {
      json = jsonBody(response)['round'] as Map<String, dynamic>;
      round = _parse(json);
    } on RoundApiException {
      rethrow;
    } on Object catch (error) {
      debugPrint('Unreadable round: $error');
      throw const RoundApiException(RoundErrorKind.server);
    }
    if (round.isFinished) await _remember(json['location']);
    return sent == null ? round : round.copyWith(lastGuess: sent);
  }

  /// Keeps the card of a place the player hit, for My map
  /// (`PlaceCardCache`).
  Future<void> _remember(Object? location) async {
    try {
      await _cache.write(
        RevealedPlace.fromJson(location as Map<String, dynamic>),
      );
    } on Object catch (error) {
      // The round is over either way; the card just shows less later.
      debugPrint('Place card not cached: $error');
    }
  }

  /// Throws [RoundApiException] for an expired round, and anything for a
  /// round the client cannot read.
  RoundState _parse(Map<String, dynamic> json) {
    final hit = switch (json['status']) {
      'active' => false,
      'guessed' => true,
      'expired' => throw const RoundApiException(RoundErrorKind.roundExpired),
      // Any other status, `failed` among them, belongs to a guess limit
      // the game does not have. Its revealed place is never read.
      final status => throw FormatException('Unknown round status $status'),
    };
    final attemptsUsed = (json['attempts_used'] as num).toInt();
    final lastGuess = json['last_guess'] as Map<String, dynamic>?;
    // The hitting guess is not a wrong one.
    final wrongGuesses = hit ? attemptsUsed - 1 : attemptsUsed;

    RoundResult? result;
    if (hit) {
      final place = RevealedPlace.fromJson(
        json['location'] as Map<String, dynamic>,
      );
      result = RoundResult(
        stars: (json['stars'] as num?)?.toInt() ?? 0,
        guesses:
            (lastGuess?['attempt_number'] as num?)?.toInt() ?? attemptsUsed,
        distanceMeters:
            (lastGuess?['distance_meters'] as num?)?.toDouble() ?? 0,
        place: _card(place),
      );
    }

    return RoundState(
      token: '${json['id']}',
      day: _day(json['daily_date'] as String),
      clues: _clues(json['clues'] as List<dynamic>? ?? const []),
      wrongGuesses: wrongGuesses,
      // Only after a miss, and only the direction: this client never shows
      // the distance of a miss. The backend may send a direction after
      // every miss; the compass shows once every clue has missed.
      compass:
          hit ||
              lastGuess == null ||
              lastGuess['hit'] == true ||
              !config.compassActive(wrongGuesses)
          ? null
          : Compass.fromDirection(lastGuess['direction']),
      result: result,
    );
  }

  /// `daily_date` ("2026-10-10") as `GameDay.of` returns a day: the Prague
  /// date at midnight UTC.
  static DateTime _day(String date) {
    final parts = date.split('-').map(int.parse).toList();
    return DateTime.utc(parts[0], parts[1], parts[2]);
  }

  /// The unlocked clues in position order, with the locked positions
  /// padded from [clueOrder] so the tiles still show.
  List<Clue> _clues(List<dynamic> wire) {
    final unlocked = <int, Clue>{};
    for (final entry in wire) {
      final clue = entry as Map<String, dynamic>;
      final position = (clue['position'] as num).toInt();
      unlocked[position] = Clue(
        ClueKind.fromWire(clue['type']),
        clue['text'] as String? ?? '',
      );
    }
    final last = unlocked.keys.fold(
      config.placeOfTheDayClues,
      (a, b) => a > b ? a : b,
    );
    return [
      for (var position = 1; position <= last; position++)
        unlocked[position] ??
            Clue(
              ClueKind.fromWire(
                position <= clueOrder.length ? clueOrder[position - 1] : null,
              ),
            ),
    ];
  }

  static PlaceCard _card(RevealedPlace place) => PlaceCard(
    id: place.id,
    name: place.name,
    type: place.category,
    description: place.description,
    location: GeoPoint(place.latitude, place.longitude),
    source: place.source?.label,
    licence: place.source?.licenseCode,
    isSpring: place.isSpring,
  );
}
