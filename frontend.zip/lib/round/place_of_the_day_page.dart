import 'dart:async';
import 'dart:ui' show lerpDouble;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pointer_interceptor/pointer_interceptor.dart';

import '../config/game_config.dart';
import '../design_system/design_system.dart';
import 'active_round_store.dart';
import 'guess_map_screen.dart';
import 'guess_map_view.dart';
import 'round.dart';
import 'round_api.dart';
import 'round_controller.dart';
import 'round_copy.dart';
import 'widgets/clue_panel.dart';
import 'widgets/hit_view.dart';
import 'widgets/map_overlays.dart';
import 'widgets/miss_panel.dart';
import 'widgets/round_top_bar.dart';

export 'guess_map_view.dart';

/// Copies the share text; the app uses the clipboard.
typedef CopyText = Future<void> Function(String text);

Future<void> _copyToClipboard(String text) =>
    Clipboard.setData(ClipboardData(text: text));

/// The place of the day: clues, the blind map, guesses, and the result
/// (screens 02–04 of the design).
class PlaceOfTheDayPage extends StatefulWidget {
  const PlaceOfTheDayPage({
    super.key,
    required this.api,
    required this.store,
    required this.mapBuilder,
    required this.onClose,
    this.config = GameConfig.defaults,
    this.clock = DateTime.now,
    this.copyText = _copyToClipboard,
  });

  final RoundApi api;
  final ActiveRoundStore store;
  final GuessMapBuilder mapBuilder;

  /// Leaves the round; an unfinished one is kept for later.
  final VoidCallback onClose;
  final GameConfig config;
  final DateTime Function() clock;
  final CopyText copyText;

  @override
  State<PlaceOfTheDayPage> createState() => _PlaceOfTheDayPageState();
}

class _PlaceOfTheDayPageState extends State<PlaceOfTheDayPage>
    with WidgetsBindingObserver {
  late final RoundController _controller = RoundController(
    api: widget.api,
    store: widget.store,
    config: widget.config,
    clock: widget.clock,
  );
  late final StreamSubscription<RoundNotice> _notices;

  /// The full-screen map, while it is open.
  Route<void>? _mapRoute;

  /// The full-screen map covers the round screen, also while it slides
  /// away. The panel after a miss waits for it, so one thing moves at a
  /// time.
  final _mapCovers = ValueNotifier<bool>(false);

  /// How much of its sliding the full-screen map has left when it counts
  /// as gone.
  static const _mapUncoveredBelow = 0.3;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _notices = _controller.notices.listen((notice) {
      if (mounted) {
        KnzToast.show(
          context,
          RoundCopy.notice(notice),
          above: RoundFooter.height,
        );
      }
    });
    _controller.addListener(_closeMapWhenAnswered);
    _controller.load();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _controller.reloadIfDayChanged();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _notices.cancel();
    _controller.removeListener(_closeMapWhenAnswered);
    _controller.dispose();
    _mapCovers.dispose();
    super.dispose();
  }

  /// Opens the blind map over the whole screen, where the player guesses.
  Future<void> _openMap() async {
    if (_mapRoute != null || !_controller.canGuess) return;
    final route = MaterialPageRoute<void>(
      fullscreenDialog: true,
      builder: (context) => GuessMapScreen(
        controller: _controller,
        config: widget.config,
        mapBuilder: widget.mapBuilder,
        onBack: () => Navigator.of(context).maybePop(),
      ),
    );
    _mapRoute = route;
    _mapCovers.value = true;
    final closed = Navigator.of(context).push(route);
    final animation = route.animation;
    // The map uncovers the round screen in its last stretch, so the next
    // move starts as it leaves rather than after a still beat.
    void uncover() {
      if (!mounted || animation == null) return;
      if (animation.isDismissed ||
          (animation.status == AnimationStatus.reverse &&
              animation.value < _mapUncoveredBelow)) {
        _mapCovers.value = false;
      }
    }

    animation?.addListener(uncover);
    animation?.addStatusListener((_) => uncover());
    await closed;
    if (_mapRoute == route) _mapRoute = null;
    // A removed route goes without sliding away; then nothing covers the
    // round screen any more.
    if (mounted && route.animation?.isAnimating != true) {
      _mapCovers.value = false;
    }
  }

  /// Closes the full-screen map once the guess has been answered, so the
  /// round screen shows the miss panel or the result. It also closes when
  /// the round reloads, for example at midnight.
  void _closeMapWhenAnswered() {
    final route = _mapRoute;
    if (route == null || !mounted) return;
    final guessing =
        _controller.phase == RoundPhase.playing && _controller.miss == null;
    if (guessing) return;
    _mapRoute = null;
    if (!route.isActive) return;
    final navigator = Navigator.of(context);
    if (route.isCurrent) {
      navigator.pop();
    } else {
      navigator.removeRoute(route);
      _mapCovers.value = false;
    }
  }

  Future<void> _share(RoundState round) async {
    final result = round.result;
    if (result == null) return;
    final text = RoundCopy.shareText(
      day: round.day,
      guesses: result.guesses,
      stars: result.stars,
      maxStars: widget.config.maxStars,
    );
    String message;
    try {
      // TODO(frontend): the system share sheet and the Web Share API once
      // the sharing plugin is chosen (FRONTEND_SPECIFICATION.md section 4).
      // The clipboard is the specified fallback.
      await widget.copyText(text);
      message = 'Výsledek je ve schránce. Vlož ho, kam chceš.';
    } on Object catch (error) {
      debugPrint('Share text not copied: $error');
      message = 'Výsledek se nepodařilo zkopírovat.';
    }
    if (mounted) KnzToast.show(context, message, above: RoundFooter.height);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KnzColors.surface,
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: _controller,
          builder: (context, _) => AnimatedSwitcher(
            duration: KnzMotion.of(context, KnzMotion.slow),
            switchInCurve: KnzMotion.easeOut,
            switchOutCurve: KnzMotion.easeOut,
            transitionBuilder: _phaseTransition,
            child: KeyedSubtree(
              key: ValueKey(_controller.phase),
              child: _body(),
            ),
          ),
        ),
      ),
    );
  }

  /// Moves between the phases of the round: the new phase fades in and
  /// grows a little into place over the old one, which fades out.
  static Widget _phaseTransition(Widget child, Animation<double> animation) {
    return FadeTransition(
      opacity: animation,
      child: ScaleTransition(
        scale: Tween(begin: _phaseStartScale, end: 1.0).animate(animation),
        child: child,
      ),
    );
  }

  static const _phaseStartScale = 0.98;

  Widget _body() {
    final controller = _controller;
    final round = controller.round;
    return switch (controller.phase) {
      RoundPhase.loading => _MessageLayout(
        onClose: widget.onClose,
        mood: KnzMood.think,
        text: 'Chystám ti místo dne…',
      ),
      RoundPhase.loadFailed => _MessageLayout(
        onClose: widget.onClose,
        mood: KnzMood.sad,
        text: RoundCopy.loadError(controller.loadError),
        actions: [
          KnzButton(
            label: 'Zkusit znovu',
            size: KnzButtonSize.cta,
            onPressed: controller.load,
          ),
          KnzButton(
            label: 'Zpět domů',
            variant: KnzButtonVariant.ghost,
            onPressed: widget.onClose,
          ),
        ],
      ),
      RoundPhase.allGuessed => _MessageLayout(
        onClose: widget.onClose,
        mood: KnzMood.cheer,
        text:
            'Všechna místa už máš uhodnutá! Nová přibudou, '
            'až je do hry přidáme.',
        actions: [
          KnzButton(
            label: 'Zpět domů',
            size: KnzButtonSize.cta,
            onPressed: widget.onClose,
          ),
        ],
      ),
      RoundPhase.finished => HitView(
        round: round!,
        maxStars: widget.config.maxStars,
        now: widget.clock,
        onShare: () => _share(round),
        onContinue: widget.onClose,
      ),
      RoundPhase.playing => _PlayingLayout(
        controller: controller,
        round: round!,
        mapCovers: _mapCovers,
        config: widget.config,
        onClose: widget.onClose,
        onOpenMap: _openMap,
        map: widget.mapBuilder(
          GuessMapView(
            pin: controller.pin,
            lastGuess: round.lastGuess,
            enabled: false,
            onPin: controller.placePin,
            interactive: false,
          ),
        ),
      ),
    };
  }
}

/// The open round. Before a guess: clues above a preview of the blind map,
/// which opens the map over the whole screen for the guess (screen 02).
/// After a wrong guess: the preview with the missed pin and the panel
/// under it (screen 03). The map keeps its place in the tree, so it is not
/// rebuilt between the two.
///
/// The two move into each other in two steps, one thing at a time. After
/// a miss the clues and the button fold away, then the panel rises with
/// what the guess unlocked. On TIPNOUT ZNOVU the panel sinks, then the
/// clues unfold and the newly unlocked clue rises into its place.
class _PlayingLayout extends StatefulWidget {
  const _PlayingLayout({
    required this.controller,
    required this.round,
    required this.mapCovers,
    required this.config,
    required this.onClose,
    required this.onOpenMap,
    required this.map,
  });

  final RoundController controller;

  /// The round as it was when this layout was built. While the phases
  /// change, the old layout fades out with it.
  final RoundState round;

  /// The full-screen map covers this screen.
  final ValueListenable<bool> mapCovers;
  final GameConfig config;
  final VoidCallback onClose;
  final VoidCallback onOpenMap;
  final Widget map;

  @override
  State<_PlayingLayout> createState() => _PlayingLayoutState();
}

class _PlayingLayoutState extends State<_PlayingLayout>
    with SingleTickerProviderStateMixin {
  /// Below this height the layout gives the map more room: smaller shares
  /// for the clues and the panel.
  static const _compactHeight = 680.0;

  /// The widest the round gets, on a desktop browser.
  static const _maxWidth = 560.0;

  static const _mapKey = ValueKey('map');

  /// 0 shows the clues, 1 the panel after a miss. The first half folds
  /// the clues, the second raises the panel, so they never take room at
  /// the same time.
  late final AnimationController _swap = AnimationController(
    vsync: this,
    value: widget.controller.miss == null ? 0 : 1,
  );

  /// The clues and the button: 1 while shown, 0 folded away.
  late final Animation<double> _clues = ReverseAnimation(
    CurvedAnimation(
      parent: _swap,
      curve: const Interval(0, 0.5, curve: KnzMotion.easeInOut),
    ),
  );

  /// The panel after a miss: 0 down, 1 up.
  late final Animation<double> _panel = CurvedAnimation(
    parent: _swap,
    curve: const Interval(0.5, 1, curve: KnzMotion.easeOut),
  );

  /// What the panel unlocked, once it is up. It stays while the panel
  /// sinks.
  late final Animation<double> _panelReveal = CurvedAnimation(
    parent: _swap,
    curve: const Interval(0.8, 1),
    reverseCurve: const Threshold(0),
  );

  /// What the miss unlocked, rising into the clues as they finish
  /// unfolding.
  late final Animation<double> _cluesReveal = ReverseAnimation(
    CurvedAnimation(parent: _swap, curve: const Interval(0, 0.3)),
  );

  /// The miss the panel shows; it stays while the panel sinks.
  late MissFeedback? _shownMiss = widget.controller.miss;

  /// The miss whose clue or compass the clues bring in.
  MissFeedback? _revealedMiss;

  /// The round before the miss. The clues show it while they fold away,
  /// so that the panel is the first to tell about the new clue.
  RoundState? _roundBeforeMiss;

  @override
  void initState() {
    super.initState();
    _swap.addStatusListener(_onSwapStatus);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _swap.duration = KnzMotion.of(context, KnzMotion.slow * 2);
  }

  @override
  void didUpdateWidget(_PlayingLayout oldWidget) {
    super.didUpdateWidget(oldWidget);
    final miss = widget.controller.miss;
    if (miss != null && miss != _shownMiss) {
      _shownMiss = miss;
      _revealedMiss = null;
      _roundBeforeMiss = oldWidget.round;
      _showPanelWhenUncovered();
    } else if (miss == null && _shownMiss != null && !_swap.isDismissed) {
      _revealedMiss = _shownMiss;
      _roundBeforeMiss = null;
      _stopWaiting();
      _swap.reverse();
    }
  }

  @override
  void dispose() {
    _stopWaiting();
    _swap.dispose();
    super.dispose();
  }

  /// Raises the panel once the full-screen map has slid away.
  void _showPanelWhenUncovered() {
    if (!widget.mapCovers.value) {
      _swap.forward();
      return;
    }
    _stopWaiting();
    widget.mapCovers.addListener(_onMapCovers);
  }

  void _onMapCovers() {
    if (widget.mapCovers.value) return;
    _stopWaiting();
    if (widget.controller.miss != null) _swap.forward();
  }

  void _stopWaiting() => widget.mapCovers.removeListener(_onMapCovers);

  void _onSwapStatus(AnimationStatus status) {
    // The panel and the clues leave the tree once they are folded away.
    if (status.isDismissed) {
      setState(() => _shownMiss = null);
    } else if (status.isCompleted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxHeight < _compactHeight;
        // The clues and the panel scroll inside their share, so the map
        // always keeps the rest.
        final cluesShare = compact ? 0.30 : 0.42;
        final panelShare = compact ? 0.50 : 0.62;
        return Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: _maxWidth),
            child: AnimatedBuilder(
              animation: _swap,
              builder: (context, _) =>
                  _column(constraints, cluesShare, panelShare),
            ),
          ),
        );
      },
    );
  }

  Widget _column(
    BoxConstraints constraints,
    double cluesShare,
    double panelShare,
  ) {
    final controller = widget.controller;
    final round = widget.round;
    final cluesRound = _roundBeforeMiss ?? round;
    final miss = _shownMiss;
    final pin = controller.pin;
    final cluesShown = !_swap.isCompleted;
    final panelShown = !_swap.isDismissed && miss != null;
    final revealed = _revealedMiss;
    final panel = _panel.value;
    return Column(
      children: [
        RoundTopBar(
          onClose: widget.onClose,
          wrongGuesses: round.wrongGuesses,
          steps: widget.config.maxStars,
          compassActive: round.compass != null,
          stars: controller.starsAvailable,
        ),
        if (cluesShown)
          _Fold(
            factor: _clues,
            // The clues slide up under the top bar and fade.
            alignment: Alignment.bottomCenter,
            fade: true,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxHeight: constraints.maxHeight * cluesShare,
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(
                  KnzSize.screenGutter,
                  KnzSpace.s8,
                  KnzSize.screenGutter,
                  KnzSpace.s4,
                ),
                child: CluePanel(
                  round: cluesRound,
                  overline: RoundCopy.overline(cluesRound.wrongGuesses + 1),
                  reveal: _cluesReveal,
                  revealClueNumber: revealed?.newClueNumber,
                  revealCompass: revealed?.compass != null,
                ),
              ),
            ),
          ),
        Expanded(
          key: _mapKey,
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              KnzSize.screenGutter,
              lerpDouble(KnzSpace.s12, KnzSpace.s8, 1 - _clues.value)!,
              KnzSize.screenGutter,
              KnzSpace.s16 * panel,
            ),
            child: _MapFrame(
              pin: pin,
              lastGuess: round.lastGuess,
              showInstruction: miss == null && pin == null,
              onOpen: controller.canGuess ? widget.onOpenMap : null,
              child: widget.map,
            ),
          ),
        ),
        if (cluesShown)
          _Fold(
            factor: _clues,
            // The button sinks below the screen edge.
            alignment: Alignment.topCenter,
            child: RoundFooter(
              button: KnzButton(
                label: 'Tipnout na mapě',
                size: KnzButtonSize.cta,
                onPressed: controller.canGuess ? widget.onOpenMap : null,
              ),
            ),
          ),
        if (panelShown)
          _Fold(
            factor: _panel,
            // The panel rises from the screen edge like a sheet.
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxHeight: constraints.maxHeight * panelShare,
              ),
              child: MissPanel(
                feedback: miss,
                onRetry: controller.dismissMiss,
                reveal: _panelReveal,
              ),
            ),
          ),
      ],
    );
  }
}

/// Folds [child] to [factor] of its height, keeping the edge at
/// [alignment] in view, and fades it with the fold when [fade] is set.
/// Until it is fully open it takes no taps; mostly folded, the screen
/// reader skips it.
class _Fold extends StatelessWidget {
  const _Fold({
    required this.factor,
    required this.alignment,
    required this.child,
    this.fade = false,
  });

  final Animation<double> factor;
  final Alignment alignment;
  final bool fade;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final value = factor.value.clamp(0.0, 1.0);
    return IgnorePointer(
      ignoring: value < 1,
      child: ExcludeSemantics(
        excluding: value < 0.5,
        child: ClipRect(
          child: Align(
            alignment: alignment,
            heightFactor: value,
            child: fade ? Opacity(opacity: value, child: child) : child,
          ),
        ),
      ),
    );
  }
}

/// The preview of the blind map in its frame (`components.md`, MapFrame),
/// with the instruction or the guess label on top. A tap opens the map
/// over the whole screen.
class _MapFrame extends StatelessWidget {
  const _MapFrame({
    required this.pin,
    required this.lastGuess,
    required this.showInstruction,
    required this.onOpen,
    required this.child,
  });

  final GeoPoint? pin;
  final GeoPoint? lastGuess;
  final bool showInstruction;

  /// Opens the full-screen map; null while the player cannot guess.
  final VoidCallback? onOpen;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final pin = this.pin;
    final pinPlace = pin == null ? null : RoundCopy.nearTown(pin);
    final last = lastGuess;
    final lastPlace = last == null ? null : RoundCopy.nearTown(last);
    final description = [
      'Mapa kraje',
      if (pin != null) 'tvůj tip ${pinPlace ?? 'je na mapě'}',
      if (pin == null && last != null)
        'poslední tip ${lastPlace ?? 'je na mapě'}',
      if (pin == null && last == null) 'zatím bez tipu',
    ].join(': ');

    final frame = KnzEdgeBox(
      color: KnzColors.surfaceSubtle,
      edgeColor: KnzColors.borderStrong,
      radius: KnzRadius.xl3,
      frame: KnzDepth.border,
      depth: KnzDepth.lg,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(KnzRadius.xl3 - KnzDepth.border),
        child: Stack(
          fit: StackFit.expand,
          children: [
            child,
            // The preview takes no gestures: the map is moved and the
            // pin placed on the full-screen map. On the web the map is
            // an HTML element that would take the pointer.
            PointerInterceptor(
              child: Listener(
                behavior: HitTestBehavior.opaque,
                child: const SizedBox.expand(),
              ),
            ),
            if (showInstruction)
              const IgnorePointer(
                child: Center(
                  child: MapInstruction(
                    text: 'Klepni na mapu a polož svůj tip.',
                  ),
                ),
              ),
            if (pin != null)
              GuessLabelOverlay(
                text: pinPlace == null ? 'Tvůj tip' : 'Tvůj tip: $pinPlace',
              ),
          ],
        ),
      ),
    );

    final open = onOpen;
    if (open == null) {
      return Semantics(label: description, container: true, child: frame);
    }
    return Semantics(
      container: true,
      child: KnzPressable(
        onPressed: open,
        semanticLabel: description,
        builder: (context, state) => frame,
      ),
    );
  }
}

/// Vřídlík with a message and actions: loading, a failed load, no place
/// left.
class _MessageLayout extends StatelessWidget {
  const _MessageLayout({
    required this.onClose,
    required this.mood,
    required this.text,
    this.actions = const [],
  });

  final VoidCallback onClose;
  final KnzMood mood;
  final String text;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        RoundTopBar(onClose: onClose),
        Expanded(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(KnzSize.screenGutter),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Semantics(
                      liveRegion: true,
                      child: KnzSpeechBubble(mood: mood, text: text),
                    ),
                    for (final action in actions) ...[
                      const SizedBox(height: KnzSpace.s12),
                      action,
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
