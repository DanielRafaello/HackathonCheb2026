import 'round.dart';

/// The round endpoints of the Game API (API_SPECIFICATION.md section 5,
/// FRONTEND_API_GUIDE.md "Daily round").
///
/// `HttpRoundApi` talks to the backend for a signed-in player;
/// `FakeRoundApi` plays the backend's part in memory for a guest trying the
/// game ("Zkusit bez účtu").
///
/// Implementations throw [RoundApiException] for every failure, never
/// anything else.
abstract interface class RoundApi {
  /// Today's place of the day: the round for the current Prague date,
  /// started if there is none yet. [resumeToken] is the token of the round
  /// the player started earlier; the backend finds today's round on its own
  /// and ignores it, the demo uses it to continue.
  Future<DailyRound> placeOfTheDay({String? resumeToken});

  /// The current state of the round [token], for example after a guess
  /// whose answer was lost. Throws [RoundErrorKind.roundExpired] for a
  /// round from an earlier day.
  Future<RoundState> refresh(String token);

  /// Confirms a guess at [position] in the round [token]. A guess outside
  /// the region comes back as [GuessOutsideRegion] without reaching the
  /// backend (PRODUCT_SPECIFICATION.md, story 6).
  Future<GuessOutcome> guess(String token, GeoPoint position);
}
