import 'geo.dart';

export 'geo.dart';

/// The kinds of clue, in the order they unlock (PRODUCT_SPECIFICATION.md,
/// Clue Progression).
enum ClueKind {
  /// Clue 1: an interesting detail, visible from the start.
  riddle('Hádanka', 'Hádanka'),

  /// Clue 2: the category of the place.
  placeType('Typ místa', 'Typ'),

  /// Clue 3: a number that fits the category (a year, an elevation).
  numbers('Čísla', 'Čísla'),

  /// Clue 4: a second interesting detail.
  detail('Další hádanka', 'Hádanka'),

  /// The Game API's third clue: the area the place lies in
  /// (API_SPECIFICATION.md 5.1, `area_narrowing`).
  area('Oblast', 'Oblast'),

  /// A kind this version of the app does not know yet. It still shows, so
  /// a newer backend cannot hide a clue from an older app.
  other('Klíč', 'Klíč');

  const ClueKind(this.title, this.lockedLabel);

  /// The clue's name in its label: "KLÍČ 2 · TYP MÍSTA".
  final String title;

  /// The short name on a locked tile: "Typ".
  final String lockedLabel;

  /// The kind the Game API names [wire], or [other]. The backend's names
  /// are `distinctive_fact`, `category`, and `area_narrowing`
  /// (API_SPECIFICATION.md 5.1); the older names stay for saved data.
  static ClueKind fromWire(Object? wire) => switch (wire) {
    'riddle' || 'distinctive_fact' => riddle,
    'place_type' || 'category' => placeType,
    'numbers' => numbers,
    'detail' => detail,
    'area_narrowing' => area,
    _ => other,
  };
}

/// One clue of a round. A locked clue has a kind but no text: the client
/// learns what a clue says only when it unlocks.
class Clue {
  const Clue(this.kind, [this.text]);

  final ClueKind kind;

  /// The clue's text, or null while it is locked.
  final String? text;

  bool get isUnlocked => text != null;
}

/// The compass after a wrong guess: only the direction from the latest
/// guess to the target. Never the distance, the coordinates, or the name
/// (PRODUCT_SPECIFICATION.md, stories 30–33). It is active from the miss
/// after the last clue on (`GameConfig.compassActive`).
class Compass {
  const Compass(this.bearingDegrees);

  /// The compass for one of the Game API's eight directions, `N` to `NW`
  /// (API_SPECIFICATION.md 5.3), or null for anything else.
  static Compass? fromDirection(Object? direction) {
    final index = direction is String ? _directions.indexOf(direction) : -1;
    return index < 0 ? null : Compass(index * 45.0);
  }

  static const _directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];

  /// Degrees clockwise from north, 0 ≤ bearing < 360.
  final double bearingDegrees;
}

/// What the player learns about a place once they have guessed it.
class PlaceCard {
  const PlaceCard({
    required this.id,
    required this.name,
    required this.type,
    required this.description,
    required this.location,
    this.source,
    this.licence,
    this.isSpring = false,
    this.photoUrl,
  });

  final int id;
  final String name;

  /// The place type label: "Národní kulturní památka".
  final String type;

  /// A short description of what makes the place interesting.
  final String description;
  final GeoPoint location;

  /// The data source: "datazapad.cz". Null when the backend does not name
  /// one; the card then shows no source line rather than an invented one.
  final String? source;

  /// The licence of the data: "CC BY". Null when unknown.
  final String? licence;

  /// A spring's card always warns that its water is not hygienically
  /// monitored.
  final bool isSpring;

  /// A photo of the place, when there is one.
  final String? photoUrl;
}

/// The end of a round: the hit and what it earned. A round ends only with
/// a hit; there is no guess limit and no failed round
/// (PRODUCT_SPECIFICATION.md, story 14).
class RoundResult {
  const RoundResult({
    required this.stars,
    required this.guesses,
    required this.distanceMeters,
    required this.place,
    this.wafersEarned,
  });

  /// Stars the backend awarded for the hit.
  final int stars;

  /// Confirmed guesses, the last one included.
  final int guesses;

  /// Distance from the hitting guess to the place.
  final double distanceMeters;

  /// The guessed place.
  final PlaceCard place;

  /// Wafers the backend added for the hit (`wafers_earned`); null when the
  /// client does not know them, for a guest or a round resumed later.
  final int? wafersEarned;

  RoundResult withWafers(int? wafers) => RoundResult(
    stars: stars,
    guesses: guesses,
    distanceMeters: distanceMeters,
    place: place,
    wafersEarned: wafers,
  );
}

/// A round as the backend describes it to the client.
///
/// While the round is open it holds nothing that identifies the place: only
/// the token, the clues unlocked so far, the player's own guesses, and the
/// compass direction.
class RoundState {
  const RoundState({
    required this.token,
    required this.day,
    required this.clues,
    required this.wrongGuesses,
    this.lastGuess,
    this.compass,
    this.result,
  });

  /// Opaque to the client; it names the round in the Game API.
  final String token;

  /// The game day of the place of the day (midnight UTC of the Prague date,
  /// as `GameDay.of` returns it).
  final DateTime day;

  /// Every clue of the place in unlock order; locked ones have no text.
  final List<Clue> clues;

  final int wrongGuesses;

  /// The latest confirmed guess, if any. The Game API does not return the
  /// coordinates, so a resumed round has none.
  final GeoPoint? lastGuess;

  /// The compass, once it is active.
  final Compass? compass;

  /// The hit, once the round is over.
  final RoundResult? result;

  /// The round ended with a hit, the only way it ends.
  bool get isFinished => result != null;

  int get unlockedClues => clues.where((clue) => clue.isUnlocked).length;

  RoundState copyWith({GeoPoint? lastGuess, RoundResult? result}) => RoundState(
    token: token,
    day: day,
    clues: clues,
    wrongGuesses: wrongGuesses,
    lastGuess: lastGuess ?? this.lastGuess,
    compass: compass,
    result: result ?? this.result,
  );
}

/// Today's place of the day, or the news that there is none.
sealed class DailyRound {
  const DailyRound();
}

class DailyRoundReady extends DailyRound {
  const DailyRoundReady(this.round);

  final RoundState round;
}

/// The player has guessed every place in the catalog
/// (PRODUCT_SPECIFICATION.md, story 43).
class AllPlacesGuessed extends DailyRound {
  const AllPlacesGuessed();
}

/// What the backend made of a confirmed guess.
sealed class GuessOutcome {
  const GuessOutcome();
}

class GuessMissed extends GuessOutcome {
  const GuessMissed(this.round);

  final RoundState round;
}

class GuessHit extends GuessOutcome {
  const GuessHit(this.round);

  /// The finished round; [RoundState.result] is set.
  final RoundState round;
}

/// The guess lies outside the Karlovy Vary Region. It does not count
/// (PRODUCT_SPECIFICATION.md, story 6).
class GuessOutsideRegion extends GuessOutcome {
  const GuessOutsideRegion();
}

enum RoundErrorKind {
  /// No connection, or the request did not reach the backend.
  network,

  /// The backend did not answer in time.
  timeout,

  /// The backend rejected the session.
  unauthorized,

  /// Too many requests; wait [RoundApiException.retryAfter].
  rateLimited,

  /// The round belongs to a day that is over.
  roundExpired,

  /// The backend does not know the round token.
  roundNotFound,

  /// The round has already ended, for example on another device.
  roundFinished,

  /// The backend failed or sent something the client cannot read.
  server,
}

class RoundApiException implements Exception {
  const RoundApiException(this.kind, {this.retryAfter});

  final RoundErrorKind kind;

  /// For [RoundErrorKind.rateLimited]: how long to wait, when known.
  final Duration? retryAfter;

  @override
  String toString() => 'RoundApiException($kind)';
}
