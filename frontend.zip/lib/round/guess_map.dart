import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import 'package:pointer_interceptor/pointer_interceptor.dart';

import '../config/map_config.dart';
import '../design_system/design_system.dart';
import '../map/game_map.dart';
import '../map/map_projection.dart';
import '../map/map_zoom_buttons.dart';
import '../my_map/places_map.dart';
import 'round.dart';

/// The blind map of a round: tap to put the pin down, drag it to move it.
///
/// The round screen shows it as a preview that takes no gestures
/// ([interactive] off); a tap there opens it over the whole screen, where
/// the player guesses.
///
/// It shows at most two pins (PRODUCT_SPECIFICATION.md, story 13): the
/// latest confirmed guess and the unconfirmed one. Fully zoomed out, the
/// whole region fits and a drag slides back; zoomed in, the map pans within
/// the region.
///
/// The drag is a Flutter gesture on a handle over the pin's head, not
/// MapLibre's feature drag: that one starts only on a mouse press on the
/// web, and on iOS it looks for the pin only after the finger has moved.
class GuessMap extends StatefulWidget {
  const GuessMap({
    super.key,
    required this.config,
    required this.pin,
    required this.lastGuess,
    required this.enabled,
    required this.onPin,
    this.interactive = true,
  });

  final MapConfig config;

  /// The unconfirmed guess.
  final GeoPoint? pin;

  /// The latest confirmed guess, drawn as a missed pin.
  final GeoPoint? lastGuess;

  /// Whether taps and drags may move the pin.
  final bool enabled;

  /// The player put the pin at, or dragged it to, a position.
  final ValueChanged<GeoPoint> onPin;

  /// Whether the player can zoom and pan. The preview shows the whole
  /// region and no zoom buttons.
  final bool interactive;

  /// The area that picks the pin up, for a pin whose tip is at [tip].
  ///
  /// It covers the pin's head, where the player holds it, and is at least
  /// a touch target wide.
  static Rect handle(Offset tip) => Rect.fromLTRB(
    tip.dx - KnzSize.touch / 2,
    tip.dy - _pinHeight,
    tip.dx + KnzSize.touch / 2,
    tip.dy + KnzSpace.s4,
  );

  /// The height of `marker-guess` at icon size 0.5, from its tip up.
  static const _pinHeight = 44.0;

  @override
  State<GuessMap> createState() => _GuessMapState();
}

class _GuessMapState extends State<GuessMap> {
  MapLibreMapController? _controller;
  bool _styleReady = false;
  Symbol? _pinSymbol;
  Symbol? _lastSymbol;

  /// While the player drags the pin: its tip on screen and its position.
  Offset? _dragTip;
  GeoPoint? _dragPosition;

  /// Symbol changes run one after another, so a quick tap after a drag
  /// cannot add the pin twice.
  Future<void> _queue = Future.value();

  double _fitZoom = 0;
  double? _zoom;
  Size? _size;

  /// The player zoomed in on purpose. Otherwise the map keeps showing the
  /// whole region, also after the frame changes size: the camera bounds
  /// zoom a taller map in by themselves, and nothing would zoom it out.
  bool _userZoomed = false;

  /// The next camera stop comes from the app (the start, a re-fit, a
  /// re-centre), not from the player.
  bool _programmatic = true;

  /// The frame changed size; show the whole region once the map has
  /// caught up. An animation started before that would be dropped.
  bool _refitPending = false;
  Timer? _refitTimer;

  /// How long to wait for the map to report the new size.
  static const _refitDelay = Duration(milliseconds: 300);

  /// The camera may leave the tile set's area a little, so a tall frame
  /// can still show the whole region instead of being zoomed in to stay
  /// within the tiles. Outside the tiles is the plain background.
  static final _cameraBounds = LatLngBounds(
    southwest: const LatLng(49.40, 11.70),
    northeast: const LatLng(50.95, 13.70),
  );

  bool get _zoomedIn => (_zoom ?? _fitZoom) > _fitZoom + 0.01;

  @override
  void didUpdateWidget(GuessMap old) {
    super.didUpdateWidget(old);
    if (!widget.enabled && _dragTip != null) {
      // The handle is gone mid-drag; put the pin back.
      _dragTip = null;
      _dragPosition = null;
      _sync();
    } else if (old.pin != widget.pin || old.lastGuess != widget.lastGuess) {
      _sync();
    }
  }

  @override
  void dispose() {
    _refitTimer?.cancel();
    _controller?.onFeatureTapped.remove(_onFeatureTap);
    super.dispose();
  }

  void _onMapCreated(MapLibreMapController controller) {
    setState(() => _controller = controller);
    controller.onFeatureTapped.add(_onFeatureTap);
  }

  /// The pins take the taps on them, so a tap on the missed pin would
  /// otherwise do nothing. It puts the new pin there, like a tap on the
  /// map.
  void _onFeatureTap(
    math.Point<double> point,
    LatLng coordinates,
    String id,
    String layerId,
    Annotation? annotation,
  ) {
    if (!mounted || !widget.enabled || !widget.interactive) return;
    if (annotation == null || annotation.id != _lastSymbol?.id) return;
    widget.onPin(GeoPoint(coordinates.latitude, coordinates.longitude));
  }

  Future<void> _onStyleLoaded() async {
    final controller = _controller;
    if (controller == null || !mounted) return;
    // A new style drops the old symbols.
    _pinSymbol = null;
    _lastSymbol = null;
    try {
      await controller.setSymbolIconAllowOverlap(true);
      await controller.setSymbolIconIgnorePlacement(true);
    } on Object catch (error) {
      debugPrint('Guess map symbol settings failed: $error');
    }
    if (!mounted) return;
    _styleReady = true;
    _sync();
  }

  void _onClick(math.Point<double> point, LatLng position) {
    if (!widget.enabled || !widget.interactive) return;
    widget.onPin(GeoPoint(position.latitude, position.longitude));
  }

  MapProjection? _projection(Size size) {
    final camera = _controller?.cameraPosition;
    if (camera == null) return null;
    return MapProjection(target: camera.target, zoom: camera.zoom, size: size);
  }

  void _onDragStart(Offset tip) => _dragTip = tip;

  void _onDragUpdate(DragUpdateDetails details, Size size) {
    final tip = _dragTip;
    final projection = _projection(size);
    if (tip == null || projection == null) return;
    final position = projection.toPosition(tip + details.delta);
    setState(() {
      _dragTip = tip + details.delta;
      _dragPosition = GeoPoint(position.latitude, position.longitude);
    });
    _sync();
  }

  void _onDragEnd() {
    final position = _dragPosition;
    setState(() {
      _dragTip = null;
      _dragPosition = null;
    });
    if (position != null && widget.enabled) widget.onPin(position);
    // After the round has taken the new pin, or put the pin back where
    // the round has it.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _sync();
    });
  }

  void _sync() {
    _queue = _queue.then((_) => _apply()).catchError((Object error) {
      debugPrint('Guess map pins failed: $error');
    });
  }

  Future<void> _apply() async {
    final controller = _controller;
    if (controller == null || !_styleReady || !mounted) return;
    _lastSymbol = await _place(
      controller,
      _lastSymbol,
      widget.lastGuess,
      image: 'marker-guess-missed',
      zIndex: 1,
    );
    if (!mounted) return;
    _pinSymbol = await _place(
      controller,
      _pinSymbol,
      _dragPosition ?? widget.pin,
      image: 'marker-guess',
      zIndex: 2,
    );
  }

  /// Puts [symbol] at [position], adding or removing it as needed.
  Future<Symbol?> _place(
    MapLibreMapController controller,
    Symbol? symbol,
    GeoPoint? position, {
    required String image,
    required int zIndex,
  }) async {
    if (position == null) {
      if (symbol != null) await controller.removeSymbol(symbol);
      return null;
    }
    final geometry = LatLng(position.latitude, position.longitude);
    if (symbol == null) {
      return controller.addSymbol(
        SymbolOptions(
          geometry: geometry,
          iconImage: image,
          iconSize: 0.5,
          iconAnchor: 'bottom',
          // The pin's tip is 2 px above the image's bottom edge.
          iconOffset: const Offset(0, 4),
          zIndex: zIndex,
        ),
      );
    }
    if (symbol.options.geometry != geometry) {
      await controller.updateSymbol(symbol, SymbolOptions(geometry: geometry));
    }
    return symbol;
  }

  void _onCameraIdle() {
    final camera = _controller?.cameraPosition;
    if (camera == null || !mounted) return;
    if (_refitPending) {
      _refit();
      return;
    }
    if (_programmatic) {
      _programmatic = false;
    } else {
      _userZoomed = camera.zoom > _fitZoom + 0.01;
    }
    setState(() => _zoom = camera.zoom);
    if (!_zoomedIn) {
      final centre = PlacesMap.centre(PlacesMap.regionBounds);
      final off =
          (camera.target.latitude - centre.latitude).abs() > 1e-4 ||
          (camera.target.longitude - centre.longitude).abs() > 1e-4;
      if (off) _showRegion();
    }
  }

  /// Shows the whole region in the middle.
  void _showRegion() {
    _programmatic = true;
    _controller?.animateCamera(
      CameraUpdate.newLatLngZoom(
        PlacesMap.centre(PlacesMap.regionBounds),
        _fitZoom,
      ),
    );
  }

  /// The frame changes size between the guess and the panel after a miss.
  /// A map showing the whole region shows all of it again; a map the
  /// player zoomed into stays where it is.
  void _onResize(Size size) {
    final old = _size;
    _size = size;
    if (old == null || old == size || _userZoomed) return;
    _refitPending = true;
    _refitTimer?.cancel();
    _refitTimer = Timer(_refitDelay, () {
      if (mounted && _refitPending) _refit();
    });
  }

  /// Jumps to the whole region; a jump cannot be cut short by the resize.
  void _refit() {
    _refitPending = false;
    _refitTimer?.cancel();
    _programmatic = true;
    _controller?.moveCamera(
      CameraUpdate.newLatLngZoom(
        PlacesMap.centre(PlacesMap.regionBounds),
        _fitZoom,
      ),
    );
  }

  void _zoomBy(CameraUpdate update) {
    _userZoomed = true;
    _controller?.animateCamera(update);
  }

  /// The handle over the pin's head; it follows the camera.
  Widget _pinHandle(Size size) {
    final pin = widget.pin;
    final projection = _projection(size);
    if (!widget.enabled ||
        !widget.interactive ||
        pin == null ||
        projection == null) {
      return const SizedBox.shrink();
    }
    final tip =
        _dragTip ?? projection.toScreen(LatLng(pin.latitude, pin.longitude));
    return Positioned.fromRect(
      rect: GuessMap.handle(tip),
      // On the web the map is an HTML element that would take the drag.
      child: PointerInterceptor(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          dragStartBehavior: DragStartBehavior.down,
          onPanStart: (_) => _onDragStart(tip),
          onPanUpdate: (details) => _onDragUpdate(details, size),
          onPanEnd: (_) => _onDragEnd(),
          onPanCancel: _onDragEnd,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final config = widget.config;
        _fitZoom = PlacesMap.fitZoom(
          PlacesMap.regionBounds,
          constraints.biggest,
          padding: PlacesMap.regionPadding,
        ).clamp(config.minZoom, config.maxZoom);
        _onResize(constraints.biggest);
        final zoom = _zoom ?? _fitZoom;
        return Stack(
          children: [
            GameMap(
              config: config.copyWith(
                initialCamera: CameraPosition(
                  target: PlacesMap.centre(PlacesMap.regionBounds),
                  zoom: _fitZoom,
                ),
                cameraBounds: _cameraBounds,
                minZoom: _fitZoom,
              ),
              onMapCreated: _onMapCreated,
              onStyleLoaded: _onStyleLoaded,
              onMapClick: _onClick,
              onCameraIdle: _onCameraIdle,
              // On the full-screen map a drag always pans: no page needs the
              // drag. Fully zoomed out, the region slides back to the middle
              // when the drag ends. The preview takes no gestures.
              scrollGesturesEnabled: widget.interactive,
            ),
            if (_controller case final controller?)
              ListenableBuilder(
                listenable: controller,
                builder: (context, _) => _pinHandle(constraints.biggest),
              ),
            if (widget.interactive)
              Positioned(
                top: KnzSpace.s10,
                right: KnzSpace.s10,
                child: MapZoomButtons(
                  onZoomIn: zoom < config.maxZoom - 0.01
                      ? () => _zoomBy(CameraUpdate.zoomIn())
                      : null,
                  onZoomOut: _zoomedIn
                      ? () => _zoomBy(CameraUpdate.zoomOut())
                      : null,
                ),
              ),
          ],
        );
      },
    );
  }
}
