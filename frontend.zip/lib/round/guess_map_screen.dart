import 'package:flutter/material.dart';

import '../config/game_config.dart';
import '../design_system/design_system.dart';
import 'guess_map_view.dart';
import 'round_controller.dart';
import 'round_copy.dart';
import 'widgets/clue_panel.dart';
import 'widgets/map_overlays.dart';
import 'widgets/round_top_bar.dart';

/// The blind map over the whole screen, where the player puts the pin
/// down, moves it, and confirms the guess.
///
/// The round screen opens it and closes it again once the guess has been
/// answered: a miss shows its panel there, and a hit the result. A guess
/// that did not count (outside the region, no connection) keeps the
/// player here with the pin.
class GuessMapScreen extends StatelessWidget {
  const GuessMapScreen({
    super.key,
    required this.controller,
    required this.config,
    required this.mapBuilder,
    required this.onBack,
  });

  final RoundController controller;
  final GameConfig config;
  final GuessMapBuilder mapBuilder;

  /// Back to the clues; the unconfirmed pin stays.
  final VoidCallback onBack;

  /// Below this height the drag hint above the button is left out; the
  /// instruction to put the pin down stays.
  static const _compactHeight = 680.0;

  /// The widest the footer and the compass get, on a desktop browser.
  static const _maxWidth = 560.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KnzColors.surface,
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: controller,
          builder: (context, _) => LayoutBuilder(
            builder: (context, constraints) =>
                _body(compact: constraints.maxHeight < _compactHeight),
          ),
        ),
      ),
    );
  }

  Widget _body({required bool compact}) {
    final round = controller.round;
    // For the frame before the round screen closes this one.
    if (round == null) return const SizedBox.shrink();
    final pin = controller.pin;
    final pinPlace = pin == null ? null : RoundCopy.nearTown(pin);
    final compass = round.compass;
    return Column(
      children: [
        _centred(
          RoundTopBar(
            onClose: onBack,
            closeIcon: KnzIcons.back,
            closeLabel: 'Zpět na klíče',
            wrongGuesses: round.wrongGuesses,
            steps: config.maxStars,
            compassActive: compass != null,
            stars: controller.starsAvailable,
          ),
        ),
        if (compass != null)
          _centred(
            Padding(
              padding: const EdgeInsets.fromLTRB(
                KnzSize.screenGutter,
                0,
                KnzSize.screenGutter,
                KnzSpace.s12,
              ),
              child: CompassCard(compass: compass),
            ),
          ),
        Expanded(
          child: DecoratedBox(
            position: DecorationPosition.foreground,
            decoration: const BoxDecoration(
              border: Border.symmetric(
                horizontal: BorderSide(
                  color: KnzColors.border,
                  width: KnzDepth.border,
                ),
              ),
            ),
            child: Semantics(
              label: [
                'Mapa kraje',
                if (pin != null)
                  'tvůj tip ${pinPlace ?? 'je na mapě'}'
                else
                  'zatím bez tipu',
              ].join(': '),
              container: true,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  mapBuilder(
                    GuessMapView(
                      pin: pin,
                      lastGuess: round.lastGuess,
                      enabled: controller.canGuess,
                      onPin: controller.placePin,
                      interactive: true,
                    ),
                  ),
                  // The label lets taps through to the map.
                  if (pin != null)
                    GuessLabelOverlay(
                      text: pinPlace == null
                          ? 'Tvůj tip'
                          : 'Tvůj tip: $pinPlace',
                    ),
                ],
              ),
            ),
          ),
        ),
        _centred(
          RoundFooter(
            // The instruction sits here, not on the map, so that it
            // covers none of the region.
            hint: pin == null
                ? 'Klepni do mapy a polož špendlík.'
                : compact
                ? null
                : 'Posuň špendlík tažením, mapu přiblížíš dvěma prsty.',
            button: KnzButton(
              label: controller.submitting ? 'Posílám tip…' : 'Potvrdit tip',
              size: KnzButtonSize.cta,
              onPressed: controller.canGuess && pin != null
                  ? controller.confirmGuess
                  : null,
            ),
          ),
        ),
      ],
    );
  }

  Widget _centred(Widget child) => Center(
    child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: _maxWidth),
      child: child,
    ),
  );
}
