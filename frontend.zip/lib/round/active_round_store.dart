/// Remembers the token of the unfinished place of the day, so the player can
/// close the round and continue it later (PRODUCT_SPECIFICATION.md,
/// story 17).
///
/// The client progress store (FRONTEND_SPECIFICATION.md section 7) will
/// implement this over local storage for a guest and over the Game API for
/// an account. Until it exists, [MemoryActiveRoundStore] keeps the token
/// for as long as the app runs.
///
/// The token is opaque; nothing about the place is stored.
abstract interface class ActiveRoundStore {
  Future<String?> readDailyToken();

  Future<void> writeDailyToken(String token);

  Future<void> clearDailyToken();
}

class MemoryActiveRoundStore implements ActiveRoundStore {
  String? _token;

  @override
  Future<String?> readDailyToken() async => _token;

  @override
  Future<void> writeDailyToken(String token) async => _token = token;

  @override
  Future<void> clearDailyToken() async => _token = null;
}
