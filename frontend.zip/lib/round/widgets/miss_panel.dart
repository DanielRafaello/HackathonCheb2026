import 'package:flutter/widgets.dart';

import '../../design_system/design_system.dart';
import '../round_controller.dart';
import '../round_copy.dart';
import 'clue_panel.dart';

/// The panel after a wrong guess (`components.md`, CompassPanel): what the
/// guess unlocked and the TIPNOUT ZNOVU button.
class MissPanel extends StatelessWidget {
  const MissPanel({
    super.key,
    required this.feedback,
    required this.onRetry,
    this.reveal = kAlwaysCompleteAnimation,
  });

  final MissFeedback feedback;
  final VoidCallback onRetry;

  /// Brings in the compass and the new clue once the panel is up.
  final Animation<double> reveal;

  @override
  Widget build(BuildContext context) {
    final compass = feedback.compass;
    final clue = feedback.newClue;
    final number = feedback.newClueNumber;
    final (heading, subheading) = _texts();

    return Container(
      decoration: const BoxDecoration(
        color: KnzColors.dangerTint,
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(KnzRadius.sheet),
        ),
      ),
      padding: const EdgeInsets.fromLTRB(
        KnzSize.screenGutter,
        KnzSpace.s18,
        KnzSize.screenGutter,
        KnzSpace.s28,
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Flexible(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Semantics(
                      liveRegion: true,
                      child: MergeSemantics(
                        child: Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: const BoxDecoration(
                                color: KnzColors.danger,
                                shape: BoxShape.circle,
                              ),
                              alignment: Alignment.center,
                              child: KnzIcon(
                                compass != null
                                    ? KnzIcons.compass
                                    : KnzIcons.close,
                                size: 24,
                                color: KnzColors.textOnPrimary,
                              ),
                            ),
                            const SizedBox(width: KnzSpace.s12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    heading,
                                    style: KnzText.titleMd.copyWith(
                                      color: KnzColors.dangerEdge,
                                    ),
                                  ),
                                  Text(
                                    subheading,
                                    style: KnzText.bodySm.copyWith(
                                      color: KnzPalette.red900,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (compass != null) ...[
                      const SizedBox(height: KnzSpace.s12),
                      KnzReveal(
                        animation: reveal,
                        child: CompassCard(
                          compass: compass,
                          isNew: feedback.compassIsNew,
                        ),
                      ),
                    ],
                    if (clue != null && number != null) ...[
                      const SizedBox(height: KnzSpace.s12),
                      KnzReveal(
                        animation: reveal,
                        child: KnzClueCard(
                          label: RoundCopy.clueLabel(number, clue.kind),
                          text: clue.text!,
                          isNew: true,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: KnzSpace.s16),
            KnzButton(
              label: 'Tipnout znovu',
              sentiment: KnzSentiment.danger,
              size: KnzButtonSize.cta,
              onPressed: onRetry,
            ),
          ],
        ),
      ),
    );
  }

  /// The heading and the line under it. The round never runs out of
  /// guesses, so nothing here counts down (copy.md: no blame).
  (String, String) _texts() {
    final stars = feedback.starsAvailable;
    final reward = stars <= 1
        ? 'Za trefu teď získáš 1 hvězdu.'
        : 'Za trefu teď získáš až ${Czech.count(stars, 'hvězdu', 'hvězdy', 'hvězd')}.';
    if (feedback.compass != null) {
      return (
        'Vedle! Kompas ti poradí.',
        feedback.compassIsNew
            ? 'Šipka ukazuje, kterým směrem od tvého tipu leží cíl. $reward'
            : 'Šipka teď ukazuje směr od tvého nového tipu. $reward',
      );
    }
    final next = feedback.compassNext
        ? ' Když se příště netrefíš, poradí ti kompas.'
        : '';
    if (feedback.newClue != null) {
      return ('Vedle! Máš nový klíč.', '$reward$next');
    }
    return ('Vedle! Zkus to znovu.', '$reward$next');
  }
}
