import 'dart:async';

import 'package:flutter/material.dart';

import '../../design_system/design_system.dart';
import '../../game/game_day.dart';
import '../round.dart';
import '../round_copy.dart';

/// The screen after a hit (`components.md`, Feedback screens: Hit).
class HitView extends StatelessWidget {
  const HitView({
    super.key,
    required this.round,
    required this.maxStars,
    required this.now,
    required this.onShare,
    required this.onContinue,
  });

  /// A finished round; [RoundState.result] is set.
  final RoundState round;
  final int maxStars;

  /// The clock, for the time until the next place of the day.
  final DateTime Function() now;
  final VoidCallback onShare;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) {
    final result = round.result!;
    final guesses = result.guesses;
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(
              KnzSize.screenGutter,
              KnzSpace.s16,
              KnzSize.screenGutter,
              KnzSpace.s16,
            ),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const _Celebration(),
                    const SizedBox(height: KnzSpace.s12),
                    Semantics(
                      header: true,
                      liveRegion: true,
                      child: Text(
                        RoundCopy.hitHeading(guesses),
                        textAlign: TextAlign.center,
                        style: KnzText.display.copyWith(
                          color: KnzColors.successText,
                        ),
                      ),
                    ),
                    const SizedBox(height: KnzSpace.s14),
                    Center(
                      child: KnzStarRating(stars: result.stars, max: maxStars),
                    ),
                    if (result.wafersEarned case final wafers?
                        when wafers > 0) ...[
                      const SizedBox(height: KnzSpace.s10),
                      Center(child: KnzWaferPill(wafers: wafers, earned: true)),
                    ],
                    const SizedBox(height: KnzSpace.s16),
                    Row(
                      children: [
                        Expanded(
                          child: ResultStat(
                            label: 'Od cíle',
                            value: RoundCopy.distance(result.distanceMeters),
                            sentiment: KnzSentiment.success,
                          ),
                        ),
                        const SizedBox(width: KnzSpace.s10),
                        Expanded(
                          child: ResultStat(
                            label: 'Pokusy',
                            // No "z 5": a round has no guess limit.
                            value: '$guesses',
                            sentiment: KnzSentiment.primary,
                          ),
                        ),
                        const SizedBox(width: KnzSpace.s10),
                        Expanded(
                          child: ResultStat(
                            label: 'Klíče',
                            value: Czech.fractionSlash(
                              round.unlockedClues,
                              round.clues.length,
                            ),
                            sentiment: KnzSentiment.accent,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: KnzSpace.s14),
                    HitPlaceCard(place: result.place),
                    const SizedBox(height: KnzSpace.s14),
                    NextPlaceOfTheDay(now: now),
                  ],
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(
            KnzSize.screenGutter,
            KnzSpace.s14,
            KnzSize.screenGutter,
            KnzSpace.s28,
          ),
          child: Row(
            children: [
              Expanded(
                child: KnzButton(
                  label: 'Sdílet',
                  icon: KnzIcons.share,
                  variant: KnzButtonVariant.secondary,
                  size: KnzButtonSize.cta,
                  onPressed: onShare,
                ),
              ),
              const SizedBox(width: KnzSpace.s10),
              Expanded(
                child: KnzButton(
                  label: 'Pokračovat',
                  sentiment: KnzSentiment.success,
                  size: KnzButtonSize.cta,
                  onPressed: onContinue,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// Vřídlík cheering among confetti. Decorative.
class _Celebration extends StatelessWidget {
  const _Celebration();

  @override
  Widget build(BuildContext context) {
    return ExcludeSemantics(
      child: SizedBox(
        height: 160,
        child: CustomPaint(
          painter: const _ConfettiPainter(),
          child: const Center(
            child: KnzMascot(mood: KnzMood.cheer, width: 112),
          ),
        ),
      ),
    );
  }
}

/// Still confetti in the game colours, so it needs no motion setting.
class _ConfettiPainter extends CustomPainter {
  const _ConfettiPainter();

  /// x and y as fractions of the size, a colour, and a shape.
  static const _pieces = [
    (0.08, 0.30, KnzPalette.gold500, 0),
    (0.18, 0.62, KnzPalette.red500, 0),
    (0.24, 0.18, KnzPalette.teal500, 1),
    (0.32, 0.08, KnzPalette.gold500, 2),
    (0.12, 0.85, KnzPalette.green500, 3),
    (0.66, 0.06, KnzPalette.green500, 2),
    (0.72, 0.40, KnzPalette.gold500, 1),
    (0.80, 0.68, KnzPalette.teal500, 0),
    (0.84, 0.20, KnzPalette.blue500, 0),
    (0.92, 0.52, KnzPalette.red500, 1),
    (0.90, 0.88, KnzPalette.blue500, 3),
    (0.04, 0.55, KnzPalette.blue500, 1),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    for (final (x, y, color, shape) in _pieces) {
      final centre = Offset(size.width * x, size.height * y);
      final paint = Paint()..color = color;
      switch (shape) {
        case 0:
          canvas.save();
          canvas.translate(centre.dx, centre.dy);
          canvas.rotate(0.5);
          canvas.drawRRect(
            RRect.fromRectAndRadius(
              Rect.fromCenter(center: Offset.zero, width: 10, height: 18),
              const Radius.circular(3),
            ),
            paint,
          );
          canvas.restore();
        case 1:
          canvas.drawCircle(centre, 5, paint);
        case 2:
          final path = Path();
          for (var i = 0; i < 10; i++) {
            final r = i.isEven ? 11.0 : 5.0;
            final a = -1.5708 + i * 0.6283;
            final p = centre + Offset.fromDirection(a, r);
            i == 0 ? path.moveTo(p.dx, p.dy) : path.lineTo(p.dx, p.dy);
          }
          canvas.drawPath(path..close(), paint);
        default:
          final stroke = Paint()
            ..color = color
            ..style = PaintingStyle.stroke
            ..strokeWidth = 4
            ..strokeCap = StrokeCap.round;
          canvas.drawPath(
            Path()
              ..moveTo(centre.dx - 18, centre.dy)
              ..quadraticBezierTo(
                centre.dx - 9,
                centre.dy - 10,
                centre.dx,
                centre.dy,
              )
              ..quadraticBezierTo(
                centre.dx + 9,
                centre.dy + 10,
                centre.dx + 18,
                centre.dy,
              ),
            stroke,
          );
      }
    }
  }

  @override
  bool shouldRepaint(_ConfettiPainter oldDelegate) => false;
}

/// A result tile (`components.md`, ResultStat): a solid header and the
/// value under it.
class ResultStat extends StatelessWidget {
  const ResultStat({
    super.key,
    required this.label,
    required this.value,
    required this.sentiment,
  });

  final String label;
  final String value;
  final KnzSentiment sentiment;

  @override
  Widget build(BuildContext context) {
    final c = sentiment.colors;
    final valueColor = sentiment == KnzSentiment.accent
        ? KnzPalette.gold800
        : c.onTint;
    return MergeSemantics(
      child: Container(
        decoration: BoxDecoration(
          color: KnzColors.surface,
          border: Border.all(color: c.line, width: KnzDepth.border),
          borderRadius: BorderRadius.circular(KnzRadius.lg),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              color: c.line,
              padding: const EdgeInsets.symmetric(vertical: KnzSpace.s4),
              child: Text(
                label.toUpperCase(),
                textAlign: TextAlign.center,
                style: KnzText.badge.copyWith(
                  color: sentiment == KnzSentiment.accent
                      ? KnzColors.text
                      : KnzColors.textOnPrimary,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(
                vertical: KnzSpace.s8,
                horizontal: KnzSpace.s4,
              ),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  value,
                  maxLines: 1,
                  style: KnzText.titleMd.copyWith(color: valueColor),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// The compact place card after a hit (`components.md`, PlaceCard): what
/// the place is, the spring warning when it is a spring, and the data
/// source with its licence.
class HitPlaceCard extends StatelessWidget {
  const HitPlaceCard({super.key, required this.place, this.addedToMap = true});

  final PlaceCard place;

  /// Shows "Přidáno na tvou mapu". Multiplayer guesses are not recorded on
  /// my map, so its reveal leaves the line out.
  final bool addedToMap;

  /// The data source and its licence, or null when the backend named
  /// neither; the card never invents one (copy.md).
  String? get attribution => switch ((place.source, place.licence)) {
    (null, null) => null,
    (final source?, null) => source,
    (null, final licence?) => licence,
    (final source?, final licence?) => '$source\u00A0· $licence',
  };

  @override
  Widget build(BuildContext context) {
    return KnzCard(
      padding: const EdgeInsets.all(KnzSpace.s12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _PlacePicture(place: place),
              const SizedBox(width: KnzSpace.s12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    KnzPill(label: place.type),
                    const SizedBox(height: KnzSpace.s6),
                    Text(place.name, style: KnzText.titleSm),
                    const SizedBox(height: KnzSpace.s4),
                    Text(
                      place.description,
                      style: KnzText.bodySm.copyWith(
                        color: KnzColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (place.isSpring) ...[
            const SizedBox(height: KnzSpace.s10),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: KnzSpace.s10,
                vertical: KnzSpace.s8,
              ),
              decoration: BoxDecoration(
                color: KnzColors.exploreTint,
                borderRadius: BorderRadius.circular(KnzRadius.sm),
              ),
              child: Row(
                children: [
                  const KnzIcon(
                    KnzIcons.info,
                    size: 16,
                    color: KnzColors.exploreText,
                  ),
                  const SizedBox(width: KnzSpace.s8),
                  Expanded(
                    child: Text(
                      'Voda není hygienicky sledovaná.',
                      style: KnzText.caption.copyWith(
                        color: KnzColors.exploreText,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: KnzSpace.s12),
          Container(height: KnzDepth.border, color: KnzColors.track),
          const SizedBox(height: KnzSpace.s10),
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: KnzSpace.s8,
            runSpacing: KnzSpace.s4,
            children: [
              if (addedToMap)
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        color: KnzColors.stateGuessed,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: KnzColors.primaryTint,
                          width: KnzDepth.sm,
                        ),
                      ),
                    ),
                    const SizedBox(width: KnzSpace.s6),
                    Flexible(
                      child: Text(
                        'Přidáno na tvou mapu',
                        style: KnzText.caption.copyWith(
                          color: KnzColors.primaryEdge,
                        ),
                      ),
                    ),
                  ],
                ),
              if (attribution case final attribution?)
                Text(
                  attribution,
                  style: KnzText.micro.copyWith(color: KnzColors.textMuted),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// The place's photo when it has one, otherwise a flat picture of its
/// kind.
class _PlacePicture extends StatelessWidget {
  const _PlacePicture({required this.place});

  final PlaceCard place;

  static const _size = 92.0;

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      color: KnzColors.primaryTint,
      alignment: Alignment.center,
      child: KnzIcon(
        place.isSpring ? KnzIcons.spring : KnzIcons.place,
        size: 40,
        color: KnzColors.primary,
      ),
    );
    final url = place.photoUrl;
    return ClipRRect(
      borderRadius: BorderRadius.circular(KnzRadius.md),
      child: SizedBox(
        width: _size,
        height: _size,
        child: url == null
            ? fallback
            : Image.network(
                url,
                fit: BoxFit.cover,
                semanticLabel: 'Fotka: ${place.name}',
                errorBuilder: (context, error, stack) => fallback,
                loadingBuilder: (context, child, progress) =>
                    progress == null ? child : fallback,
              ),
      ),
    );
  }
}

/// "Další místo dne bude za 7 h 12 min." (PRODUCT_SPECIFICATION.md,
/// story 40). Updates every half minute.
class NextPlaceOfTheDay extends StatefulWidget {
  const NextPlaceOfTheDay({super.key, required this.now});

  final DateTime Function() now;

  @override
  State<NextPlaceOfTheDay> createState() => _NextPlaceOfTheDayState();
}

class _NextPlaceOfTheDayState extends State<NextPlaceOfTheDay> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(
      const Duration(seconds: 30),
      (_) => setState(() {}),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final left = untilNextDay(widget.now());
    final hours = left.inHours;
    final minutes = left.inMinutes % 60;
    final text = hours > 0
        ? '$hours h $minutes min'
        : '${minutes < 1 ? 1 : minutes} min';
    return Text(
      'Další místo dne bude za $text.',
      textAlign: TextAlign.center,
      style: KnzText.bodySm.copyWith(color: KnzColors.textMuted),
    );
  }

  /// Time from [now] to the next midnight in Prague. The summer time
  /// switch happens at 2 or 3 a.m., never between now and midnight.
  static Duration untilNextDay(DateTime now) {
    final local = GameDay.wallClock(now);
    final midnight = DateTime.utc(local.year, local.month, local.day + 1);
    return midnight.difference(local);
  }
}
