import 'dart:math' as math;

import 'package:flutter/widgets.dart';

import '../../design_system/design_system.dart';
import '../round.dart';
import '../round_copy.dart';

/// The clues above the blind map: the first one in Vřídlík's bubble, the
/// other unlocked ones in order, the locked ones as tiles, and the compass
/// once it is active (PRODUCT_SPECIFICATION.md, Clue Display).
class CluePanel extends StatelessWidget {
  const CluePanel({
    super.key,
    required this.round,
    required this.overline,
    this.reveal = kAlwaysCompleteAnimation,
    this.revealClueNumber,
    this.revealCompass = false,
  });

  final RoundState round;

  /// "MÍSTO DNE · POKUS 3".
  final String overline;

  /// Brings in what the last guess unlocked, when the player is back on
  /// the clues: the clue numbered [revealClueNumber] (from 1) and the
  /// compass when [revealCompass] is set.
  final Animation<double> reveal;
  final int? revealClueNumber;
  final bool revealCompass;

  Widget _revealed(bool isNew, Widget child) =>
      isNew ? KnzReveal(animation: reveal, child: child) : child;

  @override
  Widget build(BuildContext context) {
    final clues = round.clues;
    final unlocked = [
      for (var i = 0; i < clues.length; i++)
        if (clues[i].isUnlocked) (number: i + 1, clue: clues[i]),
    ];
    final locked = [
      for (final clue in clues)
        if (!clue.isUnlocked) clue,
    ];
    final compass = round.compass;
    final first = unlocked.firstOrNull;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          overline,
          style: KnzText.overline.copyWith(color: KnzColors.textMuted),
        ),
        const SizedBox(height: KnzSpace.s12),
        if (first != null)
          _revealed(
            first.number == revealClueNumber,
            KnzSpeechBubble(
              mood: KnzMood.think,
              mascotWidth: 72,
              raised: true,
              child: KnzClueContent(
                label: RoundCopy.clueLabel(first.number, first.clue.kind),
                text: first.clue.text!,
              ),
            ),
          ),
        for (final entry in unlocked.skip(1)) ...[
          const SizedBox(height: KnzSpace.s10),
          _revealed(
            entry.number == revealClueNumber,
            KnzClueCard(
              label: RoundCopy.clueLabel(entry.number, entry.clue.kind),
              text: entry.clue.text!,
            ),
          ),
        ],
        if (compass != null) ...[
          const SizedBox(height: KnzSpace.s10),
          _revealed(revealCompass, CompassCard(compass: compass)),
        ],
        if (locked.isNotEmpty) ...[
          const SizedBox(height: KnzSpace.s12),
          Row(
            children: [
              for (var i = 0; i < locked.length; i++) ...[
                if (i > 0) const SizedBox(width: KnzSpace.s8),
                Expanded(
                  child: KnzLockedClue(label: locked[i].kind.lockedLabel),
                ),
              ],
            ],
          ),
        ],
      ],
    );
  }
}

/// The compass: an arrow and the direction from the latest guess to the
/// target, nothing more (PRODUCT_SPECIFICATION.md, story 32).
class CompassCard extends StatelessWidget {
  const CompassCard({super.key, required this.compass, this.isNew = false});

  final Compass compass;

  /// Shown in the panel right after the guess that turned it on or moved
  /// it.
  final bool isNew;

  @override
  Widget build(BuildContext context) {
    final direction = RoundCopy.direction(compass.bearingDegrees);
    return Semantics(
      label: 'Kompas: cíl leží $direction od tvého posledního tipu',
      excludeSemantics: true,
      child: KnzCard(
        sentiment: KnzSentiment.danger,
        radius: KnzRadius.xl,
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s14,
          vertical: KnzSpace.s12,
        ),
        child: Row(
          children: [
            CompassArrow(bearingDegrees: compass.bearingDegrees),
            const SizedBox(width: KnzSpace.s12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'KOMPAS',
                          style: KnzText.label.copyWith(
                            color: KnzColors.dangerEdge,
                          ),
                        ),
                      ),
                      if (isNew)
                        const KnzPill(
                          label: 'Nově odemčeno',
                          sentiment: KnzSentiment.accent,
                          tinted: false,
                        ),
                    ],
                  ),
                  const SizedBox(height: KnzSpace.s2),
                  Text('Cíl leží $direction', style: KnzText.cardTitle),
                  Text(
                    'od tvého posledního tipu',
                    style: KnzText.micro.copyWith(color: KnzColors.textMuted),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// A white arrow in a red circle, turned to [bearingDegrees].
class CompassArrow extends StatelessWidget {
  const CompassArrow({super.key, required this.bearingDegrees});

  final double bearingDegrees;

  /// The `direction-se` icon points south-east.
  static const _iconBearing = 135.0;

  @override
  Widget build(BuildContext context) {
    final bearing = bearingDegrees.isFinite ? bearingDegrees : _iconBearing;
    return Container(
      width: KnzSize.touch,
      height: KnzSize.touch,
      decoration: const BoxDecoration(
        color: KnzColors.danger,
        shape: BoxShape.circle,
      ),
      alignment: Alignment.center,
      child: Transform.rotate(
        angle: (bearing - _iconBearing) * math.pi / 180,
        child: const KnzIcon(
          KnzIcons.directionSe,
          size: 26,
          color: KnzColors.textOnPrimary,
        ),
      ),
    );
  }
}
