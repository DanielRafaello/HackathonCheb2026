import 'package:flutter/widgets.dart';

import '../../design_system/design_system.dart';
import '../round_copy.dart';

/// The round's top bar (`components.md`, GameTopBar): close, the guess
/// segments, and the stars a hit can still earn.
class RoundTopBar extends StatelessWidget {
  const RoundTopBar({
    super.key,
    required this.onClose,
    this.closeIcon = KnzIcons.close,
    this.closeLabel = 'Zavřít',
    this.wrongGuesses,
    this.steps,
    this.compassActive = false,
    this.stars,
  });

  final VoidCallback onClose;

  /// The button on the left: close the round, or go back from the
  /// full-screen map.
  final KnzIcons closeIcon;
  final String closeLabel;

  /// Without [wrongGuesses] and [steps] the bar shows only the close
  /// button, for example while the round loads.
  final int? wrongGuesses;

  /// Segments of the indicator: one per star a hit can lose
  /// (`GameConfig.maxStars`). A round has no guess limit, so the last
  /// segment stays current for every guess after it.
  final int? steps;

  /// The compass points, for the screen reader.
  final bool compassActive;
  final int? stars;

  @override
  Widget build(BuildContext context) {
    final wrong = wrongGuesses;
    final steps = this.steps;
    final stars = this.stars;
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        KnzSpace.s20 - KnzSpace.s10,
        KnzSpace.s18,
        KnzSpace.s20,
        KnzSpace.s8,
      ),
      child: Row(
        children: [
          KnzIconButton(
            icon: closeIcon,
            semanticLabel: closeLabel,
            onPressed: onClose,
          ),
          const SizedBox(width: KnzSpace.s14 - KnzSpace.s10),
          if (wrong != null && steps != null)
            Expanded(
              child: KnzAttemptProgress(
                missed: wrong.clamp(0, steps - 1),
                total: steps,
                semanticLabel: RoundCopy.guessProgress(
                  wrong + 1,
                  compass: compassActive,
                ),
              ),
            )
          else
            const Spacer(),
          if (stars != null) ...[
            const SizedBox(width: KnzSpace.s14),
            KnzStarCounter(stars: stars),
          ],
        ],
      ),
    );
  }
}
