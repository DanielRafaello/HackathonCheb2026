import 'package:flutter/widgets.dart';

import '../../design_system/design_system.dart';

/// An instruction on an ink pill in the middle of the map
/// (`components.md`, MapFrame): "Klepni do mapy a polož špendlík."
class MapInstruction extends StatelessWidget {
  const MapInstruction({super.key, required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: KnzSpace.s16),
      padding: const EdgeInsets.symmetric(
        horizontal: KnzSpace.s14,
        vertical: KnzSpace.s8,
      ),
      decoration: BoxDecoration(
        color: KnzColors.text,
        borderRadius: BorderRadius.circular(KnzRadius.pill),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const KnzIcon(KnzIcons.tap, size: 18, color: KnzColors.textOnPrimary),
          const SizedBox(width: KnzSpace.s8),
          Flexible(
            child: Text(
              text,
              style: KnzText.weight(
                KnzText.bodySm,
                800,
              ).copyWith(color: KnzColors.textOnPrimary),
            ),
          ),
        ],
      ),
    );
  }
}

/// "Tvůj tip: kousek od Sokolova" on a white pill.
class GuessLabel extends StatelessWidget {
  const GuessLabel({super.key, required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: KnzSpace.s12,
        vertical: KnzSpace.s6,
      ),
      decoration: BoxDecoration(
        color: KnzColors.surface,
        borderRadius: BorderRadius.circular(KnzRadius.pill),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const KnzIcon(KnzIcons.place, size: 14, color: KnzColors.danger),
          const SizedBox(width: KnzSpace.s6),
          Flexible(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: KnzText.caption.copyWith(color: KnzColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}

/// The guess label in the top left corner of the map: the zoom buttons
/// take the top right, and the OpenStreetMap attribution the bottom.
class GuessLabelOverlay extends StatelessWidget {
  const GuessLabelOverlay({super.key, required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: KnzSpace.s12,
      top: KnzSpace.s12,
      right: 64,
      child: IgnorePointer(
        child: Align(
          alignment: Alignment.topLeft,
          child: GuessLabel(text: text),
        ),
      ),
    );
  }
}

/// The footer of a round screen with a hint and the main action (padding
/// 14 / 20 / 28).
class RoundFooter extends StatelessWidget {
  const RoundFooter({super.key, required this.button, this.hint});

  /// Left out on short screens.
  final String? hint;
  final Widget button;

  /// The footer's height with a CTA button and without the hint, which a
  /// toast must leave free so the player can try again right away.
  static const height = KnzSize.buttonCta + KnzSpace.s14 + KnzSpace.s28;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          KnzSize.screenGutter,
          KnzSpace.s14,
          KnzSize.screenGutter,
          KnzSpace.s28,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (hint case final hint?) ...[
              Text(
                hint,
                textAlign: TextAlign.center,
                style: KnzText.bodySm.copyWith(color: KnzColors.textMuted),
              ),
              const SizedBox(height: KnzSpace.s12),
            ],
            button,
          ],
        ),
      ),
    );
  }
}
