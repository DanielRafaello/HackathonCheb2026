import 'package:flutter/material.dart';

import '../account/account_api.dart';
import '../design_system/design_system.dart';
import 'my_map_markers.dart';
import 'my_map_place.dart';
import 'my_map_summary.dart';

/// My map (`07 Mapa`): every place in the region with the player's
/// progress, the counts, the filter, and the map over the rest of the
/// screen.
class MyMapPage extends StatefulWidget {
  const MyMapPage({
    super.key,
    required this.account,
    required this.load,
    required this.mapBuilder,
    required this.onOpenPlace,
    required this.onSignIn,
  });

  /// The signed-in account, or null for a guest. The Game API keeps progress
  /// only for an account, so a guest is asked to sign in.
  final Account? account;

  /// Loads the places with the player's progress (`GET /locations`).
  final Future<List<MyMapPlace>> Function() load;

  /// Draws the map for the filtered places; a tap on a guessed or visited
  /// place calls `onTap`. Injected so that tests can replace MapLibre, which
  /// does not run in widget tests.
  final Widget Function(List<MyMapPlace> places, ValueChanged<MyMapPlace> onTap)
  mapBuilder;

  /// Opens the place card; completes when the card closes. A visit may have
  /// changed the place, so my map loads again then.
  final Future<void> Function(MyMapPlace place) onOpenPlace;

  final VoidCallback onSignIn;

  @override
  State<MyMapPage> createState() => _MyMapPageState();
}

class _MyMapPageState extends State<MyMapPage> {
  Future<List<MyMapPlace>>? _places;

  /// The last places loaded, shown while my map loads again.
  List<MyMapPlace> _shown = const [];
  MyMapFilter _filter = MyMapFilter.all;

  @override
  void initState() {
    super.initState();
    if (widget.account != null) _places = _load();
  }

  @override
  void didUpdateWidget(MyMapPage old) {
    super.didUpdateWidget(old);
    if (widget.account?.id != old.account?.id) {
      _shown = const [];
      _places = widget.account == null ? null : _load();
    }
  }

  /// Loads the places; a failure shows a toast over the zeros.
  Future<List<MyMapPlace>> _load() {
    final places = widget.load();
    places.then<void>(
      (loaded) {
        if (identical(_places, places)) _shown = loaded;
      },
      onError: (Object _) {
        if (!mounted) return;
        KnzToast.show(
          context,
          'Místa na mapě se nepodařilo načíst. Zkontroluj připojení.',
        );
      },
    );
    return places;
  }

  Future<void> _openPlace(MyMapPlace place) async {
    await widget.onOpenPlace(place);
    if (mounted && widget.account != null) {
      setState(() {
        _places = _load();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final places = _places;
    return ColoredBox(
      color: KnzColors.surface,
      child: SafeArea(
        bottom: false,
        child: places == null
            ? _guest()
            : FutureBuilder(
                future: places,
                // While loading again, the last places stay. On the first
                // load, and when loading fails, everything shows zeros over
                // the bare region map.
                builder: (context, snapshot) => _content(
                  snapshot.hasError ? const [] : snapshot.data ?? _shown,
                ),
              ),
      ),
    );
  }

  Widget _guest() => Center(
    child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 480),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(
          KnzSize.screenGutter,
          KnzSpace.s16,
          KnzSize.screenGutter,
          KnzSpace.s24,
        ),
        children: [
          const _Header(total: 0),
          const SizedBox(height: KnzSpace.s20),
          const KnzSpeechBubble(
            mood: KnzMood.think,
            text:
                'Svoji mapu si zatím uložíš jen s účtem. '
                'Přihlas se a uvidíš všechna místa kraje.',
          ),
          const SizedBox(height: KnzSpace.s20),
          KnzButton(label: 'Přihlásit se', onPressed: widget.onSignIn),
        ],
      ),
    ),
  );

  Widget _content(List<MyMapPlace> places) {
    final summary = MyMapSummary.of(places);
    final shown = [
      for (final place in places)
        if (_filter.includes(place)) place,
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(
                KnzSize.screenGutter,
                KnzSpace.s16,
                KnzSize.screenGutter,
                KnzSpace.s14,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _Header(total: places.length),
                  const SizedBox(height: KnzSpace.s16),
                  _Counts(summary: summary),
                  const SizedBox(height: KnzSpace.s14),
                  KnzSegmentedControl(
                    labels: [
                      for (final filter in MyMapFilter.values) filter.label,
                    ],
                    selected: _filter.index,
                    onSelected: (i) =>
                        setState(() => _filter = MyMapFilter.values[i]),
                  ),
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: DecoratedBox(
            position: DecorationPosition.foreground,
            decoration: const BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: KnzColors.border,
                  width: KnzDepth.border,
                ),
              ),
            ),
            child: Stack(
              children: [
                Positioned.fill(
                  child: Semantics(
                    label:
                        'Mapa kraje: '
                        '${Czech.count(shown.length, 'místo', 'místa', 'míst')}'
                        ' – ${_filter.label.toLowerCase()}',
                    child: ColoredBox(
                      color: KnzColors.surfaceSubtle,
                      child: widget.mapBuilder(shown, _openPlace),
                    ),
                  ),
                ),
                const Positioned(
                  left: KnzSize.screenGutter,
                  right: KnzSize.screenGutter,
                  bottom: KnzSpace.s16,
                  child: Center(child: MyMapLegend()),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// "Mapa kraje" and the number of places in the region.
class _Header extends StatelessWidget {
  const _Header({required this.total});

  /// All places in the region; nothing shows until they load.
  final int total;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        Expanded(
          child: Semantics(
            header: true,
            child: Text('Mapa kraje', style: KnzText.titleXl),
          ),
        ),
        if (total > 0)
          Text(
            Czech.count(total, 'místo', 'místa', 'míst'),
            style: KnzText.caption.copyWith(color: KnzColors.textMuted),
          ),
      ],
    );
  }
}

/// The guessed, visited and in-the-fog counts (`components.md`, CountTile).
class _Counts extends StatelessWidget {
  const _Counts({required this.summary});

  final MyMapSummary summary;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: KnzCountTile(
            marker: const PlaceDot(color: KnzColors.stateGuessed),
            count: summary.guessed,
            label: 'uhodnuto',
          ),
        ),
        const SizedBox(width: KnzSpace.s8),
        Expanded(
          child: KnzCountTile(
            marker: const KnzIcon(KnzIcons.flag, size: 24),
            count: summary.visited,
            label: 'navštíveno',
          ),
        ),
        const SizedBox(width: KnzSpace.s8),
        Expanded(
          child: KnzCountTile(
            marker: const PlaceDot(color: KnzColors.stateUnknown),
            count: summary.unknown,
            label: 'neobjeveno',
            inFog: true,
          ),
        ),
      ],
    );
  }
}
