import 'package:flutter/widgets.dart';

import '../design_system/design_system.dart';

/// A place dot as on the map: a filled circle with a white ring.
class PlaceDot extends StatelessWidget {
  const PlaceDot({super.key, required this.color, this.size = 22});

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: size,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(
            color: KnzColors.surface,
            width: size / 7,
            strokeAlign: BorderSide.strokeAlignInside,
          ),
          boxShadow: [BoxShadow(color: color, spreadRadius: 1.5)],
        ),
      ),
    );
  }
}

/// The map legend (`components.md`, Legend): what the dots and the flag
/// mean, in a white pill.
class MyMapLegend extends StatelessWidget {
  const MyMapLegend({super.key});

  @override
  Widget build(BuildContext context) {
    final style = KnzText.caption.copyWith(color: KnzColors.textSecondary);
    Widget item(Widget marker, String label) => Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        marker,
        const SizedBox(width: KnzSpace.s6),
        Text(label, style: style),
      ],
    );
    return ExcludeSemantics(
      child: KnzEdgeBox(
        color: KnzColors.surface,
        edgeColor: KnzColors.border,
        radius: KnzRadius.pill,
        frame: KnzDepth.border,
        depth: KnzDepth.sm,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: KnzSpace.s16,
            vertical: KnzSpace.s8,
          ),
          child: Wrap(
            alignment: WrapAlignment.center,
            spacing: KnzSpace.s18,
            runSpacing: KnzSpace.s6,
            children: [
              item(
                const PlaceDot(color: KnzColors.stateUnknown, size: 14),
                'neobjeveno',
              ),
              item(
                const PlaceDot(color: KnzColors.stateGuessed, size: 14),
                'uhodnuto',
              ),
              item(const KnzIcon(KnzIcons.flag, size: 18), 'navštíveno'),
            ],
          ),
        ),
      ),
    );
  }
}
