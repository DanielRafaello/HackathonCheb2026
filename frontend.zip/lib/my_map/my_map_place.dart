import '../game/area.dart';

/// Which marker a place has on my map. A visited place shows the flag even
/// when it is also guessed.
enum PlaceMarker { unknown, guessed, visited }

/// One place on my map with the player's progress on it, as `GET /locations`
/// returns it (API_SPECIFICATION.md 4.1).
class MyMapPlace {
  const MyMapPlace({
    required this.id,
    required this.name,
    required this.latitude,
    required this.longitude,
    this.area,
    bool? guessed,
    bool? visited,
    this.guessedAt,
    this.visitedAt,
    this.rating,
    this.ratedAt,
    this.averageRating,
    this.ratingCount,
  }) : guessed = guessed ?? guessedAt != null,
       visited = visited ?? visitedAt != null;

  /// Throws [FormatException] when [json] is not a place.
  ///
  /// The backend sends no district yet; a place without one has no [area].
  /// The area is never guessed from the coordinates: a place near the
  /// border would get the wrong one (copy.md: never invent a missing
  /// value).
  factory MyMapPlace.fromJson(Map<String, dynamic> json) {
    final district = json['district'] ?? json['district_code'];
    final guessedAt = _time(json['guessed_at']);
    final visitedAt = _time(json['visited_at']);
    return MyMapPlace(
      id: (json['id'] as num).toInt(),
      name: json['name'] as String,
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      area: district is String ? Area.ofDistrict(district) : null,
      guessed: _flag(json['guessed']) ?? guessedAt != null,
      visited: _flag(json['visited']) ?? visitedAt != null,
      guessedAt: guessedAt,
      visitedAt: visitedAt,
      rating: (json['rating'] as num?)?.toInt(),
      ratedAt: _time(json['rated_at']),
      averageRating: (json['average_rating'] as num?)?.toDouble(),
      ratingCount: (json['rating_count'] as num?)?.toInt(),
    );
  }

  final int id;
  final String name;
  final double latitude;
  final double longitude;

  /// The area of the place, or null while the backend sends no district.
  final Area? area;

  /// Whether the player guessed the place. From the backend's flag, with
  /// the timestamp as the fallback.
  final bool guessed;

  /// Whether the player visited the place.
  final bool visited;

  /// When the player guessed the place, or null.
  final DateTime? guessedAt;

  /// When the player visited the place, or null.
  final DateTime? visitedAt;

  /// The player's own rating of a visited place, 1–5, or null.
  final int? rating;

  /// When the player last rated the place, or null.
  final DateTime? ratedAt;

  /// The average rating of all players, or null when nobody rated it.
  final double? averageRating;
  final int? ratingCount;

  bool get isGuessed => guessed;
  bool get isVisited => visited;

  /// Neither guessed nor visited: in the fog.
  bool get isUnknown => !isGuessed && !isVisited;

  PlaceMarker get marker => isVisited
      ? PlaceMarker.visited
      : isGuessed
      ? PlaceMarker.guessed
      : PlaceMarker.unknown;

  /// This place as visited at [at], for a visit kept on the client.
  MyMapPlace withVisit(DateTime at) => MyMapPlace(
    id: id,
    name: name,
    latitude: latitude,
    longitude: longitude,
    area: area,
    guessed: guessed,
    visited: true,
    guessedAt: guessedAt,
    visitedAt: at,
    rating: rating,
    ratedAt: ratedAt,
    averageRating: averageRating,
    ratingCount: ratingCount,
  );

  static DateTime? _time(Object? value) =>
      value is String ? DateTime.parse(value) : null;

  static bool? _flag(Object? value) => value is bool ? value : null;
}
