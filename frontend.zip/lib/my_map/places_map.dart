import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:maplibre_gl/maplibre_gl.dart';

import '../config/map_config.dart';
import '../design_system/design_system.dart';
import '../map/game_map.dart';
import '../map/map_projection.dart';
import '../map/map_zoom_buttons.dart';
import 'my_map_place.dart';

/// The game map with my map's places: gray dots in the fog, blue dots for
/// guessed places, and gold flags for visited ones.
///
/// Fully zoomed out, the whole region fits the frame and a drag scrolls the
/// page; zoomed in, a drag pans the map within the region. Two fingers zoom.
/// Zoom buttons sit top right.
///
/// Tapping near a place calls [onPlaceTap], for places in the fog too: the
/// dots are small, so a tap counts within a finger's reach ([tapRadius]).
class PlacesMap extends StatefulWidget {
  const PlacesMap({
    super.key,
    required this.config,
    required this.places,
    this.onPlaceTap,
  });

  final MapConfig config;

  /// The places to show; the filter has already been applied.
  final List<MyMapPlace> places;

  final ValueChanged<MyMapPlace>? onPlaceTap;

  /// How far from a marker a tap still hits it, in logical pixels: about
  /// half a fingertip.
  static const tapRadius = 22.0;

  /// The middle of a visited place's flag above its point: the flag icon is
  /// 30 px tall and stands on the point ([flagsLayer]).
  static const _flagCentre = Offset(0, -15);

  /// The place a tap at [tap] hits: the nearest one within [tapRadius].
  /// Guessed and visited places win over places in the fog, so a gray dot
  /// next to a known place never swallows its tap.
  static MyMapPlace? placeAt(
    Offset tap,
    Iterable<MyMapPlace> places,
    MapProjection projection,
  ) {
    MyMapPlace? best;
    var bestDistance = double.infinity;
    var bestKnown = false;
    for (final place in places) {
      final point = projection.toScreen(
        LatLng(place.latitude, place.longitude),
      );
      var distance = (tap - point).distance;
      if (place.marker == PlaceMarker.visited) {
        distance = math.min(distance, (tap - (point + _flagCentre)).distance);
      }
      if (distance > tapRadius) continue;
      final known = !place.isUnknown;
      if ((known && !bestKnown) ||
          (known == bestKnown && distance < bestDistance)) {
        best = place;
        bestDistance = distance;
        bestKnown = known;
      }
    }
    return best;
  }

  /// The Karlovy Vary Region, which the camera fits at the start.
  static final regionBounds = LatLngBounds(
    southwest: const LatLng(49.92, 12.08),
    northeast: const LatLng(50.46, 13.32),
  );

  /// Space between the region and the frame when fully zoomed out.
  static const regionPadding = KnzSpace.s12;

  static const _sourceId = 'my-map-places';

  static const _marker = ['get', 'marker'];

  /// Gray dots in the fog and blue dots for guessed places.
  @visibleForTesting
  static CircleLayerProperties get dotsLayer => CircleLayerProperties(
    // Guessed dots over gray ones.
    circleSortKey: ['match', _marker, PlaceMarker.guessed.name, 1, 0],
    circleColor: [
      'match',
      _marker,
      PlaceMarker.guessed.name,
      _hex(KnzColors.stateGuessed),
      _hex(KnzColors.stateUnknown),
    ],
    // MapLibre allows the zoom only as the input of one top-level curve, so
    // the zoom curve is outside and the marker match inside its stops.
    circleRadius: _byZoom(_guessedOrNot(6, 4), _guessedOrNot(9, 7)),
    circleStrokeColor: _hex(KnzColors.surface),
    circleStrokeWidth: 2,
  );

  /// Gold flags for visited places.
  @visibleForTesting
  static const flagsLayer = SymbolLayerProperties(
    iconImage: 'marker-flag',
    iconSize: 0.5,
    iconAnchor: 'bottom',
    iconAllowOverlap: true,
    iconIgnorePlacement: true,
  );

  /// [guessed] for guessed places, [other] for the rest.
  static List<Object> _guessedOrNot(Object guessed, Object other) => [
    'match',
    _marker,
    PlaceMarker.guessed.name,
    guessed,
    other,
  ];

  /// A value that grows linearly with the zoom from [low] at zoom 8 to
  /// [high] at zoom 13.
  static List<Object> _byZoom(Object low, Object high) => [
    'interpolate',
    ['linear'],
    ['zoom'],
    8,
    low,
    13,
    high,
  ];

  /// `#rrggbb` of a token, for the map style.
  static String _hex(Color color) =>
      '#${(color.toARGB32() & 0xFFFFFF).toRadixString(16).padLeft(6, '0')}';

  /// The zoom at which [bounds] just fit [size] with [padding] around them,
  /// for MapLibre's 512 px tiles in Web Mercator.
  static double fitZoom(LatLngBounds bounds, Size size, {double padding = 0}) {
    final width = math.max(size.width - 2 * padding, 1.0);
    final height = math.max(size.height - 2 * padding, 1.0);
    final lonSpan = bounds.northeast.longitude - bounds.southwest.longitude;
    final ySpan =
        _mercatorY(bounds.northeast.latitude) -
        _mercatorY(bounds.southwest.latitude);
    double log2(double x) => math.log(x) / math.ln2;
    return math.min(
      log2(width * 360 / (512 * lonSpan)),
      log2(height * 2 * math.pi / (512 * ySpan)),
    );
  }

  /// The centre of [bounds] on the Mercator map.
  static LatLng centre(LatLngBounds bounds) {
    final y =
        (_mercatorY(bounds.northeast.latitude) +
            _mercatorY(bounds.southwest.latitude)) /
        2;
    return LatLng(
      (2 * math.atan(math.exp(y)) - math.pi / 2) * 180 / math.pi,
      (bounds.northeast.longitude + bounds.southwest.longitude) / 2,
    );
  }

  static double _mercatorY(double latitude) =>
      math.log(math.tan(math.pi / 4 + latitude * math.pi / 360));

  @override
  State<PlacesMap> createState() => _PlacesMapState();
}

class _PlacesMapState extends State<PlacesMap> {
  MapLibreMapController? _controller;
  bool _ready = false;

  /// The zoom at which the whole region fits; also the minimum zoom.
  double _fitZoom = 0;
  double? _zoom;

  /// The size of the map frame, for hit-testing taps.
  Size _size = Size.zero;

  /// Zoomed in past the whole region, so a drag may pan.
  bool get _zoomedIn => (_zoom ?? _fitZoom) > _fitZoom + 0.01;

  void _onCameraIdle() {
    final camera = _controller?.cameraPosition;
    if (camera == null || !mounted) return;
    setState(() => _zoom = camera.zoom);
    // Back at the whole region: put it in the middle again after a pan.
    if (!_zoomedIn) {
      final centre = PlacesMap.centre(PlacesMap.regionBounds);
      final off =
          (camera.target.latitude - centre.latitude).abs() > 1e-4 ||
          (camera.target.longitude - centre.longitude).abs() > 1e-4;
      if (off) {
        _controller?.animateCamera(
          CameraUpdate.newLatLngZoom(centre, _fitZoom),
        );
      }
    }
  }

  void _zoomBy(CameraUpdate update) => _controller?.animateCamera(update);

  @override
  void didUpdateWidget(PlacesMap old) {
    super.didUpdateWidget(old);
    if (_ready && !identical(old.places, widget.places)) {
      _controller?.setGeoJsonSource(PlacesMap._sourceId, _features());
    }
  }

  Future<void> _onStyleLoaded() async {
    final controller = _controller;
    if (controller == null || !mounted) return;
    await controller.addGeoJsonSource(PlacesMap._sourceId, _features());
    await controller.addCircleLayer(
      PlacesMap._sourceId,
      'my-map-dots',
      PlacesMap.dotsLayer,
      filter: ['!=', PlacesMap._marker, PlaceMarker.visited.name],
      // Taps are hit-tested in _onMapClick, with a finger-sized radius.
      enableInteraction: false,
    );
    await controller.addSymbolLayer(
      PlacesMap._sourceId,
      'my-map-flags',
      PlacesMap.flagsLayer,
      filter: ['==', PlacesMap._marker, PlaceMarker.visited.name],
      enableInteraction: false,
    );
    if (mounted) _ready = true;
  }

  /// Finds the place under the tap. The tap's map position is projected
  /// back to the frame, because the tap point MapLibre reports is in
  /// physical pixels on some platforms and logical ones on others.
  void _onMapClick(math.Point<double> point, LatLng coordinates) {
    final camera = _controller?.cameraPosition;
    if (camera == null || _size.isEmpty) return;
    final projection = MapProjection(
      target: camera.target,
      zoom: camera.zoom,
      size: _size,
    );
    final place = PlacesMap.placeAt(
      projection.toScreen(coordinates),
      widget.places,
      projection,
    );
    if (place != null) widget.onPlaceTap?.call(place);
  }

  Map<String, dynamic> _features() => {
    'type': 'FeatureCollection',
    'features': [
      for (final place in widget.places)
        {
          'type': 'Feature',
          'id': place.id,
          'properties': {'marker': place.marker.name},
          'geometry': {
            'type': 'Point',
            'coordinates': [place.longitude, place.latitude],
          },
        },
    ],
  };

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final config = widget.config;
        _size = constraints.biggest;
        _fitZoom = PlacesMap.fitZoom(
          PlacesMap.regionBounds,
          constraints.biggest,
          padding: PlacesMap.regionPadding,
        ).clamp(config.minZoom, config.maxZoom);
        // Zoomed in as far as the map goes, so that a place can be found
        // street by street.
        final maxZoom = config.maxZoom;
        final zoom = _zoom ?? _fitZoom;
        return Stack(
          children: [
            GameMap(
              config: config.copyWith(
                initialCamera: CameraPosition(
                  target: PlacesMap.centre(PlacesMap.regionBounds),
                  zoom: _fitZoom,
                ),
                minZoom: _fitZoom,
                maxZoom: maxZoom,
              ),
              onMapCreated: (controller) => _controller = controller,
              onMapClick: _onMapClick,
              onStyleLoaded: _onStyleLoaded,
              onCameraIdle: _onCameraIdle,
              // Zoomed in, a drag on the map pans it; fully zoomed out, it
              // scrolls the profile page. Two fingers zoom either way.
              inScrollView: true,
              scrollGesturesEnabled: _zoomedIn,
              // Scrolling the page must not zoom the map; the zoom buttons
              // do that.
              webWheelZoomEnabled: false,
            ),
            Positioned(
              top: KnzSpace.s10,
              right: KnzSpace.s10,
              child: MapZoomButtons(
                onZoomIn: zoom < maxZoom - 0.01
                    ? () => _zoomBy(CameraUpdate.zoomIn())
                    : null,
                onZoomOut: _zoomedIn
                    ? () => _zoomBy(CameraUpdate.zoomOut())
                    : null,
              ),
            ),
          ],
        );
      },
    );
  }
}
