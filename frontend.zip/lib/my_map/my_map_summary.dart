import '../home/home_summary.dart';
import 'my_map_place.dart';

/// The filter above the map (`07 My map`).
enum MyMapFilter {
  all('Vše'),
  unknown('Neobjevené'),
  guessed('Uhodnuté'),
  visited('Navštívené');

  const MyMapFilter(this.label);

  final String label;

  bool includes(MyMapPlace place) => switch (this) {
    all => true,
    unknown => place.isUnknown,
    guessed => place.isGuessed,
    visited => place.isVisited,
  };
}

/// The counts and area progress that my map shows.
///
/// Guessed and visited are independent: a place that is both counts in both.
/// "Neobjeveno" counts the places that are neither.
class MyMapSummary {
  const MyMapSummary({
    required this.guessed,
    required this.visited,
    required this.unknown,
    required this.areas,
  });

  factory MyMapSummary.of(List<MyMapPlace> places) {
    var guessed = 0;
    var visited = 0;
    var unknown = 0;
    final known = {for (final area in Area.values) area: 0};
    final total = {for (final area in Area.values) area: 0};
    var anyArea = false;
    for (final place in places) {
      if (place.isGuessed) guessed++;
      if (place.isVisited) visited++;
      if (place.isUnknown) unknown++;
      final area = place.area;
      if (area == null) continue;
      anyArea = true;
      total[area] = total[area]! + 1;
      if (!place.isUnknown) known[area] = known[area]! + 1;
    }
    return MyMapSummary(
      guessed: guessed,
      visited: visited,
      unknown: unknown,
      areas: anyArea
          ? [
              for (final area in Area.values)
                AreaProgress(
                  area: area,
                  known: known[area]!,
                  total: total[area],
                ),
            ]
          : const [],
    );
  }

  final int guessed;
  final int visited;
  final int unknown;

  /// Guessed or visited places out of all places, per area, counted over
  /// the places whose area is known. Empty while the backend sends no
  /// district for any place; the UI then shows no area progress rather
  /// than invented zeros.
  final List<AreaProgress> areas;

  /// Whether any place has a known area, so that [areas] means something.
  bool get hasAreas => areas.isNotEmpty;
}
