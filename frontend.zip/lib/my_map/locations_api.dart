import 'package:http/http.dart' as http;

import '../api/authorized_client.dart';
import '../progress/revealed_place.dart';
import 'my_map_place.dart';

enum LocationsErrorKind {
  /// No session, or the backend rejected the JWT for good.
  unauthorized,

  /// No connection, or the backend did not answer in time.
  network,

  /// The place does not exist (404 `not.found.location`).
  notFound,

  /// The player has neither guessed nor visited the place, so the backend
  /// keeps its texts (403 `location.in_fog`).
  inFog,

  /// The backend failed or sent something that is not a place.
  server,
}

class LocationsApiException implements Exception {
  const LocationsApiException(this.kind);

  final LocationsErrorKind kind;

  @override
  String toString() => 'LocationsApiException($kind)';
}

/// The locations endpoints of the Game API (API_SPECIFICATION.md 4):
/// my map and the player's progress on a place.
///
/// Only the profile and the place card call it. The round screen never
/// does: the list carries the names and coordinates of every place
/// (FRONTEND_API_GUIDE, "Load the player's map").
class LocationsApi {
  LocationsApi({required this._client});

  final AuthorizedClient _client;

  /// Every place in the region with the player's progress on it
  /// (`GET /locations`).
  Future<List<MyMapPlace>> list() async {
    final response = await _send(() => _client.get('locations'));
    try {
      return [
        for (final place in jsonBody(response)['locations'] as List)
          MyMapPlace.fromJson(place as Map<String, dynamic>),
      ];
    } on Object {
      throw const LocationsApiException(LocationsErrorKind.server);
    }
  }

  /// Records a visit of the place (`POST /locations/{id}/progress`). The
  /// backend sets the time and does not check the position, so the caller
  /// must have checked the visit radius first. Idempotent. Returns the place
  /// and the wafers the visit earned: 50 the first time, then 0.
  Future<({MyMapPlace place, int wafersEarned})> markVisited(
    int placeId,
  ) async {
    final response = await _send(
      () => _client.post('locations/$placeId/progress', {'state': 'visited'}),
    );
    try {
      final body = jsonBody(response);
      return (
        place: MyMapPlace.fromJson(body['location'] as Map<String, dynamic>),
        wafersEarned: (body['wafers_earned'] as num?)?.toInt() ?? 0,
      );
    } on Object {
      throw const LocationsApiException(LocationsErrorKind.server);
    }
  }

  /// The description, category and data source of a place the player has
  /// guessed or visited (`GET /locations/{id}/description`), in the shape of
  /// the card after a hit. A place in the fog throws [LocationsErrorKind.inFog].
  Future<RevealedPlace> description(int placeId) async {
    final response = await _send(
      () => _client.get('locations/$placeId/description'),
      // Here 403 is the fog, not a rejected session.
      forbidden: LocationsErrorKind.inFog,
    );
    try {
      return RevealedPlace.fromJson(
        jsonBody(response)['location'] as Map<String, dynamic>,
      );
    } on Object {
      throw const LocationsApiException(LocationsErrorKind.server);
    }
  }

  /// Rates a visited place with 1–5 [stars], replacing the player's
  /// earlier rating (`PUT /locations/{id}/rating`). The backend refuses a
  /// place the player has not visited (422 `location.not_visited`).
  Future<MyMapPlace> rate(int placeId, int stars) async {
    final response = await _send(
      () => _client.put('locations/$placeId/rating', {'rating': stars}),
    );
    try {
      return MyMapPlace.fromJson(
        jsonBody(response)['location'] as Map<String, dynamic>,
      );
    } on Object {
      throw const LocationsApiException(LocationsErrorKind.server);
    }
  }

  /// Sends a request and turns everything but a success into a
  /// [LocationsApiException].
  Future<http.Response> _send(
    Future<http.Response> Function() request, {
    LocationsErrorKind forbidden = LocationsErrorKind.unauthorized,
  }) async {
    final http.Response response;
    try {
      response = await request();
    } on ApiTransportException catch (e) {
      throw LocationsApiException(switch (e.error) {
        ApiTransportError.unauthorized => LocationsErrorKind.unauthorized,
        ApiTransportError.network ||
        ApiTransportError.timeout => LocationsErrorKind.network,
      });
    }
    final status = response.statusCode;
    if (status >= 200 && status < 300) return response;
    throw LocationsApiException(switch (status) {
      401 => LocationsErrorKind.unauthorized,
      403 => forbidden,
      404 => LocationsErrorKind.notFound,
      _ => LocationsErrorKind.server,
    });
  }
}
