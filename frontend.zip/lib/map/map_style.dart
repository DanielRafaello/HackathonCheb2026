import 'dart:convert';

import '../config/map_config.dart';

/// The MapLibre style of the game map.
///
/// The style draws only the layers that the tile set from `tools/map`
/// contains: the region, the mask around it, forests, reservoirs, rivers,
/// the main roads, the cities, high peaks, and the mountain range names. Keep it in step
/// with the draft in `tools/map/preview/index.html`, which is the same style
/// in JavaScript.
abstract final class GameMapStyle {
  /// The id of the vector source. Layers refer to it by this name.
  static const sourceId = 'kvk';

  /// The source layers of the tile set, see `tools/map/README.md`.
  static const sourceLayers = [
    'region',
    'border',
    'mask',
    'place',
    'waterway',
    'road',
    'water',
    'wood',
    'peak',
    'landform',
    'country',
  ];

  static const attribution = '© OpenStreetMap contributors';

  /// The images the style refers to by `icon-image`, with the asset that
  /// holds each one. [GameMap] adds them to the map once the style has
  /// loaded. The 2.0x assets are used and drawn at `icon-size` 0.5, so the
  /// icons stay sharp on dense screens. Sources: `tools/map/icons/`.
  static const icons = {
    'mountain': 'assets/map/2.0x/mountain.png',
    'mountain-snow': 'assets/map/2.0x/mountain-snow.png',
    'marker-flag': 'assets/map/2.0x/marker-flag.png',
    'marker-guess': 'assets/map/2.0x/marker-guess.png',
    'marker-guess-missed': 'assets/map/2.0x/marker-guess-missed.png',
  };

  static const _background = '#e7ebf3';
  static const _regionFill = '#dcecc8';

  /// The style as a JSON document, ready for `MapLibreMap.styleString`.
  ///
  /// [tilesUrl] is the `pmtiles://` URL of the archive that `MapTiles.load`
  /// returns.
  static String json(MapConfig config, {required String tilesUrl}) =>
      jsonEncode(document(config, tilesUrl: tilesUrl));

  /// The style as a JSON object.
  static Map<String, Object?> document(
    MapConfig config, {
    required String tilesUrl,
  }) => {
    'version': 8,
    'name': 'kde-na-zapade',
    'glyphs': config.glyphsUrl,
    'sources': {
      sourceId: {'type': 'vector', 'url': tilesUrl, 'attribution': attribution},
    },
    'layers': [
      {
        'id': 'background',
        'type': 'background',
        'paint': {'background-color': _background},
      },
      // The outline and its shadow are drawn from the "border" line, not
      // from the polygon: a clipped polygon's ring runs along tile edges.
      // A translated fill would show seams at tile edges; an offset outline
      // under the fill gives the same drop shadow without them.
      _layer('region-shadow', 'line', 'border', {
        'layout': {'line-join': 'round', 'line-cap': 'round'},
        'paint': {
          'line-color': '#a9c48b',
          'line-translate': [4, 7],
          'line-width': _byZoom({7: 10, 12: 18}),
        },
      }),
      // No antialiasing: it draws hairlines along tile edges of big polygons.
      _layer('region', 'fill', 'region', {
        'paint': {'fill-color': _regionFill, 'fill-antialias': false},
      }),
      // The forest blobs are circle polygons in the data, so they scale
      // with the map.
      _layer('wood', 'fill', 'wood', {
        'paint': {
          'fill-color': '#c3dfa9',
          'fill-opacity': 0.9,
          'fill-antialias': false,
        },
      }),
      _layer('water', 'fill', 'water', {
        'paint': {'fill-color': '#8fcbe8'},
      }),
      _layer('waterway', 'line', 'waterway', {
        'layout': {'line-cap': 'round', 'line-join': 'round'},
        'paint': {
          'line-color': '#8fcbe8',
          'line-width': _byZoom({7: 3, 10: 6, 14: 14}),
        },
      }),
      // Main roads: a white line on a darker casing, the motorway (D…)
      // wider than the class I roads.
      _layer('road-casing', 'line', 'road', {
        'layout': {'line-cap': 'round', 'line-join': 'round'},
        'paint': {
          'line-color': '#b4c39c',
          'line-width': _byRoad({7: (3.5, 2.5), 14: (12, 9)}),
        },
      }),
      _layer('road', 'line', 'road', {
        'layout': {'line-cap': 'round', 'line-join': 'round'},
        'paint': {
          'line-color': '#ffffff',
          'line-width': _byRoad({7: (2, 1.25), 14: (8, 6)}),
        },
      }),
      // Hides anything that sticks out of the region.
      _layer('mask', 'fill', 'mask', {
        'paint': {'fill-color': _background, 'fill-antialias': false},
      }),
      _layer('region-outline', 'line', 'border', {
        'layout': {'line-join': 'round', 'line-cap': 'round'},
        'paint': {
          'line-color': '#86b25e',
          'line-width': _byZoom({7: 4, 12: 8}),
        },
      }),
      // Mountains: the few highest peaks (build_tiles.sh picks them). They
      // are always shown and grow with the zoom; nothing pops in or out.
      _layer('peak', 'symbol', 'peak', {
        'layout': {
          'icon-image': [
            'case',
            [
              '>=',
              [
                'to-number',
                ['get', 'ele'],
              ],
              1100,
            ],
            'mountain-snow',
            'mountain',
          ],
          'icon-size': _byZoom({7: 0.3, 9: 0.5, 12: 1, 14: 1.5}),
          'icon-anchor': 'bottom',
          'icon-allow-overlap': true,
          'icon-ignore-placement': true,
          'text-field': [
            'step',
            ['zoom'],
            '',
            10,
            ['get', 'name'],
          ],
          'text-font': ['Open Sans Italic'],
          'text-size': 11,
          'text-anchor': 'top',
          'text-offset': [0, 0.2],
          'text-optional': true,
        },
        'paint': {
          'text-color': '#8aa86b',
          'text-halo-color': _regionFill,
          'text-halo-width': 1.5,
        },
      }),
      _layer('place', 'circle', 'place', {
        'paint': {
          'circle-radius': _byClass(city: 9, town: 7),
          'circle-color': '#ffffff',
          'circle-stroke-color': '#3b4256',
          'circle-stroke-width': 3,
        },
      }),
      // Colliding labels: MapLibre places the last layer first, so a later
      // layer wins over an earlier one, and within a layer the lower
      // symbol-sort-key wins. The mountain range names come first (they
      // yield), then the city and town labels, where the city wins.
      _layer('landform-label', 'symbol', 'landform', {
        'layout': {
          'text-field': ['get', 'name'],
          'text-font': ['Open Sans Italic'],
          'text-size': 15,
          'text-letter-spacing': 0.05,
        },
        'paint': {
          'text-color': '#8aa86b',
          'text-halo-color': _regionFill,
          'text-halo-width': 1.5,
        },
      }),
      _layer('place-label', 'symbol', 'place', {
        'layout': {
          'text-field': ['get', 'name'],
          'text-font': ['Open Sans Bold'],
          'text-size': _byClass(city: 18, town: 16),
          'text-anchor': 'left',
          'text-offset': [0.9, 0],
          'symbol-sort-key': _byClass(city: 0, town: 1),
        },
        'paint': {
          'text-color': '#3b4256',
          'text-halo-color': '#ffffff',
          'text-halo-width': 2,
        },
      }),
      // The neighbouring country, outside the region; always shown.
      _layer('country-label', 'symbol', 'country', {
        'layout': {
          'text-field': ['get', 'name'],
          'text-font': ['Open Sans Bold'],
          'text-size': 16,
          'text-transform': 'uppercase',
          'text-letter-spacing': 0.3,
          'text-allow-overlap': true,
          'text-ignore-placement': true,
        },
        'paint': {
          'text-color': '#9aa3b8',
          'text-halo-color': _background,
          'text-halo-width': 1,
        },
      }),
    ],
  };

  static Map<String, Object?> _layer(
    String id,
    String type,
    String sourceLayer,
    Map<String, Object?> properties,
  ) => {
    'id': id,
    'type': type,
    'source': sourceId,
    'source-layer': sourceLayer,
    ...properties,
  };

  /// A value that grows linearly with the zoom between the given stops.
  static List<Object?> _byZoom(Map<int, num> stops) => [
    'interpolate',
    ['linear'],
    ['zoom'],
    for (final stop in stops.entries) ...[stop.key, stop.value],
  ];

  /// A value that grows with the zoom, with one stop value for the
  /// motorway and one for the class I roads. A motorway's ref starts with
  /// "D" (D6); class I roads are plain numbers.
  static List<Object?> _byRoad(Map<int, (num, num)> stops) => [
    'interpolate',
    ['linear'],
    ['zoom'],
    for (final MapEntry(key: zoom, value: (motorway, road))
        in stops.entries) ...[
      zoom,
      [
        'case',
        [
          '==',
          [
            'slice',
            ['get', 'ref'],
            0,
            1,
          ],
          'D',
        ],
        motorway,
        road,
      ],
    ],
  ];

  /// A value for a city and another one for a town.
  static List<Object?> _byClass({required num city, required num town}) => [
    'match',
    ['get', 'class'],
    'city',
    city,
    town,
  ];
}
