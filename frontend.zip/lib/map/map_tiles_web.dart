import 'dart:js_interop';
import 'dart:js_interop_unsafe';

import 'package:flutter/services.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import 'package:web/web.dart' as web;

/// `maplibregl.addProtocol`, on the global that the plugin publishes once
/// [MapLibreMap.ensureWebLibraryLoaded] completes.
@JS('maplibregl.addProtocol')
external void _addProtocol(JSString scheme, JSFunction handler);

/// The `pmtiles` ES module. Pinned, as the plugin pins maplibre-gl-js.
const _pmTilesModuleUrl = 'https://unpkg.com/pmtiles@3.2.1/dist/index.js';

/// The `pmtiles` module and the protocol instance registered with MapLibre.
typedef _PmTiles = ({JSObject module, JSObject protocol});

/// Web: loads the archive from the asset bundle into memory and registers
/// it with the `pmtiles` protocol of MapLibre GL JS.
///
/// The protocol finds an archive by the key of its source. A `FileSource`
/// uses the file name as the key, so the style names the archive as
/// `pmtiles://<file name>` and no request reaches a tile server.
abstract final class MapTiles {
  static Future<_PmTiles>? _pmTiles;
  static final _loaded = <String, Future<String>>{};

  static Future<String> load(String asset) =>
      _loaded[asset] ??= _load(asset).catchError((Object error) {
        // Let the next map build retry after a failed download.
        _loaded.remove(asset);
        throw error;
      });

  static Future<String> _load(String asset) async {
    final pmTiles = await (_pmTiles ??= _registerProtocol());
    final data = await rootBundle.load(asset);
    final bytes = data.buffer.asUint8List(
      data.offsetInBytes,
      data.lengthInBytes,
    );
    final name = asset.split('/').last;
    final file = web.File(<JSAny>[bytes.toJS].toJS, name);
    final source = pmTiles.module
        .getProperty<JSFunction>('FileSource'.toJS)
        .callAsConstructor<JSObject>(file);
    final archive = pmTiles.module
        .getProperty<JSFunction>('PMTiles'.toJS)
        .callAsConstructor<JSObject>(source);
    pmTiles.protocol.callMethod<JSAny?>('add'.toJS, archive);
    return 'pmtiles://$name';
  }

  static Future<_PmTiles> _registerProtocol() async {
    try {
      await MapLibreMap.ensureWebLibraryLoaded();
      final module = await importModule(_pmTilesModuleUrl.toJS).toDart;
      final protocol = module
          .getProperty<JSFunction>('Protocol'.toJS)
          .callAsConstructor<JSObject>();
      _addProtocol(
        'pmtiles'.toJS,
        protocol.getProperty<JSFunction>('tile'.toJS),
      );
      return (module: module, protocol: protocol);
    } catch (_) {
      _pmTiles = null;
      rethrow;
    }
  }
}
