import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:maplibre_gl/maplibre_gl.dart';

import '../config/map_config.dart';
import 'map_gestures.dart';
import 'map_style.dart';
import 'map_tiles.dart';
import 'touch_input.dart';

/// The game map: a MapLibre map of the region. The OpenStreetMap
/// attribution is behind MapLibre's info button.
class GameMap extends StatefulWidget {
  const GameMap({
    super.key,
    required this.config,
    this.onMapCreated,
    this.onStyleLoaded,
    this.onMapClick,
    this.inScrollView = false,
    this.scrollGesturesEnabled = true,
    this.webWheelZoomEnabled = true,
    this.onCameraIdle,
  });

  final MapConfig config;
  final MapCreatedCallback? onMapCreated;
  final OnStyleLoadedCallback? onStyleLoaded;
  final OnMapClickCallback? onMapClick;

  /// Whether the map sits in a scrolling page. A drag that starts on the
  /// map then pans the map while [scrollGesturesEnabled] is on and scrolls
  /// the page while it is off; two fingers always zoom the map
  /// ([MapGestureRecognizer]).
  final bool inScrollView;

  /// Whether a drag pans the map.
  final bool scrollGesturesEnabled;

  /// Whether the mouse wheel or a trackpad scroll zooms the map on the web.
  /// Turn it off for a map inside a scrolling page, or scrolling the page
  /// zooms the map under the pointer. MapLibre's web plugin ties it to pinch
  /// zoom, so off also stops pinch zoom in a desktop browser; double-click
  /// zoom stays. A touch-first browser has no wheel and keeps pinch zoom.
  final bool webWheelZoomEnabled;

  /// Called when the camera stops moving; read the camera from the
  /// controller's `cameraPosition`.
  final OnCameraIdleCallback? onCameraIdle;

  @override
  State<GameMap> createState() => _GameMapState();
}

class _GameMapState extends State<GameMap> {
  /// The `pmtiles://` URL of the bundled archive, once MapLibre can read it.
  late final Future<String> _tilesUrl = MapTiles.load(widget.config.tilesAsset)
      .catchError((Object error) {
        debugPrint('Game map unavailable: $error');
        throw error;
      });
  MapLibreMapController? _controller;

  void _onMapCreated(MapLibreMapController controller) {
    _controller = controller;
    widget.onMapCreated?.call(controller);
  }

  /// Adds the style's icons, then tells the owner that the style is ready.
  Future<void> _onStyleLoaded() async {
    final controller = _controller;
    if (controller != null) {
      for (final icon in GameMapStyle.icons.entries) {
        final bytes = await rootBundle.load(icon.value);
        await controller.addImage(icon.key, bytes.buffer.asUint8List());
      }
    }
    widget.onStyleLoaded?.call();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: _tilesUrl,
      builder: (context, snapshot) => switch (snapshot) {
        AsyncSnapshot(hasError: true) => const _MapUnavailable(),
        AsyncSnapshot(hasData: true, :final data!) => _map(data),
        _ => const SizedBox.shrink(),
      },
    );
  }

  /// The touch policy of a map in a scrolling page. It reads the widget at
  /// each finger down: a platform view keeps its first recognizer.
  late final _gestures = Factory<MapGestureRecognizer>(
    () => MapGestureRecognizer(
      pans: () => widget.scrollGesturesEnabled,
      debugOwner: this,
    ),
  );

  Widget _map(String tilesUrl) {
    final map = _mapLibre(tilesUrl);
    if (!kIsWeb || !widget.inScrollView) return map;
    // In the browser the map is an HTML element that sees every touch on
    // it, and Flutter sees the same touches; the platform view takes no
    // recognizers. Claiming a touch here keeps the page from scrolling
    // while MapLibre pans or zooms.
    return RawGestureDetector(
      gestures: {
        MapGestureRecognizer:
            GestureRecognizerFactoryWithHandlers<MapGestureRecognizer>(
              _gestures.constructor,
              (_) {},
            ),
      },
      child: map,
    );
  }

  Widget _mapLibre(String tilesUrl) {
    final config = widget.config;
    return MapLibreMap(
      styleString: GameMapStyle.json(config, tilesUrl: tilesUrl),
      initialCameraPosition: config.initialCamera,
      cameraTargetBounds: CameraTargetBounds(config.cameraBounds),
      minMaxZoomPreference: MinMaxZoomPreference(
        config.minZoom,
        config.maxZoom,
      ),
      // The game has no use for a tilted or rotated map.
      rotateGesturesEnabled: false,
      tiltGesturesEnabled: false,
      compassEnabled: false,
      // The style's source carries "© OpenStreetMap contributors"; MapLibre
      // shows it behind this info button. Zoom buttons take the top right.
      attributionButtonPosition: AttributionButtonPosition.bottomRight,
      scrollGesturesEnabled: widget.scrollGesturesEnabled,
      zoomGesturesEnabled:
          !kIsWeb || widget.webWheelZoomEnabled || TouchInput.isPrimary,
      doubleClickZoomEnabled: true,
      trackCameraPosition: widget.onCameraIdle != null,
      onCameraIdle: widget.onCameraIdle,
      onMapCreated: _onMapCreated,
      onStyleLoadedCallback: _onStyleLoaded,
      onMapClick: widget.onMapClick,
      // Native maps are platform views that get only the touches their
      // recognizers win in Flutter's gesture arena.
      gestureRecognizers: widget.inScrollView ? {_gestures} : null,
    );
  }
}

/// Shown when the map library or the tiles could not be loaded, for example
/// offline on the web.
class _MapUnavailable extends StatelessWidget {
  const _MapUnavailable();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Mapu se nepodařilo načíst. Zkontrolujte připojení k internetu.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
