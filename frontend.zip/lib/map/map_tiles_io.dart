import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

/// Android and iOS: copies the archive out of the asset bundle into the
/// app's cache directory, where MapLibre Native opens it as a file.
abstract final class MapTiles {
  static final _loaded = <String, Future<String>>{};

  static Future<String> load(String asset) =>
      _loaded[asset] ??= _copy(asset).catchError((Object error) {
        // Let the next map build retry.
        _loaded.remove(asset);
        throw error;
      });

  static Future<String> _copy(String asset) async {
    final data = await rootBundle.load(asset);
    final directory = await getApplicationCacheDirectory();
    final file = File('${directory.path}/${asset.split('/').last}');
    // Written on every start, so an app update always brings its own tiles.
    // The rename keeps a half-written file away from MapLibre.
    final partial = File('${file.path}.partial');
    await partial.writeAsBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      flush: true,
    );
    await partial.rename(file.path);
    return 'pmtiles://file://${file.path}';
  }
}
