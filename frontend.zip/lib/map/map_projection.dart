import 'dart:math' as math;
import 'dart:ui';

import 'package:maplibre_gl/maplibre_gl.dart';

/// Converts between positions and points in a north-up map frame, the way
/// MapLibre draws it (Web Mercator, 512 px tiles), with the camera target
/// in the middle of the frame.
class MapProjection {
  const MapProjection({
    required this.target,
    required this.zoom,
    required this.size,
  });

  final LatLng target;
  final double zoom;

  /// The size of the map frame in logical pixels.
  final Size size;

  static const _tileSize = 512.0;

  double get _worldSize => _tileSize * math.pow(2, zoom);

  /// The point of [position] in the frame.
  Offset toScreen(LatLng position) =>
      size.center(Offset.zero) + _toWorld(position) - _toWorld(target);

  /// The position under [point] in the frame.
  LatLng toPosition(Offset point) =>
      _fromWorld(_toWorld(target) + point - size.center(Offset.zero));

  Offset _toWorld(LatLng position) {
    final sin = math.sin(position.latitude * math.pi / 180);
    return Offset(
          (position.longitude + 180) / 360,
          0.5 - math.log((1 + sin) / (1 - sin)) / (4 * math.pi),
        ) *
        _worldSize;
  }

  LatLng _fromWorld(Offset point) {
    final x = point.dx / _worldSize;
    final y = point.dy / _worldSize;
    return LatLng(
      90 - 360 * math.atan(math.exp((y - 0.5) * 2 * math.pi)) / math.pi,
      x * 360 - 180,
    );
  }
}
