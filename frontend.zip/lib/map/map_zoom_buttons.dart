import 'package:flutter/widgets.dart';
import 'package:pointer_interceptor/pointer_interceptor.dart';

import '../design_system/design_system.dart';

/// "+" and "−" in a white column (`components.md`, MapFrame: Zoom).
class MapZoomButtons extends StatelessWidget {
  const MapZoomButtons({
    super.key,
    required this.onZoomIn,
    required this.onZoomOut,
  });

  final VoidCallback? onZoomIn;
  final VoidCallback? onZoomOut;

  static const _size = 40.0;

  @override
  Widget build(BuildContext context) {
    // On the web the map is an HTML element that would take the taps.
    return PointerInterceptor(
      child: Container(
        decoration: BoxDecoration(
          color: KnzColors.surface,
          border: Border.all(
            color: KnzColors.borderStrong,
            width: KnzDepth.border,
          ),
          borderRadius: BorderRadius.circular(KnzRadius.sm),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _button('+', 'Přiblížit', onZoomIn),
            Container(
              width: _size,
              height: KnzDepth.border,
              color: KnzColors.borderStrong,
            ),
            _button('−', 'Oddálit', onZoomOut),
          ],
        ),
      ),
    );
  }

  Widget _button(String symbol, String label, VoidCallback? onPressed) =>
      KnzPressable(
        onPressed: onPressed,
        semanticLabel: label,
        builder: (context, state) => Container(
          width: _size,
          height: _size,
          alignment: Alignment.center,
          color: state.hovered || state.pressed
              ? KnzColors.surfaceSubtle
              : null,
          child: Text(
            symbol,
            style: KnzText.titleMd.copyWith(
              height: 1,
              color: state.enabled
                  ? KnzColors.textSecondary
                  : KnzColors.textDisabled,
            ),
          ),
        ),
      );
}
