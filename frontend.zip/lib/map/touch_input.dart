/// Whether the device's main input is a finger rather than a mouse.
///
/// - Android, iOS: always.
/// - Web: when the browser reports a coarse primary pointer, as on phones
///   and tablets.
library;

export 'touch_input_io.dart'
    if (dart.library.js_interop) 'touch_input_web.dart';
