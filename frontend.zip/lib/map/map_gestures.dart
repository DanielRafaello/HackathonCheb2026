import 'package:flutter/gestures.dart';

/// Shares the touches on a map inside a scrolling page between the map and
/// the page.
///
/// It claims a touch for the map when the map pans ([pans] returns true) or
/// as soon as a second finger lands, so two fingers always zoom the map. A
/// one-finger drag on a map that does not pan stays undecided, so the
/// page's drag wins it and the page scrolls. A tap stays undecided too, and
/// the gesture arena gives it to the map once the page's drag gives up.
///
/// A touch that starts outside the map never reaches it, so a page scroll
/// that carries the finger onto the map does not move the map.
class MapGestureRecognizer extends OneSequenceGestureRecognizer {
  MapGestureRecognizer({required this.pans, super.debugOwner});

  /// Whether a one-finger drag pans the map, read at each finger down.
  final bool Function() pans;

  final _fingers = <int>{};

  @override
  void addAllowedPointer(PointerDownEvent event) {
    super.addAllowedPointer(event);
    _fingers.add(event.pointer);
    if (pans() || _fingers.length > 1) resolve(GestureDisposition.accepted);
  }

  @override
  void handleEvent(PointerEvent event) {
    if (event is PointerUpEvent || event is PointerCancelEvent) {
      _release(event.pointer);
    }
  }

  @override
  void rejectGesture(int pointer) => _release(pointer);

  void _release(int pointer) {
    _fingers.remove(pointer);
    stopTrackingPointer(pointer);
  }

  @override
  void didStopTrackingLastPointer(int pointer) => _fingers.clear();

  @override
  String get debugDescription => 'map';
}
