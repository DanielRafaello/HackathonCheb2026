/// Makes the bundled PMTiles archive readable by MapLibre on every platform.
///
/// The archive ships as an app asset, so the map needs no tile server.
/// `MapTiles.load(asset)` returns the `pmtiles://` URL that the style names
/// as its vector source.
///
/// - Android, iOS: MapLibre Native reads PMTiles itself but cannot open a
///   Flutter asset, so the archive is copied to a file first.
/// - Web: MapLibre GL JS reads PMTiles through the `pmtiles` protocol
///   handler, which serves the archive from memory.
library;

export 'map_tiles_io.dart' if (dart.library.js_interop) 'map_tiles_web.dart';
