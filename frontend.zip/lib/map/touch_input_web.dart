import 'package:web/web.dart' as web;

/// Web: asks the browser whether the primary pointer is coarse (a finger).
abstract final class TouchInput {
  static final bool isPrimary = web.window
      .matchMedia('(pointer: coarse)')
      .matches;
}
