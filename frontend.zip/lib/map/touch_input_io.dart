/// Android and iOS: the app runs on touch screens.
abstract final class TouchInput {
  static const isPrimary = true;
}
