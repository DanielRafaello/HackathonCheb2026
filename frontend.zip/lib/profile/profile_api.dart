import '../api/authorized_client.dart';

/// The player's level from the points earned by guessing and visiting
/// (API_SPECIFICATION.md 3.2). The backend computes it; the client only
/// shows it.
class PlayerLevel {
  const PlayerLevel({
    required this.number,
    required this.points,
    required this.startsAt,
    required this.nextLevelAt,
    this.wafers = 0,
  });

  factory PlayerLevel.fromJson(Map<String, dynamic> json) {
    final level = json['level'] as Map<String, dynamic>;
    return PlayerLevel(
      number: (level['number'] as num).toInt(),
      points: ((json['points'] as Map<String, dynamic>)['total'] as num)
          .toInt(),
      startsAt: (level['starts_at'] as num).toInt(),
      nextLevelAt: (level['next_level_at'] as num).toInt(),
      wafers: (json['wafers'] as num?)?.toInt() ?? 0,
    );
  }

  /// The current level, starting at 1.
  final int number;

  /// All points earned.
  final int points;

  /// The total points at which this level began and the next one begins.
  final int startsAt;
  final int nextLevelAt;

  /// The wafer balance (oplatky), the game's currency. It comes with the
  /// level in `GET /me/profile`, but it is not part of it.
  final int wafers;

  int get pointsToNextLevel => nextLevelAt - points;

  /// The progress inside this level, from 0 to 1.
  double get progress {
    final span = nextLevelAt - startsAt;
    return span <= 0 ? 1 : (points - startsAt) / span;
  }
}

class ProfileApiException implements Exception {
  const ProfileApiException();

  @override
  String toString() => 'ProfileApiException';
}

/// The caller's profile (`GET /me/profile`).
class ProfileApi {
  ProfileApi({required this._client});

  final AuthorizedClient _client;

  /// Throws [ProfileApiException] on any failure.
  Future<PlayerLevel> level() async {
    try {
      final response = await _client.get('me/profile');
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw const ProfileApiException();
      }
      return PlayerLevel.fromJson(
        jsonBody(response)['profile'] as Map<String, dynamic>,
      );
    } on ProfileApiException {
      rethrow;
    } on Object {
      throw const ProfileApiException();
    }
  }
}
