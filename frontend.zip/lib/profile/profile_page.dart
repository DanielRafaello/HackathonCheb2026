import 'package:flutter/material.dart';

import '../account/account_api.dart';
import '../config/game_config.dart';
import '../design_system/design_system.dart';
import '../my_map/my_map_markers.dart';
import '../my_map/my_map_place.dart';
import '../my_map/my_map_summary.dart';
import 'badges.dart';
import 'profile_api.dart';

/// Profile (`07b Profil`): the account and level, a summary of the progress
/// that leads to my map, the badges, the player's ratings, progress per
/// area, and sign-out.
class ProfilePage extends StatefulWidget {
  const ProfilePage({
    super.key,
    required this.account,
    required this.load,
    required this.loadLevel,
    required this.onOpenMap,
    required this.onOpenPlace,
    required this.onSignIn,
    required this.onSignOut,
    this.config = GameConfig.defaults,
  });

  /// The signed-in account, or null for a guest. The Game API keeps progress
  /// only for an account, so a guest is asked to sign in.
  final Account? account;

  /// Loads the places with the player's progress (`GET /locations`).
  final Future<List<MyMapPlace>> Function() load;

  /// Loads the player's level (`GET /me/profile`).
  final Future<PlayerLevel> Function() loadLevel;

  /// Opens my map (the MAPA tab).
  final VoidCallback onOpenMap;

  /// Opens the place card of a rated place; completes when the card closes.
  /// The rating may have changed, so the profile loads again then.
  final Future<void> Function(MyMapPlace place) onOpenPlace;
  final GameConfig config;

  final VoidCallback onSignIn;
  final VoidCallback onSignOut;

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Future<List<MyMapPlace>>? _places;

  /// The last places loaded, shown while my map loads again.
  List<MyMapPlace> _shown = const [];

  /// The level, or null until it loads. A failure leaves the last one: the
  /// map's toast already says the connection failed.
  PlayerLevel? _level;

  @override
  void initState() {
    super.initState();
    if (widget.account != null) _loadAll();
  }

  void _loadAll() {
    _places = _load();
    _loadLevel();
  }

  Future<void> _loadLevel() async {
    final account = widget.account;
    try {
      final level = await widget.loadLevel();
      if (mounted && widget.account?.id == account?.id) {
        setState(() => _level = level);
      }
    } on Object {
      // Keep the last level, or none.
    }
  }

  @override
  void didUpdateWidget(ProfilePage old) {
    super.didUpdateWidget(old);
    if (widget.account?.id != old.account?.id) {
      _shown = const [];
      _level = null;
      _places = null;
      if (widget.account != null) _loadAll();
    }
  }

  /// Loads the places; a failure shows a toast over the zeros.
  Future<List<MyMapPlace>> _load() {
    final places = widget.load();
    places.then<void>(
      (loaded) {
        if (identical(_places, places)) _shown = loaded;
      },
      onError: (Object _) {
        if (!mounted) return;
        KnzToast.show(
          context,
          'Postup se nepodařilo načíst. Zkontroluj připojení.',
        );
      },
    );
    return places;
  }

  Future<void> _openPlace(MyMapPlace place) async {
    await widget.onOpenPlace(place);
    if (mounted && widget.account != null) {
      setState(() {
        _places = _load();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final places = _places;
    return ColoredBox(
      color: KnzColors.surface,
      child: SafeArea(
        bottom: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: places == null
                ? _scroll([
                    _Header(account: widget.account),
                    const SizedBox(height: KnzSpace.s20),
                    const KnzSpeechBubble(
                      mood: KnzMood.think,
                      text:
                          'Svoji mapu si zatím uložíš jen s účtem. '
                          'Přihlas se a uvidíš všechna místa kraje.',
                    ),
                    const SizedBox(height: KnzSpace.s20),
                    KnzButton(
                      label: 'Přihlásit se',
                      onPressed: widget.onSignIn,
                    ),
                  ])
                : FutureBuilder(
                    future: places,
                    // While loading again, the last places stay. On the
                    // first load, and when loading fails, everything shows
                    // zeros.
                    builder: (context, snapshot) => _content(
                      snapshot.hasError ? const [] : snapshot.data ?? _shown,
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  Widget _scroll(List<Widget> children) => ListView(
    padding: const EdgeInsets.fromLTRB(
      KnzSize.screenGutter,
      KnzSpace.s16,
      KnzSize.screenGutter,
      KnzSpace.s24,
    ),
    children: children,
  );

  Widget _content(List<MyMapPlace> places) {
    final summary = MyMapSummary.of(places);
    final badges = BadgeProgress.of(places);
    final earned = badges.where((b) => b.earned).length;
    return _scroll([
      _Header(account: widget.account),
      if (_level case final level?) ...[
        const SizedBox(height: KnzSpace.s16),
        _LevelCard(level: level),
        const SizedBox(height: KnzSpace.s12),
        _WaferBalance(wafers: level.wafers),
      ],
      const SizedBox(height: KnzSpace.s16),
      _SummaryPill(
        summary: summary,
        total: places.length,
        onOpenMap: widget.onOpenMap,
      ),
      const SizedBox(height: KnzSpace.s24),
      Semantics(
        header: true,
        child: Text.rich(
          TextSpan(
            text: 'Odznaky',
            children: [
              TextSpan(
                text: '  ${Czech.fraction(earned, badges.length)}',
                style: KnzText.bodyLg.copyWith(color: KnzColors.textMuted),
              ),
            ],
          ),
          style: KnzText.titleMd,
        ),
      ),
      const SizedBox(height: KnzSpace.s14),
      _BadgeGrid(badges: badges),
      const SizedBox(height: KnzSpace.s24),
      Semantics(
        header: true,
        child: Text('Tvoje hodnocení', style: KnzText.titleMd),
      ),
      const SizedBox(height: KnzSpace.s10),
      _Ratings(
        places: places,
        maxRating: widget.config.maxRating,
        onOpenPlace: _openPlace,
      ),
      // Progress per area only when the backend tells which area a place
      // is in; the counts above stand on their own.
      if (summary.hasAreas) ...[
        const SizedBox(height: KnzSpace.s24),
        Semantics(
          header: true,
          child: Text('Po oblastech', style: KnzText.titleMd),
        ),
        const SizedBox(height: KnzSpace.s10),
        for (final area in summary.areas)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: KnzSpace.s8),
            child: KnzProgressRow(
              label: area.area.label,
              count: area.known,
              total: area.total,
              sentiment: area.area.sentiment,
              height: KnzSpace.s12,
            ),
          ),
      ],
      const SizedBox(height: KnzSpace.s24),
      _signOutButton(),
    ]);
  }

  Widget _signOutButton() => KnzButton(
    label: 'Odhlásit se',
    icon: KnzIcons.signOut,
    variant: KnzButtonVariant.secondary,
    sentiment: KnzSentiment.danger,
    onPressed: widget.onSignOut,
  );
}

/// The avatar with the initial, the nickname and the e-mail.
class _Header extends StatelessWidget {
  const _Header({required this.account});

  final Account? account;

  static const _avatar = 84.0;

  @override
  Widget build(BuildContext context) {
    final account = this.account;
    return Row(
      children: [
        ExcludeSemantics(
          child: Container(
            width: _avatar,
            height: _avatar,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: KnzColors.primary,
              shape: BoxShape.circle,
              border: Border.all(
                color: KnzColors.accent,
                width: KnzDepth.lg,
                strokeAlign: BorderSide.strokeAlignOutside,
              ),
            ),
            child: account == null
                ? const KnzIcon(
                    KnzIcons.profile,
                    size: 40,
                    color: KnzColors.textOnPrimary,
                  )
                : Text(
                    account.nickname.characters.first.toUpperCase(),
                    style: KnzText.display.copyWith(
                      color: KnzColors.textOnPrimary,
                    ),
                  ),
          ),
        ),
        const SizedBox(width: KnzSpace.s16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'PROFIL',
                style: KnzText.overline.copyWith(color: KnzColors.textMuted),
              ),
              Semantics(
                header: true,
                child: Text(
                  account?.nickname ?? 'Hraješ bez účtu',
                  style: KnzText.titleXl,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (account != null)
                Text(
                  account.email,
                  style: KnzText.bodyLg.copyWith(color: KnzColors.textMuted),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
            ],
          ),
        ),
      ],
    );
  }
}

/// The level, the points, and how far the next level is.
class _LevelCard extends StatelessWidget {
  const _LevelCard({required this.level});

  final PlayerLevel level;

  static String _points(int n) =>
      '${Czech.number(n)}\u00A0${Czech.plural(n, 'bod', 'body', 'bodů')}';

  @override
  Widget build(BuildContext context) {
    final next = level.number + 1;
    final missing = level.pointsToNextLevel;
    return MergeSemantics(
      child: KnzCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Expanded(
                  child: Text('ÚROVEŇ ${level.number}', style: KnzText.titleSm),
                ),
                Text(
                  _points(level.points),
                  style: KnzText.caption.copyWith(color: KnzColors.accentText),
                ),
              ],
            ),
            const SizedBox(height: KnzSpace.s10),
            KnzProgressBar(
              value: level.progress,
              semanticLabel: 'Postup na úroveň $next',
              sentiment: KnzSentiment.accent,
            ),
            const SizedBox(height: KnzSpace.s8),
            Text(
              'Do úrovně $next ti chybí ${_points(missing)}.',
              style: KnzText.bodySm.copyWith(color: KnzColors.textMuted),
            ),
          ],
        ),
      ),
    );
  }
}

/// The wafer balance and what earns wafers (`components.md`, WaferPill).
class _WaferBalance extends StatelessWidget {
  const _WaferBalance({required this.wafers});

  final int wafers;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            'Oplatky dostáváš za trefy a\u00A0ještě víc za návštěvy míst.',
            style: KnzText.bodySm.copyWith(color: KnzColors.textMuted),
          ),
        ),
        const SizedBox(width: KnzSpace.s12),
        KnzWaferPill(wafers: wafers),
      ],
    );
  }
}

/// Guessed and visited out of all places, with a link to my map.
class _SummaryPill extends StatelessWidget {
  const _SummaryPill({
    required this.summary,
    required this.total,
    required this.onOpenMap,
  });

  final MyMapSummary summary;
  final int total;
  final VoidCallback onOpenMap;

  @override
  Widget build(BuildContext context) {
    final count = KnzText.titleSm;
    final muted = KnzText.caption.copyWith(color: KnzColors.textMuted);
    // Genitive after "z": "z 1 místa", otherwise "z 540 míst".
    final ofTotal = total > 0
        ? '${Czech.outOf(total)} ${Czech.number(total)} '
              '${total == 1 ? 'místa' : 'míst'} kraje'
        : '';
    return KnzPressable(
      onPressed: onOpenMap,
      isLink: true,
      semanticLabel:
          '${summary.guessed} uhodnuto, ${summary.visited} navštíveno'
          '${ofTotal.isEmpty ? '' : ' $ofTotal'}. Otevřít mapu',
      builder: (context, state) => Container(
        padding: const EdgeInsets.symmetric(
          horizontal: KnzSpace.s16,
          vertical: KnzSpace.s12,
        ),
        decoration: BoxDecoration(
          color: state.hovered ? KnzColors.track : KnzColors.surfaceSubtle,
          borderRadius: BorderRadius.circular(KnzRadius.xl3),
          boxShadow: state.focused ? KnzShadows.focus : null,
        ),
        child: Row(
          children: [
            const PlaceDot(color: KnzColors.stateGuessed, size: 16),
            const SizedBox(width: KnzSpace.s8),
            Text('${summary.guessed}', style: count),
            const SizedBox(width: KnzSpace.s14),
            const KnzIcon(KnzIcons.flag, size: 20),
            const SizedBox(width: KnzSpace.s6),
            Text('${summary.visited}', style: count),
            const SizedBox(width: KnzSpace.s14),
            Expanded(
              child: Text(
                ofTotal,
                style: muted,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text(
              'Mapa ›',
              style: KnzText.caption.copyWith(color: KnzColors.textLink),
            ),
          ],
        ),
      ),
    );
  }
}

/// The places the player rated, the latest rating first; each opens its
/// place card (`components.md`, RatedPlaceRow).
class _Ratings extends StatelessWidget {
  const _Ratings({
    required this.places,
    required this.maxRating,
    required this.onOpenPlace,
  });

  final List<MyMapPlace> places;
  final int maxRating;
  final ValueChanged<MyMapPlace> onOpenPlace;

  @override
  Widget build(BuildContext context) {
    final rated = [
      for (final place in places)
        if (place.rating != null) place,
    ];
    if (rated.isEmpty) {
      return Text(
        'Zatím tu nic není. Navštiv místo a\u00A0ohodnoť ho hvězdami.',
        style: KnzText.body.copyWith(color: KnzColors.textMuted),
      );
    }
    // The latest first; a rating without a time goes last.
    final epoch = DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
    rated.sort((a, b) => (b.ratedAt ?? epoch).compareTo(a.ratedAt ?? epoch));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final (i, place) in rated.indexed) ...[
          if (i > 0) const SizedBox(height: KnzSpace.s10),
          KnzCard(
            padding: const EdgeInsets.symmetric(
              horizontal: KnzSpace.s16,
              vertical: KnzSpace.s12,
            ),
            onPressed: () => onOpenPlace(place),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    place.name,
                    style: KnzText.cardTitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: KnzSpace.s12),
                KnzStarRating(stars: place.rating!, max: maxRating, size: 18),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

/// The badges, four in a row.
class _BadgeGrid extends StatelessWidget {
  const _BadgeGrid({required this.badges});

  final List<BadgeProgress> badges;

  static const _columns = 4;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        const gap = KnzSpace.s8;
        final width = (constraints.maxWidth - gap * (_columns - 1)) / _columns;
        return Wrap(
          spacing: gap,
          runSpacing: KnzSpace.s16,
          children: [
            for (final badge in badges)
              SizedBox(
                width: width,
                child: KnzBadge(
                  label: badge.kind.label,
                  icon: badge.kind.icon,
                  sentiment: badge.kind.sentiment,
                  count: badge.count,
                  goal: badge.goal,
                ),
              ),
          ],
        );
      },
    );
  }
}
