import '../design_system/design_system.dart';
import '../game/area.dart';
import '../my_map/my_map_place.dart';

/// One badge on the profile (`07b Profil`): a goal the player reaches by
/// guessing or visiting places.
///
/// The Game API has no badges yet, so the client counts these few generic
/// ones from my map's places. They hold no state of their own: a badge is
/// earned while the places it counts reach its goal.
enum BadgeKind {
  firstHit('První trefa', KnzIcons.place, KnzSentiment.primary),
  sharpEye('Bystré oko', KnzIcons.eye, KnzSentiment.primary),
  collector('Sběratel', KnzIcons.done, KnzSentiment.primary),
  tripper('Výletník', KnzIcons.navigate, KnzSentiment.accent),
  wanderer('Poutník', KnzIcons.elevation, KnzSentiment.accent),
  wholeChebsko('Celé Chebsko', KnzIcons.map, KnzSentiment.primary),
  wholeSokolovsko('Celé Sokolovsko', KnzIcons.map, KnzSentiment.explore),
  wholeKarlovarsko('Celé Karlovarsko', KnzIcons.map, KnzSentiment.accent);

  const BadgeKind(this.label, this.icon, this.sentiment);

  final String label;
  final KnzIcons icon;

  /// Blue for guessing, gold for visiting, the area's colour for an area.
  final KnzSentiment sentiment;
}

/// A badge with how far the player is.
class BadgeProgress {
  const BadgeProgress({
    required this.kind,
    required this.count,
    required this.goal,
  });

  final BadgeKind kind;
  final int count;
  final int goal;

  bool get earned => count >= goal;

  /// Every badge with the player's progress on [places]. The area badges
  /// come only when the backend tells which area a place is in, since the
  /// goal is every place in the area.
  static List<BadgeProgress> of(List<MyMapPlace> places) {
    final guessed = places.where((p) => p.isGuessed).length;
    final visited = places.where((p) => p.isVisited).length;
    BadgeProgress area(BadgeKind kind, Area area) {
      final inArea = places.where((p) => p.area == area);
      return BadgeProgress(
        kind: kind,
        count: inArea.where((p) => !p.isUnknown).length,
        // An area without places would be earned for nothing.
        goal: inArea.isEmpty ? 1 : inArea.length,
      );
    }

    return [
      BadgeProgress(kind: BadgeKind.firstHit, count: guessed, goal: 1),
      BadgeProgress(kind: BadgeKind.sharpEye, count: guessed, goal: 10),
      BadgeProgress(kind: BadgeKind.collector, count: guessed, goal: 50),
      BadgeProgress(kind: BadgeKind.tripper, count: visited, goal: 1),
      BadgeProgress(kind: BadgeKind.wanderer, count: visited, goal: 10),
      if (places.any((p) => p.area != null)) ...[
        area(BadgeKind.wholeChebsko, Area.chebsko),
        area(BadgeKind.wholeSokolovsko, Area.sokolovsko),
        area(BadgeKind.wholeKarlovarsko, Area.karlovarsko),
      ],
    ];
  }
}
