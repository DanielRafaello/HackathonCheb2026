import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/config/map_config.dart';
import 'package:kde_na_zapade/map/map_style.dart';

/// Reads the metadata JSON of a PMTiles v3 archive.
Map<String, Object?> pmTilesMetadata(Uint8List archive) {
  final header = ByteData.sublistView(archive, 0, 127);
  final offset = header.getUint64(24, Endian.little);
  final length = header.getUint64(32, Endian.little);
  final compression = header.getUint8(97);
  final raw = archive.sublist(offset, offset + length);
  final text = utf8.decode(compression == 2 ? gzip.decode(raw) : raw);
  return jsonDecode(text) as Map<String, Object?>;
}

void main() {
  final asset = File(MapConfig.fromEnvironment().tilesAsset);

  test('the bundled tile archive is a PMTiles v3 archive', () {
    final bytes = asset.readAsBytesSync();

    expect(ascii.decode(bytes.sublist(0, 7)), 'PMTiles');
    expect(bytes[7], 3);
  });

  // Fails when the style draws a layer that an older archive lacks: rebuild
  // the tiles and copy build/map/kvk.pmtiles to the asset.
  test('the bundled tile archive has exactly the layers of the style', () {
    final metadata = pmTilesMetadata(asset.readAsBytesSync());
    final layers = (metadata['vector_layers'] as List)
        .map((layer) => (layer as Map)['id'] as String)
        .toSet();

    expect(layers, GameMapStyle.sourceLayers.toSet());
  });
}
