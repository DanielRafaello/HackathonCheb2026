import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;

import 'package:kde_na_zapade/config/game_config.dart';
import 'package:kde_na_zapade/home/account_home_summary.dart';
import 'package:kde_na_zapade/home/daily_hero_card.dart';
import 'package:kde_na_zapade/home/home_page.dart';
import 'package:kde_na_zapade/home/home_summary.dart';
import 'package:kde_na_zapade/my_map/locations_api.dart';

import 'fake_game_backend.dart';

final _now = DateTime.utc(2026, 10, 10, 10);

Map<String, Object?> dailyJson({
  String status = 'active',
  int attemptsUsed = 0,
}) => {
  'round': {
    'id': 15,
    'status': status,
    'daily_date': '2026-10-10',
    'attempts_used': attemptsUsed,
    'stars': status == 'guessed' ? 3 : null,
    'clues': [
      {'position': 1, 'type': 'riddle', 'text': 'Secret'},
    ],
    'completed_at': null,
    'last_guess': null,
    if (status != 'active')
      'location': {'id': 1, 'name': 'Secret place', 'latitude': 50},
  },
};

void main() {
  group('AccountHomeSummary', () {
    late FakeGameBackend backend;

    Future<AccountHomeSummary> loader() async {
      final session = await signedInSession(backend);
      final client = authorizedClient(backend, session);
      return AccountHomeSummary(
        locations: LocationsApi(client: client),
        client: client,
      );
    }

    setUp(() {
      backend = FakeGameBackend(
        places: [
          locationJson(1, guessedAt: '2026-10-09T21:13:43Z'),
          locationJson(2, visitedAt: '2026-10-08T10:00:00Z'),
          locationJson(3),
        ],
      );
    });

    test('counts my map and reads today\'s attempts', () async {
      backend.daily = () => jsonResponse(dailyJson(attemptsUsed: 2));

      final summary = await (await loader()).load();

      expect(summary.guessed, 1);
      expect(summary.visited, 1);
      expect(summary.areas, isEmpty);
      expect(summary.attemptsUsedToday, 2);
      expect(summary.dailyStatus, DailyStatus.open);
      expect(summary.wafers, 112);
      expect(backend.sent('/rounds/daily'), hasLength(1));
    });

    test('has the areas when the backend sends districts', () async {
      backend.places[0]['district'] = 'CZ0411';
      backend.places[1]['district'] = 'CZ0412';

      final summary = await (await loader()).load();

      expect(summary.areas, hasLength(3));
      final chebsko = summary.areas.singleWhere((a) => a.area == Area.chebsko);
      expect((chebsko.known, chebsko.total), (1, 1));
    });

    test('only a hit finishes the round', () async {
      backend.daily = () =>
          jsonResponse(dailyJson(status: 'guessed', attemptsUsed: 3));
      expect((await (await loader()).load()).dailyStatus, DailyStatus.guessed);

      // A round has no guess limit: many misses leave it open.
      backend.daily = () => jsonResponse(dailyJson(attemptsUsed: 9));
      final open = await (await loader()).load();
      expect(open.dailyStatus, DailyStatus.open);
      expect(open.attemptsUsedToday, 9);
    });

    test('every place guessed means nothing to play', () async {
      backend.daily = () => jsonResponse({
        'error': true,
        'status': 409,
        'message': 'round.no_eligible_daily_location',
      }, 409);

      final summary = await (await loader()).load();

      expect(summary.dailyStatus, DailyStatus.allGuessed);
      expect(summary.attemptsUsedToday, 0);
    });

    test('a failing daily call leaves the counts and no guess spent', () async {
      backend.daily = () => null;
      expect((await (await loader()).load()).guessed, 1);

      backend.daily = () => http.Response('oops', 500);
      final summary = await (await loader()).load();
      expect(summary.guessed, 1);
      expect(summary.attemptsUsedToday, 0);
      expect(summary.dailyStatus, DailyStatus.open);
    });

    test('a failing map fails the summary', () async {
      backend.locations = () => null;

      await expectLater(
        (await loader()).load(),
        throwsA(isA<LocationsApiException>()),
      );
    });
  });

  group('DailyHeroCard', () {
    Future<void> pumpCard(
      WidgetTester tester, {
      required int attemptsUsed,
      bool finished = false,
    }) async {
      tester.view.physicalSize = const Size(390, 1200);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: DailyHeroCard(
              day: _now,
              attemptsUsed: attemptsUsed,
              finished: finished,
              config: GameConfig.defaults,
              onPlay: () {},
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
    }

    testWidgets('a new round invites to play', (tester) async {
      await pumpCard(tester, attemptsUsed: 0);

      expect(find.text('Zatím bez pokusu'), findsOneWidget);
      expect(find.text('HRÁT MÍSTO DNE'), findsOneWidget);
      // No guess limit to announce: the compass comes instead.
      expect(find.text('kompas'), findsOneWidget);
      expect(find.textContaining('pokusů'), findsNothing);
    });

    testWidgets('a started round goes on where the player left it', (
      tester,
    ) async {
      await pumpCard(tester, attemptsUsed: 7);

      expect(find.text('Rozehráno\u00A0· 7\u00A0pokusů'), findsOneWidget);
      expect(find.text('HRÁT DÁL'), findsOneWidget);
    });

    testWidgets('a finished round shows the result', (tester) async {
      await pumpCard(tester, attemptsUsed: 3, finished: true);

      expect(find.text('Dnes dohráno\u00A0· 3\u00A0pokusy'), findsOneWidget);
      expect(find.text('ZOBRAZIT VÝSLEDEK'), findsOneWidget);
      expect(find.text('HRÁT MÍSTO DNE'), findsNothing);
    });
  });

  group('HomePage', () {
    Future<void> pumpHome(
      WidgetTester tester, {
      required Future<HomeSummary> Function()? load,
    }) async {
      tester.view.physicalSize = const Size(390, 2000);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      tester.platformDispatcher.accessibilityFeaturesTestValue =
          const FakeAccessibilityFeatures(disableAnimations: true);
      addTearDown(
        tester.platformDispatcher.clearAccessibilityFeaturesTestValue,
      );
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: HomePage(load: load, config: GameConfig.defaults, now: _now),
          ),
        ),
      );
      await tester.pumpAndSettle();
    }

    testWidgets('a guest sees an empty summary without areas', (tester) async {
      await pumpHome(tester, load: null);

      expect(find.text('0 uhodnuto'), findsOneWidget);
      expect(find.text('0 navštíveno'), findsOneWidget);
      expect(find.text('Zatím bez pokusu'), findsOneWidget);
      expect(find.text('Chebsko'), findsNothing);
    });

    testWidgets('shows the loaded counts and areas', (tester) async {
      await pumpHome(
        tester,
        load: () async => const HomeSummary(
          guessed: 3,
          visited: 1,
          areas: [
            AreaProgress(area: Area.chebsko, known: 2, total: 40),
            AreaProgress(area: Area.sokolovsko, known: 1, total: 30),
            AreaProgress(area: Area.karlovarsko, known: 1, total: 42),
          ],
          attemptsUsedToday: 1,
          wafers: 112,
        ),
      );

      expect(find.text('3 uhodnuto'), findsOneWidget);
      expect(find.text('1 navštíveno'), findsOneWidget);
      expect(find.text('112'), findsOneWidget);
      expect(find.bySemanticsLabel('Máš 112\u00A0oplatek'), findsOneWidget);
      // The area column describes itself for screen readers.
      expect(
        find.byWidgetPredicate(
          (w) =>
              w is Semantics &&
              w.properties.label == 'Chebsko: 2\u00A0ze\u00A040',
        ),
        findsOneWidget,
      );
      expect(find.text('Rozehráno\u00A0· 1\u00A0pokus'), findsOneWidget);
    });

    testWidgets('hides the areas when none is known and says a finished day', (
      tester,
    ) async {
      await pumpHome(
        tester,
        load: () async => const HomeSummary(
          guessed: 3,
          visited: 1,
          areas: [],
          attemptsUsedToday: 3,
          dailyStatus: DailyStatus.guessed,
        ),
      );

      expect(find.text('3 uhodnuto'), findsOneWidget);
      expect(find.text('Chebsko'), findsNothing);
      expect(find.text('Dnes dohráno\u00A0· 3\u00A0pokusy'), findsOneWidget);
      expect(find.text('ZOBRAZIT VÝSLEDEK'), findsOneWidget);
      expect(find.textContaining('Nové tu bude'), findsOneWidget);
    });

    testWidgets('a failed load shows the empty summary and a toast', (
      tester,
    ) async {
      await pumpHome(
        tester,
        load: () async =>
            throw const LocationsApiException(LocationsErrorKind.network),
      );

      expect(find.text('0 uhodnuto'), findsOneWidget);
      expect(find.text('HRÁT MÍSTO DNE'), findsOneWidget);
      expect(
        find.text('Tvůj postup se nepodařilo načíst. Zkontroluj připojení.'),
        findsOneWidget,
      );
    });
  });
}
