import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/config/multiplayer_config.dart';

void main() {
  test('a debug build connects to the local socket server', () {
    expect(
      MultiplayerConfig.defaultUrl(
        debug: true,
        web: true,
        platform: TargetPlatform.android,
      ),
      MultiplayerConfig.local,
    );
    expect(
      MultiplayerConfig.defaultUrl(
        debug: true,
        web: false,
        platform: TargetPlatform.iOS,
      ),
      MultiplayerConfig.local,
    );
    expect(
      MultiplayerConfig.defaultUrl(
        debug: true,
        web: false,
        platform: TargetPlatform.android,
      ),
      MultiplayerConfig.localFromAndroidEmulator,
    );
  });

  test('a release build connects to the deployed socket server', () {
    for (final web in [true, false]) {
      expect(
        MultiplayerConfig.defaultUrl(
          debug: false,
          web: web,
          platform: TargetPlatform.android,
        ),
        MultiplayerConfig.production,
      );
    }
    expect(
      MultiplayerConfig.production.toString(),
      'wss://aether217.zcu.cz/ws',
    );
  });

  test('invite links lead to the web app', () {
    final deployed = MultiplayerConfig(url: MultiplayerConfig.production);
    expect(
      deployed.inviteLink('K7M2QX').toString(),
      'https://aether217.zcu.cz/multiplayer/K7M2QX',
    );

    final local = MultiplayerConfig(
      url: MultiplayerConfig.local,
      inviteBaseUrl: Uri.parse('http://localhost:5173/free-play?x=1'),
    );
    expect(
      local.inviteLink('K7M2QX').toString(),
      'http://localhost:5173/multiplayer/K7M2QX',
    );
  });
}
