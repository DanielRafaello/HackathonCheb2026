import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

import 'package:kde_na_zapade/account/account_api.dart';
import 'package:kde_na_zapade/account/session.dart';
import 'package:kde_na_zapade/account/token_storage.dart';
import 'package:kde_na_zapade/api/authorized_client.dart';
import 'package:kde_na_zapade/config/api_config.dart';
import 'package:kde_na_zapade/progress/place_card_cache.dart';
import 'package:kde_na_zapade/round/http_round_api.dart';
import 'package:kde_na_zapade/round/round.dart';

/// Loket, inside the region.
const inRegion = GeoPoint(50.2579, 12.7541);

/// In Bavaria, outside the region.
const abroad = GeoPoint(49.95, 12.10);

/// A Game API backend for the round endpoints with one signed-in account.
///
/// `jwt1` is valid until [expireToken]; the refresh token `refresh1` buys
/// `jwt2`. [onRound] answers every `rounds/…` request.
class RoundBackend {
  RoundBackend(this.onRound);

  http.Response Function(http.Request request) onRound;

  final requests = <http.Request>[];
  final validTokens = {'jwt1'};

  /// Requests to the round endpoints that carried a valid token.
  List<http.Request> get roundRequests => [
    for (final request in requests)
      if (request.url.path.startsWith('/api/rounds')) request,
  ];

  void expireToken() => validTokens.remove('jwt1');

  late final client = MockClient((request) async {
    requests.add(request);
    final path = request.url.path;
    if (path == '/api/auth/refresh') {
      final body = jsonDecode(request.body) as Map<String, dynamic>;
      if (body['refreshToken'] == 'refresh1') {
        validTokens.add('jwt2');
        return json({
          'token': 'jwt2',
          'refresh_token': 'refresh2',
          'user': {'id': 1, 'name': 'Eva', 'email': 'eva@example.cz'},
        }, 200);
      }
      return json({'error': true, 'status': 401}, 401);
    }
    final token = request.headers['Authorization']?.substring(7);
    if (!validTokens.contains(token)) {
      return json({'error': true, 'status': 401}, 401);
    }
    if (path == '/api/me') {
      return json({
        'user': {'id': 1, 'name': 'Eva', 'email': 'eva@example.cz'},
      }, 200);
    }
    return onRound(request);
  });

  static http.Response json(
    Object body,
    int status, {
    Map<String, String> headers = const {},
  }) => http.Response(
    jsonEncode(body),
    status,
    headers: {'content-type': 'application/json; charset=utf-8', ...headers},
  );

  static http.Response error(int status, String message) =>
      json({'error': true, 'status': status, 'message': message}, status);
}

final apiConfig = ApiConfig(baseUrl: Uri.parse('https://example.cz/api/'));

/// A signed-in session over [backend].
Future<Session> signedIn(RoundBackend backend) async {
  final session = Session(
    api: AccountApi(config: apiConfig, client: backend.client),
    storage: MemoryTokenStorage()
      ..tokens = const StoredTokens(token: 'jwt1', refreshToken: 'refresh1'),
  );
  await session.restore();
  expect(session.isSignedIn, isTrue);
  return session;
}

Map<String, Object?> clue(int position, String type, String text) => {
  'position': position,
  'type': type,
  'text': text,
};

const clueTexts = {
  1: 'Vzácný poklad tu ležel pod podlahou kaple.',
  2: 'Hrady, tvrze a zříceniny',
  3: 'Karlovarsko',
  4: 'Na nádvoří se konají výstavy.',
};

const clueTypes = {
  1: 'distinctive_fact',
  2: 'category',
  3: 'area_narrowing',
  4: 'detail',
};

/// A round as the backend sends it, with [unlocked] clues.
Map<String, Object?> wireRound({
  int id = 15,
  String status = 'active',
  String date = '2026-10-10',
  int attemptsUsed = 0,
  int? stars,
  int unlocked = 1,
  Map<String, Object?>? lastGuess,
  Map<String, Object?>? location,
}) => {
  'id': id,
  'status': status,
  'daily_date': date,
  'attempts_used': attemptsUsed,
  'stars': stars,
  'clues': [
    for (var p = 1; p <= unlocked; p++) clue(p, clueTypes[p]!, clueTexts[p]!),
  ],
  'completed_at': status == 'active' ? null : '2026-10-10T10:00:00+00:00',
  'last_guess': lastGuess,
  'location': ?location,
};

Map<String, Object?> wireGuess({
  required int attempt,
  required bool hit,
  required num distance,
  String? direction,
}) => {
  'attempt_number': attempt,
  'hit': hit,
  'distance_meters': distance,
  'direction': direction,
};

Map<String, Object?> wireLocation({bool withSource = true}) => {
  'id': 42,
  'name': 'Hrad Loket',
  'latitude': 50.187104,
  'longitude': 12.754285,
  'category': 'Hrady, tvrze a zříceniny',
  'description': 'Gotický hrad na skále nad Ohří.',
  'content_source_url': 'https://example.test/loket',
  'source': withSource
      ? {
          'title': 'Památky Karlovarského kraje',
          'publisher': 'Karlovarský kraj',
          'portal_url': 'https://example.test/dataset',
          'license_code': 'CC BY 4.0',
          'license_url': 'https://creativecommons.org/licenses/by/4.0/',
          'attribution_text': 'Zdroj: datazapad.cz',
          'retrieved_at': '2026-10-09T00:00:00+00:00',
          'source_updated_at': null,
        }
      : null,
};

Matcher throwsRoundError(RoundErrorKind kind) =>
    throwsA(isA<RoundApiException>().having((e) => e.kind, 'kind', kind));

void main() {
  late RoundBackend backend;
  late MemoryPlaceCardCache cache;

  Future<HttpRoundApi> api() async => HttpRoundApi(
    client: AuthorizedClient(
      config: apiConfig,
      session: await signedIn(backend),
      client: backend.client,
    ),
    cache: cache,
  );

  setUp(() {
    cache = MemoryPlaceCardCache();
    backend = RoundBackend(
      (_) => RoundBackend.json({'round': wireRound()}, 200),
    );
  });

  group('placeOfTheDay', () {
    test('parses today\'s round and pads the locked clues', () async {
      final daily = await (await api()).placeOfTheDay(resumeToken: 'old');
      final round = (daily as DailyRoundReady).round;

      expect(round.token, '15');
      expect(round.day, DateTime.utc(2026, 10, 10));
      expect(round.wrongGuesses, 0);
      // Four tiles: the backend's known order, then a plain locked clue.
      expect(round.clues.map((c) => c.kind), [
        ClueKind.riddle,
        ClueKind.placeType,
        ClueKind.area,
        ClueKind.other,
      ]);
      expect(round.clues.map((c) => c.text), [clueTexts[1], null, null, null]);
      expect(round.lastGuess, isNull);
      expect(round.compass, isNull);
      expect(round.result, isNull);

      final request = backend.roundRequests.single;
      expect(request.method, 'GET');
      expect(request.url.path, '/api/rounds/daily');
      expect(request.headers['Authorization'], 'Bearer jwt1');
    });

    test('a resumed round has its clues and compass but no pin', () async {
      backend.onRound = (_) => RoundBackend.json({
        'round': wireRound(
          attemptsUsed: 6,
          unlocked: 4,
          lastGuess: wireGuess(
            attempt: 6,
            hit: false,
            distance: 8240.6,
            direction: 'E',
          ),
        ),
      }, 200);
      final round =
          ((await (await api()).placeOfTheDay()) as DailyRoundReady).round;

      expect(round.wrongGuesses, 6);
      expect(round.unlockedClues, 4);
      expect(round.lastGuess, isNull);
      expect(round.compass!.bearingDegrees, 90);
      expect(round.isFinished, isFalse);
    });

    test('a clue of an unknown kind still shows', () async {
      backend.onRound = (_) => RoundBackend.json({
        'round': wireRound()
          ..['clues'] = [
            clue(1, 'distinctive_fact', 'a'),
            clue(4, 'something_new', 'b'),
          ],
      }, 200);
      final round =
          ((await (await api()).placeOfTheDay()) as DailyRoundReady).round;
      expect(round.clues.map((c) => c.kind), [
        ClueKind.riddle,
        ClueKind.placeType,
        ClueKind.area,
        ClueKind.other,
      ]);
      expect(round.clues.last.text, 'b');
    });

    test('every place guessed means no place of the day', () async {
      backend.onRound = (_) =>
          RoundBackend.error(409, 'round.no_eligible_daily_location');
      expect(await (await api()).placeOfTheDay(), isA<AllPlacesGuessed>());
    });

    test('a guessed round comes back finished with the place', () async {
      backend.onRound = (_) => RoundBackend.json({
        'round': wireRound(
          status: 'guessed',
          attemptsUsed: 2,
          stars: 4,
          unlocked: 3,
          lastGuess: wireGuess(attempt: 2, hit: true, distance: 220),
          location: wireLocation(),
        ),
      }, 200);
      final round =
          ((await (await api()).placeOfTheDay()) as DailyRoundReady).round;
      expect(round.isFinished, isTrue);
      expect(round.result!.stars, 4);
      expect(round.wrongGuesses, 1);
      expect(round.compass, isNull);
    });

    for (final (status, kind) in [
      (401, RoundErrorKind.unauthorized),
      (404, RoundErrorKind.roundNotFound),
      (422, RoundErrorKind.server),
      (500, RoundErrorKind.server),
    ]) {
      test('a $status answer is $kind', () async {
        backend.onRound = (_) => RoundBackend.error(status, 'x');
        if (status == 401) {
          // The client refreshes once and retries once; the second 401
          // ends the session.
          backend.validTokens.clear();
          backend.onRound = (_) => RoundBackend.error(401, 'x');
        }
        await expectLater(
          (await api()).placeOfTheDay(),
          throwsRoundError(kind),
        );
      });
    }

    test('an unreadable body is a server error', () async {
      backend.onRound = (_) => http.Response('<html>', 200);
      await expectLater(
        (await api()).placeOfTheDay(),
        throwsRoundError(RoundErrorKind.server),
      );
    });

    test('an expired JWT is refreshed and the request retried once', () async {
      final a = await api();
      backend.expireToken();
      final daily = await a.placeOfTheDay();
      expect(daily, isA<DailyRoundReady>());
      final tokens = [
        for (final r in backend.requests)
          if (r.url.path == '/api/rounds/daily') r.headers['Authorization'],
      ];
      expect(tokens, ['Bearer jwt1', 'Bearer jwt2']);
    });

    test('without a connection the error is network', () async {
      final a = HttpRoundApi(
        client: AuthorizedClient(
          config: apiConfig,
          session: await signedIn(backend),
          client: MockClient((_) => throw http.ClientException('offline')),
        ),
        cache: cache,
      );
      await expectLater(
        a.placeOfTheDay(),
        throwsRoundError(RoundErrorKind.network),
      );
    });
  });

  group('guess', () {
    test('a miss unlocks a clue and keeps the sent pin', () async {
      backend.onRound = (request) {
        expect(request.method, 'POST');
        expect(request.url.path, '/api/rounds/15/guesses');
        expect(jsonDecode(request.body), {
          'latitude': inRegion.latitude,
          'longitude': inRegion.longitude,
        });
        final guess = wireGuess(
          attempt: 1,
          hit: false,
          distance: 8240.6,
          direction: 'SW',
        );
        return RoundBackend.json({
          'guess': guess,
          'round': wireRound(attemptsUsed: 1, unlocked: 2, lastGuess: guess),
        }, 200);
      };
      final outcome = await (await api()).guess('15', inRegion);
      final round = (outcome as GuessMissed).round;

      expect(round.wrongGuesses, 1);
      expect(round.lastGuess, inRegion);
      // The backend sends a direction after every miss; the compass waits
      // until every clue has missed.
      expect(round.compass, isNull);
      expect(round.clues.map((c) => c.text), [
        clueTexts[1],
        clueTexts[2],
        null,
        null,
      ]);
      expect(round.result, isNull);
    });

    test('the fourth miss turns the compass on', () async {
      Map<String, Object?> miss(int attempt, String direction) {
        final guess = wireGuess(
          attempt: attempt,
          hit: false,
          distance: 8240.6,
          direction: direction,
        );
        return {
          'guess': guess,
          'round': wireRound(
            attemptsUsed: attempt,
            unlocked: 4,
            lastGuess: guess,
          ),
        };
      }

      backend.onRound = (_) => RoundBackend.json(miss(3, 'S'), 200);
      final third = await (await api()).guess('15', inRegion);
      expect((third as GuessMissed).round.compass, isNull);

      backend.onRound = (_) => RoundBackend.json(miss(4, 'SW'), 200);
      final fourth = await (await api()).guess('15', inRegion);
      expect((fourth as GuessMissed).round.compass!.bearingDegrees, 225);
    });

    test('the round goes on after many misses', () async {
      final guess = wireGuess(
        attempt: 12,
        hit: false,
        distance: 900,
        direction: 'N',
      );
      backend.onRound = (_) => RoundBackend.json({
        'guess': guess,
        // The limit fields of an older backend do not end the round.
        'round': wireRound(attemptsUsed: 12, unlocked: 4, lastGuess: guess)
          ..['attempts_remaining'] = 0
          ..['max_attempts'] = 5,
      }, 200);
      final outcome = await (await api()).guess('15', inRegion);
      final round = (outcome as GuessMissed).round;

      expect(round.isFinished, isFalse);
      expect(round.wrongGuesses, 12);
      expect(round.compass!.bearingDegrees, 0);
    });

    test('a hit ends the round with the place and caches its card', () async {
      final guess = wireGuess(attempt: 2, hit: true, distance: 220);
      backend.onRound = (_) => RoundBackend.json({
        'guess': guess,
        'round': wireRound(
          status: 'guessed',
          attemptsUsed: 2,
          stars: 4,
          unlocked: 3,
          lastGuess: guess,
          location: wireLocation(),
        ),
        'wafers_earned': 8,
      }, 200);
      final outcome = await (await api()).guess('15', inRegion);
      final round = (outcome as GuessHit).round;
      final result = round.result!;

      expect(result.stars, 4);
      expect(result.wafersEarned, 8);
      expect(result.guesses, 2);
      expect(result.distanceMeters, 220);
      expect(round.wrongGuesses, 1);
      expect(round.compass, isNull);
      expect(round.lastGuess, inRegion);
      expect(round.unlockedClues, 3);

      final place = result.place;
      expect(place.id, 42);
      expect(place.name, 'Hrad Loket');
      expect(place.type, 'Hrady, tvrze a zříceniny');
      expect(place.location, const GeoPoint(50.187104, 12.754285));
      expect(place.source, 'Zdroj: datazapad.cz');
      expect(place.licence, 'CC BY 4.0');
      expect(place.isSpring, isFalse);

      final cached = await cache.read(42);
      expect(cached?.name, 'Hrad Loket');
      expect(cached?.source?.licenseCode, 'CC BY 4.0');
    });

    test('a place without a source has no source on its card', () async {
      final guess = wireGuess(attempt: 1, hit: true, distance: 10);
      backend.onRound = (_) => RoundBackend.json({
        'guess': guess,
        'round': wireRound(
          status: 'guessed',
          attemptsUsed: 1,
          stars: 5,
          unlocked: 3,
          lastGuess: guess,
          location: wireLocation(withSource: false),
        ),
      }, 200);
      final outcome = await (await api()).guess('15', inRegion);
      final place = (outcome as GuessHit).round.result!.place;
      expect(place.source, isNull);
      expect(place.licence, isNull);
    });

    test(
      'a failed round is a server error and its place is never kept',
      () async {
        final guess = wireGuess(
          attempt: 5,
          hit: false,
          distance: 13240,
          direction: 'N',
        );
        backend.onRound = (_) => RoundBackend.json({
          'guess': guess,
          'round': wireRound(
            status: 'failed',
            attemptsUsed: 5,
            stars: 0,
            unlocked: 3,
            lastGuess: guess,
            location: wireLocation(),
          ),
        }, 200);

        await expectLater(
          (await api()).guess('15', inRegion),
          throwsRoundError(RoundErrorKind.server),
        );
        expect(await cache.read(42), isNull);
      },
    );

    test('a pin outside the region is never sent', () async {
      final outcome = await (await api()).guess('15', abroad);
      expect(outcome, isA<GuessOutsideRegion>());
      expect(backend.roundRequests, isEmpty);
    });

    test('a round from yesterday has expired', () async {
      backend.onRound = (_) => RoundBackend.json({
        'round': wireRound(status: 'expired', date: '2026-10-09'),
      }, 200);
      await expectLater(
        (await api()).guess('15', inRegion),
        throwsRoundError(RoundErrorKind.roundExpired),
      );
    });

    test('a round that is no longer active has finished', () async {
      backend.onRound = (_) => RoundBackend.error(409, 'round.not_active');
      await expectLater(
        (await api()).guess('15', inRegion),
        throwsRoundError(RoundErrorKind.roundFinished),
      );
    });

    test('an unknown round is not found', () async {
      backend.onRound = (_) => RoundBackend.error(404, 'not.found.round');
      await expectLater(
        (await api()).guess('99', inRegion),
        throwsRoundError(RoundErrorKind.roundNotFound),
      );
    });

    test('too many guesses say how long to wait', () async {
      backend.onRound = (_) => RoundBackend.json(
        {'error': true, 'status': 429},
        429,
        headers: {'retry-after': '30'},
      );
      await expectLater(
        (await api()).guess('15', inRegion),
        throwsA(
          isA<RoundApiException>()
              .having((e) => e.kind, 'kind', RoundErrorKind.rateLimited)
              .having(
                (e) => e.retryAfter,
                'retryAfter',
                const Duration(seconds: 30),
              ),
        ),
      );
    });

    test('a lost answer is a timeout, and the guess is not resent', () async {
      final a = HttpRoundApi(
        client: AuthorizedClient(
          config: apiConfig,
          session: await signedIn(backend),
          client: MockClient((request) async {
            backend.requests.add(request);
            await Future<void>.delayed(const Duration(milliseconds: 50));
            return RoundBackend.json({'round': wireRound()}, 200);
          }),
          timeout: const Duration(milliseconds: 10),
        ),
        cache: cache,
      );
      await expectLater(
        a.guess('15', inRegion),
        throwsRoundError(RoundErrorKind.timeout),
      );
      expect(backend.roundRequests, hasLength(1));
    });
  });

  group('refresh', () {
    test('fetches the round by its token', () async {
      backend.onRound = (request) {
        expect(request.method, 'GET');
        expect(request.url.path, '/api/rounds/15');
        return RoundBackend.json({
          'round': wireRound(
            attemptsUsed: 4,
            unlocked: 4,
            lastGuess: wireGuess(
              attempt: 4,
              hit: false,
              distance: 5000,
              direction: 'NW',
            ),
          ),
        }, 200);
      };
      final round = await (await api()).refresh('15');
      expect(round.wrongGuesses, 4);
      expect(round.compass!.bearingDegrees, 315);
      expect(round.lastGuess, isNull);
    });

    test('an expired round is reported as such', () async {
      backend.onRound = (_) => RoundBackend.json({
        'round': wireRound(status: 'expired', date: '2026-10-09'),
      }, 200);
      await expectLater(
        (await api()).refresh('15'),
        throwsRoundError(RoundErrorKind.roundExpired),
      );
    });
  });

  test('Compass.fromDirection maps the eight directions', () {
    expect(
      [
        for (final d in ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'])
          Compass.fromDirection(d)!.bearingDegrees,
      ],
      [0, 45, 90, 135, 180, 225, 270, 315],
    );
    expect(Compass.fromDirection(null), isNull);
    expect(Compass.fromDirection('up'), isNull);
  });

  test('ClueKind.fromWire knows the backend\'s names and the old ones', () {
    expect(ClueKind.fromWire('distinctive_fact'), ClueKind.riddle);
    expect(ClueKind.fromWire('category'), ClueKind.placeType);
    expect(ClueKind.fromWire('area_narrowing'), ClueKind.area);
    expect(ClueKind.fromWire('riddle'), ClueKind.riddle);
    expect(ClueKind.fromWire('place_type'), ClueKind.placeType);
    expect(ClueKind.fromWire('numbers'), ClueKind.numbers);
    expect(ClueKind.fromWire('detail'), ClueKind.detail);
    expect(ClueKind.fromWire('mystery'), ClueKind.other);
    expect(ClueKind.area.title, 'Oblast');
  });
}
