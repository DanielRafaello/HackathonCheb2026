import 'dart:async';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/multiplayer/multiplayer_connection.dart';
import 'package:kde_na_zapade/multiplayer/multiplayer_controller.dart';
import 'package:kde_na_zapade/multiplayer/multiplayer_store.dart';
import 'package:kde_na_zapade/multiplayer/protocol.dart';
import 'package:kde_na_zapade/multiplayer/websocket_multiplayer_connection.dart';
import 'package:kde_na_zapade/round/geo.dart';

/// A smoke test against a real socket server (`../backend/multiplayer`),
/// skipped unless `MULTIPLAYER_SMOKE_URL` names one:
///
/// ```sh
/// MULTIPLAYER_SMOKE_URL=ws://localhost:8090/ws \
///   flutter test test/multiplayer_server_smoke_test.dart
/// ```
///
/// `MULTIPLAYER_SMOKE_JWT` (a JWT the server accepts) adds the account
/// path. The server needs places in its database.
void main() {
  final url = Platform.environment['MULTIPLAYER_SMOKE_URL'];
  final jwt = Platform.environment['MULTIPLAYER_SMOKE_JWT'];
  final skip = url == null || url.isEmpty
      ? 'Set MULTIPLAYER_SMOKE_URL to run against a socket server'
      : null;
  const loket = GeoPoint(50.1859, 12.7541);

  Future<MultiplayerConnection> connect() =>
      WebSocketMultiplayerConnection.connect(Uri.parse(url!));

  /// Waits until [done] holds, checked whenever [controller] changes.
  Future<void> until(
    MultiplayerController controller,
    bool Function() done, {
    Duration timeout = const Duration(seconds: 10),
  }) async {
    if (done()) return;
    final completer = Completer<void>();
    void check() {
      if (done() && !completer.isCompleted) completer.complete();
    }

    controller.addListener(check);
    try {
      await completer.future.timeout(timeout);
    } finally {
      controller.removeListener(check);
    }
  }

  MultiplayerController controller({String? Function()? token}) {
    final controller = MultiplayerController(
      connect: connect,
      store: MemoryMultiplayerStore(),
      token: token ?? () => null,
      refreshToken: () async => false,
    );
    addTearDown(controller.dispose);
    return controller;
  }

  test('two guests play a whole game against the real server', () async {
    final eva = controller();
    final adam = controller();
    await eva.start();
    await eva.createLobby(nickname: 'Eva Smoke');
    await until(eva, () => eva.phase == MultiplayerPhase.lobby);
    expect(eva.limits, isNotNull);
    expect(eva.defaults, isNotNull);
    final code = eva.lobby!.code;
    expect(code, hasLength(MultiplayerController.codeLength));
    expect(eva.lobby!.isHost, isTrue);

    await adam.start(joinCode: code.toLowerCase());
    expect(adam.phase, MultiplayerPhase.entry);
    await adam.joinLobby(code.toLowerCase(), nickname: '  Adam   Smoke ');
    await until(adam, () => adam.phase == MultiplayerPhase.lobby);
    await until(eva, () => eva.lobby!.players.length == 2);
    expect(adam.lobby!.self!.nickname, 'Adam Smoke');

    eva.updateSettings(placeCount: 2, durationSeconds: 60);
    await until(adam, () => adam.lobby!.settings.placeCount == 2);
    expect(adam.lobby!.settings.durationSeconds, 60);

    eva.startGame();
    await until(eva, () => eva.phase == MultiplayerPhase.playing);
    await until(adam, () => adam.phase == MultiplayerPhase.playing);
    final remaining = eva.remaining!;
    expect(remaining.inSeconds, inInclusiveRange(55, 60));
    expect(eva.selfGame!.currentPlaceName, isNotEmpty);
    expect(eva.selfGame!.rounds, isEmpty);

    for (final player in [eva, adam]) {
      for (var index = 0; index < 2; index++) {
        await until(player, () => player.canGuess);
        player.placePin(loket);
        player.confirmGuess();
        // A second tap sends nothing.
        player.confirmGuess();
        await until(player, () => player.shownResult != null);
        final result = player.shownResult!;
        expect(result.index, index);
        expect(result.distanceMeters, greaterThanOrEqualTo(0));
        expect(result.place.source?.licenseCode, isNotNull);
        expect(result.place.toCard().licence, isNotNull);
        // The server sends the state that moves on to the next place in a
        // frame of its own after the result; a guess before it arrives
        // would be for this place again.
        await until(
          player,
          () =>
              player.phase != MultiplayerPhase.playing ||
              player.selfGame!.currentIndex > index,
        );
        player.dismissResult();
      }
    }

    await until(eva, () => eva.phase == MultiplayerPhase.results);
    await until(adam, () => adam.phase == MultiplayerPhase.results);
    final game = eva.lobby!.game!;
    expect(game.status, GameStatus.finished);
    expect(game.leaderboard, hasLength(2));
    expect([for (final r in game.leaderboard!) r.rank], [1, 2]);
    expect(game.places, hasLength(2));
    expect(game.guesses!.keys, containsAll(game.participantIds));
    expect(game.self!.rounds, hasLength(2));
    expect(game.leaderboard!.first.finishedAt, isNotNull);

    adam.returnToLobby();
    await until(adam, () => adam.phase == MultiplayerPhase.lobby);
    adam.leave();
    await until(eva, () => eva.lobby!.players.length == 1);
    eva.leave();
  }, skip: skip);

  test(
    'a stale seat and a bad token are answered as the contract says',
    () async {
      final connection = await connect();
      final messages = <ServerMessage>[];
      final subscription = connection.messages.listen(messages.add);
      addTearDown(subscription.cancel);
      addTearDown(connection.close);
      connection.send(
        const HelloMessage(nickname: 'Smoke', resumeToken: 'no-such-seat'),
      );
      connection.send(const PingMessage());
      await Future<void>.delayed(const Duration(milliseconds: 500));
      expect(messages.whereType<ErrorMessage>().map((e) => e.code), [
        'resume.invalid',
      ]);
      expect(messages.whereType<WelcomeMessage>(), hasLength(1));
      expect(messages.whereType<StateMessage>().single.lobby, isNull);
      expect(messages.whereType<PongMessage>(), hasLength(1));

      final second = await connect();
      final secondMessages = <ServerMessage>[];
      final secondSubscription = second.messages.listen(secondMessages.add);
      addTearDown(secondSubscription.cancel);
      addTearDown(second.close);
      second.send(const HelloMessage(token: 'not-a-jwt'));
      second.send(const JoinLobbyMessage('ZZZZZZ'));
      await Future<void>.delayed(const Duration(milliseconds: 500));
      expect(secondMessages.whereType<ErrorMessage>().map((e) => e.code), [
        'auth.invalid_token',
        'hello.required',
      ]);
    },
    skip: skip,
  );

  test('a signed-in player plays under the account name', () async {
    final player = controller(token: () => jwt);
    await player.start();
    await player.createLobby();
    await until(player, () => player.phase == MultiplayerPhase.lobby);
    expect(player.lobby!.self!.isGuest, isFalse);
    expect(player.nickname, isNotEmpty);
    player.leave();
  }, skip: skip ?? (jwt == null ? 'Set MULTIPLAYER_SMOKE_JWT' : null));

  test(
    'a signed-in player with an expired seat joins its lobby again',
    () async {
      final host = controller();
      await host.start();
      await host.createLobby(nickname: 'Host Smoke');
      await until(host, () => host.phase == MultiplayerPhase.lobby);
      final code = host.lobby!.code;

      final player = MultiplayerController(
        connect: connect,
        store: MemoryMultiplayerStore(
          seat: StoredSeat(
            resumeToken: 'expired-seat',
            lobbyCode: code,
            owner: MultiplayerController.guestIdentity,
          ),
        ),
        token: () => jwt,
      );
      addTearDown(player.dispose);
      final notices = <MultiplayerNotice>[];
      final subscription = player.notices.listen(notices.add);
      addTearDown(subscription.cancel);
      await player.start();
      await until(player, () => player.phase == MultiplayerPhase.lobby);
      expect(player.lobby!.code, code);
      await Future<void>.delayed(const Duration(milliseconds: 300));
      expect(notices, isEmpty);
      player.leave();
      host.leave();
    },
    skip: skip ?? (jwt == null ? 'Set MULTIPLAYER_SMOKE_JWT' : null),
  );
}
