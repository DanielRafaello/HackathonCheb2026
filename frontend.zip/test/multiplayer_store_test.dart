import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:kde_na_zapade/multiplayer/multiplayer_store.dart';
import 'package:kde_na_zapade/multiplayer/tab_storage.dart';

/// A browser tab's `sessionStorage`.
class FakeTabStorage implements TabStorage {
  final values = <String, String>{};

  @override
  String? read(String key) => values[key];

  @override
  void write(String key, String? value) =>
      value == null ? values.remove(key) : values[key] = value;
}

const seat = StoredSeat(
  resumeToken: 'resume-1',
  lobbyCode: 'K7M2QX',
  owner: 'account:7',
);

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('keeps the seat and who took it', () async {
    final store = SharedPreferencesMultiplayerStore();

    await store.writeSeat(seat);
    final read = await SharedPreferencesMultiplayerStore().readSeat();

    expect(read!.resumeToken, 'resume-1');
    expect(read.lobbyCode, 'K7M2QX');
    expect(read.owner, 'account:7');

    await store.writeSeat(null);
    expect(await store.readSeat(), isNull);
  });

  test('a seat stored without its owner is not taken back', () async {
    SharedPreferences.setMockInitialValues({
      SharedPreferencesMultiplayerStore.resumeTokenKey: 'resume-1',
      SharedPreferencesMultiplayerStore.lobbyCodeKey: 'K7M2QX',
    });

    expect(await SharedPreferencesMultiplayerStore().readSeat(), isNull);
  });

  test('on the web the seat stays in its tab', () async {
    final tab = FakeTabStorage();
    final store = SharedPreferencesMultiplayerStore(tab: tab);

    await store.writeSeat(seat);
    await store.writeNickname('Eva');

    // Another tab shares the preferences, but not the seat.
    final otherTab = SharedPreferencesMultiplayerStore(tab: FakeTabStorage());
    expect(await otherTab.readSeat(), isNull);
    expect(await otherTab.readNickname(), 'Eva');
    expect((await store.readSeat())!.resumeToken, 'resume-1');
    expect(tab.values, hasLength(3));

    await store.writeSeat(null);
    expect(tab.values, isEmpty);
  });
}
