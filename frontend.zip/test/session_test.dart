import 'dart:async';
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

import 'package:kde_na_zapade/account/account_api.dart';
import 'package:kde_na_zapade/account/session.dart';
import 'package:kde_na_zapade/account/token_storage.dart';
import 'package:kde_na_zapade/config/api_config.dart';

import 'multiplayer_store_test.dart' show FakeTabStorage;

/// A fake backend with one account, `eva@example.cz` / `tajneheslo`.
class FakeBackend {
  final requests = <http.Request>[];
  var issued = 0;
  final validRefreshTokens = <String>{};
  final validTokens = <String>{};

  Map<String, Object> _tokens() {
    issued++;
    validTokens.add('jwt$issued');
    validRefreshTokens.add('refresh$issued');
    return {
      'token': 'jwt$issued',
      'refresh_token': 'refresh$issued',
      'user': {
        'id': 1,
        'name': 'Eva',
        'email': 'eva@example.cz',
        'role': 'user',
      },
    };
  }

  http.Response _json(Object body, int status) => http.Response(
    jsonEncode(body),
    status,
    headers: {'content-type': 'application/json; charset=utf-8'},
  );

  late final client = MockClient((request) async {
    requests.add(request);
    final body = request.body.isEmpty
        ? const {}
        : jsonDecode(request.body) as Map<String, dynamic>;
    switch (request.url.path) {
      case '/api/auth/login':
        if (body['email'] == 'eva@example.cz' &&
            body['password'] == 'tajneheslo') {
          return _json(_tokens(), 200);
        }
        return _json({'error': true, 'status': 401, 'message': 'x'}, 401);
      case '/api/auth/register':
        if (body['email'] == 'eva@example.cz') {
          return _json({
            'error': true,
            'status': 422,
            'errors': {'email': 'auth.register.email_taken'},
          }, 422);
        }
        return _json(_tokens(), 201);
      case '/api/auth/refresh':
        if (validRefreshTokens.remove(body['refreshToken'])) {
          return _json(_tokens(), 200);
        }
        return _json({'error': true, 'status': 401}, 401);
      case '/api/auth/logout':
        validRefreshTokens.remove(body['refreshToken']);
        return _json({'logged_out': true}, 200);
      case '/api/me':
        final token = request.headers['Authorization']?.substring(7);
        if (validTokens.contains(token)) {
          return _json({
            'user': {'id': 1, 'name': 'Eva', 'email': 'eva@example.cz'},
          }, 200);
        }
        return _json({'error': true, 'status': 401}, 401);
    }
    return _json({'error': true, 'status': 404}, 404);
  });
}

void main() {
  late FakeBackend backend;
  late MemoryTokenStorage storage;

  Session newSession() => Session(
    api: AccountApi(
      config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api/')),
      client: backend.client,
    ),
    storage: storage,
  );

  /// Sends a copy of [request] to the fake backend; a request is sent once.
  Future<http.Response> forward(http.Request request) => backend.client
      .send(
        http.Request(request.method, request.url)
          ..headers.addAll(request.headers)
          ..body = request.body,
      )
      .then(http.Response.fromStream);

  setUp(() {
    backend = FakeBackend();
    storage = MemoryTokenStorage();
  });

  test('a new player is a guest', () async {
    final session = newSession();
    await session.restore();

    expect(session.isRestored, isTrue);
    expect(session.isSignedIn, isFalse);
    expect(backend.requests, isEmpty);
  });

  test('sign-in keeps the account and its tokens', () async {
    final session = newSession();
    await session.signIn(email: ' eva@example.cz ', password: 'tajneheslo');

    expect(session.account?.nickname, 'Eva');
    expect(session.token, 'jwt1');
    expect(storage.tokens?.refreshToken, 'refresh1');
  });

  test('a wrong password is refused and stores nothing', () async {
    final session = newSession();

    await expectLater(
      session.signIn(email: 'eva@example.cz', password: 'spatne'),
      throwsA(
        isA<AccountApiException>().having(
          (e) => e.kind,
          'kind',
          AccountErrorKind.unauthorized,
        ),
      ),
    );
    expect(session.isSignedIn, isFalse);
    expect(storage.tokens, isNull);
  });

  test('registration sends the nickname and the password twice', () async {
    final session = newSession();
    await session.register(
      nickname: 'Petr',
      email: 'petr@example.cz',
      password: 'dlouheheslo',
    );

    expect(session.isSignedIn, isTrue);
    final sent = jsonDecode(backend.requests.single.body);
    expect(sent, {
      'name': 'Petr',
      'email': 'petr@example.cz',
      'password': 'dlouheheslo',
      'password_confirm': 'dlouheheslo',
    });
  });

  test('a used e-mail comes back as a field error', () async {
    final session = newSession();

    await expectLater(
      session.register(
        nickname: 'Eva',
        email: 'eva@example.cz',
        password: 'dlouheheslo',
      ),
      throwsA(
        isA<AccountApiException>()
            .having((e) => e.kind, 'kind', AccountErrorKind.invalid)
            .having((e) => e.fieldErrors['email'], 'email', [
              'auth.register.email_taken',
            ]),
      ),
    );
  });

  test('the next start resumes the session', () async {
    await newSession().signIn(email: 'eva@example.cz', password: 'tajneheslo');

    final session = newSession();
    await session.restore();

    expect(session.account?.email, 'eva@example.cz');
  });

  test('an expired JWT is refreshed at start', () async {
    await newSession().signIn(email: 'eva@example.cz', password: 'tajneheslo');
    backend.validTokens.clear();

    final session = newSession();
    await session.restore();

    expect(session.isSignedIn, isTrue);
    expect(session.token, 'jwt2');
    expect(storage.tokens?.refreshToken, 'refresh2');
  });

  test('a rejected refresh token signs the player out', () async {
    await newSession().signIn(email: 'eva@example.cz', password: 'tajneheslo');
    backend.validTokens.clear();
    backend.validRefreshTokens.clear();

    final session = newSession();
    await session.restore();

    expect(session.isSignedIn, isFalse);
    expect(storage.tokens, isNull);
  });

  test('sign-out revokes the refresh token and forgets the tokens', () async {
    final session = newSession();
    await session.signIn(email: 'eva@example.cz', password: 'tajneheslo');
    await session.signOut();

    expect(session.isSignedIn, isFalse);
    expect(storage.tokens, isNull);
    expect(backend.validRefreshTokens, isEmpty);
  });

  test(
    'sign-out ends the session at once, without waiting for the backend',
    () async {
      final logout = Completer<http.Response>();
      final session = Session(
        api: AccountApi(
          config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api/')),
          client: MockClient(
            (request) => request.url.path == '/api/auth/logout'
                ? logout.future
                : forward(request),
          ),
        ),
        storage: storage,
      );
      await session.signIn(email: 'eva@example.cz', password: 'tajneheslo');

      final signingOut = session.signOut();
      await Future<void>.delayed(Duration.zero);

      expect(session.isSignedIn, isFalse);
      expect(storage.tokens, isNull);
      logout.complete(http.Response('{}', 200));
      await signingOut;
    },
  );

  test('a request without an answer counts as no connection', () async {
    final api = AccountApi(
      config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api/')),
      client: MockClient((_) => Completer<http.Response>().future),
      timeout: const Duration(milliseconds: 20),
    );

    await expectLater(
      api.login(email: 'eva@example.cz', password: 'tajneheslo'),
      throwsA(
        isA<AccountApiException>().having(
          (e) => e.kind,
          'kind',
          AccountErrorKind.network,
        ),
      ),
    );
  });

  test('a success that is not an account is a server error', () async {
    final api = AccountApi(
      config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api/')),
      client: MockClient((_) async => http.Response('<html></html>', 200)),
    );

    await expectLater(
      api.login(email: 'eva@example.cz', password: 'tajneheslo'),
      throwsA(
        isA<AccountApiException>().having(
          (e) => e.kind,
          'kind',
          AccountErrorKind.server,
        ),
      ),
    );
  });

  test('a late refresh of an old session does not end a new one', () async {
    final refresh = Completer<http.Response>();
    final session = Session(
      api: AccountApi(
        config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api/')),
        client: MockClient(
          (request) => request.url.path == '/api/auth/refresh'
              ? refresh.future
              : forward(request),
        ),
      ),
      storage: storage,
    );
    await session.signIn(email: 'eva@example.cz', password: 'tajneheslo');

    final refreshing = session.refresh();
    await session.signOut();
    await session.signIn(email: 'eva@example.cz', password: 'tajneheslo');
    refresh.complete(http.Response('{"error":true,"status":401}', 401));

    expect(await refreshing, isTrue);
    expect(session.isSignedIn, isTrue);
    expect(session.token, 'jwt2');
    expect(storage.tokens?.token, 'jwt2');
  });

  test('without a connection the stored session is kept', () async {
    storage.tokens = const StoredTokens(token: 'jwt', refreshToken: 'r');
    final session = Session(
      api: AccountApi(
        config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api')),
        client: MockClient((_) => throw http.ClientException('offline')),
      ),
      storage: storage,
    );
    await session.restore();

    expect(session.isRestored, isTrue);
    expect(storage.tokens, isNotNull);
  });

  group('the guest choice in a browser tab', () {
    Session tabSession(FakeTabStorage tab) => Session(
      api: AccountApi(
        config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api/')),
        client: backend.client,
      ),
      storage: storage,
      tab: tab,
    );

    test('survives a reload of the page', () async {
      final tab = FakeTabStorage();
      final before = tabSession(tab);
      await before.restore();
      before.continueAsGuest();

      final reloaded = tabSession(tab);
      await reloaded.restore();
      expect(reloaded.isGuest, isTrue);
      expect(reloaded.hasEntered, isTrue);
    });

    test('a new tab asks again', () async {
      final first = tabSession(FakeTabStorage());
      await first.restore();
      first.continueAsGuest();

      final other = tabSession(FakeTabStorage());
      await other.restore();
      expect(other.hasEntered, isFalse);
    });

    test('sign-out forgets it', () async {
      final tab = FakeTabStorage();
      final session = tabSession(tab);
      await session.restore();
      session.continueAsGuest();
      await session.signOut();

      final reloaded = tabSession(tab);
      await reloaded.restore();
      expect(reloaded.hasEntered, isFalse);
    });
  });
}
