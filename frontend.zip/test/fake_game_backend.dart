import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

import 'package:kde_na_zapade/account/account_api.dart';
import 'package:kde_na_zapade/account/session.dart';
import 'package:kde_na_zapade/account/token_storage.dart';
import 'package:kde_na_zapade/api/authorized_client.dart';
import 'package:kde_na_zapade/config/api_config.dart';
import 'package:kde_na_zapade/my_map/locations_api.dart';

/// A place as `GET /locations` lists it: no district, the flags beside the
/// timestamps (API_SPECIFICATION.md 4.1).
Map<String, Object?> locationJson(
  int id, {
  String? district,
  String? guessedAt,
  String? visitedAt,
  double latitude = 50.08,
  double longitude = 12.37,
  int? rating,
  double? averageRating,
  int ratingCount = 0,
}) => {
  'id': id,
  'name': 'Místo $id',
  'latitude': latitude,
  'longitude': longitude,
  'district': ?district,
  'guessed': guessedAt != null,
  'guessed_at': guessedAt,
  'visited': visitedAt != null,
  'visited_at': visitedAt,
  'rating': rating,
  'rated_at': rating == null ? null : '2026-10-02T11:00:00Z',
  'average_rating': averageRating,
  'rating_count': ratingCount,
};

/// A JSON response in UTF-8, as the backend sends it.
http.Response jsonResponse(Object body, [int status = 200]) =>
    http.Response.bytes(
      utf8.encode(jsonEncode(body)),
      status,
      headers: {'content-type': 'application/json; charset=utf-8'},
    );

/// The Game API as the tests see it: one account whose tokens are
/// `jwt<n>` / `refresh<n>`, the locations endpoints over [places], and
/// today's round as [daily] says.
class FakeGameBackend {
  FakeGameBackend({List<Map<String, Object?>>? places})
    : places = places ?? [locationJson(1), locationJson(2)];

  static final config = ApiConfig(
    baseUrl: Uri.parse('https://example.cz/api/'),
  );

  final List<Map<String, Object?>> places;
  final requests = <http.Request>[];
  var issued = 1;
  final validTokens = <String>{'jwt1'};
  final validRefreshTokens = <String>{'refresh1'};

  /// The answer to `GET /rounds/daily`; null throws a network error.
  http.Response? Function() daily = () => jsonResponse({
    'round': {
      'id': 15,
      'status': 'active',
      'daily_date': '2026-10-10',
      'attempts_used': 0,
      'attempts_remaining': 5,
      'max_attempts': 5,
      'stars': null,
      'clues': [],
      'completed_at': null,
      'last_guess': null,
    },
  });

  /// What `GET /locations` answers instead of the places, when set.
  http.Response? Function()? locations;

  /// What `POST /locations/{id}/progress` answers instead of marking the
  /// place, when set.
  http.Response? Function()? progress;

  /// What `GET /locations/{id}/description` answers instead of the card,
  /// when set.
  http.Response? Function()? description;

  /// The wafer balance `GET /me` reports.
  int wafers = 112;

  /// The time the backend stamps on a visit.
  String visitedAt = '2026-10-10T10:00:00Z';

  Map<String, Object> _tokens() {
    issued++;
    validTokens.add('jwt$issued');
    validRefreshTokens.add('refresh$issued');
    return {
      'token': 'jwt$issued',
      'refresh_token': 'refresh$issued',
      'user': {'id': 1, 'name': 'Eva', 'email': 'eva@example.cz'},
    };
  }

  http.Response _error(int status, [String? message]) => jsonResponse({
    'error': true,
    'status': status,
    'message': ?message,
  }, status);

  late final client = MockClient((request) async {
    requests.add(request);
    final path = request.url.path;
    if (path == '/api/auth/refresh') {
      final body = jsonDecode(request.body) as Map<String, dynamic>;
      if (validRefreshTokens.remove(body['refreshToken'])) {
        return jsonResponse(_tokens());
      }
      return _error(401);
    }
    final token = request.headers['Authorization']?.substring(7);
    if (!validTokens.contains(token)) return _error(401);
    if (path == '/api/me') {
      return jsonResponse({
        'user': {
          'id': 1,
          'name': 'Eva',
          'email': 'eva@example.cz',
          'wafers': wafers,
        },
      });
    }
    if (path == '/api/locations') {
      final override = locations?.call();
      if (locations != null) return override ?? _offline();
      return jsonResponse({'locations': places});
    }
    final progressMatch = RegExp(r'^/api/locations/(\d+)/progress$')
        .firstMatch(path);
    if (progressMatch != null && request.method == 'POST') {
      final override = progress?.call();
      if (progress != null) return override ?? _offline();
      final id = int.parse(progressMatch.group(1)!);
      final body = jsonDecode(request.body) as Map<String, dynamic>;
      for (final place in places) {
        if (place['id'] != id) continue;
        var wafers = 0;
        if (body['state'] == 'visited') {
          if (place['visited'] != true) wafers = 50;
          place['visited'] = true;
          place['visited_at'] ??= visitedAt;
        } else if (body['state'] == 'guessed') {
          place['guessed'] = true;
          place['guessed_at'] ??= visitedAt;
        } else {
          return _error(422, 'Validation failed.');
        }
        return jsonResponse({'location': place, 'wafers_earned': wafers});
      }
      return _error(404, 'not.found.location');
    }
    final descriptionMatch = RegExp(r'^/api/locations/(\d+)/description$')
        .firstMatch(path);
    if (descriptionMatch != null && request.method == 'GET') {
      final override = description?.call();
      if (description != null) return override ?? _offline();
      final id = int.parse(descriptionMatch.group(1)!);
      for (final place in places) {
        if (place['id'] != id) continue;
        if (place['guessed'] != true && place['visited'] != true) {
          return _error(403, 'location.in_fog');
        }
        return jsonResponse({
          'location': {
            'id': id,
            'name': place['name'],
            'latitude': place['latitude'],
            'longitude': place['longitude'],
            'category': 'Hrady, tvrze a zříceniny',
            'description': 'Popis místa $id.',
            'content_source_url': null,
            'source': {
              'title': 'Hrady',
              'publisher': 'datazapad.cz',
              'portal_url': 'https://datazapad.cz',
              'license_code': 'CC BY 4.0',
              'license_url': 'https://creativecommons.org/licenses/by/4.0/',
              'attribution_text': 'Zdroj: datazapad.cz',
              'retrieved_at': null,
              'source_updated_at': null,
            },
          },
        });
      }
      return _error(404, 'not.found.location');
    }
    final ratingMatch = RegExp(r'^/api/locations/(\d+)/rating$')
        .firstMatch(path);
    if (ratingMatch != null && request.method == 'PUT') {
      final id = int.parse(ratingMatch.group(1)!);
      final body = jsonDecode(request.body) as Map<String, dynamic>;
      final stars = body['rating'];
      if (stars is! int || stars < 1 || stars > 5) {
        return _error(422, 'Validation failed.');
      }
      for (final place in places) {
        if (place['id'] != id) continue;
        if (place['visited'] != true) {
          return _error(422, 'location.not_visited');
        }
        final count = place['rating_count'] as int;
        final average = (place['average_rating'] as num?)?.toDouble() ?? 0;
        final own = place['rating'] as int?;
        final total = average * count - (own ?? 0) + stars;
        final newCount = count + (own == null ? 1 : 0);
        place['rating'] = stars;
        place['rated_at'] = visitedAt;
        place['rating_count'] = newCount;
        place['average_rating'] = total / newCount;
        return jsonResponse({'location': place});
      }
      return _error(404, 'not.found.location');
    }
    if (path == '/api/rounds/daily') return daily() ?? _offline();
    return _error(404);
  });

  Never _offline() => throw http.ClientException('offline');

  /// Requests to [path], by method.
  List<http.Request> sent(String path, {String? method}) => [
    for (final request in requests)
      if (request.url.path == '/api$path' &&
          (method == null || request.method == method))
        request,
  ];
}

/// A session signed in against [backend] with `jwt1`, restored as at an
/// app start.
Future<Session> signedInSession(FakeGameBackend backend) async {
  final session = Session(
    api: AccountApi(config: FakeGameBackend.config, client: backend.client),
    storage: MemoryTokenStorage()
      ..tokens = const StoredTokens(token: 'jwt1', refreshToken: 'refresh1'),
  );
  await session.restore();
  backend.requests.clear();
  return session;
}

AuthorizedClient authorizedClient(FakeGameBackend backend, Session session) =>
    AuthorizedClient(
      config: FakeGameBackend.config,
      session: session,
      client: backend.client,
    );

Future<LocationsApi> locationsApi(FakeGameBackend backend) async =>
    LocationsApi(
      client: authorizedClient(backend, await signedInSession(backend)),
    );
