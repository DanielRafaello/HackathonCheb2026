import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/config/api_config.dart';

void main() {
  test('a debug build calls the local backend', () {
    expect(
      ApiConfig.defaultBaseUrl(
        debug: true,
        web: true,
        platform: TargetPlatform.android,
      ),
      ApiConfig.local,
    );
    expect(
      ApiConfig.defaultBaseUrl(
        debug: true,
        web: false,
        platform: TargetPlatform.iOS,
      ),
      ApiConfig.local,
    );
    expect(
      ApiConfig.defaultBaseUrl(
        debug: true,
        web: false,
        platform: TargetPlatform.android,
      ),
      ApiConfig.localFromAndroidEmulator,
    );
  });

  test('a release build calls the deployed backend', () {
    for (final web in [true, false]) {
      expect(
        ApiConfig.defaultBaseUrl(
          debug: false,
          web: web,
          platform: TargetPlatform.android,
        ),
        ApiConfig.production,
      );
    }
  });

  test('resolves endpoints on a local backend without a prefix', () {
    final config = ApiConfig(baseUrl: Uri.parse('http://localhost:8080'));

    expect(
      config.resolve('auth/login').toString(),
      'http://localhost:8080/auth/login',
    );
    expect(config.resolve('me').toString(), 'http://localhost:8080/me');
  });

  test('resolves endpoints under the deployed /api prefix', () {
    final config = ApiConfig(
      baseUrl: Uri.parse('https://aether217.zcu.cz/api/'),
    );

    expect(
      config.resolve('auth/login').toString(),
      'https://aether217.zcu.cz/api/auth/login',
    );
  });
}
