import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/map/map_gestures.dart';

/// Records the touches the map wins, as a platform view would get them.
class _RecordingRecognizer extends MapGestureRecognizer {
  _RecordingRecognizer({required super.pans});

  final won = <int>[];

  @override
  void acceptGesture(int pointer) => won.add(pointer);
}

const _mapKey = ValueKey('map');

void main() {
  late _RecordingRecognizer recognizer;
  late ScrollController scroll;

  /// A scrolling page with a 300 px tall map below a 100 px header.
  Future<void> pumpPage(WidgetTester tester, {required bool pans}) async {
    scroll = ScrollController();
    addTearDown(scroll.dispose);
    await tester.pumpWidget(
      MaterialApp(
        home: ListView(
          controller: scroll,
          children: [
            const SizedBox(height: 100),
            RawGestureDetector(
              key: _mapKey,
              behavior: HitTestBehavior.opaque,
              gestures: {
                _RecordingRecognizer:
                    GestureRecognizerFactoryWithHandlers<_RecordingRecognizer>(
                      () => recognizer = _RecordingRecognizer(pans: () => pans),
                      (_) {},
                    ),
              },
              child: const SizedBox(height: 300),
            ),
            const SizedBox(height: 2000),
          ],
        ),
      ),
    );
  }

  Offset mapCentre(WidgetTester tester) =>
      tester.getCenter(find.byKey(_mapKey));

  testWidgets('a drag on a map that pans moves the map, not the page', (
    tester,
  ) async {
    await pumpPage(tester, pans: true);
    await tester.dragFrom(mapCentre(tester), const Offset(0, -120));
    await tester.pumpAndSettle();

    expect(scroll.offset, 0);
    expect(recognizer.won, isNotEmpty);
  });

  testWidgets('a drag on a fully zoomed-out map scrolls the page', (
    tester,
  ) async {
    await pumpPage(tester, pans: false);
    await tester.dragFrom(mapCentre(tester), const Offset(0, -120));
    await tester.pumpAndSettle();

    expect(scroll.offset, greaterThan(0));
    expect(recognizer.won, isEmpty);
  });

  testWidgets('two fingers on a fully zoomed-out map zoom it', (tester) async {
    await pumpPage(tester, pans: false);
    final centre = mapCentre(tester);
    final first = await tester.startGesture(centre - const Offset(0, 20));
    final second = await tester.startGesture(
      centre + const Offset(0, 20),
      pointer: 2,
    );
    await first.moveBy(const Offset(0, -60));
    await second.moveBy(const Offset(0, 60));
    await first.up();
    await second.up();
    await tester.pumpAndSettle();

    expect(scroll.offset, 0);
    expect(recognizer.won, isNotEmpty);
  });

  testWidgets('a scroll that starts above the map does not move the map', (
    tester,
  ) async {
    await pumpPage(tester, pans: true);
    // The page is at its top, so it stays and the finger slides from the
    // header onto the map.
    final gesture = await tester.startGesture(const Offset(400, 50));
    for (var i = 0; i < 10; i++) {
      await gesture.moveBy(const Offset(0, 20));
      await tester.pump();
    }
    expect(
      tester.getRect(find.byKey(_mapKey)).contains(const Offset(400, 250)),
      isTrue,
    );
    await gesture.up();
    await tester.pumpAndSettle();

    expect(recognizer.won, isEmpty);
  });

  testWidgets('a tap on a fully zoomed-out map reaches the map', (
    tester,
  ) async {
    await pumpPage(tester, pans: false);
    await tester.tapAt(mapCentre(tester));
    await tester.pumpAndSettle();

    expect(recognizer.won, hasLength(1));
  });
}
