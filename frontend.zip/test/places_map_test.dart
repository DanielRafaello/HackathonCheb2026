import 'dart:ui';

import 'package:flutter_test/flutter_test.dart';
import 'package:maplibre_gl/maplibre_gl.dart';

import 'package:kde_na_zapade/map/map_projection.dart';
import 'package:kde_na_zapade/my_map/my_map_place.dart';
import 'package:kde_na_zapade/my_map/places_map.dart';

/// Whether [node] is a `step` or `interpolate` whose input is the zoom.
bool _isZoomCurve(Object? node) {
  if (node is! List || node.isEmpty) return false;
  return switch (node.first) {
    'interpolate' => node.length > 2 && _isZoomInput(node[2]),
    'step' => node.length > 1 && _isZoomInput(node[1]),
    _ => false,
  };
}

bool _isZoomInput(Object? node) =>
    node is List && node.length == 1 && node.first == 'zoom';

/// Every zoom-based `step`/`interpolate` node inside [node], itself included.
int _zoomCurves(Object? node) {
  if (node is! List) return 0;
  return (_isZoomCurve(node) ? 1 : 0) +
      node.fold<int>(0, (sum, child) => sum + _zoomCurves(child));
}

/// Evaluates the subset of MapLibre expressions PlacesMap uses, for one
/// feature's `marker` at one [zoom].
num _evaluate(Object? node, {required String marker, required double zoom}) {
  if (node is num) return node;
  final list = node as List;
  Object? value(Object? n) => switch (n) {
    ['get', 'marker'] => marker,
    ['zoom'] => zoom,
    _ => _evaluate(n, marker: marker, zoom: zoom),
  };
  switch (list.first) {
    case 'match':
      final input = value(list[1]);
      for (var i = 2; i + 1 < list.length - 1; i += 2) {
        final label = list[i];
        if (label == input || (label is List && label.contains(input))) {
          return value(list[i + 1]) as num;
        }
      }
      return value(list.last) as num;
    case 'interpolate':
      expect(list[1], ['linear']);
      final x = value(list[2]) as num;
      final stops = list.sublist(3);
      if (x <= (stops.first as num)) return value(stops[1]) as num;
      for (var i = 0; i + 3 < stops.length; i += 2) {
        final x0 = stops[i] as num, x1 = stops[i + 2] as num;
        if (x <= x1) {
          final y0 = value(stops[i + 1]) as num;
          final y1 = value(stops[i + 3]) as num;
          return y0 + (y1 - y0) * (x - x0) / (x1 - x0);
        }
      }
      return value(stops.last) as num;
    default:
      throw UnsupportedError('${list.first}');
  }
}

void main() {
  group('PlacesMap layers', () {
    final layers = <String, Map<String, dynamic>>{
      'my-map-dots': PlacesMap.dotsLayer.toJson(),
      'my-map-flags': PlacesMap.flagsLayer.toJson(),
    };

    for (final MapEntry(key: layer, value: properties) in layers.entries) {
      for (final MapEntry(key: property, value: expression)
          in properties.entries) {
        test('$layer $property uses zoom only in one top-level curve', () {
          final curves = _zoomCurves(expression);
          expect(curves, lessThanOrEqualTo(1));
          if (curves == 1) expect(_isZoomCurve(expression), isTrue);
        });
      }
    }

    test('dots keep their radius per marker and zoom', () {
      final radius = PlacesMap.dotsLayer.toJson()['circle-radius'];
      num at(PlaceMarker marker, double zoom) =>
          _evaluate(radius, marker: marker.name, zoom: zoom);

      expect(at(PlaceMarker.guessed, 8), 6);
      expect(at(PlaceMarker.guessed, 13), 9);
      expect(at(PlaceMarker.guessed, 10.5), closeTo(7.5, 1e-9));
      expect(at(PlaceMarker.unknown, 8), 4);
      expect(at(PlaceMarker.unknown, 13), 7);
      expect(at(PlaceMarker.unknown, 5), 4);
      expect(at(PlaceMarker.unknown, 16), 7);
    });
  });

  group('PlacesMap.placeAt', () {
    const projection = MapProjection(
      target: LatLng(50.2, 12.7),
      zoom: 10,
      size: Size(400, 400),
    );

    /// A place drawn at [point] in the frame.
    MyMapPlace placeAt(int id, Offset point, PlaceMarker marker) {
      final position = projection.toPosition(point);
      return MyMapPlace(
        id: id,
        name: 'Místo $id',
        latitude: position.latitude,
        longitude: position.longitude,
        guessed: marker == PlaceMarker.guessed,
        visited: marker == PlaceMarker.visited,
      );
    }

    MyMapPlace? tap(Offset at, List<MyMapPlace> places) =>
        PlacesMap.placeAt(at, places, projection);

    test('a tap near a small dot hits it', () {
      final guessed = placeAt(1, const Offset(200, 200), PlaceMarker.guessed);

      expect(tap(const Offset(215, 210), [guessed])?.id, 1);
    });

    test('a tap beyond a fingertip misses', () {
      final guessed = placeAt(1, const Offset(200, 200), PlaceMarker.guessed);

      expect(tap(const Offset(230, 200), [guessed]), isNull);
    });

    test('the nearest of two places wins', () {
      final places = [
        placeAt(1, const Offset(200, 200), PlaceMarker.guessed),
        placeAt(2, const Offset(214, 200), PlaceMarker.guessed),
      ];

      expect(tap(const Offset(210, 200), places)?.id, 2);
    });

    test('a known place wins over a nearer place in the fog', () {
      final places = [
        placeAt(1, const Offset(200, 200), PlaceMarker.unknown),
        placeAt(2, const Offset(215, 200), PlaceMarker.guessed),
      ];

      expect(tap(const Offset(201, 200), places)?.id, 2);
    });

    test('a place in the fog is found when nothing known is near', () {
      final fog = placeAt(1, const Offset(200, 200), PlaceMarker.unknown);

      expect(tap(const Offset(205, 200), [fog])?.isUnknown, isTrue);
    });

    test('a tap on the flag above a visited place hits it', () {
      final visited = placeAt(1, const Offset(200, 200), PlaceMarker.visited);

      expect(tap(const Offset(200, 170), [visited])?.id, 1);
    });
  });
}
