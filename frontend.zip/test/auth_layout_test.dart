import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/account/auth_hero.dart';
import 'package:kde_na_zapade/account/auth_layout.dart';
import 'package:kde_na_zapade/design_system/design_system.dart';

void main() {
  // An iPhone 17 in logical pixels, and its keyboard with the bar above it.
  const screen = Size(402, 874);
  const keyboard = 336.0;
  const dpr = 3.0;

  Future<void> pumpSignIn(WidgetTester tester) async {
    tester.view
      ..devicePixelRatio = dpr
      ..physicalSize = screen * dpr;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(
      MaterialApp(
        home: AuthLayout(
          hero: AuthHero.signIn,
          title: const Text('Kde na západě'),
          subtitle: 'Přihlas se a tvoje mapa kraje zůstane s tebou.',
          footer: const Text('Zkusit bez účtu'),
          child: Column(
            children: [
              KnzTextField(
                label: 'E-mail',
                controller: TextEditingController(),
              ),
              const SizedBox(height: KnzSpace.s16),
              KnzTextField(
                label: 'Heslo',
                controller: TextEditingController(),
                password: true,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> openKeyboard(WidgetTester tester) async {
    tester.view.viewInsets = const FakeViewPadding(bottom: keyboard * dpr);
    // Past the focus scroll animation.
    for (var i = 0; i < 3; i++) {
      await tester.pump(const Duration(milliseconds: 200));
    }
  }

  testWidgets('the keyboard does not move the page', (tester) async {
    await pumpSignIn(tester);
    final footer = tester.getTopLeft(find.text('Zkusit bez účtu'));
    final title = tester.getTopLeft(find.text('Kde na západě'));

    await openKeyboard(tester);

    expect(tester.getTopLeft(find.text('Zkusit bez účtu')), footer);
    expect(tester.getTopLeft(find.text('Kde na západě')), title);
  });

  testWidgets('a focused field scrolls above the keyboard', (tester) async {
    await pumpSignIn(tester);
    await tester.tap(find.byType(TextField).last);
    await tester.pump();
    await openKeyboard(tester);

    final field = tester.getRect(find.byType(TextField).last);
    expect(field.bottom, lessThanOrEqualTo(screen.height - keyboard));
  });
}
