import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';

import 'package:kde_na_zapade/app_routes.dart';
import 'package:kde_na_zapade/home/game_modes_page.dart';

void main() {
  Future<void> pumpPage(WidgetTester tester) async {
    final router = GoRouter(
      initialLocation: AppRoutes.freePlay,
      routes: [
        GoRoute(
          path: AppRoutes.freePlay,
          builder: (context, state) => const Scaffold(body: GameModesPage()),
        ),
        GoRoute(
          path: AppRoutes.placeOfTheDay,
          builder: (context, state) => const Text('round'),
        ),
        GoRoute(
          path: AppRoutes.multiplayer,
          builder: (context, state) => const Text('multiplayer'),
        ),
      ],
    );
    addTearDown(router.dispose);
    await tester.pumpWidget(MaterialApp.router(routerConfig: router));
    await tester.pumpAndSettle();
  }

  testWidgets('lists the two mini games as tiles that fill the page', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await pumpPage(tester);

    expect(find.text('Minihry'), findsOneWidget);
    expect(find.text('Místo dne'), findsOneWidget);
    expect(find.text('Hra s kamarády'), findsOneWidget);
    expect(
      find.text('Stejná místa pro všechny, vyhraje nejpřesnější.'),
      findsOneWidget,
    );
    // The two tiles share the height under the heading.
    final first = tester.getRect(
      find
          .ancestor(
            of: find.text('Místo dne'),
            matching: find.byType(ConstrainedBox),
          )
          .first,
    );
    final second = tester.getRect(
      find
          .ancestor(
            of: find.text('Hra s kamarády'),
            matching: find.byType(ConstrainedBox),
          )
          .first,
    );
    expect(first.height, greaterThan(GameModesPage.minTileHeight));
    expect(first.height, closeTo(second.height, 1));
    expect(second.bottom, greaterThan(844 - 60));
  });

  testWidgets('a short screen scrolls instead of squeezing the tiles', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await pumpPage(tester);

    expect(tester.takeException(), isNull);
    final tile = tester.getRect(
      find
          .ancestor(
            of: find.text('Místo dne'),
            matching: find.byType(ConstrainedBox),
          )
          .first,
    );
    expect(tile.height, greaterThanOrEqualTo(GameModesPage.minTileHeight));
  });

  testWidgets('the place of the day opens the round', (tester) async {
    await pumpPage(tester);

    await tester.tap(find.text('Místo dne'));
    await tester.pumpAndSettle();

    expect(find.text('round'), findsOneWidget);
  });

  testWidgets('multiplayer opens the game with friends', (tester) async {
    await pumpPage(tester);

    await tester.tap(find.text('Hra s kamarády'));
    await tester.pumpAndSettle();

    expect(find.text('multiplayer'), findsOneWidget);
  });
}
