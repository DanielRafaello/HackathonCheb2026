import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:maplibre_gl/maplibre_gl.dart';

import 'package:kde_na_zapade/account/account_api.dart';
import 'package:kde_na_zapade/game/area.dart';
import 'package:kde_na_zapade/my_map/locations_api.dart';
import 'package:kde_na_zapade/my_map/my_map_page.dart';
import 'package:kde_na_zapade/my_map/my_map_place.dart';
import 'package:kde_na_zapade/my_map/my_map_summary.dart';
import 'package:kde_na_zapade/my_map/places_map.dart';
import 'package:kde_na_zapade/profile/badges.dart';
import 'package:kde_na_zapade/profile/profile_api.dart';
import 'package:kde_na_zapade/profile/profile_page.dart';

import 'fake_game_backend.dart';

MyMapPlace place(
  int id, {
  Area? area = Area.chebsko,
  DateTime? guessedAt,
  DateTime? visitedAt,
  int? rating,
  DateTime? ratedAt,
}) => MyMapPlace(
  id: id,
  name: 'Místo $id',
  latitude: 50.08,
  longitude: 12.37,
  area: area,
  guessedAt: guessedAt,
  visitedAt: visitedAt,
  rating: rating,
  ratedAt: ratedAt,
);

Matcher throwsLocationsError(LocationsErrorKind kind) =>
    throwsA(isA<LocationsApiException>().having((e) => e.kind, 'kind', kind));

void main() {
  group('MyMapPlace', () {
    test('parses a place without a district as one without an area', () {
      final parsed = MyMapPlace.fromJson(
        locationJson(7, guessedAt: '2026-10-09T21:13:43Z'),
      );

      expect(parsed.area, isNull);
      expect(parsed.guessedAt, DateTime.utc(2026, 10, 9, 21, 13, 43));
      expect(parsed.marker, PlaceMarker.guessed);
      expect(parsed.isVisited, isFalse);
      expect(parsed.ratingCount, 0);
      expect(parsed.rating, isNull);
    });

    test('takes the area from a district code when there is one', () {
      expect(
        MyMapPlace.fromJson(locationJson(1, district: 'CZ0413')).area,
        Area.sokolovsko,
      );
      expect(
        MyMapPlace.fromJson(locationJson(1, district: 'CZ9999')).area,
        isNull,
      );
    });

    test('believes the flags and falls back to the timestamps', () {
      final flagged = MyMapPlace.fromJson({
        ...locationJson(1),
        'visited': true,
        'visited_at': null,
      });
      expect(flagged.isVisited, isTrue);
      expect(flagged.visitedAt, isNull);

      final stamped = MyMapPlace.fromJson({
        ...locationJson(1, visitedAt: '2026-10-10T10:00:00Z')
          ..remove('visited')
          ..remove('guessed'),
      });
      expect(stamped.isVisited, isTrue);
      expect(stamped.isGuessed, isFalse);
    });
  });

  group('LocationsApi', () {
    test('lists the places with the bearer token', () async {
      final backend = FakeGameBackend(
        places: [
          locationJson(1, guessedAt: '2026-10-09T21:13:43Z'),
          locationJson(2),
        ],
      );
      final api = await locationsApi(backend);

      final places = await api.list();

      final sent = backend.sent('/locations').single;
      expect(sent.headers['Authorization'], 'Bearer jwt1');
      expect(places.map((p) => p.id), [1, 2]);
      expect(places[0].marker, PlaceMarker.guessed);
      expect(places[1].marker, PlaceMarker.unknown);
      expect(places.every((p) => p.area == null), isTrue);
    });

    test('refreshes an expired token once and retries', () async {
      final backend = FakeGameBackend();
      final api = await locationsApi(backend);
      backend.validTokens.clear();

      final places = await api.list();

      expect(places, hasLength(2));
      expect(backend.sent('/auth/refresh'), hasLength(1));
      expect(
        backend.sent('/locations').map((r) => r.headers['Authorization']),
        ['Bearer jwt1', 'Bearer jwt2'],
      );
    });

    test('gives up when the refresh fails', () async {
      final backend = FakeGameBackend();
      final api = await locationsApi(backend);
      backend.validTokens.clear();
      backend.validRefreshTokens.clear();

      await expectLater(
        api.list(),
        throwsLocationsError(LocationsErrorKind.unauthorized),
      );
      expect(backend.sent('/locations'), hasLength(1));
    });

    test('marks a place visited and returns it', () async {
      final backend = FakeGameBackend(
        places: [locationJson(1, guessedAt: '2026-10-09T21:13:43Z')],
      );
      final api = await locationsApi(backend);

      final (place: visited, :wafersEarned) = await api.markVisited(1);

      final sent = backend.sent('/locations/1/progress', method: 'POST');
      expect(jsonDecode(sent.single.body), {'state': 'visited'});
      expect(visited.marker, PlaceMarker.visited);
      expect(visited.visitedAt, DateTime.utc(2026, 10, 10, 10));
      expect(visited.guessedAt, DateTime.utc(2026, 10, 9, 21, 13, 43));
      expect(wafersEarned, 50);

      expect((await api.markVisited(1)).wafersEarned, 0);
    });

    test(
      'loads the texts of a guessed place but not of one in the fog',
      () async {
        final backend = FakeGameBackend(
          places: [
            locationJson(1, guessedAt: '2026-10-09T21:13:43Z'),
            locationJson(2),
          ],
        );
        final api = await locationsApi(backend);

        final card = await api.description(1);
        expect(card.description, 'Popis místa 1.');
        expect(card.source?.licenseCode, 'CC BY 4.0');

        // A 403 here is the fog, not a rejected session.
        await expectLater(
          api.description(2),
          throwsLocationsError(LocationsErrorKind.inFog),
        );
      },
    );

    test('maps a missing place, a failing backend and no connection', () async {
      final backend = FakeGameBackend();
      final api = await locationsApi(backend);

      await expectLater(
        api.markVisited(99),
        throwsLocationsError(LocationsErrorKind.notFound),
      );

      backend.locations = () => http.Response('oops', 500);
      await expectLater(
        api.list(),
        throwsLocationsError(LocationsErrorKind.server),
      );

      backend.locations = () => jsonResponse({'locations': 'nonsense'});
      await expectLater(
        api.list(),
        throwsLocationsError(LocationsErrorKind.server),
      );

      backend.locations = () => null;
      await expectLater(
        api.list(),
        throwsLocationsError(LocationsErrorKind.network),
      );
    });
  });

  group('MyMapSummary', () {
    final places = [
      place(1, guessedAt: DateTime.utc(2026, 10, 1)),
      place(
        2,
        area: Area.karlovarsko,
        guessedAt: DateTime.utc(2026, 10, 2),
        visitedAt: DateTime.utc(2026, 10, 5),
      ),
      place(3, area: Area.sokolovsko, visitedAt: DateTime.utc(2026, 10, 3)),
      place(4),
      place(5, area: Area.karlovarsko),
    ];

    test('counts guessed and visited independently', () {
      final summary = MyMapSummary.of(places);

      expect(summary.guessed, 2);
      expect(summary.visited, 2);
      expect(summary.unknown, 2);
    });

    test('counts known places out of all places per area', () {
      final summary = MyMapSummary.of(places);
      final areas = {for (final a in summary.areas) a.area: (a.known, a.total)};

      expect(summary.hasAreas, isTrue);
      expect(areas, {
        Area.chebsko: (1, 2),
        Area.sokolovsko: (1, 1),
        Area.karlovarsko: (1, 2),
      });
    });

    test('has no areas while no place has one', () {
      final summary = MyMapSummary.of([
        place(1, area: null, guessedAt: DateTime.utc(2026, 10, 1)),
        place(2, area: null),
      ]);

      expect(summary.guessed, 1);
      expect(summary.unknown, 1);
      expect(summary.hasAreas, isFalse);
      expect(summary.areas, isEmpty);
    });

    test('counts areas only over the places that have one', () {
      final summary = MyMapSummary.of([
        place(1, area: null, guessedAt: DateTime.utc(2026, 10, 1)),
        place(2, area: Area.chebsko, guessedAt: DateTime.utc(2026, 10, 1)),
        place(3, area: Area.chebsko),
      ]);

      expect(summary.hasAreas, isTrue);
      final chebsko = summary.areas.singleWhere((a) => a.area == Area.chebsko);
      expect((chebsko.known, chebsko.total), (1, 2));
    });

    test('filters by state; a visited and guessed place is in both', () {
      List<int> ids(MyMapFilter filter) => [
        for (final p in places)
          if (filter.includes(p)) p.id,
      ];

      expect(ids(MyMapFilter.all), [1, 2, 3, 4, 5]);
      expect(ids(MyMapFilter.unknown), [4, 5]);
      expect(ids(MyMapFilter.guessed), [1, 2]);
      expect(ids(MyMapFilter.visited), [2, 3]);
    });

    test('shows the flag for a place that is guessed and visited', () {
      expect(places[1].marker, PlaceMarker.visited);
    });
  });

  group('PlacesMap', () {
    test('fits the region by its tighter side', () {
      // 45° of longitude across 512 px is zoom 3 (512 px tiles).
      final wide = LatLngBounds(
        southwest: const LatLng(-1, 0),
        northeast: const LatLng(1, 45),
      );
      expect(PlacesMap.fitZoom(wide, const Size(512, 5000)), closeTo(3, 1e-9));
      expect(
        PlacesMap.fitZoom(wide, const Size(536, 5000), padding: 12),
        closeTo(3, 1e-9),
      );
      // Half the width: one zoom level out.
      expect(PlacesMap.fitZoom(wide, const Size(256, 5000)), closeTo(2, 1e-9));
    });

    test('centres on the Mercator middle of the region', () {
      final centre = PlacesMap.centre(
        LatLngBounds(
          southwest: const LatLng(-10, 10),
          northeast: const LatLng(10, 20),
        ),
      );
      expect(centre.latitude, closeTo(0, 1e-9));
      expect(centre.longitude, 15);

      // Further north, the Mercator middle lies north of the plain average.
      expect(
        PlacesMap.centre(PlacesMap.regionBounds).latitude,
        greaterThan(50.19),
      );
    });
  });

  group('BadgeProgress', () {
    test('earns a badge once the places reach its goal', () {
      final badges = {
        for (final b in BadgeProgress.of([
          place(1, guessedAt: DateTime.utc(2026, 10, 1)),
          place(2, visitedAt: DateTime.utc(2026, 10, 2)),
          place(3),
        ]))
          b.kind: b,
      };

      expect(badges[BadgeKind.firstHit]!.earned, isTrue);
      expect(badges[BadgeKind.tripper]!.earned, isTrue);
      final sharpEye = badges[BadgeKind.sharpEye]!;
      expect((sharpEye.count, sharpEye.goal, sharpEye.earned), (1, 10, false));
      final chebsko = badges[BadgeKind.wholeChebsko]!;
      expect((chebsko.count, chebsko.goal, chebsko.earned), (2, 3, false));
    });

    test('an area without places is not earned', () {
      final badges = BadgeProgress.of([place(1, area: Area.chebsko)]);
      final sokolovsko = badges.singleWhere(
        (b) => b.kind == BadgeKind.wholeSokolovsko,
      );

      expect(sokolovsko.earned, isFalse);
    });

    test('has no area badges while no place has an area', () {
      final kinds = BadgeProgress.of([place(1, area: null)]).map((b) => b.kind);

      expect(kinds, isNot(contains(BadgeKind.wholeChebsko)));
      expect(kinds, contains(BadgeKind.firstHit));
    });
  });

  group('MyMapPage', () {
    const eva = Account(id: 1, email: 'eva@example.cz', nickname: 'Eva');

    Future<List<List<MyMapPlace>>> pumpPage(
      WidgetTester tester, {
      required bool signedIn,
      List<MyMapPlace> places = const [],
      bool fails = false,
    }) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      tester.platformDispatcher.accessibilityFeaturesTestValue =
          const FakeAccessibilityFeatures(disableAnimations: true);
      addTearDown(
        tester.platformDispatcher.clearAccessibilityFeaturesTestValue,
      );
      final shown = <List<MyMapPlace>>[];
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: MyMapPage(
              account: signedIn ? eva : null,
              load: () async => fails
                  ? throw const LocationsApiException(LocationsErrorKind.server)
                  : places,
              mapBuilder: (places, onTap) {
                shown.add(places);
                return const SizedBox.expand();
              },
              onOpenPlace: (place) async {},
              onSignIn: () {},
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      return shown;
    }

    testWidgets('shows the counts and the number of places', (tester) async {
      await pumpPage(
        tester,
        signedIn: true,
        places: [
          place(1, guessedAt: DateTime.utc(2026, 10, 1)),
          place(2, visitedAt: DateTime.utc(2026, 10, 2)),
          place(3),
        ],
      );

      expect(find.text('Mapa kraje'), findsOneWidget);
      expect(find.text('3 místa'), findsOneWidget);
      expect(find.bySemanticsLabel('1 uhodnuto'), findsOneWidget);
      expect(find.bySemanticsLabel('1 navštíveno'), findsOneWidget);
      expect(find.bySemanticsLabel('1 neobjeveno'), findsOneWidget);
    });

    testWidgets('the filter narrows the places on the map', (tester) async {
      final shown = await pumpPage(
        tester,
        signedIn: true,
        places: [
          place(1, guessedAt: DateTime.utc(2026, 10, 1)),
          place(2),
        ],
      );
      expect(shown.last.map((p) => p.id), [1, 2]);

      await tester.tap(find.text('Neobjevené'));
      await tester.pumpAndSettle();

      expect(shown.last.map((p) => p.id), [2]);
    });

    testWidgets('shows zeros and the filters when loading fails', (
      tester,
    ) async {
      final shown = await pumpPage(tester, signedIn: true, fails: true);

      expect(
        find.text('Místa na mapě se nepodařilo načíst. Zkontroluj připojení.'),
        findsOneWidget,
      );
      expect(find.bySemanticsLabel('0 uhodnuto'), findsOneWidget);
      expect(find.bySemanticsLabel('0 neobjeveno'), findsOneWidget);
      expect(shown.last, isEmpty);

      await tester.tap(find.text('Uhodnuté'));
      await tester.pumpAndSettle();
      expect(shown.last, isEmpty);
    });

    testWidgets('asks a guest to sign in instead of loading', (tester) async {
      final shown = await pumpPage(tester, signedIn: false);

      expect(find.text('PŘIHLÁSIT SE'), findsOneWidget);
      expect(shown, isEmpty);
    });
  });

  group('ProfilePage', () {
    const eva = Account(id: 1, email: 'eva@example.cz', nickname: 'Eva');
    var signOuts = 0;
    var mapOpens = 0;
    var placeOpens = <int>[];

    Future<void> pumpPage(
      WidgetTester tester, {
      required bool signedIn,
      List<MyMapPlace> places = const [],
      bool fails = false,
      PlayerLevel level = const PlayerLevel(
        number: 1,
        points: 0,
        startsAt: 0,
        nextLevelAt: 250,
      ),
    }) async {
      signOuts = 0;
      mapOpens = 0;
      placeOpens = [];
      tester.view.physicalSize = const Size(390, 2400);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      // Vřídlík moves for as long as it is on screen; reduced motion stops
      // it so that the page can settle.
      tester.platformDispatcher.accessibilityFeaturesTestValue =
          const FakeAccessibilityFeatures(disableAnimations: true);
      addTearDown(
        tester.platformDispatcher.clearAccessibilityFeaturesTestValue,
      );
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: ProfilePage(
              account: signedIn ? eva : null,
              load: () async => fails
                  ? throw const LocationsApiException(LocationsErrorKind.server)
                  : places,
              loadLevel: () async =>
                  fails ? throw const ProfileApiException() : level,
              onOpenMap: () => mapOpens++,
              onOpenPlace: (place) async => placeOpens.add(place.id),
              onSignIn: () {},
              onSignOut: () => signOuts++,
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
    }

    testWidgets('shows the account, the summary and areas', (tester) async {
      await pumpPage(
        tester,
        signedIn: true,
        places: [
          place(1, guessedAt: DateTime.utc(2026, 10, 1)),
          place(
            2,
            area: Area.karlovarsko,
            visitedAt: DateTime.utc(2026, 10, 2),
          ),
          place(3),
        ],
      );

      expect(find.text('Eva'), findsOneWidget);
      expect(find.text('eva@example.cz'), findsOneWidget);
      expect(
        find.bySemanticsLabel(
          '1 uhodnuto, 1 navštíveno z 3 míst kraje. Otevřít mapu',
        ),
        findsOneWidget,
      );
      expect(find.text('Po oblastech'), findsOneWidget);
      expect(find.bySemanticsLabel('Chebsko: 1 z 2'), findsOneWidget);
    });

    testWidgets('the summary opens my map', (tester) async {
      await pumpPage(tester, signedIn: true);

      await tester.tap(find.text('Mapa ›'));

      expect(mapOpens, 1);
    });

    testWidgets('lists the rated places, the latest first', (tester) async {
      final visited = DateTime.utc(2026, 10, 1);
      await pumpPage(
        tester,
        signedIn: true,
        places: [
          place(
            1,
            visitedAt: visited,
            rating: 2,
            ratedAt: DateTime.utc(2026, 10, 2),
          ),
          place(2, visitedAt: visited),
          place(
            3,
            visitedAt: visited,
            rating: 5,
            ratedAt: DateTime.utc(2026, 10, 3),
          ),
        ],
      );

      expect(find.text('Tvoje hodnocení'), findsOneWidget);
      expect(find.text('Místo 2'), findsNothing);
      expect(
        tester.getTopLeft(find.text('Místo 3')).dy,
        lessThan(tester.getTopLeft(find.text('Místo 1')).dy),
      );
      // A tappable card reads as one link: the name, then the stars.
      expect(
        find.bySemanticsLabel(RegExp('Místo 3\\s+5\u00A0z\u00A05 hvězd')),
        findsOneWidget,
      );
      expect(
        find.bySemanticsLabel(RegExp('Místo 1\\s+2\u00A0z\u00A05 hvězd')),
        findsOneWidget,
      );

      await tester.tap(find.text('Místo 1'));
      await tester.pumpAndSettle();
      expect(placeOpens, [1]);
    });

    testWidgets('says when nothing is rated yet', (tester) async {
      await pumpPage(tester, signedIn: true, places: [place(1)]);

      expect(
        find.text(
          'Zatím tu nic není. Navštiv místo a\u00A0ohodnoť ho hvězdami.',
        ),
        findsOneWidget,
      );
    });

    testWidgets('shows earned and locked badges', (tester) async {
      await pumpPage(
        tester,
        signedIn: true,
        places: [
          place(1, guessedAt: DateTime.utc(2026, 10, 1)),
          place(2),
        ],
      );

      expect(find.textContaining('1 z 8'), findsOneWidget);
      expect(find.bySemanticsLabel('První trefa, získáno'), findsOneWidget);
      expect(
        find.bySemanticsLabel('Bystré oko, zamčeno, 1 z 10'),
        findsOneWidget,
      );
      expect(
        find.bySemanticsLabel('Celé Chebsko, zamčeno, 1 z 2'),
        findsOneWidget,
      );
    });

    testWidgets('shows the level and the points to the next one', (
      tester,
    ) async {
      await pumpPage(
        tester,
        signedIn: true,
        level: const PlayerLevel(
          number: 4,
          points: 2475,
          startsAt: 1500,
          nextLevelAt: 2500,
          wafers: 112,
        ),
      );

      expect(find.text('ÚROVEŇ 4'), findsOneWidget);
      expect(find.text('112\u00A0oplatek'), findsOneWidget);
      expect(find.bySemanticsLabel('Máš 112\u00A0oplatek'), findsOneWidget);
      expect(find.text('2 475 bodů'), findsOneWidget);
      expect(find.text('Do úrovně 5 ti chybí 25 bodů.'), findsOneWidget);
    });

    testWidgets('hides the level when it fails to load', (tester) async {
      await pumpPage(tester, signedIn: true, fails: true);

      expect(find.textContaining('ÚROVEŇ'), findsNothing);
    });

    testWidgets('hides the areas while no place has one', (tester) async {
      await pumpPage(
        tester,
        signedIn: true,
        places: [
          place(1, area: null, guessedAt: DateTime.utc(2026, 10, 1)),
          place(2, area: null),
        ],
      );

      expect(find.text('Po oblastech'), findsNothing);
      expect(find.textContaining('Chebsko'), findsNothing);
      expect(find.text('ODHLÁSIT SE'), findsOneWidget);
    });

    testWidgets('shows zeros and sign-out when loading fails', (tester) async {
      await pumpPage(tester, signedIn: true, fails: true);

      expect(
        find.text('Postup se nepodařilo načíst. Zkontroluj připojení.'),
        findsOneWidget,
      );
      expect(
        find.bySemanticsLabel('0 uhodnuto, 0 navštíveno. Otevřít mapu'),
        findsOneWidget,
      );
      expect(find.text('Po oblastech'), findsNothing);

      await tester.tap(find.text('ODHLÁSIT SE'));
      expect(signOuts, 1);
    });

    testWidgets('asks a guest to sign in instead of loading', (tester) async {
      await pumpPage(tester, signedIn: false);

      expect(find.text('PŘIHLÁSIT SE'), findsOneWidget);
      expect(find.text('ODHLÁSIT SE'), findsNothing);
    });
  });
}
