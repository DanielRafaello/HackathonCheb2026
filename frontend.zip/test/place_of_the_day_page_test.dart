import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/config/game_config.dart';
import 'package:kde_na_zapade/design_system/design_system.dart';
import 'package:kde_na_zapade/round/active_round_store.dart';
import 'package:kde_na_zapade/round/fake_round_api.dart';
import 'package:kde_na_zapade/round/place_of_the_day_page.dart';
import 'package:kde_na_zapade/round/round.dart';
import 'package:kde_na_zapade/round/round_api.dart';
import 'package:kde_na_zapade/theme.dart';

const target = GeoPoint(50.1859, 12.7541);
const near = GeoPoint(50.2579, 12.7541);
const onTarget = GeoPoint(50.1859, 12.7572);
const abroad = GeoPoint(49.95, 12.10);

FakePlace place({bool spring = false}) => FakePlace(
  card: PlaceCard(
    id: 1,
    name: 'Tajný hrad',
    type: spring ? 'Pramen' : 'Hrad',
    description: 'Hrad na skále.',
    location: target,
    source: 'datazapad.cz',
    licence: 'CC BY',
    isSpring: spring,
  ),
  clues: const [
    Clue(ClueKind.riddle, 'Stojí na skále nad řekou.'),
    Clue(ClueKind.placeType, 'Gotický hrad.'),
    Clue(ClueKind.numbers, 'Rok 1234.'),
    Clue(ClueKind.detail, 'Má meteorit.'),
  ],
);

/// A round API that answers like the Game API would: [daily] at first, and
/// [onGuess] to every guess. For the states the demo never reaches, such
/// as a failed round.
class ScriptedRoundApi implements RoundApi {
  ScriptedRoundApi({required this.daily, required this.onGuess});

  RoundState daily;
  final GuessOutcome Function(GeoPoint position) onGuess;

  @override
  Future<DailyRound> placeOfTheDay({String? resumeToken}) async =>
      DailyRoundReady(daily);

  @override
  Future<RoundState> refresh(String token) async => daily;

  @override
  Future<GuessOutcome> guess(String token, GeoPoint position) async {
    final outcome = onGuess(position);
    daily = switch (outcome) {
      GuessMissed(:final round) || GuessHit(:final round) => round,
      GuessOutsideRegion() => daily,
    };
    return outcome;
  }
}

/// The Game API's four clues, [unlocked] of them with text. The fourth
/// tile is a plain locked clue until it unlocks (`HttpRoundApi.clueOrder`).
List<Clue> backendClues(int unlocked) => [
  Clue(ClueKind.riddle, unlocked >= 1 ? 'Poklad pod podlahou kaple.' : null),
  Clue(ClueKind.placeType, unlocked >= 2 ? 'Hrady, tvrze a zříceniny' : null),
  Clue(ClueKind.area, unlocked >= 3 ? 'Karlovarsko' : null),
  unlocked >= 4
      ? const Clue(ClueKind.detail, 'Na nádvoří se konají výstavy.')
      : const Clue(ClueKind.other),
];

/// A backend round after [wrong] misses.
RoundState backendRound({
  required int wrong,
  GeoPoint? lastGuess,
  Compass? compass,
  RoundResult? result,
}) => RoundState(
  token: '15',
  day: DateTime.utc(2026, 10, 10),
  clues: backendClues(result == null ? wrong + 1 : 4),
  wrongGuesses: wrong,
  lastGuess: lastGuess,
  compass: compass,
  result: result,
);

const revealed = PlaceCard(
  id: 42,
  name: 'Hrad Loket',
  type: 'Hrady, tvrze a zříceniny',
  description: 'Gotický hrad na skále nad Ohří.',
  location: target,
  source: 'Zdroj: datazapad.cz',
  licence: 'CC BY 4.0',
);

/// The blind map's stand-in: on the full-screen map, a button puts the
/// pin at [Harness.nextPin].
class Harness {
  GeoPoint nextPin = near;
  final copied = <String>[];
  var closed = 0;

  Widget map(GuessMapView view) => Column(
    children: [
      Text(view.pin == null ? 'bez tipu' : 'tip položen'),
      if (view.lastGuess != null) const Text('minulý tip'),
      if (view.interactive)
        TextButton(
          onPressed: view.enabled ? () => view.onPin(nextPin) : null,
          child: const Text('Polož tip'),
        ),
    ],
  );
}

Future<Harness> pumpPage(
  WidgetTester tester, {
  RoundApi? api,
  bool spring = false,
  Size size = const Size(390, 844),
  bool animate = false,
}) async {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.reset);
  // Vřídlík moves for as long as it is on screen; reduced motion stops it
  // so that the page can settle.
  // With [animate], the page moves as on a device and never settles; the
  // test pumps frames itself.
  if (!animate) {
    tester.platformDispatcher.accessibilityFeaturesTestValue =
        const FakeAccessibilityFeatures(disableAnimations: true);
    addTearDown(tester.platformDispatcher.clearAccessibilityFeaturesTestValue);
  }
  final harness = Harness();
  await tester.pumpWidget(
    MaterialApp(
      theme: AppTheme.light,
      home: PlaceOfTheDayPage(
        api:
            api ??
            FakeRoundApi(
              places: [place(spring: spring)],
              clock: () => DateTime.utc(2026, 10, 10, 10),
              latency: Duration.zero,
            ),
        store: MemoryActiveRoundStore(),
        clock: () => DateTime.utc(2026, 10, 10, 10),
        mapBuilder: harness.map,
        onClose: () => harness.closed++,
        copyText: (text) async => harness.copied.add(text),
      ),
    ),
  );
  if (animate) {
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
  } else {
    await tester.pumpAndSettle();
  }
  return harness;
}

KnzButton button(WidgetTester tester, String label) => tester.widget(
  find.ancestor(of: find.text(label), matching: find.byType(KnzButton)),
);

/// Opens the full-screen map from the round screen.
Future<void> openMap(WidgetTester tester) async {
  await tester.tap(find.text('TIPNOUT NA MAPĚ'));
  await tester.pumpAndSettle();
}

/// Places the pin at [at] and confirms it, opening the full-screen map
/// first unless it is open already.
Future<void> guess(WidgetTester tester, Harness harness, GeoPoint at) async {
  if (find.text('Polož tip').evaluate().isEmpty) await openMap(tester);
  harness.nextPin = at;
  await tester.tap(find.text('Polož tip'));
  await tester.pump();
  await tester.tap(find.text('POTVRDIT TIP'));
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('starts with the first clue and the others locked', (
    tester,
  ) async {
    await pumpPage(tester);
    expect(find.text('MÍSTO DNE\u00A0· POKUS 1'), findsOneWidget);
    expect(find.text('KLÍČ 1 · HÁDANKA'), findsOneWidget);
    expect(find.text('Stojí na skále nad řekou.'), findsOneWidget);
    expect(find.text('Gotický hrad.'), findsNothing);
    for (final label in ['Typ', 'Čísla', 'Hádanka']) {
      expect(find.bySemanticsLabel('Zamčený klíč: $label'), findsOneWidget);
    }
    expect(find.text('Klepni na mapu a polož svůj tip.'), findsOneWidget);
    expect(find.text('Polož tip'), findsNothing);
    expect(button(tester, 'TIPNOUT NA MAPĚ').onPressed, isNotNull);
    expect(find.bySemanticsLabel('Hvězdy za trefu: 5'), findsOneWidget);
  });

  testWidgets('a tap on the map opens it over the whole screen for the '
      'guess', (tester) async {
    final harness = await pumpPage(tester);

    await tester.tap(find.bySemanticsLabel('Mapa kraje: zatím bez tipu'));
    await tester.pumpAndSettle();
    expect(find.text('Klepni do mapy a polož špendlík.'), findsOneWidget);
    expect(find.text('Stojí na skále nad řekou.'), findsNothing);
    expect(button(tester, 'POTVRDIT TIP').onPressed, isNull);

    harness.nextPin = near;
    await tester.tap(find.text('Polož tip'));
    await tester.pump();
    expect(find.textContaining(RegExp('^Tvůj tip')), findsOneWidget);
    expect(button(tester, 'POTVRDIT TIP').onPressed, isNotNull);

    // Back on the clues, the preview keeps the unconfirmed pin.
    await tester.tap(find.bySemanticsLabel('Zpět na klíče'));
    await tester.pumpAndSettle();
    expect(find.text('Stojí na skále nad řekou.'), findsOneWidget);
    expect(find.text('tip položen'), findsOneWidget);
    expect(find.text('POTVRDIT TIP'), findsNothing);

    // The pin is still there on the map, ready to confirm.
    await openMap(tester);
    expect(find.text('tip položen'), findsOneWidget);
    await tester.tap(find.text('POTVRDIT TIP'));
    await tester.pumpAndSettle();

    // The miss closes the map and shows its panel on the round screen.
    expect(find.text('Vedle! Máš nový klíč.'), findsOneWidget);
    expect(find.text('POTVRDIT TIP'), findsNothing);
    expect(find.text('minulý tip'), findsOneWidget);
    expect(harness.closed, 0);
  });

  testWidgets('a miss, another try, a hit, and sharing', (tester) async {
    final harness = await pumpPage(tester);

    await openMap(tester);
    harness.nextPin = near;
    await tester.tap(find.text('Polož tip'));
    await tester.pump();
    expect(find.textContaining(RegExp('^Tvůj tip: ')), findsOneWidget);
    expect(button(tester, 'POTVRDIT TIP').onPressed, isNotNull);

    await tester.tap(find.text('POTVRDIT TIP'));
    await tester.pumpAndSettle();
    expect(find.text('Vedle! Máš nový klíč.'), findsOneWidget);
    expect(find.text('NOVĚ ODEMČENO'), findsOneWidget);
    expect(find.text('Gotický hrad.'), findsOneWidget);
    expect(find.text('minulý tip'), findsOneWidget);
    expect(find.bySemanticsLabel('Hvězdy za trefu: 4'), findsOneWidget);
    // The map does not open while the panel is open.
    expect(find.text('TIPNOUT NA MAPĚ'), findsNothing);
    await tester.tap(find.text('minulý tip'));
    await tester.pumpAndSettle();
    expect(find.text('Polož tip'), findsNothing);

    await tester.tap(find.text('TIPNOUT ZNOVU'));
    await tester.pumpAndSettle();
    expect(find.text('MÍSTO DNE\u00A0· POKUS 2'), findsOneWidget);
    expect(find.text('KLÍČ 2\u00A0· TYP MÍSTA'), findsOneWidget);
    expect(find.text('bez tipu'), findsOneWidget);

    await guess(tester, harness, onTarget);
    expect(find.text('Trefa na 2. pokus!'), findsOneWidget);
    expect(find.bySemanticsLabel('4 z 5 hvězd'), findsOneWidget);
    expect(find.text('Tajný hrad'), findsOneWidget);
    expect(find.text('datazapad.cz · CC BY'), findsOneWidget);
    expect(find.text('2'), findsOneWidget);
    expect(find.text('2\u00A0/\u00A04'), findsOneWidget);
    expect(find.text('Voda není hygienicky sledovaná.'), findsNothing);
    expect(find.textContaining('Další místo dne bude za'), findsOneWidget);

    await tester.tap(find.text('SDÍLET'));
    await tester.pump();
    expect(harness.copied, hasLength(1));
    expect(harness.copied.single, isNot(contains('Tajný hrad')));
    expect(harness.copied.single, contains('Trefa na 2. pokus'));
    expect(
      find.text('Výsledek je ve schránce. Vlož ho, kam chceš.'),
      findsOneWidget,
    );

    await tester.tap(find.text('POKRAČOVAT'));
    expect(harness.closed, 1);
  });

  testWidgets('the miss panel waits for the map to slide away, and the '
      'clues come back with the new clue', (tester) async {
    final harness = await pumpPage(tester, animate: true);
    const settle = Duration(seconds: 1);

    await tester.tap(find.text('TIPNOUT NA MAPĚ'));
    await tester.pump();
    await tester.pump(settle);
    harness.nextPin = near;
    await tester.tap(find.text('Polož tip'));
    await tester.pump();
    await tester.tap(find.text('POTVRDIT TIP'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 50));

    // The map is still sliding away; the panel has not started to rise.
    expect(find.text('POTVRDIT TIP'), findsOneWidget);
    expect(find.text('TIPNOUT ZNOVU'), findsNothing);
    // The clues behind it keep the round before the guess, so the panel
    // is the first to show the new clue.
    expect(find.text('Gotický hrad.'), findsNothing);

    await tester.pump(settle);
    await tester.pump(settle);
    expect(find.text('POTVRDIT TIP'), findsNothing);
    expect(find.text('Vedle! Máš nový klíč.'), findsOneWidget);
    expect(find.text('TIPNOUT NA MAPĚ'), findsNothing);
    expect(find.text('Stojí na skále nad řekou.'), findsNothing);

    await tester.tap(find.text('TIPNOUT ZNOVU'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 50));
    // The panel sinks before the clues come back.
    expect(find.text('TIPNOUT ZNOVU'), findsOneWidget);

    await tester.pump(settle);
    expect(find.text('TIPNOUT ZNOVU'), findsNothing);
    expect(find.text('KLÍČ 2\u00A0· TYP MÍSTA'), findsOneWidget);
    expect(find.text('Gotický hrad.'), findsOneWidget);
    expect(button(tester, 'TIPNOUT NA MAPĚ').onPressed, isNotNull);
    expect(tester.takeException(), isNull);
  });

  testWidgets('a spring warns that its water is not monitored', (tester) async {
    final harness = await pumpPage(tester, spring: true);
    await guess(tester, harness, onTarget);
    expect(find.text('Voda není hygienicky sledovaná.'), findsOneWidget);
  });

  testWidgets('the compass turns on after the fourth miss', (tester) async {
    final harness = await pumpPage(tester);
    for (var i = 0; i < 3; i++) {
      await guess(tester, harness, near);
      await tester.tap(find.text('TIPNOUT ZNOVU'));
      await tester.pumpAndSettle();
    }
    expect(find.bySemanticsLabel(RegExp('^Kompas')), findsNothing);
    await guess(tester, harness, near);
    expect(find.text('Vedle! Kompas ti poradí.'), findsOneWidget);
    expect(
      find.bySemanticsLabel('Kompas: cíl leží na jih od tvého posledního tipu'),
      findsOneWidget,
    );
    expect(find.bySemanticsLabel('Hvězdy za trefu: 1'), findsOneWidget);
    expect(find.bySemanticsLabel('Pokus 5, kompas je zapnutý'), findsOneWidget);
    // Only the direction: no distance anywhere.
    expect(find.textContaining('km'), findsNothing);
  });

  testWidgets('a guess outside the region is not counted', (tester) async {
    final harness = await pumpPage(tester);
    await guess(tester, harness, abroad);
    expect(
      find.text('Tip musí ležet v Karlovarském kraji. Tenhle se nepočítá.'),
      findsOneWidget,
    );
    // The player stays on the map to move the pin.
    expect(find.text('tip položen'), findsOneWidget);
    expect(button(tester, 'POTVRDIT TIP').onPressed, isNotNull);

    await tester.tap(find.bySemanticsLabel('Zpět na klíče'));
    await tester.pumpAndSettle();
    expect(find.text('MÍSTO DNE\u00A0· POKUS 1'), findsOneWidget);
  });

  testWidgets('a network failure while guessing keeps the pin', (tester) async {
    final api = FakeRoundApi(
      places: [place()],
      clock: () => DateTime.utc(2026, 10, 10, 10),
      latency: Duration.zero,
    );
    final harness = await pumpPage(tester, api: api);
    api.failNext(const RoundApiException(RoundErrorKind.network));
    await guess(tester, harness, near);
    expect(
      find.text(
        'Tip se nepodařilo odeslat. Zkontroluj připojení a zkus to znovu.',
      ),
      findsOneWidget,
    );
    expect(find.text('tip položen'), findsOneWidget);
    expect(button(tester, 'POTVRDIT TIP').onPressed, isNotNull);
  });

  testWidgets('a failed load offers another try', (tester) async {
    final api = FakeRoundApi(
      places: [place()],
      clock: () => DateTime.utc(2026, 10, 10, 10),
      latency: Duration.zero,
    )..failNext(const RoundApiException(RoundErrorKind.network));
    final harness = await pumpPage(tester, api: api);
    expect(find.textContaining('nepodařilo načíst'), findsOneWidget);

    await tester.tap(find.text('ZKUSIT ZNOVU'));
    await tester.pumpAndSettle();
    expect(find.text('Stojí na skále nad řekou.'), findsOneWidget);

    await tester.tap(find.bySemanticsLabel('Zavřít'));
    expect(harness.closed, 1);
  });

  testWidgets('with every place guessed there is nothing to play', (
    tester,
  ) async {
    await pumpPage(
      tester,
      api: FakeRoundApi(
        places: [place()],
        guessedPlaceIds: [1],
        latency: Duration.zero,
      ),
    );
    expect(
      find.textContaining('Všechna místa už máš uhodnutá'),
      findsOneWidget,
    );
    expect(find.text('ZPĚT DOMŮ'), findsOneWidget);
  });

  testWidgets('every state fits a small phone', (tester) async {
    final harness = await pumpPage(
      tester,
      spring: true,
      size: const Size(320, 568),
    );
    for (var i = 0; i < 5; i++) {
      await guess(tester, harness, near);
      expect(tester.takeException(), isNull, reason: 'miss ${i + 1}');
      await tester.tap(find.text('TIPNOUT ZNOVU'));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull, reason: 'after miss ${i + 1}');
    }
    await guess(tester, harness, onTarget);
    expect(find.text('Trefa na 6.\u00A0pokus!'), findsOneWidget);
    expect(find.text('6'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  group('with the Game API', () {
    /// A backend that follows the product rules: one more clue per miss,
    /// the compass from the fourth miss on, no limit, and a hit at
    /// [onTarget].
    ScriptedRoundApi rulesBackend({required int wrong, Compass? compass}) {
      late final ScriptedRoundApi api;
      api = ScriptedRoundApi(
        daily: backendRound(wrong: wrong, compass: compass),
        onGuess: (position) {
          final misses = api.daily.wrongGuesses;
          if (position == onTarget) {
            return GuessHit(
              backendRound(
                wrong: misses,
                lastGuess: position,
                result: RoundResult(
                  stars: GameConfig.defaults.starsAvailable(misses),
                  guesses: misses + 1,
                  distanceMeters: 220,
                  place: revealed,
                ),
              ),
            );
          }
          final next = misses + 1;
          return GuessMissed(
            backendRound(
              wrong: next,
              lastGuess: position,
              compass: GameConfig.defaults.compassActive(next)
                  ? const Compass(180)
                  : null,
            ),
          );
        },
      );
      return api;
    }

    testWidgets('a resumed round: the last clues, the compass for as long as '
        'it takes, and a hit', (tester) async {
      final harness = await pumpPage(tester, api: rulesBackend(wrong: 1));
      // The round goes on where the player left it.
      expect(find.text('MÍSTO DNE · POKUS 2'), findsOneWidget);
      expect(find.text('KLÍČ 2 · TYP MÍSTA'), findsOneWidget);
      expect(find.bySemanticsLabel('Zamčený klíč: Oblast'), findsOneWidget);
      expect(find.bySemanticsLabel('Zamčený klíč: Klíč'), findsOneWidget);

      // The second miss: the third clue.
      await guess(tester, harness, near);
      expect(find.text('Vedle! Máš nový klíč.'), findsOneWidget);
      expect(find.text('KLÍČ 3 · OBLAST'), findsOneWidget);
      await tester.tap(find.text('TIPNOUT ZNOVU'));
      await tester.pumpAndSettle();

      // The third miss: the last clue, and a word about the compass.
      await guess(tester, harness, near);
      expect(find.text('KLÍČ 4 · DALŠÍ HÁDANKA'), findsOneWidget);
      expect(
        find.textContaining('Když se příště netrefíš, poradí ti kompas.'),
        findsOneWidget,
      );
      await tester.tap(find.text('TIPNOUT ZNOVU'));
      await tester.pumpAndSettle();
      expect(find.text('MÍSTO DNE · POKUS 4'), findsOneWidget);
      expect(find.bySemanticsLabel(RegExp('^Zamčený klíč')), findsNothing);
      expect(find.bySemanticsLabel(RegExp('^Kompas')), findsNothing);

      // The fourth miss: the compass.
      await guess(tester, harness, near);
      expect(find.text('Vedle! Kompas ti poradí.'), findsOneWidget);
      expect(find.text('NOVĚ ODEMČENO'), findsOneWidget);
      expect(
        find.bySemanticsLabel(
          'Kompas: cíl leží na jih od tvého posledního tipu',
        ),
        findsOneWidget,
      );
      expect(find.textContaining('km'), findsNothing);
      await tester.tap(find.text('TIPNOUT ZNOVU'));
      await tester.pumpAndSettle();

      // Any number of misses later the compass still points, and nothing
      // counts down or ends the round.
      for (var i = 5; i <= 8; i++) {
        await guess(tester, harness, near);
        expect(find.text('Vedle! Kompas ti poradí.'), findsOneWidget);
        expect(find.text('NOVĚ ODEMČENO'), findsNothing);
        expect(find.textContaining('poslední pokus'), findsNothing);
        await tester.tap(find.text('TIPNOUT ZNOVU'));
        await tester.pumpAndSettle();
      }
      expect(find.text('MÍSTO DNE · POKUS 9'), findsOneWidget);
      expect(
        find.bySemanticsLabel('Pokus 9, kompas je zapnutý'),
        findsOneWidget,
      );
      expect(find.bySemanticsLabel('Hvězdy za trefu: 1'), findsOneWidget);
      expect(find.bySemanticsLabel(RegExp('^Kompas: ')), findsOneWidget);

      await guess(tester, harness, onTarget);
      expect(find.text('Trefa na 9. pokus!'), findsOneWidget);
      expect(find.bySemanticsLabel('1 z 5 hvězd'), findsOneWidget);
      expect(find.text('9'), findsOneWidget);
      expect(find.text('4 / 4'), findsOneWidget);
      expect(find.text('Přidáno na tvou mapu'), findsOneWidget);
      expect(find.text('Zdroj: datazapad.cz · CC BY 4.0'), findsOneWidget);
      expect(tester.takeException(), isNull);

      await tester.tap(find.text('POKRAČOVAT'));
      expect(harness.closed, 1);
    });

    testWidgets('a place without a known source shows no source line', (
      tester,
    ) async {
      final api = ScriptedRoundApi(
        daily: backendRound(wrong: 0),
        onGuess: (position) => GuessHit(
          backendRound(
            wrong: 0,
            lastGuess: position,
            result: const RoundResult(
              stars: 5,
              guesses: 1,
              distanceMeters: 220,
              wafersEarned: 10,
              place: PlaceCard(
                id: 42,
                name: 'Hrad Loket',
                type: 'Hrady, tvrze a zříceniny',
                description: 'Gotický hrad.',
                location: target,
              ),
            ),
          ),
        ),
      );
      final harness = await pumpPage(tester, api: api);
      await guess(tester, harness, onTarget);
      expect(find.text('Trefa na 1. pokus!'), findsOneWidget);
      expect(find.text('+10\u00A0oplatek'), findsOneWidget);
      expect(find.text('Přidáno na tvou mapu'), findsOneWidget);
      expect(find.text('1'), findsOneWidget);
      expect(find.textContaining('null'), findsNothing);
      expect(find.textContaining(' · '), findsNothing);
    });

    testWidgets('a resumed round with the compass fits a small phone', (
      tester,
    ) async {
      await pumpPage(
        tester,
        size: const Size(320, 568),
        api: rulesBackend(wrong: 7, compass: const Compass(45)),
      );
      expect(find.text('MÍSTO DNE · POKUS 8'), findsOneWidget);
      expect(
        find.bySemanticsLabel(
          'Kompas: cíl leží na severovýchod od tvého posledního tipu',
        ),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    });
  });
}
