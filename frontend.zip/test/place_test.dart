import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/config/game_config.dart';
import 'package:kde_na_zapade/design_system/czech.dart';
import 'package:kde_na_zapade/design_system/pill.dart';
import 'package:kde_na_zapade/game/area.dart';
import 'package:kde_na_zapade/my_map/my_map_place.dart';
import 'package:kde_na_zapade/place/device_location.dart';
import 'package:kde_na_zapade/place/directions.dart';
import 'package:kde_na_zapade/place/dummy_place_source.dart';
import 'package:kde_na_zapade/place/place_detail.dart';
import 'package:kde_na_zapade/place/place_demo.dart';
import 'package:kde_na_zapade/place/place_detail_page.dart';
import 'package:kde_na_zapade/place/visit_result_page.dart';

const _lat = 50.0807;
const _lon = 12.8389;

MyMapPlace place(int id, {DateTime? guessedAt, DateTime? visitedAt}) =>
    MyMapPlace(
      id: id,
      name: 'Místo $id',
      latitude: _lat,
      longitude: _lon,
      area: Area.karlovarsko,
      guessedAt: guessedAt,
      visitedAt: visitedAt,
    );

final _now = DateTime.utc(2026, 10, 10, 12);

/// About [meters] north of the place.
DevicePosition near(double meters) => DevicePosition(
  latitude: _lat + meters / 111195,
  longitude: _lon,
  accuracyMeters: 12,
  timestamp: _now,
);

DummyPlaceSource source(
  List<MyMapPlace> places, {
  GameConfig config = GameConfig.defaults,
}) => DummyPlaceSource(
  places: () async => places,
  config: config,
  clock: () => _now,
);

/// A place card as the Game API serves it for a place guessed on another
/// device: the name and the progress only, no texts, no facts, no tips.
class BarePlaceSource implements PlaceSource {
  BarePlaceSource({
    this.visitedAt,
    this.rating,
    this.averageRating,
    this.ratingCount = 0,
  });

  DateTime? visitedAt;
  int? rating;
  double? averageRating;
  int ratingCount;
  final visits = <int>[];
  final ratings = <int>[];

  PlaceDetail get _detail => PlaceDetail(
    id: 1,
    name: 'Místo 1',
    latitude: _lat,
    longitude: _lon,
    factCount: 0,
    guessedAt: DateTime.utc(2026, 10, 9),
    visitedAt: visitedAt,
    facts: visitedAt == null ? null : const [],
    rating: rating,
    averageRating: averageRating,
    ratingCount: ratingCount,
  );

  @override
  Future<PlaceDetail> load(int placeId) async => _detail;

  @override
  Future<VisitOutcome> visit(int placeId, DevicePosition position) async {
    visits.add(placeId);
    visitedAt = _now;
    return VisitConfirmed(
      distanceMeters: position.distanceTo(_lat, _lon),
      place: _detail,
      wafersEarned: 50,
    );
  }

  @override
  Future<PlaceDetail> rate(int placeId, int stars) async {
    ratings.add(stars);
    final rated = _detail.rated(stars);
    rating = rated.rating;
    averageRating = rated.averageRating;
    ratingCount = rated.ratingCount;
    return rated;
  }
}

class FakeLocation implements LocationReader {
  FakeLocation({this.position, this.problem, this.allowed});

  DevicePosition? position;
  LocationProblem? problem;

  /// What [locateIfAllowed] returns.
  DevicePosition? allowed;
  int locates = 0;

  @override
  Future<DevicePosition> locate() async {
    locates++;
    final problem = this.problem;
    if (problem != null) throw LocationException(problem);
    return position!;
  }

  @override
  Future<DevicePosition?> locateIfAllowed() async => allowed;

  @override
  bool canOpenSettings(LocationProblem problem) => false;

  @override
  Future<void> openSettings(LocationProblem problem) async {}
}

void main() {
  group('Czech', () {
    test('formats distances', () {
      expect(Czech.distance(38), '40\u00A0m');
      expect(Czech.distance(994), '990\u00A0m');
      expect(Czech.distance(1000), '1\u00A0km');
      expect(Czech.distance(1400), '1,4\u00A0km');
      expect(Czech.distance(6020), '6\u00A0km');
      expect(Czech.distance(31200), '31\u00A0km');
    });

    test('formats a day and month', () {
      expect(Czech.dayMonth(DateTime(2026, 10, 9)), '9.\u00A010.');
    });
  });

  group('directionsUri', () {
    test('opens Google Maps directions on Android and the web', () {
      final uri = directionsUri(50.08, 12.83, platform: TargetPlatform.android);
      expect(uri.host, 'www.google.com');
      expect(uri.path, '/maps/dir/');
      expect(uri.queryParameters, {'api': '1', 'destination': '50.08,12.83'});
    });

    test('opens Apple Maps on iOS', () {
      final uri = directionsUri(50.08, 12.83, platform: TargetPlatform.iOS);
      expect(uri.host, 'maps.apple.com');
      expect(uri.queryParameters['daddr'], '50.08,12.83');
    });
  });

  group('DummyPlaceSource', () {
    test('loads a guessed place with its facts locked', () async {
      final guessed = DateTime.utc(2026, 10, 9);
      final detail = await source([place(1, guessedAt: guessed)]).load(1);

      expect(detail.name, 'Místo 1');
      expect(detail.guessedAt, guessed);
      expect(detail.isVisited, isFalse);
      expect(detail.facts, isNull);
      expect(detail.factCount, 3);
      expect(detail.source, contains('licence'));
    });

    test('loads a place in the fog, but not an unlisted one', () async {
      final fog = await source([place(1)]).load(1);
      expect(fog.isGuessed, isFalse);
      expect(fog.stars, isNull);
      expect(source([place(1)]).load(2), throwsA(isA<PlaceNotFound>()));
    });

    test('a visit outside the radius records nothing', () async {
      final places = source([place(1, guessedAt: _now)]);

      final outcome = await places.visit(1, near(1500));

      expect(outcome, isA<VisitTooFar>());
      expect(outcome.distanceMeters, closeTo(1500, 1));
      expect((await places.myMap()).single.isVisited, isFalse);
      expect((await places.load(1)).facts, isNull);
    });

    test(
      'a visit within the radius unlocks the facts and marks my map',
      () async {
        final places = source([place(1, guessedAt: _now), place(2)]);

        final outcome = await places.visit(1, near(40));

        expect(outcome, isA<VisitConfirmed>());
        final confirmed = outcome as VisitConfirmed;
        expect(confirmed.place.visitedAt, _now);
        expect(confirmed.place.facts, hasLength(3));
        expect(
          confirmed.nearby.where((t) => t.kind == NearbyTipKind.spring),
          isNotEmpty,
        );
        final map = await places.myMap();
        expect(map.first.marker, PlaceMarker.visited);
        expect(map.last.isUnknown, isTrue);
        expect((await places.load(1)).facts, hasLength(3));
      },
    );

    test('rates a visited place, but not one in the fog', () async {
      final places = source([place(1, visitedAt: _now), place(2)]);

      final rated = await places.rate(1, 4);
      expect(rated.rating, 4);
      expect(rated.averageRating, 4);
      expect(rated.ratingCount, 1);
      expect((await places.load(1)).rating, 4);

      final again = await places.rate(1, 2);
      expect(again.ratingCount, 1);
      expect(again.averageRating, 2);

      expect(places.rate(2, 4), throwsA(isA<StateError>()));
    });

    test('takes the visit radius from the configuration', () async {
      const wide = GameConfig(
        maxStars: 5,
        maxRating: 5,
        placeOfTheDayClues: 5,
        freePlayClues: 3,
        hitRadiusMeters: 1000,
        visitRadiusMeters: 500,
        timeZone: 'Europe/Prague',
      );
      final places = source([place(1, guessedAt: _now)], config: wide);

      expect(await places.visit(1, near(400)), isA<VisitConfirmed>());
    });
  });

  group('PlaceDetailPage', () {
    late List<(double, double)> directions;
    late int closes;

    Future<void> pumpCard(
      WidgetTester tester, {
      required LocationReader location,
      List<MyMapPlace>? places,
      PlaceSource? placeSource,
    }) async {
      tester.view.physicalSize = const Size(390, 844) * 3;
      tester.view.devicePixelRatio = 3;
      addTearDown(tester.view.reset);
      tester.platformDispatcher.accessibilityFeaturesTestValue =
          const FakeAccessibilityFeatures(disableAnimations: true);
      addTearDown(
        tester.platformDispatcher.clearAccessibilityFeaturesTestValue,
      );
      directions = [];
      closes = 0;
      await tester.pumpWidget(
        MaterialApp(
          home: PlaceDetailPage(
            placeId: 1,
            source:
                placeSource ?? source(places ?? [place(1, guessedAt: _now)]),
            location: location,
            openDirections: (lat, lon) async {
              directions.add((lat, lon));
              return true;
            },
            onClose: () => closes++,
            clock: () => _now,
          ),
        ),
      );
      await tester.pumpAndSettle();
    }

    testWidgets('a guessed place offers a visit without asking for location', (
      tester,
    ) async {
      final location = FakeLocation(position: near(40));
      await pumpCard(tester, location: location);

      expect(find.text('Místo 1'), findsOneWidget);
      expect(find.text('Navštiv ho naživo'), findsOneWidget);
      expect(find.textContaining('do 1\u00A0km'), findsOneWidget);
      expect(find.text('JSEM TU!'), findsOneWidget);
      expect(find.textContaining('od\u00A0tebe'), findsNothing);
      expect(location.locates, 0);
    });

    testWidgets('shows the distance when location is already allowed', (
      tester,
    ) async {
      await pumpCard(tester, location: FakeLocation(allowed: near(31000)));

      expect(find.text('31\u00A0km od\u00A0tebe'), findsOneWidget);
    });

    testWidgets('NAVIGOVAT opens the directions to the place', (tester) async {
      await pumpCard(tester, location: FakeLocation());

      await tester.tap(find.text('NAVIGOVAT'));
      await tester.pumpAndSettle();

      expect(directions, [(_lat, _lon)]);
    });

    testWidgets('a visit on the spot shows the facts and the nearby tips', (
      tester,
    ) async {
      await pumpCard(tester, location: FakeLocation(position: near(40)));

      await tester.tap(find.text('JSEM TU!'));
      await tester.pumpAndSettle();

      expect(find.text('Jsi tady!'), findsOneWidget);
      expect(find.textContaining('GPS: 40\u00A0m'), findsOneWidget);
      expect(find.text('Máš odemčené 3\u00A0zajímavosti'), findsOneWidget);
      await tester.scrollUntilVisible(
        find.text('Voda není hygienicky sledovaná.'),
        200,
      );
      expect(find.text('Voda není hygienicky sledovaná.'), findsOneWidget);

      await tester.tap(find.text('Zobrazit'));
      await tester.pumpAndSettle();

      expect(closes, 1);
      expect(find.text('Tvoje zajímavosti'), findsOneWidget);
      expect(find.text('SDÍLET'), findsOneWidget);
      expect(find.text('JSEM TU!'), findsNothing);
    });

    testWidgets('too far away shows the distance and can try again', (
      tester,
    ) async {
      final location = FakeLocation(position: near(31000));
      await pumpCard(tester, location: location);

      await tester.tap(find.text('JSEM TU!'));
      await tester.pumpAndSettle();

      expect(find.text('Ještě nejsi na místě'), findsOneWidget);
      expect(find.text('31\u00A0km'), findsOneWidget);
      expect(find.textContaining('přesnost ±10\u00A0m'), findsOneWidget);

      location.position = near(20);
      await tester.tap(find.text('JSEM TU, ZKUSIT ZNOVU'));
      await tester.pumpAndSettle();

      expect(location.locates, 2);
      expect(find.text('Jsi tady!'), findsOneWidget);
    });

    testWidgets('a denied permission explains how to fix it', (tester) async {
      await pumpCard(
        tester,
        location: FakeLocation(problem: LocationProblem.denied),
      );

      await tester.tap(find.text('JSEM TU!'));
      await tester.pumpAndSettle();

      expect(find.text('Bez polohy to nepůjde'), findsOneWidget);
      await tester.tap(find.bySemanticsLabel('Zavřít'));
      await tester.pumpAndSettle();
      expect(find.text('JSEM TU!'), findsOneWidget);
    });

    testWidgets('a visited place shows its facts', (tester) async {
      await pumpCard(
        tester,
        location: FakeLocation(),
        places: [
          place(
            1,
            guessedAt: DateTime.utc(2026, 10, 9),
            visitedAt: DateTime.utc(2026, 10, 10),
          ),
        ],
      );

      expect(find.text('navštíveno 10.\u00A010.'), findsOneWidget);
      expect(find.text('Tvoje zajímavosti'), findsOneWidget);
      expect(find.text('3\u00A0z\u00A03'), findsOneWidget);
      expect(find.text('Navštiv ho naživo'), findsNothing);
    });

    testWidgets('a card without texts shows the name and the progress only', (
      tester,
    ) async {
      await pumpCard(
        tester,
        location: FakeLocation(),
        placeSource: BarePlaceSource(),
      );

      expect(find.text('Místo 1'), findsOneWidget);
      expect(find.text('uhodnuto 9.\u00A010.'), findsOneWidget);
      expect(find.byType(KnzPill), findsNothing);
      expect(find.textContaining('Zdroj'), findsNothing);
      expect(find.textContaining('licence'), findsNothing);
      expect(find.text('Navštiv ho naživo'), findsOneWidget);
      expect(
        find.text('Až budeš do 1\u00A0km, ulož si ho na mapu.'),
        findsOneWidget,
      );
      expect(find.textContaining('odemkneš'), findsNothing);
      expect(
        find.bySemanticsLabel(RegExp('Zamčené zajímavosti')),
        findsNothing,
      );
      expect(find.text('JSEM TU!'), findsOneWidget);
      expect(find.text('zatím bez hodnocení'), findsOneWidget);
      expect(find.text('Jak se ti tu líbilo?'), findsNothing);
      expect(
        find.text('50,0807°\u00A0s.\u00A0š., 12,8389°\u00A0v.\u00A0d.'),
        findsOneWidget,
      );
    });

    testWidgets('shows the ratings from the backend', (tester) async {
      await pumpCard(
        tester,
        location: FakeLocation(),
        placeSource: BarePlaceSource(
          visitedAt: _now,
          rating: 4,
          averageRating: 4.3,
          ratingCount: 12,
        ),
      );

      expect(find.text('4,3 · 12\u00A0hodnocení'), findsOneWidget);
      expect(
        find.text('Tvoje hodnocení: 4\u00A0hvězdy. Změnit ho můžeš kdykoli.'),
        findsOneWidget,
      );
      expect(find.text('zatím bez hodnocení'), findsNothing);
    });

    testWidgets('a visited place is rated by tapping a star', (tester) async {
      final bare = BarePlaceSource(visitedAt: _now);
      await pumpCard(tester, location: FakeLocation(), placeSource: bare);

      expect(find.text('Jak se ti tu líbilo?'), findsOneWidget);
      expect(find.textContaining('Ohodnoť místo hvězdami.'), findsOneWidget);

      final fourth = find.bySemanticsLabel('Ohodnotit: 4\u00A0z\u00A05 hvězd');
      await tester.ensureVisible(fourth);
      await tester.tap(fourth);
      await tester.pumpAndSettle();

      expect(bare.ratings, [4]);
      expect(
        find.text('Tvoje hodnocení: 4\u00A0hvězdy. Změnit ho můžeš kdykoli.'),
        findsOneWidget,
      );
      expect(find.text('4,0 · 1\u00A0hodnocení'), findsOneWidget);
      expect(find.text('Díky! Hodnocení je uložené.'), findsOneWidget);
    });

    testWidgets('a visit without facts confirms the place only', (
      tester,
    ) async {
      final bare = BarePlaceSource();
      await pumpCard(
        tester,
        location: FakeLocation(position: near(40)),
        placeSource: bare,
      );

      await tester.tap(find.text('JSEM TU!'));
      await tester.pumpAndSettle();

      expect(bare.visits, [1]);
      expect(find.byType(VisitResultPage), findsOneWidget);
      expect(find.text('Jsi tady!'), findsOneWidget);
      expect(find.text('Uloženo na tvou mapu'), findsOneWidget);
      expect(find.text('+50\u00A0oplatek'), findsOneWidget);
      expect(find.textContaining('zajímavost'), findsNothing);
      expect(find.text('Tipy poblíž'), findsNothing);
      expect(find.textContaining('Zdroj dat'), findsNothing);

      await tester.tap(find.text('Zobrazit'));
      await tester.pumpAndSettle();

      expect(closes, 1);
      expect(find.text('Tvoje zajímavosti'), findsNothing);
      expect(find.text('Navštiv ho naživo'), findsNothing);
      expect(find.text('SDÍLET'), findsOneWidget);
    });
  });

  group('VisitResultPage', () {
    Future<List<int>> pumpResult(
      WidgetTester tester, {
      String? description = 'Gotický hrad na skále.',
    }) async {
      tester.view.physicalSize = const Size(390, 1400);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      tester.platformDispatcher.accessibilityFeaturesTestValue =
          const FakeAccessibilityFeatures(disableAnimations: true);
      addTearDown(
        tester.platformDispatcher.clearAccessibilityFeaturesTestValue,
      );
      final ratings = <int>[];
      final place = PlaceDetail(
        id: 1,
        name: 'Hrad Loket',
        latitude: _lat,
        longitude: _lon,
        factCount: 0,
        description: description,
        source: 'Zdroj: datazapad.cz · CC BY 4.0',
        visitedAt: _now,
        facts: const [],
      );
      await tester.pumpWidget(
        MaterialApp(
          home: VisitResultPage(
            visit: VisitConfirmed(
              distanceMeters: 40,
              place: place,
              wafersEarned: 50,
            ),
            onRate: (stars) async {
              ratings.add(stars);
              return place.rated(stars);
            },
          ),
        ),
      );
      await tester.pumpAndSettle();
      return ratings;
    }

    testWidgets('shows the description with its source and asks for a rating', (
      tester,
    ) async {
      final ratings = await pumpResult(tester);

      expect(find.text('O\u00A0místě'), findsOneWidget);
      expect(find.text('Gotický hrad na skále.'), findsOneWidget);
      expect(find.text('Zdroj: datazapad.cz · CC BY 4.0'), findsOneWidget);
      expect(find.text('Jak se ti tu líbilo?'), findsOneWidget);

      final fifth = find.bySemanticsLabel('Ohodnotit: 5\u00A0z\u00A05 hvězd');
      await tester.ensureVisible(fifth);
      await tester.tap(fifth);
      await tester.pumpAndSettle();

      expect(ratings, [5]);
      expect(
        find.text('Tvoje hodnocení: 5\u00A0hvězd. Změnit ho můžeš kdykoli.'),
        findsOneWidget,
      );
    });

    testWidgets('a place without a known description leaves it out', (
      tester,
    ) async {
      await pumpResult(tester, description: null);

      expect(find.text('O\u00A0místě'), findsNothing);
      expect(find.text('Jak se ti tu líbilo?'), findsOneWidget);
    });
  });

  group('PlaceDemo', () {
    DemoLocation gps(String? value) =>
        DemoLocation(DemoGps.parse(value), delay: Duration.zero);

    test('reads the fake GPS from the URL, near by default', () {
      expect(DemoGps.parse('far'), DemoGps.far);
      expect(DemoGps.parse(null), DemoGps.here);
      expect(DemoGps.parse('nonsense'), DemoGps.here);
    });

    test(
      'a visit near the sample place succeeds, a far one does not',
      () async {
        final demo = PlaceDemo.source(visited: false, clock: () => _now);

        final near = await demo.visit(0, await gps('here').locate());
        final far = await demo.visit(0, await gps('far').locate());

        expect(near, isA<VisitConfirmed>());
        expect(far, isA<VisitTooFar>());
        expect(far.distanceMeters, closeTo(31000, 10));
      },
    );

    test('reports location problems without a position', () async {
      expect(
        gps('denied').locate(),
        throwsA(
          isA<LocationException>().having(
            (e) => e.problem,
            'problem',
            LocationProblem.denied,
          ),
        ),
      );
      expect(await gps('off').locateIfAllowed(), isNull);
    });

    test('opens the sample place as visited on request', () async {
      final detail = await PlaceDemo.source(
        visited: true,
        clock: () => _now,
      ).load(0);

      expect(detail.isVisited, isTrue);
      expect(detail.facts, hasLength(3));
    });
  });
}
