import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:maplibre_gl/maplibre_gl.dart';

import 'package:kde_na_zapade/config/map_config.dart';
import 'package:kde_na_zapade/map/map_style.dart';

void main() {
  final config = MapConfig(
    tilesAsset: 'assets/map/kvk.pmtiles',
    glyphsUrl: 'https://example.test/fonts/{fontstack}/{range}.pbf',
    initialCamera: const CameraPosition(target: LatLng(50.15, 12.75)),
    cameraBounds: LatLngBounds(
      southwest: const LatLng(49.75, 11.90),
      northeast: const LatLng(50.60, 13.50),
    ),
    minZoom: 7,
    maxZoom: 14,
  );

  const tilesUrl = 'pmtiles://kvk.pmtiles';

  test('style points MapLibre at the PMTiles archive', () {
    final style = jsonDecode(
      GameMapStyle.json(config, tilesUrl: tilesUrl),
    ) as Map<String, Object?>;
    final sources = style['sources'] as Map<String, Object?>;
    final source = sources[GameMapStyle.sourceId] as Map<String, Object?>;

    expect(style['version'], 8);
    expect(style['glyphs'], config.glyphsUrl);
    expect(source['type'], 'vector');
    expect(source['url'], tilesUrl);
  });

  test('style carries the OpenStreetMap attribution', () {
    final sources =
        GameMapStyle.document(config, tilesUrl: tilesUrl)['sources'] as Map;
    final source = sources[GameMapStyle.sourceId] as Map;

    expect(source['attribution'], '© OpenStreetMap contributors');
  });

  test('style uses every layer of the tile set and nothing else', () {
    final layers =
        GameMapStyle.document(config, tilesUrl: tilesUrl)['layers'] as List;
    final used = <String>{};
    for (final layer in layers.cast<Map<String, Object?>>()) {
      if (layer['type'] == 'background') continue;
      expect(layer['source'], GameMapStyle.sourceId, reason: '${layer['id']}');
      used.add(layer['source-layer'] as String);
    }

    expect(used, GameMapStyle.sourceLayers.toSet());
  });

  test('layer ids are unique', () {
    final layers =
        GameMapStyle.document(config, tilesUrl: tilesUrl)['layers'] as List;
    final ids = layers.map((layer) => (layer as Map)['id']).toList();

    expect(ids.toSet().length, ids.length);
  });
}
