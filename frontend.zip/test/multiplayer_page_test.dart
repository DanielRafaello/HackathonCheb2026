import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/account/account_api.dart';
import 'package:kde_na_zapade/account/session.dart';
import 'package:kde_na_zapade/account/token_storage.dart';
import 'package:kde_na_zapade/config/api_config.dart';
import 'package:kde_na_zapade/config/multiplayer_config.dart';
import 'package:kde_na_zapade/design_system/design_system.dart';
import 'package:kde_na_zapade/multiplayer/multiplayer_controller.dart';
import 'package:kde_na_zapade/multiplayer/multiplayer_page.dart';
import 'package:kde_na_zapade/multiplayer/multiplayer_store.dart';
import 'package:kde_na_zapade/multiplayer/widgets/invite_qr_code.dart';
import 'package:kde_na_zapade/round/guess_map_view.dart';
import 'package:kde_na_zapade/round/geo.dart';

import 'fake_multiplayer_server.dart';
import 'session_test.dart' show FakeBackend;

const loket = GeoPoint(50.1859, 12.7541);

/// A stand-in for the blind map: a tap puts the pin on Loket.
Widget stubMap(GuessMapView view) => GestureDetector(
  key: ValueKey(view.interactive ? 'full map' : 'preview map'),
  behavior: HitTestBehavior.opaque,
  onTap: view.enabled ? () => view.onPin(loket) : null,
  child: const SizedBox.expand(),
);

void main() {
  late FakeBackend backend;
  late FakeMultiplayerServer server;
  late MemoryMultiplayerStore store;
  late List<String> copied;
  late int closed;

  setUp(() {
    backend = FakeBackend();
    server = FakeMultiplayerServer();
    store = MemoryMultiplayerStore();
    copied = [];
    closed = 0;
  });

  Session newSession() => Session(
    api: AccountApi(
      config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api/')),
      client: backend.client,
    ),
    storage: MemoryTokenStorage(),
  );

  Future<void> pumpPage(
    WidgetTester tester, {
    Session? session,
    String? joinCode,
  }) async {
    tester.view.physicalSize = const Size(390, 1400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    // Vřídlík moves for as long as he is on screen; reduced motion stops
    // him so that the page can settle.
    tester.platformDispatcher.accessibilityFeaturesTestValue =
        const FakeAccessibilityFeatures(disableAnimations: true);
    addTearDown(tester.platformDispatcher.clearAccessibilityFeaturesTestValue);
    await tester.pumpWidget(
      MaterialApp(
        home: MultiplayerPage(
          config: MultiplayerConfig(url: MultiplayerConfig.local),
          session: session ?? (newSession()..continueAsGuest()),
          mapBuilder: stubMap,
          joinCode: joinCode,
          onClose: () => closed++,
          connect: server.connect,
          store: store,
          clock: () => serverEpoch,
          ticker: () => const Stream.empty(),
          copyText: (text) async => copied.add(text),
        ),
      ),
    );
    await tester.pumpAndSettle();
  }

  /// The server answers the hello and puts the player in a lobby.
  Future<void> answer(WidgetTester tester, Map<String, Object?> state) async {
    server.last.receive(welcomeJson());
    server.last.receive(state);
    await tester.pumpAndSettle();
  }

  Future<void> enterLobby(WidgetTester tester) async {
    store.nickname = 'Eva';
    await pumpPage(tester, joinCode: 'K7M2QX');
    await answer(tester, stateJson());
  }

  testWidgets('a guest creates a lobby and shares its code', (tester) async {
    await pumpPage(tester);

    expect(find.text('Hra s kamarády'), findsOneWidget);
    expect(find.text('Tvoje přezdívka'), findsOneWidget);
    expect(find.text('PŘIPOJIT SE'), findsOneWidget);

    await tester.enterText(find.byType(TextField).first, 'Eva');
    await tester.tap(find.text('ZALOŽIT MÍSTNOST'));
    await tester.pumpAndSettle();
    expect(server.last.sent.first, {'type': 'hello', 'nickname': 'Eva'});

    await answer(tester, stateJson());

    expect(find.text('K7M2QX'), findsOneWidget);
    expect(find.text('HRÁČI · 2 Z 8'), findsOneWidget);
    expect(find.text('Adam'), findsOneWidget);
    expect(find.text('HOSTITEL'), findsOneWidget);
    expect(find.text('START HRY'), findsOneWidget);
    expect(find.text('Počet míst'), findsOneWidget);

    final qr = tester.widget<InviteQrCode>(find.byType(InviteQrCode));
    expect(qr.link, 'https://aether217.zcu.cz/multiplayer/K7M2QX');
    expect(find.bySemanticsLabel('QR kód s odkazem do místnosti'), findsOneWidget);

    await tester.tap(find.text('KOPÍROVAT KÓD'));
    await tester.tap(find.text('SDÍLET ODKAZ'));
    await tester.pumpAndSettle();
    expect(copied, ['K7M2QX', 'https://aether217.zcu.cz/multiplayer/K7M2QX']);

    await tester.tap(find.text('START HRY'));
    expect(server.last.sentTypes.last, 'startGame');
  });

  testWidgets('a short nickname shows an error under the field', (
    tester,
  ) async {
    await pumpPage(tester);

    await tester.enterText(find.byType(TextField).first, 'E');
    await tester.tap(find.text('ZALOŽIT MÍSTNOST'));
    await tester.pumpAndSettle();

    expect(find.text('Přezdívka musí mít 2 až 24 znaků.'), findsOneWidget);
    expect(server.connections, isEmpty);
  });

  testWidgets('a signed-in player plays under the account name', (
    tester,
  ) async {
    final session = newSession();
    await tester.runAsync(
      () => session.signIn(email: 'eva@example.cz', password: 'tajneheslo'),
    );
    await pumpPage(tester, session: session);

    expect(find.text('Hraješ jako Eva'), findsOneWidget);
    expect(find.text('Tvoje přezdívka'), findsNothing);

    await tester.tap(find.text('ZALOŽIT MÍSTNOST'));
    await tester.pumpAndSettle();
    expect(server.last.sent.first, {'type': 'hello', 'token': 'jwt1'});
  });

  testWidgets('a player who is not the host waits for the start', (
    tester,
  ) async {
    store.nickname = 'Eva';
    await pumpPage(tester, joinCode: 'K7M2QX');
    await answer(tester, stateJson(hostId: 'p2'));

    expect(server.last.lastOf('joinLobby')['code'], 'K7M2QX');
    expect(find.text('Hru spustí hostitel.'), findsOneWidget);
    expect(find.text('START HRY'), findsNothing);
    expect(find.text('3 místa'), findsOneWidget);
    expect(find.text('Počet míst'), findsNothing);
  });

  testWidgets('the player finds a place on the map and sees the result', (
    tester,
  ) async {
    await enterLobby(tester);
    server.last.receive(stateJson(phase: 'playing', game: playingGameJson()));
    await tester.pumpAndSettle();

    expect(find.text('MÍSTO 1 Z 3'), findsOneWidget);
    expect(find.text('Místo 1'), findsOneWidget);
    expect(find.text('5:00'), findsOneWidget);

    await tester.tap(find.text('TIPNOUT NA MAPĚ'));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('full map')), findsOneWidget);
    expect(find.text('Klepni do mapy a\u00A0polož špendlík.'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('full map')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('POTVRDIT TIP'));
    await tester.pumpAndSettle();
    expect(server.last.lastOf('guess'), {
      'type': 'guess',
      'index': 0,
      'latitude': loket.latitude,
      'longitude': loket.longitude,
    });
    expect(find.text('POSÍLÁM TIP…'), findsOneWidget);

    server.last.receive(guessResultJson(0, distance: 1500));
    server.last.receive(
      stateJson(phase: 'playing', game: playingGameJson(guessed: 1)),
    );
    await tester.pumpAndSettle();

    expect(find.text('OD CÍLE'), findsOneWidget);
    expect(find.text('1,5 km'), findsOneWidget);
    expect(find.text('Hrady, tvrze a zříceniny'.toUpperCase()), findsOneWidget);
    expect(find.text('datazapad.cz · CC BY'), findsOneWidget);
    expect(find.text('Přidáno na tvou mapu'), findsNothing);

    await tester.tap(find.text('DALŠÍ MÍSTO'));
    await tester.pumpAndSettle();
    expect(find.text('Místo 2'), findsOneWidget);
    expect(find.text('MÍSTO 2 Z 3'), findsOneWidget);
  });

  testWidgets('after the last place the player sees the others progress', (
    tester,
  ) async {
    await enterLobby(tester);
    server.last.receive(
      stateJson(
        phase: 'playing',
        game: playingGameJson(guessed: 3),
        players: [
          playerJson('p1', 'Eva', host: true, view: 'game', guessedCount: 3),
          playerJson('p2', 'Adam', view: 'game', guessedCount: 1),
        ],
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('POSTUP HRÁČŮ'), findsOneWidget);
    expect(find.text('Adam'), findsOneWidget);
    // The own row is marked in words, not only by its colour.
    expect(find.text('Eva\u00A0(ty)'), findsOneWidget);
    expect(find.text('1 z 3'), findsOneWidget);
    expect(find.text('TIPNOUT NA MAPĚ'), findsNothing);
  });

  testWidgets('the results show the leaderboard and go back to the lobby', (
    tester,
  ) async {
    await enterLobby(tester);
    server.last.receive(
      stateJson(
        phase: 'finished',
        game: finishedGameJson(),
        players: [
          playerJson('p1', 'Eva', host: true, view: 'results'),
          playerJson('p2', 'Adam', view: 'results'),
        ],
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Výsledky'), findsOneWidget);
    expect(find.text('1.'), findsOneWidget);
    expect(find.text('2.'), findsOneWidget);
    expect(find.text('800 m'), findsOneWidget);
    expect(find.text('Místo 1'), findsNothing);
    expect(find.text('1. Místo 1'), findsOneWidget);
    expect(find.text('Nejblíž: Eva · 1,2 km'), findsOneWidget);
    expect(find.text('Nejblíž: Adam · 400 m'), findsNWidgets(2));

    await tester.tap(find.text('ZPĚT DO MÍSTNOSTI'));
    expect(server.last.sentTypes.last, 'returnToLobby');
  });

  testWidgets('first place without a single guess is not praised', (
    tester,
  ) async {
    await enterLobby(tester);
    final game = finishedGameJson();
    game['leaderboard'] = [
      for (final (i, id, name) in [(1, 'p1', 'Eva'), (2, 'p2', 'Adam')])
        {
          'rank': i,
          'playerId': id,
          'nickname': name,
          'averageDistanceMeters': 100000,
          'guessedCount': 0,
          'totalDistanceMeters': 300000,
          'finishedAt': null,
        },
    ];
    server.last.receive(
      stateJson(
        phase: 'finished',
        game: game,
        players: [
          playerJson('p1', 'Eva', host: true, view: 'results'),
          playerJson('p2', 'Adam', view: 'results'),
        ],
      ),
    );
    await tester.pumpAndSettle();

    expect(find.textContaining('Jsi první'), findsNothing);
    expect(
      find.text('Čas vypršel. Tentokrát nemáš tipnuté žádné místo.'),
      findsOneWidget,
    );
  });

  testWidgets('the results stay while the next game runs without the player', (
    tester,
  ) async {
    await enterLobby(tester);
    server.last.receive(
      stateJson(
        phase: 'finished',
        game: finishedGameJson(),
        players: [
          playerJson('p1', 'Eva', host: true, view: 'results'),
          playerJson('p2', 'Adam', view: 'results'),
        ],
      ),
    );
    await tester.pumpAndSettle();
    final next = playingGameJson(participant: false)
      ..['startedAt'] = ms(serverEpoch.add(const Duration(minutes: 10)))
      ..['participantIds'] = ['p2'];
    server.last.receive(
      stateJson(
        phase: 'playing',
        hostId: 'p2',
        game: next,
        players: [
          playerJson('p1', 'Eva', view: 'results'),
          playerJson('p2', 'Adam', host: true, view: 'game'),
        ],
      ),
    );
    await tester.pumpAndSettle();

    expect(tester.takeException(), isNull);
    expect(find.text('Výsledky'), findsOneWidget);
    expect(find.text('1.\u00A0Místo 1', skipOffstage: false), findsOneWidget);
    expect(find.text('ZPĚT DO MÍSTNOSTI'), findsOneWidget);
  });

  testWidgets('the guess that ends the game shows its result first', (
    tester,
  ) async {
    await enterLobby(tester);
    server.last.receive(
      stateJson(phase: 'playing', game: playingGameJson(guessed: 2)),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('TIPNOUT NA MAPĚ'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('full map')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('POTVRDIT TIP'));
    await tester.pumpAndSettle();

    server.last.receive(guessResultJson(2, distance: 40000));
    server.last.receive(
      stateJson(
        phase: 'finished',
        game: finishedGameJson(),
        players: [
          playerJson('p1', 'Eva', host: true, view: 'results'),
          playerJson('p2', 'Adam', view: 'results'),
        ],
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('OD CÍLE'), findsOneWidget);
    expect(find.text('40\u00A0km'), findsOneWidget);
    expect(find.text('Tohle bylo těžké.'), findsOneWidget);
    expect(find.text('Výsledky'), findsNothing);

    await tester.tap(find.text('HOTOVO'));
    await tester.pumpAndSettle();
    expect(find.text('Výsledky'), findsOneWidget);
    expect(server.last.sentTypes, isNot(contains('leaveLobby')));
  });

  testWidgets('the system back on the guess map goes back to the place', (
    tester,
  ) async {
    await enterLobby(tester);
    server.last.receive(stateJson(phase: 'playing', game: playingGameJson()));
    await tester.pumpAndSettle();
    await tester.tap(find.text('TIPNOUT NA MAPĚ'));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('full map')), findsOneWidget);

    await tester.binding.handlePopRoute();
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('full map')), findsNothing);
    expect(find.text('TIPNOUT NA MAPĚ'), findsOneWidget);
    expect(find.text('Odejít ze hry?'), findsNothing);

    await tester.binding.handlePopRoute();
    await tester.pumpAndSettle();
    expect(find.text('Odejít ze hry?'), findsOneWidget);
  });

  testWidgets('the host is not offered fewer players than the server takes', (
    tester,
  ) async {
    store.nickname = 'Eva';
    await pumpPage(tester, joinCode: 'K7M2QX');
    server.last.receive(welcomeJson(minPlayers: 3));
    server.last.receive(stateJson());
    await tester.pumpAndSettle();

    expect(find.text('Nejvýš hráčů'), findsOneWidget);
    expect(find.text('2'), findsNothing);
    expect(find.text('4'), findsOneWidget);
  });

  testWidgets('the server\'s default settings stay among the options', (
    tester,
  ) async {
    store.nickname = 'Eva';
    await pumpPage(tester, joinCode: 'K7M2QX');
    final welcome = welcomeJson();
    welcome['defaults'] = {
      'maxPlayers': 5,
      'placeCount': 2,
      'durationSeconds': 90,
    };
    server.last.receive(welcome);
    // The host has changed every setting from the default.
    final state = stateJson();
    final lobby = state['lobby']! as Map<String, Object?>;
    lobby['settings'] = {
      'maxPlayers': 8,
      'placeCount': 10,
      'durationSeconds': 180,
    };
    server.last.receive(state);
    await tester.pumpAndSettle();

    final [places, durations, players] = [
      for (final control in tester.widgetList<KnzSegmentedControl>(
        find.byType(KnzSegmentedControl),
      ))
        control.labels,
    ];
    expect(places, ['2', '5', '10', '15', '20']);
    expect(durations, [
      '90\u00a0s',
      '3\u00a0min',
      '5\u00a0min',
      '10\u00a0min',
      '15\u00a0min',
    ]);
    expect(players, ['2', '4', '5', '6', '8']);

    await tester.tap(find.text('90\u00a0s'));
    expect(server.last.sent.last['settings'], {'durationSeconds': 90});
  });

  testWidgets('a game taken over in another window stays there', (
    tester,
  ) async {
    await enterLobby(tester);

    server.last.drop(code: closeReplaced);
    await tester.pumpAndSettle();

    expect(find.textContaining('jiném okně'), findsOneWidget);
    expect(server.connections, hasLength(1));

    await tester.tap(find.text('HRÁT TADY'));
    await tester.pumpAndSettle();
    expect(server.connections, hasLength(2));
    expect(server.last.sent.single['resumeToken'], 'resume-1');
  });

  testWidgets('leaving a running game asks first', (tester) async {
    await enterLobby(tester);
    server.last.receive(stateJson(phase: 'playing', game: playingGameJson()));
    await tester.pumpAndSettle();

    await tester.tap(find.bySemanticsLabel('Odejít ze hry'));
    await tester.pumpAndSettle();
    expect(find.text('Odejít ze hry?'), findsOneWidget);

    await tester.tap(find.text('HRÁT DÁL'));
    await tester.pumpAndSettle();
    expect(server.last.sentTypes, isNot(contains('leaveLobby')));
    expect(closed, 0);

    final connection = server.last;
    await tester.tap(find.bySemanticsLabel('Odejít ze hry'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('ODEJÍT'));
    await tester.pumpAndSettle();
    expect(connection.sentTypes.last, 'leaveLobby');
    expect(closed, 1);
  });

  testWidgets('a lost connection shows a banner while it reconnects', (
    tester,
  ) async {
    await enterLobby(tester);

    server.fail = 100;
    server.last.drop();
    await tester.pump();
    await tester.pump();

    expect(find.text('Spojení se přerušilo, připojuji znovu…'), findsOneWidget);
    expect(find.text('K7M2QX'), findsOneWidget);

    // The page goes; its timers with it.
    await tester.pumpWidget(const SizedBox());
  });
}
