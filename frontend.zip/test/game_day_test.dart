import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/design_system/czech.dart';
import 'package:kde_na_zapade/game/game_day.dart';

void main() {
  group('GameDay', () {
    test('the day changes at midnight in Prague, not in UTC', () {
      // 22:30 UTC in October summer time is 00:30 in Prague.
      expect(
        GameDay.of(DateTime.utc(2026, 10, 9, 22, 30)),
        DateTime.utc(2026, 10, 10),
      );
      expect(
        GameDay.of(DateTime.utc(2026, 10, 9, 21, 59)),
        DateTime.utc(2026, 10, 9),
      );
      // 23:30 UTC in winter is 00:30 on New Year's Day.
      expect(
        GameDay.of(DateTime.utc(2026, 12, 31, 23, 30)),
        DateTime.utc(2027),
      );
    });

    test('follows summer time on the last Sundays of March and October', () {
      // 29 March 2026: clocks go from 02:00 CET to 03:00 CEST.
      expect(GameDay.wallClock(DateTime.utc(2026, 3, 29, 0, 59)).hour, 1);
      expect(GameDay.wallClock(DateTime.utc(2026, 3, 29, 1)).hour, 3);
      // 25 October 2026: clocks go from 03:00 CEST back to 02:00 CET.
      expect(GameDay.wallClock(DateTime.utc(2026, 10, 25, 0, 59)).hour, 2);
      expect(GameDay.wallClock(DateTime.utc(2026, 10, 25, 1)).hour, 2);
      expect(GameDay.wallClock(DateTime.utc(2026, 10, 25, 2)).hour, 3);
    });
  });

  group('Czech', () {
    test('plural picks the form by count', () {
      String clues(int n) => Czech.count(n, 'klíč', 'klíče', 'klíčů');

      expect(clues(0), '0 klíčů');
      expect(clues(1), '1 klíč');
      expect(clues(3), '3 klíče');
      expect(clues(5), '5 klíčů');
      expect(clues(22), '22 klíčů');
    });

    test('shortDate is the weekday and date of an overline', () {
      expect(Czech.shortDate(DateTime.utc(2026, 10, 9)), 'PÁ 9. 10.');
      expect(Czech.shortDate(DateTime.utc(2026, 10, 12)), 'PO 12. 10.');
    });
  });
}
