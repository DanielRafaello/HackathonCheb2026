import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:xml/xml.dart';

import 'package:kde_na_zapade/design_system/design_system.dart';
import 'package:kde_na_zapade/design_system/mascot_motion.dart';

/// The drawn elements (not groups or metadata) of an SVG.
int _shapes(String svg) => XmlDocument.parse(svg).rootElement.descendantElements
    .where((e) => e.name.local != 'g')
    .where((e) => !e.ancestorElements.any((a) => a.name.local == 'metadata'))
    .where((e) => e.name.local != 'metadata')
    .length;

void main() {
  group('mascotLayers', () {
    for (final mood in KnzMood.values) {
      test('keeps every shape of ${mood.file} in order', () {
        final svg = File(mood.asset).readAsStringSync();
        final layers = mascotLayers(svg, mood);

        expect(
          layers.map((l) => _shapes(l.svg)).fold(0, (a, b) => a + b),
          _shapes(svg),
        );
        expect(layers.first.part, MascotPart.shadow);
        for (var i = 1; i < layers.length; i++) {
          expect(layers[i].part, isNot(layers[i - 1].part));
        }
        for (final layer in layers) {
          final root = XmlDocument.parse(layer.svg).rootElement;
          expect(root.getAttribute('viewBox'), '0 0 120 140');
        }
      });
    }

    test('fails loudly when a mood is redrawn with other parts', () {
      final svg = File(KnzMood.happy.asset).readAsStringSync();
      expect(() => mascotLayers(svg, KnzMood.think), throwsFormatException);
    });
  });

  group('MascotPose', () {
    test('is the same at the same time', () {
      for (final mood in KnzMood.values) {
        final a = MascotPose.at(mood, 7.3);
        final b = MascotPose.at(mood, 7.3);
        expect(a.root.scaleY, b.root.scaleY);
        for (final part in MascotPart.values) {
          expect(a[part].rotation, b[part].rotation);
          expect(a[part].dy, b[part].dy);
        }
      }
    });

    // No visible part jumps between two frames at 60 fps, including where
    // the cycles wrap around.
    for (final mood in KnzMood.values) {
      test('moves ${mood.name} without jumps', () {
        bool visible(MascotTransform m) =>
            m.opacity > 0.01 && m.scaleX.abs() > 0.01 && m.scaleY.abs() > 0.01;
        var previous = MascotPose.at(mood, 0);
        for (var frame = 1; frame <= 60 * 30; frame++) {
          final pose = MascotPose.at(mood, frame / 60);
          final moves = [
            (pose.root, previous.root, 'root'),
            for (final part in MascotPart.values)
              (pose[part], previous[part], part.name),
          ];
          for (final (now, before, name) in moves) {
            if (!visible(now) || !visible(before)) continue;
            final at = 'frame $frame, $name';
            expect((now.dx - before.dx).abs(), lessThan(3), reason: at);
            expect((now.dy - before.dy).abs(), lessThan(3), reason: at);
            expect(
              (now.rotation - before.rotation).abs(),
              lessThan(0.1),
              reason: at,
            );
            // A blink closes the eyes in four frames.
            expect(
              (now.scaleX - before.scaleX).abs(),
              lessThan(0.25),
              reason: at,
            );
            expect(
              (now.scaleY - before.scaleY).abs(),
              lessThan(0.25),
              reason: at,
            );
            expect(
              (now.opacity - before.opacity).abs(),
              lessThan(0.1),
              reason: at,
            );
          }
          previous = pose;
        }
      });
    }
  });
}
