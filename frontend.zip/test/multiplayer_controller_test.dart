import 'dart:async';

import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/multiplayer/multiplayer_controller.dart';
import 'package:kde_na_zapade/multiplayer/multiplayer_store.dart';
import 'package:kde_na_zapade/multiplayer/protocol.dart';
import 'package:kde_na_zapade/round/geo.dart';

import 'fake_multiplayer_server.dart';

/// Inside the region (Loket) and outside it (Bavaria).
const inRegion = GeoPoint(50.1859, 12.7541);
const abroad = GeoPoint(49.95, 12.10);

/// Lets the microtasks and zero timers run.
Future<void> settle() async {
  for (var i = 0; i < 5; i++) {
    await Future<void>.delayed(Duration.zero);
  }
}

void main() {
  late FakeMultiplayerServer server;
  late MemoryMultiplayerStore store;
  late DateTime now;
  late StreamController<void> ticks;
  String? token;
  late int refreshes;
  late List<MultiplayerNotice> notices;

  MultiplayerController newController({
    int maxReconnectAttempts = 6,
    String identity = MultiplayerController.guestIdentity,
    Duration pingInterval = const Duration(hours: 1),
    Duration answerTimeout = const Duration(hours: 1),
  }) {
    final controller = MultiplayerController(
      connect: server.connect,
      store: store,
      token: () => token,
      refreshToken: () async {
        refreshes++;
        token = 'fresh-jwt';
        return true;
      },
      clock: () => now,
      ticker: () => ticks.stream,
      reconnectDelay: (_) => Duration.zero,
      maxReconnectAttempts: maxReconnectAttempts,
      identity: () => identity,
      pingInterval: pingInterval,
      answerTimeout: answerTimeout,
    );
    controller.notices.listen(notices.add);
    addTearDown(controller.dispose);
    return controller;
  }

  setUp(() {
    server = FakeMultiplayerServer();
    store = MemoryMultiplayerStore();
    now = serverEpoch;
    ticks = StreamController<void>.broadcast();
    token = null;
    refreshes = 0;
    notices = [];
  });

  /// A guest in lobby K7M2QX as its host.
  Future<MultiplayerController> inLobby({
    Duration pingInterval = const Duration(hours: 1),
    Duration answerTimeout = const Duration(hours: 1),
  }) async {
    final controller = newController(
      pingInterval: pingInterval,
      answerTimeout: answerTimeout,
    );
    await controller.start();
    await controller.createLobby(nickname: 'Eva');
    server.last.receive(welcomeJson());
    server.last.receive(stateJson());
    await settle();
    return controller;
  }

  /// A guest playing a game of three places.
  Future<MultiplayerController> playing({int guessed = 0}) async {
    final controller = await inLobby();
    server.last.receive(
      stateJson(
        phase: 'playing',
        game: playingGameJson(guessed: guessed),
        players: [
          playerJson('p1', 'Eva', host: true, view: 'game'),
          playerJson('p2', 'Adam', view: 'game'),
        ],
      ),
    );
    await settle();
    return controller;
  }

  group('entry', () {
    test('a guest creates a lobby under a nickname', () async {
      final controller = newController();
      await controller.start();
      expect(controller.phase, MultiplayerPhase.entry);

      await controller.createLobby(nickname: '  Eva ');
      expect(controller.phase, MultiplayerPhase.connecting);
      expect(server.last.sent, [
        {'type': 'hello', 'nickname': 'Eva'},
      ]);

      server.last.receive(welcomeJson());
      await settle();
      expect(server.last.sentTypes, ['hello', 'createLobby']);

      server.last.receive(stateJson());
      await settle();
      expect(controller.phase, MultiplayerPhase.lobby);
      expect(controller.lobby!.code, 'K7M2QX');
      expect(controller.lobby!.isHost, isTrue);
      expect(store.nickname, 'Eva');
      expect(store.seat!.resumeToken, 'resume-1');
      expect(store.seat!.lobbyCode, 'K7M2QX');
    });

    test('refuses a nickname that is too short without connecting', () async {
      final controller = newController();
      await controller.start();

      await controller.createLobby(nickname: 'E');

      expect(controller.entryError, EntryError.nicknameInvalid);
      expect(server.connections, isEmpty);
    });

    test('refuses a code of the wrong length', () async {
      final controller = newController();
      await controller.start();

      await controller.joinLobby('ABC', nickname: 'Eva');

      expect(controller.entryError, EntryError.codeInvalid);
      expect(server.connections, isEmpty);
    });

    test('a signed-in player joins the lobby of an invite link', () async {
      token = 'jwt';
      final controller = newController();
      await controller.start(joinCode: 'k7m2 qx');

      expect(server.last.sent.single, {'type': 'hello', 'token': 'jwt'});
      server.last.receive(welcomeJson(isGuest: false, nickname: 'Eva N.'));
      await settle();
      expect(server.last.lastOf('joinLobby'), {
        'type': 'joinLobby',
        'code': 'K7M2QX',
      });
      expect(controller.nickname, 'Eva N.');

      server.last.receive(stateJson(hostId: 'p2'));
      await settle();
      expect(controller.phase, MultiplayerPhase.lobby);
      expect(controller.lobby!.isHost, isFalse);
    });

    test('a guest without a nickname sees the form with the code', () async {
      final controller = newController();
      await controller.start(joinCode: 'K7M2QX');

      expect(controller.phase, MultiplayerPhase.entry);
      expect(controller.initialCode, 'K7M2QX');
      expect(server.connections, isEmpty);
    });

    test('an unknown lobby goes back to the form', () async {
      final controller = newController();
      await controller.start();
      await controller.joinLobby('K7M2QX', nickname: 'Eva');
      server.last.receive(welcomeJson());
      server.last.receive(errorJson('lobby.not_found'));
      await settle();

      expect(controller.phase, MultiplayerPhase.entry);
      expect(controller.entryError, EntryError.lobbyNotFound);
      expect(server.last.closed, isTrue);
    });

    test('an unreachable server goes back to the form with a notice', () async {
      server.fail = 1;
      final controller = newController();
      await controller.start();
      await controller.createLobby(nickname: 'Eva');
      await settle();

      expect(controller.phase, MultiplayerPhase.entry);
      expect(notices, [MultiplayerNotice.connectionFailed]);
    });

    test('a server error answering the hello goes back to the form', () async {
      final controller = newController();
      await controller.start();
      await controller.createLobby(nickname: 'Eva');
      server.last.receive(errorJson('server.error'));
      await settle();

      expect(controller.phase, MultiplayerPhase.entry);
      expect(controller.entryError, isNull);
      expect(notices, [MultiplayerNotice.serverError]);
      expect(server.last.closed, isTrue);
    });

    test('a refused join goes back to the form', () async {
      final controller = newController();
      await controller.start();
      await controller.joinLobby('K7M2QX', nickname: 'Eva');
      server.last.receive(welcomeJson());
      server.last.receive(errorJson('rate_limited'));
      await settle();

      expect(controller.phase, MultiplayerPhase.entry);
      expect(notices, [MultiplayerNotice.rateLimited]);
    });

    test('an expired JWT is refreshed once and the hello sent again', () async {
      token = 'old-jwt';
      final controller = newController();
      await controller.start();
      await controller.createLobby();
      server.last.receive(errorJson('auth.invalid_token'));
      await settle();

      expect(refreshes, 1);
      expect(server.connections, hasLength(2));
      expect(server.connections.first.closed, isTrue);
      expect(server.last.sent.single, {'type': 'hello', 'token': 'fresh-jwt'});
      server.last.receive(welcomeJson(isGuest: false));
      await settle();
      expect(server.last.sentTypes, ['hello', 'createLobby']);
      expect(controller.phase, MultiplayerPhase.connecting);
    });

    test('a JWT rejected after the refresh asks to sign in again', () async {
      token = 'old-jwt';
      final controller = newController();
      await controller.start();
      await controller.createLobby();
      server.last.receive(errorJson('auth.invalid_token'));
      await settle();
      server.last.receive(errorJson('auth.invalid_token'));
      await settle();

      expect(refreshes, 1);
      expect(server.connections, hasLength(2));
      expect(server.last.closed, isTrue);
      expect(controller.phase, MultiplayerPhase.entry);
      expect(notices, [MultiplayerNotice.signInExpired]);
    });

    test('leaving while the JWT is refreshed does not connect again', () async {
      token = 'old-jwt';
      final refreshed = Completer<bool>();
      final controller = MultiplayerController(
        connect: server.connect,
        store: store,
        token: () => token,
        refreshToken: () => refreshed.future,
        clock: () => now,
        ticker: () => ticks.stream,
        reconnectDelay: (_) => Duration.zero,
      );
      addTearDown(controller.dispose);
      await controller.start();
      await controller.createLobby();
      server.last.receive(errorJson('auth.invalid_token'));
      await settle();

      controller.leave();
      token = 'fresh-jwt';
      refreshed.complete(true);
      await settle();

      expect(server.connections, hasLength(1));
      expect(controller.phase, MultiplayerPhase.entry);
    });

    test('a guest nickname follows the server rule', () {
      String? valid(String nickname) =>
          MultiplayerController.validNickname(nickname);

      expect(valid('  Eva  '), 'Eva');
      expect(valid('Eva   Nová'), 'Eva Nová');
      expect(valid('E'), isNull);
      expect(valid('Ev'), 'Ev');
      expect(valid('a' * 24), 'a' * 24);
      expect(valid('a' * 25), isNull);
      // Characters, not UTF-16 units: 24 emoji are fine, as on the server.
      expect(valid('😀' * 24), '😀' * 24);
      // Runs of spaces count once, as the server keeps them.
      expect(valid('a${' ' * 30}b'), 'a b');
      expect(valid('Eva\u0007'), isNull);
      expect(valid('Eva\u0085x'), isNull);
      expect(valid('E\u200Bva'), isNull);
      expect(valid('E\u2028va'), isNull);
    });
  });

  group('lobby', () {
    test('the host changes the settings and starts the game', () async {
      final controller = await inLobby();
      expect(controller.canStart, isTrue);

      controller.updateSettings(placeCount: 15);
      controller.startGame();

      expect(server.last.lastOf('updateSettings'), {
        'type': 'updateSettings',
        'settings': {'placeCount': 15},
      });
      expect(server.last.sentTypes.last, 'startGame');
    });

    test('a player who is not the host cannot start', () async {
      final controller = await inLobby();
      server.last.receive(stateJson(hostId: 'p2'));
      await settle();

      expect(controller.canStart, isFalse);
      controller.startGame();
      expect(server.last.sentTypes, isNot(contains('startGame')));
    });

    test('leaving frees the seat and goes back to the form', () async {
      final controller = await inLobby();
      final connection = server.last;

      controller.leave();

      expect(connection.sentTypes.last, 'leaveLobby');
      expect(connection.closed, isTrue);
      expect(store.seat, isNull);
      expect(controller.phase, MultiplayerPhase.entry);
      expect(controller.lobby, isNull);
    });

    test('leaving while the connection is restored stops the retry', () async {
      final controller = MultiplayerController(
        connect: server.connect,
        store: store,
        clock: () => now,
        ticker: () => ticks.stream,
        reconnectDelay: (_) => const Duration(milliseconds: 20),
      );
      addTearDown(controller.dispose);
      await controller.start();
      await controller.createLobby(nickname: 'Eva');
      server.last.receive(welcomeJson());
      server.last.receive(stateJson());
      await settle();
      server.last.drop();
      await settle();
      expect(controller.reconnecting, isTrue);

      controller.leave();
      await Future<void>.delayed(const Duration(milliseconds: 60));

      expect(server.connections, hasLength(1));
      expect(controller.reconnecting, isFalse);
      expect(controller.phase, MultiplayerPhase.entry);
    });

    test('a lost seat in a lobby that is gone goes back to the form', () async {
      final controller = await inLobby();
      server.last.drop();
      await settle();
      server.last.receive(errorJson('resume.invalid'));
      server.last.receive(welcomeJson(resumeToken: 'resume-3'));
      server.last.receive(stateJson(noLobby: true));
      server.last.receive(errorJson('lobby.not_found'));
      await settle();

      expect(controller.phase, MultiplayerPhase.entry);
      expect(controller.entryError, EntryError.lobbyNotFound);
      expect(controller.lobby, isNull);
      expect(store.seat, isNull);

      // A later failure to connect is not taken for a lost lobby seat.
      server.fail = 1;
      await controller.createLobby(nickname: 'Eva');
      await settle();
      expect(controller.phase, MultiplayerPhase.entry);
      expect(controller.reconnecting, isFalse);
      expect(notices.last, MultiplayerNotice.connectionFailed);
    });

    test('a removed player goes back to the form', () async {
      final controller = await inLobby();
      server.last.receive(stateJson(noLobby: true));
      await settle();

      expect(controller.phase, MultiplayerPhase.entry);
      expect(notices, [MultiplayerNotice.removed]);
    });

    test('server refusals become notices', () async {
      await inLobby();
      server.last.receive(errorJson('lobby.not_enough_players'));
      server.last.receive(errorJson('rate_limited'));
      server.last.receive(errorJson('something.new'));
      await settle();

      expect(notices, [
        MultiplayerNotice.notEnoughPlayers,
        MultiplayerNotice.rateLimited,
        MultiplayerNotice.serverError,
      ]);
    });
  });

  group('game', () {
    test('the player guesses each place once and sees the result', () async {
      final controller = await playing();
      expect(controller.phase, MultiplayerPhase.playing);
      expect(controller.selfGame!.currentPlaceName, 'Místo 1');
      expect(controller.canGuess, isTrue);

      controller.placePin(inRegion);
      controller.confirmGuess();
      controller.confirmGuess();

      expect(server.last.sent.where((m) => m['type'] == 'guess').toList(), [
        {
          'type': 'guess',
          'index': 0,
          'latitude': inRegion.latitude,
          'longitude': inRegion.longitude,
        },
      ]);
      expect(controller.submitting, isTrue);
      expect(controller.canGuess, isFalse);

      server.last.receive(guessResultJson(0, distance: 2300));
      server.last.receive(
        stateJson(phase: 'playing', game: playingGameJson(guessed: 1)),
      );
      await settle();

      expect(controller.submitting, isFalse);
      expect(controller.pin, isNull);
      expect(controller.shownResult!.distanceMeters, 2300);
      expect(controller.shownResult!.place.name, 'Místo 1');
      expect(controller.canGuess, isFalse);

      controller.dismissResult();
      expect(controller.shownResult, isNull);
      expect(controller.selfGame!.currentPlaceName, 'Místo 2');
      expect(controller.canGuess, isTrue);
    });

    test('a pin outside the region is not sent', () async {
      final controller = await playing();

      controller.placePin(abroad);
      controller.confirmGuess();
      await settle();

      expect(server.last.sentTypes, isNot(contains('guess')));
      expect(controller.pin, abroad);
      expect(notices, [MultiplayerNotice.outsideRegion]);
    });

    test('a refused guess keeps the pin', () async {
      final controller = await playing();
      controller.placePin(inRegion);
      controller.confirmGuess();
      server.last.receive(errorJson('guess.outside_region'));
      await settle();

      expect(controller.submitting, isFalse);
      expect(controller.pin, inRegion);
      expect(controller.canGuess, isTrue);
    });

    test('the guess that ends the game shows its result first', () async {
      final controller = await playing(guessed: 2);
      controller.placePin(inRegion);
      controller.confirmGuess();
      server.last.receive(guessResultJson(2, distance: 2300));
      server.last.receive(
        stateJson(
          phase: 'finished',
          game: finishedGameJson(),
          players: [
            playerJson('p1', 'Eva', host: true, view: 'results'),
            playerJson('p2', 'Adam', view: 'results'),
          ],
        ),
      );
      await settle();

      expect(controller.phase, MultiplayerPhase.results);
      expect(controller.shownResult!.index, 2);
      expect(controller.shownResult!.distanceMeters, 2300);

      controller.dismissResult();
      expect(controller.shownResult, isNull);
      expect(controller.resultsGame!.leaderboard, isNotNull);
    });

    test('after the last place the player waits for the others', () async {
      final controller = await playing(guessed: 3);

      expect(controller.finishedAllPlaces, isTrue);
      expect(controller.canGuess, isFalse);
    });

    test('the end of the game shows the results', () async {
      final controller = await playing(guessed: 3);
      server.last.receive(
        stateJson(
          phase: 'finished',
          game: finishedGameJson(),
          players: [
            playerJson('p1', 'Eva', host: true, view: 'results'),
            playerJson('p2', 'Adam', view: 'results'),
          ],
        ),
      );
      await settle();

      expect(controller.phase, MultiplayerPhase.results);
      expect(controller.game!.leaderboard!.first.nickname, 'Adam');
      expect(controller.remaining, isNull);

      controller.returnToLobby();
      expect(server.last.sentTypes.last, 'returnToLobby');
      server.last.receive(
        stateJson(phase: 'finished', game: finishedGameJson()),
      );
      await settle();
      expect(controller.phase, MultiplayerPhase.lobby);
      expect(controller.canStart, isTrue);
    });

    test(
      'the results stay while the next game runs without the player',
      () async {
        final controller = await playing(guessed: 3);
        server.last.receive(
          stateJson(
            phase: 'finished',
            game: finishedGameJson(),
            players: [
              playerJson('p1', 'Eva', host: true, view: 'results'),
              playerJson('p2', 'Adam', view: 'results'),
            ],
          ),
        );
        await settle();
        expect(controller.resultsGame!.leaderboard, isNotNull);

        // Adam went back and started a new game; Eva still reads the results.
        final next = playingGameJson(participant: false)
          ..['startedAt'] = ms(serverEpoch.add(const Duration(minutes: 10)))
          ..['participantIds'] = ['p2'];
        server.last.receive(
          stateJson(
            phase: 'playing',
            hostId: 'p2',
            game: next,
            players: [
              playerJson('p1', 'Eva', view: 'results'),
              playerJson('p2', 'Adam', host: true, view: 'game'),
            ],
          ),
        );
        await settle();

        expect(controller.phase, MultiplayerPhase.results);
        expect(controller.game!.status, GameStatus.playing);
        expect(controller.resultsGame!.status, GameStatus.finished);
        expect(controller.resultsGame!.leaderboard!.first.nickname, 'Adam');
      },
    );

    test('the countdown follows the server clock and ticks', () async {
      // This device's clock is an hour behind the server's.
      now = serverEpoch.subtract(const Duration(hours: 1));
      final controller = await playing();
      server.last.receive(
        stateJson(
          serverNow: serverEpoch.add(const Duration(seconds: 20)),
          phase: 'playing',
          game: playingGameJson(),
        ),
      );
      await settle();
      expect(controller.remaining, const Duration(minutes: 4, seconds: 40));

      var notified = 0;
      controller.addListener(() => notified++);
      now = now.add(const Duration(seconds: 30));
      ticks.add(null);
      await settle();

      expect(notified, 1);
      expect(controller.remaining, const Duration(minutes: 4, seconds: 10));

      now = now.add(const Duration(hours: 1));
      expect(controller.remaining, Duration.zero);
    });
  });

  group('connection', () {
    test(
      'a lost connection takes the seat back with the resume token',
      () async {
        final controller = await playing();
        server.last.drop();
        await settle();

        expect(controller.reconnecting, isTrue);
        expect(controller.phase, MultiplayerPhase.playing);
        expect(controller.canGuess, isFalse);
        expect(server.connections, hasLength(2));
        expect(server.last.sent.single, {
          'type': 'hello',
          'nickname': 'Eva',
          'resumeToken': 'resume-1',
        });

        server.last.receive(welcomeJson(resumeToken: 'resume-2'));
        server.last.receive(
          stateJson(phase: 'playing', game: playingGameJson()),
        );
        await settle();

        expect(controller.reconnecting, isFalse);
        expect(controller.canGuess, isTrue);
        expect(store.seat!.resumeToken, 'resume-2');
      },
    );

    test('a guess whose answer was lost shows its result', () async {
      final controller = await playing();
      controller.placePin(inRegion);
      controller.confirmGuess();
      server.last.drop();
      await settle();

      server.last.receive(welcomeJson());
      server.last.receive(
        stateJson(phase: 'playing', game: playingGameJson(guessed: 1)),
      );
      await settle();

      expect(controller.submitting, isFalse);
      expect(controller.shownResult!.index, 0);
      expect(controller.shownResult!.distanceMeters, 1200);
    });

    test('a guess that did not land keeps the pin', () async {
      final controller = await playing();
      controller.placePin(inRegion);
      controller.confirmGuess();
      server.last.drop();
      await settle();

      server.last.receive(welcomeJson());
      server.last.receive(stateJson(phase: 'playing', game: playingGameJson()));
      await settle();

      expect(controller.shownResult, isNull);
      expect(controller.pin, inRegion);
      expect(controller.canGuess, isTrue);
    });

    test('a lost seat joins the lobby again', () async {
      final controller = await inLobby();
      server.last.drop();
      await settle();

      server.last.receive(errorJson('resume.invalid'));
      await settle();
      // The join waits for the welcome, or it would race the hello.
      expect(server.last.sentTypes, ['hello']);
      server.last.receive(welcomeJson(resumeToken: 'resume-3'));
      await settle();

      expect(server.last.sentTypes, ['hello', 'joinLobby']);
      expect(server.last.lastOf('joinLobby'), {
        'type': 'joinLobby',
        'code': 'K7M2QX',
      });
      server.last.receive(stateJson());
      await settle();
      expect(controller.phase, MultiplayerPhase.lobby);
      expect(store.seat!.resumeToken, 'resume-3');
    });

    test('gives up after the attempts and tries again on request', () async {
      final controller = MultiplayerController(
        connect: server.connect,
        store: store,
        clock: () => now,
        ticker: () => ticks.stream,
        reconnectDelay: (_) => Duration.zero,
        maxReconnectAttempts: 2,
      );
      addTearDown(controller.dispose);
      await controller.start();
      await controller.createLobby(nickname: 'Eva');
      server.last.receive(welcomeJson());
      server.last.receive(stateJson());
      await settle();

      server.fail = 5;
      server.last.drop();
      await settle();

      expect(controller.phase, MultiplayerPhase.disconnected);
      expect(controller.reconnecting, isFalse);

      server.fail = 0;
      await controller.retry();
      expect(server.last.sent.single['resumeToken'], 'resume-1');
      server.last.receive(welcomeJson());
      server.last.receive(stateJson());
      await settle();
      expect(controller.phase, MultiplayerPhase.lobby);
    });

    test('a connection that stops answering is restored', () async {
      final controller = await inLobby(
        pingInterval: const Duration(milliseconds: 20),
        answerTimeout: const Duration(milliseconds: 200),
      );
      final first = server.last;
      await Future<void>.delayed(const Duration(milliseconds: 100));
      expect(first.sentTypes, contains('ping'));
      expect(server.connections, hasLength(1));
      expect(controller.reconnecting, isFalse);

      // No pong and no state: the socket is dead without having closed.
      await Future<void>.delayed(const Duration(milliseconds: 200));
      expect(first.closed, isTrue);
      expect(server.connections, hasLength(2));
      expect(controller.reconnecting, isTrue);
      expect(server.last.sent.single['resumeToken'], 'resume-1');

      server.last.receive(welcomeJson());
      server.last.receive(stateJson());
      await settle();
      expect(controller.reconnecting, isFalse);
    });

    test('back in the foreground a dead connection is restored', () async {
      final controller = await inLobby(
        answerTimeout: const Duration(milliseconds: 50),
      );
      final first = server.last;

      controller.checkConnection();
      expect(first.sentTypes.last, 'ping');
      first.receive({'type': 'pong'});
      await Future<void>.delayed(const Duration(milliseconds: 100));
      expect(server.connections, hasLength(1));

      controller.checkConnection();
      await Future<void>.delayed(const Duration(milliseconds: 100));
      expect(first.closed, isTrue);
      expect(server.connections, hasLength(2));
      expect(controller.reconnecting, isTrue);
    });

    test('a server error while the seat is restored tries again', () async {
      final controller = await inLobby();
      server.last.drop();
      await settle();
      server.last.receive(errorJson('resume.invalid'));
      server.last.receive(welcomeJson(resumeToken: 'resume-3'));
      await settle();
      expect(server.last.sentTypes, ['hello', 'joinLobby']);

      server.last.receive(errorJson('server.error'));
      await settle();

      expect(server.connections, hasLength(3));
      expect(controller.reconnecting, isTrue);
      expect(server.last.sent.single['resumeToken'], 'resume-3');
      server.last.receive(errorJson('resume.invalid'));
      server.last.receive(welcomeJson(resumeToken: 'resume-4'));
      await settle();
      expect(server.last.sentTypes, ['hello', 'joinLobby']);
      server.last.receive(stateJson());
      await settle();
      expect(controller.phase, MultiplayerPhase.lobby);
      expect(controller.reconnecting, isFalse);
    });

    test(
      'a lost seat whose join was cut off joins on the next connection',
      () async {
        final controller = await inLobby();
        server.last.drop();
        await settle();
        server.last.receive(errorJson('resume.invalid'));
        server.last.drop();
        await settle();

        expect(server.connections, hasLength(3));
        expect(server.last.sent.single, {'type': 'hello', 'nickname': 'Eva'});
        server.last.receive(welcomeJson(resumeToken: 'resume-4'));
        await settle();
        expect(server.last.sentTypes, ['hello', 'joinLobby']);
        server.last.receive(stateJson());
        await settle();
        expect(controller.phase, MultiplayerPhase.lobby);
      },
    );

    test('a seat taken over in another window is not taken back', () async {
      final controller = await inLobby();
      server.last.drop(code: closeReplaced);
      await settle();

      expect(server.connections, hasLength(1));
      expect(controller.phase, MultiplayerPhase.disconnected);
      expect(controller.openElsewhere, isTrue);
      expect(controller.reconnecting, isFalse);

      // Only when the player asks does this window take the seat back.
      await controller.retry();
      expect(controller.openElsewhere, isFalse);
      expect(server.last.sent.single['resumeToken'], 'resume-1');
    });

    test(
      'leaving after a takeover forgets this window\'s copy of the seat',
      () async {
        final controller = await inLobby();
        server.last.drop(code: closeReplaced);
        await settle();
        final connections = server.connections.length;

        controller.leave();

        expect(controller.phase, MultiplayerPhase.entry);
        expect(store.seat, isNull);

        // Entering multiplayer here again does not take the seat back from
        // the other window.
        final again = newController();
        await again.start();
        expect(again.phase, MultiplayerPhase.entry);
        expect(server.connections, hasLength(connections));
      },
    );

    test('a seat stored for another player is not taken back', () async {
      store = MemoryMultiplayerStore(
        nickname: 'Eva',
        seat: const StoredSeat(
          resumeToken: 'resume-9',
          lobbyCode: 'K7M2QX',
          owner: 'account:7',
        ),
      );
      final controller = newController();
      await controller.start();

      expect(controller.phase, MultiplayerPhase.entry);
      expect(server.connections, isEmpty);
      expect(store.seat, isNull);
    });

    test('a seat is stored with the player who took it', () async {
      token = 'jwt';
      final controller = newController(identity: 'account:7');
      await controller.start();
      await controller.createLobby();
      server.last.receive(welcomeJson(isGuest: false));
      server.last.receive(stateJson());
      await settle();

      expect(controller.phase, MultiplayerPhase.lobby);
      expect(store.seat!.owner, 'account:7');
    });

    test('starts by taking back the seat of the last lobby', () async {
      store = MemoryMultiplayerStore(
        nickname: 'Eva',
        seat: const StoredSeat(
          resumeToken: 'resume-9',
          lobbyCode: 'K7M2QX',
          owner: MultiplayerController.guestIdentity,
        ),
      );
      final controller = newController();
      await controller.start();

      expect(server.last.sent.single, {
        'type': 'hello',
        'nickname': 'Eva',
        'resumeToken': 'resume-9',
      });
      server.last.receive(welcomeJson());
      server.last.receive(stateJson());
      await settle();
      expect(controller.phase, MultiplayerPhase.lobby);
      expect(server.last.sentTypes, ['hello']);
    });
  });
}
