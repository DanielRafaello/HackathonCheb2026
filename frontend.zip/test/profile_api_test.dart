import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/design_system/czech.dart';
import 'package:kde_na_zapade/profile/profile_api.dart';

void main() {
  test('parses the level from the profile', () {
    final level = PlayerLevel.fromJson({
      'wafers': 112,
      'points': {'total': 725, 'guessing': 425, 'visits': 300},
      'level': {
        'number': 2,
        'starts_at': 250,
        'next_level_at': 750,
        'points_in_level': 475,
        'points_to_next_level': 25,
      },
    });

    expect(level.number, 2);
    expect(level.points, 725);
    expect(level.pointsToNextLevel, 25);
    expect(level.progress, closeTo(0.95, 1e-9));
    expect(level.wafers, 112);
  });

  test('a profile without wafers has none', () {
    final level = PlayerLevel.fromJson({
      'points': {'total': 0},
      'level': {'number': 1, 'starts_at': 0, 'next_level_at': 250},
    });

    expect(level.wafers, 0);
  });

  test('writes thousands with a no-break space', () {
    expect(Czech.number(0), '0');
    expect(Czech.number(725), '725');
    expect(Czech.number(1000), '1 000');
    expect(Czech.number(56000), '56 000');
    expect(Czech.number(1234567), '1 234 567');
  });
}
