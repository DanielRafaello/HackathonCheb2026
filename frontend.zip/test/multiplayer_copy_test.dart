import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/multiplayer/multiplayer_copy.dart';

const nbsp = ' ';

void main() {
  test('the countdown label agrees with its first number', () {
    String label(int seconds) =>
        MultiplayerCopy.countdownLabel(Duration(seconds: seconds));

    expect(label(245), 'Zbývají 4${nbsp}minuty a${nbsp}5${nbsp}sekund');
    expect(label(2), 'Zbývají 2${nbsp}sekundy');
    expect(label(60), 'Zbývá 1${nbsp}minuta');
    expect(label(61), 'Zbývá 1${nbsp}minuta a${nbsp}1${nbsp}sekunda');
    expect(label(300), 'Zbývá 5${nbsp}minut');
    expect(label(9), 'Zbývá 9${nbsp}sekund');
    expect(label(0), 'Zbývá 0${nbsp}sekund');
  });

  test('after the last place Vřídlík does not point to a next place', () {
    for (final meters in [8000, 40000]) {
      expect(MultiplayerCopy.resultLine(meters), contains('alší'));
      expect(
        MultiplayerCopy.resultLine(meters, last: true),
        isNot(contains('alší')),
      );
    }
    expect(
      MultiplayerCopy.resultLine(300, last: true),
      MultiplayerCopy.resultLine(300),
    );
  });
}
