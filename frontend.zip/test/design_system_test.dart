import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/design_system/design_system.dart';
import 'package:kde_na_zapade/design_system/design_system_page.dart';

Widget _wrap(Widget child) => MaterialApp(
  home: Scaffold(body: Center(child: child)),
);

void main() {
  group('Czech.decimal and Czech.coordinates', () {
    test('write a decimal comma', () {
      expect(Czech.decimal(4.26, 1), '4,3');
      expect(Czech.decimal(4, 1), '4,0');
    });

    test('write the hemispheres the Czech way', () {
      expect(
        Czech.coordinates(50.081137, 12.366035),
        '50,0811°\u00A0s.\u00A0š., 12,3660°\u00A0v.\u00A0d.',
      );
      expect(
        Czech.coordinates(-1.5, -2.25),
        '1,5000°\u00A0j.\u00A0š., 2,2500°\u00A0z.\u00A0d.',
      );
    });
  });

  group('Czech.outOf', () {
    test('uses "ze" before numbers spoken with a sibilant', () {
      expect(Czech.fraction(9, 148), '9 ze 148');
      expect(Czech.fraction(1, 5), '1 z 5');
      for (final n in [4, 6, 7, 14, 17, 40, 70, 100, 199, 400, 4000]) {
        expect(Czech.outOf(n), 'ze', reason: '$n');
      }
      for (final n in [2, 3, 5, 10, 20, 25, 50, 200, 1000, 1500, 2000]) {
        expect(Czech.outOf(n), 'z', reason: '$n');
      }
    });
  });

  group('KnzButton', () {
    testWidgets('shows the label in capitals and reports taps', (tester) async {
      var taps = 0;
      await tester.pumpWidget(
        _wrap(KnzButton(label: 'Potvrdit tip', onPressed: () => taps++)),
      );

      await tester.tap(find.text('POTVRDIT TIP'));
      expect(taps, 1);
    });

    testWidgets('keeps its height while pressed', (tester) async {
      await tester.pumpWidget(
        _wrap(KnzButton(label: 'Pokračovat', onPressed: () {})),
      );
      final before = tester.getSize(find.byType(KnzButton));

      final gesture = await tester.startGesture(
        tester.getCenter(find.byType(KnzButton)),
      );
      await tester.pumpAndSettle();
      expect(tester.getSize(find.byType(KnzButton)), before);
      await gesture.up();
    });

    testWidgets('is announced as disabled without onPressed', (tester) async {
      final handle = tester.ensureSemantics();
      await tester.pumpWidget(
        _wrap(const KnzButton(label: 'Luštit dál', onPressed: null)),
      );

      expect(
        tester.getSemantics(find.byType(KnzButton)),
        matchesSemantics(
          isButton: true,
          hasEnabledState: true,
          isEnabled: false,
          label: 'LUŠTIT DÁL',
        ),
      );
      handle.dispose();
    });
  });

  group('KnzAttemptProgress', () {
    testWidgets('describes the current guess', (tester) async {
      await tester.pumpWidget(
        _wrap(const KnzAttemptProgress(missed: 1, total: 5)),
      );
      expect(find.bySemanticsLabel('Pokus 2 z 5'), findsOneWidget);
    });

    testWidgets('describes exhausted guesses', (tester) async {
      await tester.pumpWidget(
        _wrap(const KnzAttemptProgress(missed: 5, total: 5)),
      );
      expect(find.bySemanticsLabel('Všech 5 pokusů vyčerpáno'), findsOneWidget);
    });
  });

  testWidgets('KnzTextField shows a validator error under the field', (
    tester,
  ) async {
    final formKey = GlobalKey<FormState>();
    await tester.pumpWidget(
      _wrap(
        Form(
          key: formKey,
          child: KnzTextField(
            label: 'E-mail',
            controller: TextEditingController(),
            validator: (value) => value!.isEmpty ? 'Zadej e-mail.' : null,
          ),
        ),
      ),
    );

    expect(find.text('Zadej e-mail.'), findsNothing);
    formKey.currentState!.validate();
    await tester.pump();
    expect(find.text('Zadej e-mail.'), findsOneWidget);
  });

  for (final width in [1200.0, 390.0]) {
    testWidgets('the /design-system page renders every section at $width', (
      tester,
    ) async {
      tester.view.physicalSize = Size(width, 14000);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);

      await tester.pumpWidget(
        MaterialApp(
          initialRoute: DesignSystemPage.routeName,
          routes: {
            '/': (_) => const SizedBox(),
            DesignSystemPage.routeName: (_) => const DesignSystemPage(),
          },
        ),
      );
      await tester.pumpAndSettle();

      for (final title in [
        'Tlačítka',
        'Ikonová tlačítka',
        'Pole formuláře',
        'Karty',
        'Postup',
        'Štítky',
      ]) {
        expect(find.text(title), findsOneWidget, reason: title);
      }
      expect(tester.takeException(), isNull);
    });
  }
}
