import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:kde_na_zapade/progress/revealed_place.dart';
import 'package:kde_na_zapade/progress/shared_preferences_place_card_cache.dart';

const becov = RevealedPlace(
  id: 1,
  name: 'Hrad a zámek Bečov nad Teplou',
  latitude: 50.0807,
  longitude: 12.8389,
  category: 'Hrady, tvrze a zříceniny',
  description: 'V kapli tu našli relikviář sv. Maura.',
  contentSourceUrl: 'https://example.cz/becov',
  source: PlaceSourceInfo(publisher: 'datazapad.cz', licenseCode: 'CC BY'),
);

const loket = RevealedPlace(
  id: 2,
  name: 'Hrad Loket',
  latitude: 50.19,
  longitude: 12.75,
  category: 'Hrady, tvrze a zříceniny',
  description: '',
);

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('keeps a card across instances', () async {
    await SharedPreferencesPlaceCardCache().write(becov);

    final read = await SharedPreferencesPlaceCardCache().read(1);

    expect(read?.name, becov.name);
    expect(read?.category, becov.category);
    expect(read?.description, becov.description);
    expect(read?.contentSourceUrl, becov.contentSourceUrl);
    expect(read?.source?.publisher, 'datazapad.cz');
    expect(read?.source?.licenseCode, 'CC BY');
    expect(read?.isSpring, isFalse);
  });

  test('reads null for an unknown place', () async {
    expect(await SharedPreferencesPlaceCardCache().read(42), isNull);
  });

  test('stores under versioned keys and an index', () async {
    final cache = SharedPreferencesPlaceCardCache();
    await cache.write(becov);
    await cache.write(loket);
    await cache.write(becov);

    final preferences = await SharedPreferences.getInstance();
    expect(preferences.getString('knz.placeCard.v1.1'), isNotNull);
    expect(preferences.getString('knz.placeCard.v1.2'), isNotNull);
    expect(preferences.getStringList('knz.placeCard.v1.index'), ['1', '2']);
  });

  test('clear forgets every card', () async {
    final cache = SharedPreferencesPlaceCardCache();
    await cache.write(becov);
    await cache.write(loket);

    await cache.clear();

    expect(await cache.read(1), isNull);
    expect(await cache.read(2), isNull);
    final preferences = await SharedPreferences.getInstance();
    expect(preferences.getKeys(), isEmpty);
  });

  test('reads null for a broken card', () async {
    SharedPreferences.setMockInitialValues({
      'knz.placeCard.v1.1': 'not json',
      'knz.placeCard.v1.2': '{"id": 2}',
    });
    final cache = SharedPreferencesPlaceCardCache();

    expect(await cache.read(1), isNull);
    expect(await cache.read(2), isNull);
  });

  test('never throws when the storage fails', () async {
    final cache = SharedPreferencesPlaceCardCache(
      preferences: () async => throw StateError('private window'),
    );

    expect(await cache.read(1), isNull);
    await cache.write(becov);
    await cache.clear();
  });
}
