import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/account/account_api.dart';
import 'package:kde_na_zapade/account/session.dart';
import 'package:kde_na_zapade/account/token_storage.dart';
import 'package:kde_na_zapade/api/authorized_client.dart';
import 'package:kde_na_zapade/app_router.dart';
import 'package:kde_na_zapade/app_routes.dart';
import 'package:kde_na_zapade/config/api_config.dart';
import 'package:kde_na_zapade/config/map_config.dart';
import 'package:kde_na_zapade/config/multiplayer_config.dart';
import 'package:kde_na_zapade/main.dart';
import 'package:kde_na_zapade/multiplayer/multiplayer_store.dart';
import 'package:kde_na_zapade/my_map/locations_api.dart';

import 'fake_multiplayer_server.dart';
import 'session_test.dart' show FakeBackend;

void main() {
  late FakeBackend backend;

  Session newSession() => Session(
    api: AccountApi(
      config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api/')),
      client: backend.client,
    ),
    storage: MemoryTokenStorage(),
  );

  String? redirect(Session session, String location) =>
      sessionRedirect(session, Uri.parse(location));

  setUp(() => backend = FakeBackend());

  group('sessionRedirect', () {
    test('waits on the loading page while the session restores', () {
      final session = newSession();

      expect(redirect(session, '/'), AppRoutes.loading);
      expect(
        redirect(session, '/profile'),
        '/loading?from=${Uri.encodeQueryComponent('/profile')}',
      );
      expect(redirect(session, '/loading'), isNull);
    });

    test('sends a player who has not entered to sign-in', () async {
      final session = newSession();
      await session.restore();

      expect(redirect(session, '/'), AppRoutes.signIn);
      expect(redirect(session, '/loading'), AppRoutes.signIn);
      expect(
        redirect(session, '/free-play'),
        '/sign-in?from=${Uri.encodeQueryComponent('/free-play')}',
      );
      expect(redirect(session, '/sign-in'), isNull);
      expect(redirect(session, '/register'), isNull);
    });

    test('lets a guest play and open the account pages', () async {
      final session = newSession();
      await session.restore();
      session.continueAsGuest();

      expect(redirect(session, '/'), isNull);
      expect(redirect(session, '/profile'), isNull);
      expect(redirect(session, '/sign-in'), isNull);
    });

    test('sends a signed-in player from the account pages on', () async {
      final session = newSession();
      await session.restore();
      await session.signIn(email: 'eva@example.cz', password: 'tajneheslo');

      expect(redirect(session, '/'), isNull);
      expect(redirect(session, '/sign-in'), AppRoutes.home);
      expect(redirect(session, '/sign-in?from=/profile'), '/profile');
      expect(redirect(session, '/loading?from=/free-play'), '/free-play');
    });

    test('never continues to another site or back to sign-in', () async {
      final session = newSession();
      await session.signIn(email: 'eva@example.cz', password: 'tajneheslo');
      await session.restore();

      expect(redirect(session, '/sign-in?from=//evil.example'), '/');
      expect(redirect(session, '/sign-in?from=https://evil.example'), '/');
      expect(redirect(session, '/register?from=/sign-in'), '/');
    });

    test('an invite link waits through sign-in and opens the lobby', () async {
      final session = newSession();
      await session.restore();
      final invite = AppRoutes.multiplayerLobby('K7M2QX');

      final signIn = redirect(session, invite)!;
      expect(
        signIn,
        '/sign-in?from=${Uri.encodeQueryComponent('/multiplayer/K7M2QX')}',
      );
      expect(
        AppRoutes.after(Uri.parse(signIn).queryParameters['from']),
        invite,
      );

      session.continueAsGuest();
      expect(redirect(session, invite), isNull);
      expect(redirect(session, AppRoutes.multiplayer), isNull);
    });

    test('sign-out sends the player back to sign-in', () async {
      final session = newSession();
      await session.restore();
      session.continueAsGuest();
      await session.signIn(email: 'eva@example.cz', password: 'tajneheslo');
      await session.signOut();

      expect(session.hasEntered, isFalse);
      expect(redirect(session, '/'), AppRoutes.signIn);
    });

    test('leaves the design system catalogue open to everyone', () {
      expect(redirect(newSession(), '/design-system'), isNull);
    });

    test('leaves the place card demo open to everyone', () {
      expect(redirect(newSession(), '/place/demo?gps=far'), isNull);
      expect(redirect(newSession(), '/place/12'), isNotNull);
    });
  });

  group('app', () {
    Future<Session> pumpApp(
      WidgetTester tester, {
      String initialLocation = AppRoutes.home,
      FakeMultiplayerServer? multiplayer,
    }) async {
      tester.view.physicalSize = const Size(390, 1200);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      // Vřídlík moves for as long as it is on screen; reduced motion stops
      // it so that the page can settle.
      tester.platformDispatcher.accessibilityFeaturesTestValue =
          const FakeAccessibilityFeatures(disableAnimations: true);
      addTearDown(
        tester.platformDispatcher.clearAccessibilityFeaturesTestValue,
      );
      final session = newSession();
      final client = AuthorizedClient(
        config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api/')),
        session: session,
        client: backend.client,
      );
      await tester.pumpWidget(
        App(
          router: createRouter(
            session: session,
            mapConfig: MapConfig.fromEnvironment(),
            client: client,
            locationsApi: LocationsApi(client: client),
            clock: () => DateTime.utc(2026, 10, 9, 6),
            initialLocation: initialLocation,
            multiplayerConfig: MultiplayerConfig(url: MultiplayerConfig.local),
            multiplayerConnector:
                (multiplayer ?? FakeMultiplayerServer()).connect,
            multiplayerStore: MemoryMultiplayerStore(),
          ),
        ),
      );
      await tester.runAsync(session.restore);
      await tester.pumpAndSettle();
      return session;
    }

    testWidgets('opens the place card demo without sign-in', (tester) async {
      await pumpApp(tester, initialLocation: '/place/demo?gps=far');

      expect(find.text('Hrad a zámek Bečov nad Teplou'), findsOneWidget);
      expect(find.text('31\u00A0km od\u00A0tebe'), findsOneWidget);

      await tester.tap(find.text('JSEM TU!'));
      await tester.pump(const Duration(seconds: 1));
      await tester.pumpAndSettle();

      expect(find.text('Ještě nejsi na místě'), findsOneWidget);
    });

    testWidgets('an invite link opens multiplayer after guest entry', (
      tester,
    ) async {
      await pumpApp(tester, initialLocation: '/multiplayer/K7M2QX');

      await tester.tap(find.text('ZKUSIT BEZ ÚČTU'));
      await tester.pumpAndSettle();

      expect(find.text('Hra s kamarády'), findsOneWidget);
      expect(find.text('Tvoje přezdívka'), findsOneWidget);
      expect(find.text('K7M2QX'), findsOneWidget);
    });

    testWidgets('opens on sign-in and enters Home as a guest', (tester) async {
      await pumpApp(tester);

      expect(find.text('PŘIHLÁSIT SE'), findsOneWidget);
      expect(find.text('Kde to je?'), findsNothing);

      await tester.tap(find.text('ZKUSIT BEZ ÚČTU'));
      await tester.pumpAndSettle();

      expect(find.text('Kde to je?'), findsOneWidget);
      expect(find.text('HRÁT MÍSTO DNE'), findsOneWidget);
      expect(find.text('MÍSTO DNE · PÁ 9. 10.'), findsOneWidget);
      expect(find.text('DNES'), findsOneWidget);
    });

    testWidgets('enters Home after sign-in and leaves it after sign-out', (
      tester,
    ) async {
      final session = await pumpApp(tester);

      await tester.runAsync(
        () => session.signIn(email: 'eva@example.cz', password: 'tajneheslo'),
      );
      await tester.pumpAndSettle();
      expect(find.text('Kde to je?'), findsOneWidget);

      await tester.runAsync(session.signOut);
      await tester.pumpAndSettle();
      expect(find.text('Kde to je?'), findsNothing);
      expect(find.text('PŘIHLÁSIT SE'), findsOneWidget);
    });

    testWidgets('signs in again from the form after a sign-out', (
      tester,
    ) async {
      final session = await pumpApp(tester);
      await tester.runAsync(
        () => session.signIn(email: 'eva@example.cz', password: 'tajneheslo'),
      );
      await tester.pumpAndSettle();
      await tester.runAsync(session.signOut);
      await tester.pumpAndSettle();

      await tester.enterText(find.byType(TextField).first, 'eva@example.cz');
      await tester.enterText(find.byType(TextField).last, 'tajneheslo');
      await tester.runAsync(() async {
        await tester.tap(find.text('PŘIHLÁSIT SE'));
        await Future<void>.delayed(const Duration(milliseconds: 100));
      });
      await tester.pumpAndSettle();

      expect(session.isSignedIn, isTrue);
      expect(find.text('Kde to je?'), findsOneWidget);
    });
  });
}
