import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/account/account_api.dart';
import 'package:kde_na_zapade/account/session.dart';
import 'package:kde_na_zapade/account/token_storage.dart';
import 'package:kde_na_zapade/config/api_config.dart';
import 'package:kde_na_zapade/config/multiplayer_config.dart';
import 'package:kde_na_zapade/multiplayer/multiplayer_page.dart';
import 'package:kde_na_zapade/multiplayer/multiplayer_store.dart';
import 'package:kde_na_zapade/round/guess_map_view.dart';
import 'package:kde_na_zapade/round/geo.dart';

import 'fake_multiplayer_server.dart';
import 'session_test.dart' show FakeBackend;

const loket = GeoPoint(50.1859, 12.7541);

Widget stubMap(GuessMapView view) => GestureDetector(
  key: ValueKey(view.interactive ? 'full map' : 'preview map'),
  behavior: HitTestBehavior.opaque,
  onTap: view.enabled ? () => view.onPin(loket) : null,
  child: const SizedBox.expand(),
);

/// 24 characters, the longest nickname the server accepts.
const longNick = 'Maximiliánka Novotná Ště';
const unbrokenNick = 'WWWWWWWWWWWWWWWWWWWWWWWW';
const longPlace =
    'Kostel sv. Mikuláše a hřbitov s kaplí Nejsvětější Trojice v Ostrově';

List<Map<String, Object?>> eightPlayers({String view = 'lobby'}) => [
  playerJson('p1', longNick, host: true, view: view, guessedCount: 10),
  playerJson('p2', unbrokenNick, view: view, guessedCount: 7),
  for (var i = 3; i <= 8; i++)
    playerJson(
      'p$i',
      'Hráč číslo $i s dlouhým jménem'.substring(0, 24),
      view: view,
      connected: i.isEven,
      guessedCount: i,
    ),
];

void main() {
  // The test font draws every glyph 1 em wide; real Nunito measures
  // overflow the way a phone does.
  setUpAll(() async {
    final bytes = File('assets/fonts/Nunito-Variable.ttf').readAsBytesSync();
    final loader = FontLoader('Nunito')
      ..addFont(Future.value(ByteData.sublistView(bytes)));
    await loader.load();
  });

  late FakeBackend backend;
  late FakeMultiplayerServer server;
  late MemoryMultiplayerStore store;

  setUp(() {
    backend = FakeBackend();
    server = FakeMultiplayerServer();
    store = MemoryMultiplayerStore();
  });

  Session newSession() => Session(
    api: AccountApi(
      config: ApiConfig(baseUrl: Uri.parse('https://example.cz/api/')),
      client: backend.client,
    ),
    storage: MemoryTokenStorage(),
  );

  Future<void> pumpPage(
    WidgetTester tester, {
    Size size = const Size(320, 568),
    double textScale = 1,
    String? joinCode = 'K7M2QX',
  }) async {
    tester.view.physicalSize = size;
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    tester.platformDispatcher.textScaleFactorTestValue = textScale;
    addTearDown(tester.platformDispatcher.clearTextScaleFactorTestValue);
    tester.platformDispatcher.accessibilityFeaturesTestValue =
        const FakeAccessibilityFeatures(disableAnimations: true);
    addTearDown(tester.platformDispatcher.clearAccessibilityFeaturesTestValue);
    store.nickname = longNick;
    await tester.pumpWidget(
      MaterialApp(
        home: MultiplayerPage(
          config: MultiplayerConfig(url: MultiplayerConfig.local),
          session: newSession()..continueAsGuest(),
          mapBuilder: stubMap,
          joinCode: joinCode,
          onClose: () {},
          connect: server.connect,
          store: store,
          clock: () => serverEpoch,
          ticker: () => const Stream.empty(),
          copyText: (text) async {},
        ),
      ),
    );
    await tester.pumpAndSettle();
  }

  Future<void> send(WidgetTester tester, Map<String, Object?> state) async {
    server.last.receive(state);
    await tester.pumpAndSettle();
  }

  Map<String, Object?> playingGame({String name = longPlace, int guessed = 0}) {
    final game = playingGameJson(guessed: guessed, placeCount: 10);
    game['participantIds'] = [for (var i = 1; i <= 8; i++) 'p$i'];
    final self = game['self'] as Map<String, Object?>?;
    if (self != null && guessed < 10) self['currentPlaceName'] = name;
    return game;
  }

  for (final (scale, size) in [
    (1.0, const Size(320, 568)),
    (1.3, const Size(320, 568)),
    (1.0, const Size(320, 480)),
    (1.0, const Size(1440, 900)),
  ]) {
    group('$size, text scale $scale', () {
      testWidgets('entry', (tester) async {
        await pumpPage(tester, textScale: scale, size: size, joinCode: null);
        await tester.enterText(find.byType(TextField).first, 'E');
        await tester.tap(find.text('ZALOŽIT MÍSTNOST'));
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
      });

      testWidgets('lobby, host, 8 players with long nicknames', (tester) async {
        await pumpPage(tester, textScale: scale, size: size);
        server.last.receive(welcomeJson(nickname: longNick));
        await send(tester, stateJson(players: eightPlayers()));
        expect(tester.takeException(), isNull);
        await tester.drag(
          find.byType(SingleChildScrollView).first,
          const Offset(0, -2000),
        );
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
      });

      testWidgets('lobby, guest, game running', (tester) async {
        await pumpPage(tester, textScale: scale, size: size);
        server.last.receive(welcomeJson(nickname: longNick));
        await send(
          tester,
          stateJson(
            hostId: 'p2',
            phase: 'playing',
            players: eightPlayers(),
            game: playingGameJson(participant: false, placeCount: 10),
          ),
        );
        expect(tester.takeException(), isNull);
      });

      testWidgets('game: long place name prompt and full-screen map', (
        tester,
      ) async {
        await pumpPage(tester, textScale: scale, size: size);
        server.last.receive(welcomeJson(nickname: longNick));
        await send(
          tester,
          stateJson(
            phase: 'playing',
            players: eightPlayers(view: 'game'),
            game: playingGame(),
          ),
        );
        expect(tester.takeException(), isNull);
        await tester.tap(find.text('TIPNOUT NA MAPĚ'));
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
      });

      testWidgets('game: place result with a long place name', (tester) async {
        await pumpPage(tester, textScale: scale, size: size);
        server.last.receive(welcomeJson(nickname: longNick));
        await send(
          tester,
          stateJson(
            phase: 'playing',
            players: eightPlayers(view: 'game'),
            game: playingGame(),
          ),
        );
        await tester.tap(find.text('TIPNOUT NA MAPĚ'));
        await tester.pumpAndSettle();
        await tester.tapAt(const Offset(160, 300));
        await tester.pumpAndSettle();
        await tester.tap(find.text('POTVRDIT TIP'));
        await tester.pumpAndSettle();
        final result = guessResultJson(0, distance: 123456);
        (result['place'] as Map<String, Object?>)['name'] = longPlace;
        server.last.receive(result);
        await send(
          tester,
          stateJson(
            phase: 'playing',
            players: eightPlayers(view: 'game'),
            game: playingGame(guessed: 1),
          ),
        );
        expect(find.text('OD CÍLE'), findsOneWidget);
        expect(tester.takeException(), isNull);
      });

      testWidgets('waiting room with 8 players', (tester) async {
        await pumpPage(tester, textScale: scale, size: size);
        server.last.receive(welcomeJson(nickname: longNick));
        await send(
          tester,
          stateJson(
            phase: 'playing',
            players: eightPlayers(view: 'game'),
            game: playingGame(guessed: 10),
          ),
        );
        expect(find.text('POSTUP HRÁČŮ'), findsOneWidget);
        expect(tester.takeException(), isNull);
      });

      testWidgets('results with 8 players and long place names', (
        tester,
      ) async {
        await pumpPage(tester, textScale: scale, size: size);
        server.last.receive(welcomeJson(nickname: longNick));
        final game = finishedGameJson(placeCount: 10);
        game['participantIds'] = [for (var i = 1; i <= 8; i++) 'p$i'];
        game['leaderboard'] = [
          for (var i = 1; i <= 8; i++)
            {
              'rank': i,
              'playerId': 'p$i',
              'nickname': i == 1
                  ? longNick
                  : i == 2
                  ? unbrokenNick
                  : 'Hráč číslo $i s dlouhým',
              'averageDistanceMeters': 99999 * i,
              'guessedCount': 10,
              'totalDistanceMeters': 999990 * i,
              'finishedAt': null,
            },
        ];
        game['places'] = [
          for (var i = 0; i < 10; i++) placeJson(i, name: longPlace),
        ];
        final guesses = game['guesses'] as Map<String, Object?>;
        guesses['p2'] = [
          for (var i = 0; i < 10; i++)
            {'latitude': 50.19, 'longitude': 12.75, 'distanceMeters': 400},
        ];
        await send(
          tester,
          stateJson(
            phase: 'finished',
            players: eightPlayers(view: 'results'),
            game: game,
          ),
        );
        expect(find.text('POŘADÍ'), findsOneWidget);
        expect(tester.takeException(), isNull);
        await tester.drag(
          find.byType(SingleChildScrollView).first,
          const Offset(0, -6000),
        );
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
      });
    });
  }

  // The real map builds through a LayoutBuilder, which cannot report
  // intrinsic sizes; the game screen must never ask the preview for one.
  testWidgets('game screen lays out a LayoutBuilder-based map', (tester) async {
    tester.view.physicalSize = const Size(420, 860);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    store.nickname = longNick;
    await tester.pumpWidget(
      MaterialApp(
        home: MultiplayerPage(
          config: MultiplayerConfig(url: MultiplayerConfig.local),
          session: newSession()..continueAsGuest(),
          mapBuilder: (view) =>
              LayoutBuilder(builder: (context, constraints) => stubMap(view)),
          joinCode: 'K7M2QX',
          onClose: () {},
          connect: server.connect,
          store: store,
          clock: () => serverEpoch,
          ticker: () => const Stream.empty(),
          copyText: (text) async {},
        ),
      ),
    );
    await tester.pumpAndSettle();
    server.last.receive(welcomeJson(nickname: longNick));
    await send(
      tester,
      stateJson(
        phase: 'playing',
        players: eightPlayers(view: 'game'),
        game: playingGame(),
      ),
    );
    expect(tester.takeException(), isNull);
    final preview = tester.getSize(find.byKey(const ValueKey('preview map')));
    expect(preview.height, greaterThan(160));
    await tester.tap(find.text('TIPNOUT NA MAPĚ'));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('full map')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  // A short viewport (a phone on its side, or large text on a small
  // phone): the prompt and the map preview scroll, the preview keeps its
  // minimum height, and the button stays on screen.
  for (final (scale, size) in [
    (1.0, const Size(568, 320)),
    (1.5, const Size(320, 568)),
    (2.0, const Size(320, 568)),
    (2.0, const Size(360, 640)),
  ]) {
    testWidgets('game prompt fits at $size, text scale $scale', (tester) async {
      await pumpPage(tester, textScale: scale, size: size);
      server.last.receive(welcomeJson(nickname: longNick));
      await send(
        tester,
        stateJson(
          phase: 'playing',
          players: eightPlayers(view: 'game'),
          game: playingGame(),
        ),
      );
      expect(tester.takeException(), isNull);

      final button = tester.getRect(find.text('TIPNOUT NA MAPĚ'));
      expect(button.bottom, lessThanOrEqualTo(size.height));
      await tester.dragUntilVisible(
        find.byKey(const ValueKey('preview map')),
        find.byType(CustomScrollView),
        const Offset(0, -100),
      );
      final preview = tester.getSize(find.byKey(const ValueKey('preview map')));
      expect(preview.height, greaterThanOrEqualTo(150));
      await tester.tap(find.text('TIPNOUT NA MAPĚ'));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('full map')), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }
}
