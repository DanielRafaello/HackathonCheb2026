import 'dart:async';
import 'dart:convert';

import 'package:kde_na_zapade/multiplayer/multiplayer_connection.dart';
import 'package:kde_na_zapade/multiplayer/protocol.dart';

/// A [MultiplayerConnection] the test talks through: it records what the
/// client sends, and the test pushes the server's JSON frames.
class FakeMultiplayerConnection implements MultiplayerConnection {
  final _messages = StreamController<ServerMessage>();

  /// What the client sent, as JSON.
  final sent = <Map<String, Object?>>[];
  bool closed = false;

  @override
  int? closeCode;

  List<String> get sentTypes => [for (final m in sent) m['type']! as String];

  Map<String, Object?> lastOf(String type) =>
      sent.lastWhere((m) => m['type'] == type);

  @override
  Stream<ServerMessage> get messages => _messages.stream;

  @override
  void send(ClientMessage message) {
    if (closed) return;
    // Through JSON, as the WebSocket would carry it.
    sent.add((jsonDecode(message.encode()) as Map).cast<String, Object?>());
  }

  /// The server sends [json]; it is parsed like a real frame.
  void receive(Map<String, Object?> json) {
    if (closed) return;
    _messages.add(ServerMessage.parse(jsonEncode(json)));
  }

  /// The connection drops, as when the network goes away; the server
  /// closes it with [code].
  void drop({int? code}) {
    if (closed) return;
    closed = true;
    closeCode = code;
    _messages.close();
  }

  @override
  Future<void> close() async => drop();
}

/// Hands out [FakeMultiplayerConnection]s; [fail] makes the next connects
/// throw, like an unreachable server.
class FakeMultiplayerServer {
  final connections = <FakeMultiplayerConnection>[];
  int fail = 0;

  FakeMultiplayerConnection get last => connections.last;

  Future<MultiplayerConnection> connect() async {
    if (fail > 0) {
      fail--;
      throw StateError('unreachable');
    }
    final connection = FakeMultiplayerConnection();
    connections.add(connection);
    return connection;
  }
}

/// The server's clock in the fixtures.
final serverEpoch = DateTime.utc(2026, 10, 10, 12);
int ms(DateTime time) => time.millisecondsSinceEpoch;

Map<String, Object?> welcomeJson({
  String playerId = 'p1',
  String resumeToken = 'resume-1',
  String nickname = 'Eva',
  bool isGuest = true,
  int minPlayers = 1,
}) => {
  'type': 'welcome',
  'playerId': playerId,
  'resumeToken': resumeToken,
  'nickname': nickname,
  'isGuest': isGuest,
  'limits': {
    'maxPlayers': 8,
    'minPlayers': minPlayers,
    'maxPlaceCount': 20,
    'minDurationSeconds': 60,
    'maxDurationSeconds': 1800,
    'penaltyDistanceMeters': 100000,
  },
  'defaults': {'maxPlayers': 8, 'placeCount': 10, 'durationSeconds': 300},
};

Map<String, Object?> playerJson(
  String id,
  String nickname, {
  bool host = false,
  bool connected = true,
  String view = 'lobby',
  int guessedCount = 0,
}) => {
  'id': id,
  'nickname': nickname,
  'isGuest': true,
  'isHost': host,
  'connected': connected,
  'view': view,
  'guessedCount': guessedCount,
};

Map<String, Object?> placeJson(int index, {String name = 'Hrad Loket'}) => {
  'index': index,
  'id': 100 + index,
  'name': name,
  'latitude': 50.1859,
  'longitude': 12.7541,
  'category': 'Hrady, tvrze a zříceniny',
  'description': 'Gotický hrad na skále nad Ohří.',
  'contentSourceUrl': null,
  'source': {
    'title': 'Národní kulturní památky',
    'publisher': 'datazapad.cz',
    'portalUrl': 'https://datazapad.cz',
    'licenseCode': 'CC BY',
    'licenseUrl': 'https://creativecommons.org/licenses/by/4.0/',
    'attributionText': null,
  },
};

/// A lobby snapshot. Without [players], Eva (p1) and Adam (p2) are in it;
/// while a game runs they are in its view.
Map<String, Object?> stateJson({
  DateTime? serverNow,
  String code = 'K7M2QX',
  String selfId = 'p1',
  String hostId = 'p1',
  String phase = 'waiting',
  List<Map<String, Object?>>? players,
  Map<String, Object?>? game,
  int placeCount = 3,
  bool noLobby = false,
}) {
  final view = phase == 'playing' && game?['self'] != null ? 'game' : 'lobby';
  return {
    'type': 'state',
    'serverNow': ms(serverNow ?? serverEpoch),
    'lobby': noLobby
        ? null
        : {
            'code': code,
            'hostId': hostId,
            'selfId': selfId,
            'phase': phase,
            'settings': {
              'maxPlayers': 8,
              'placeCount': placeCount,
              'durationSeconds': 300,
            },
            'players':
                players ??
                [
                  playerJson('p1', 'Eva', host: hostId == 'p1', view: view),
                  playerJson('p2', 'Adam', host: hostId == 'p2', view: view),
                ],
            'game': game,
          },
  };
}

/// A running game in which this player has guessed [guessed] of
/// [placeCount] places.
Map<String, Object?> playingGameJson({
  int guessed = 0,
  int placeCount = 3,
  DateTime? endsAt,
  bool participant = true,
}) => {
  'status': 'playing',
  'startedAt': ms(serverEpoch),
  'endsAt': ms(endsAt ?? serverEpoch.add(const Duration(minutes: 5))),
  'placeCount': placeCount,
  'participantIds': ['p1', 'p2'],
  'self': participant
      ? {
          'currentIndex': guessed,
          'currentPlaceName': guessed < placeCount
              ? 'Místo ${guessed + 1}'
              : null,
          'rounds': [
            for (var i = 0; i < guessed; i++)
              {
                'index': i,
                'name': 'Místo ${i + 1}',
                'guess': {'latitude': 50.2, 'longitude': 12.8},
                'distanceMeters': 1200 * (i + 1),
                'place': placeJson(i, name: 'Místo ${i + 1}'),
              },
          ],
        }
      : null,
  'leaderboard': null,
  'places': null,
  'guesses': null,
};

Map<String, Object?> finishedGameJson({int placeCount = 3}) => {
  'status': 'finished',
  'startedAt': ms(serverEpoch),
  'endsAt': ms(serverEpoch.add(const Duration(minutes: 5))),
  'placeCount': placeCount,
  'participantIds': ['p1', 'p2'],
  'self': {
    'currentIndex': placeCount,
    'currentPlaceName': null,
    'rounds': [
      for (var i = 0; i < placeCount; i++)
        {
          'index': i,
          'name': 'Místo ${i + 1}',
          'guess': {'latitude': 50.2, 'longitude': 12.8},
          'distanceMeters': 1200,
          'place': placeJson(i, name: 'Místo ${i + 1}'),
        },
    ],
  },
  'leaderboard': [
    {
      'rank': 1,
      'playerId': 'p2',
      'nickname': 'Adam',
      'averageDistanceMeters': 800,
      'guessedCount': placeCount,
      'totalDistanceMeters': 800 * placeCount,
      'finishedAt': ms(serverEpoch.add(const Duration(minutes: 2))),
    },
    {
      'rank': 2,
      'playerId': 'p1',
      'nickname': 'Eva',
      'averageDistanceMeters': 1200,
      'guessedCount': placeCount,
      'totalDistanceMeters': 1200 * placeCount,
      'finishedAt': ms(serverEpoch.add(const Duration(minutes: 3))),
    },
  ],
  'places': [
    for (var i = 0; i < placeCount; i++) placeJson(i, name: 'Místo ${i + 1}'),
  ],
  'guesses': {
    'p1': [
      for (var i = 0; i < placeCount; i++)
        {'latitude': 50.2, 'longitude': 12.8, 'distanceMeters': 1200},
    ],
    'p2': [
      for (var i = 0; i < placeCount; i++)
        i == 0
            ? null
            : {'latitude': 50.19, 'longitude': 12.75, 'distanceMeters': 400},
    ],
  },
};

Map<String, Object?> guessResultJson(int index, {int distance = 1500}) => {
  'type': 'guessResult',
  'index': index,
  'distanceMeters': distance,
  'guess': {'latitude': 50.2, 'longitude': 12.8},
  'place': placeJson(index, name: 'Místo ${index + 1}'),
};

Map<String, Object?> errorJson(String code) => {'type': 'error', 'code': code};
