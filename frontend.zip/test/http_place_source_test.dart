import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/config/game_config.dart';
import 'package:kde_na_zapade/my_map/locations_api.dart';
import 'package:kde_na_zapade/place/device_location.dart';
import 'package:kde_na_zapade/place/http_place_source.dart';
import 'package:kde_na_zapade/place/place_detail.dart';
import 'package:kde_na_zapade/progress/place_card_cache.dart';
import 'package:kde_na_zapade/progress/revealed_place.dart';

import 'fake_game_backend.dart';

const _lat = 50.0807;
const _lon = 12.8389;
final _now = DateTime.utc(2026, 10, 10, 12);

Map<String, Object?> placeJson(
  int id, {
  String? guessedAt,
  String? visitedAt,
}) => locationJson(
  id,
  latitude: _lat,
  longitude: _lon,
  guessedAt: guessedAt,
  visitedAt: visitedAt,
);

/// About [meters] north of the place.
DevicePosition near(double meters) => DevicePosition(
  latitude: _lat + meters / 111195,
  longitude: _lon,
  accuracyMeters: 12,
  timestamp: _now,
);

const becov = RevealedPlace(
  id: 1,
  name: 'Hrad a zámek Bečov nad Teplou',
  latitude: _lat,
  longitude: _lon,
  category: 'Hrady, tvrze a zříceniny',
  description: 'V kapli tu našli relikviář sv. Maura.',
  source: PlaceSourceInfo(
    title: 'Hrady',
    publisher: 'datazapad.cz',
    licenseCode: 'CC BY',
  ),
);

void main() {
  late FakeGameBackend backend;
  late MemoryPlaceCardCache cache;

  Future<HttpPlaceSource> source({
    GameConfig config = GameConfig.defaults,
  }) async => HttpPlaceSource(
    api: await locationsApi(backend),
    cache: cache,
    config: config,
    clock: () => _now,
  );

  setUp(() {
    backend = FakeGameBackend(
      places: [
        placeJson(1, guessedAt: '2026-10-09T21:13:43Z'),
        placeJson(2),
        placeJson(
          3,
          guessedAt: '2026-10-01T10:00:00Z',
          visitedAt: '2026-10-02T10:00:00Z',
        ),
      ],
    );
    cache = MemoryPlaceCardCache();
  });

  group('load', () {
    test('fills the card from my map and the cached revealed place', () async {
      await cache.write(becov);

      final detail = await (await source()).load(1);

      expect(detail.name, 'Místo 1');
      expect(detail.latitude, _lat);
      expect(detail.guessedAt, DateTime.utc(2026, 10, 9, 21, 13, 43));
      expect(detail.isVisited, isFalse);
      expect(detail.category, 'Hrady, tvrze a zříceniny');
      expect(detail.description, 'V kapli tu našli relikviář sv. Maura.');
      expect(detail.source, 'datazapad.cz · CC BY');
      expect(detail.stars, isNull);
      expect(detail.factCount, 0);
      expect(detail.facts, isNull);
    });

    test(
      'loads the texts of a place guessed elsewhere and keeps them',
      () async {
        final places = await source();

        final detail = await places.load(1);

        expect(detail.name, 'Místo 1');
        expect(detail.category, 'Hrady, tvrze a zříceniny');
        expect(detail.description, 'Popis místa 1.');
        expect(detail.source, 'Zdroj: datazapad.cz\u00A0· CC BY 4.0');
        expect((await cache.read(1))?.description, 'Popis místa 1.');

        await places.load(1);
        expect(backend.sent('/locations/1/description'), hasLength(1));
      },
    );

    test('asks for no texts of a place in the fog', () async {
      final detail = await (await source()).load(2);

      expect(detail.description, isNull);
      expect(backend.sent('/locations/2/description'), isEmpty);
      expect(await cache.read(2), isNull);
    });

    test('shows only the progress when the texts cannot load', () async {
      backend.description = () => null;

      final detail = await (await source()).load(1);

      expect(detail.name, 'Místo 1');
      expect(detail.category, isNull);
      expect(detail.description, isNull);
      expect(detail.source, isNull);
    });

    test('carries the ratings from my map', () async {
      backend.places.add(
        locationJson(
          4,
          guessedAt: '2026-10-01T10:00:00Z',
          visitedAt: '2026-10-02T10:00:00Z',
          rating: 4,
          averageRating: 4.3,
          ratingCount: 12,
        ),
      );

      final detail = await (await source()).load(4);

      expect(detail.rating, 4);
      expect(detail.averageRating, 4.3);
      expect(detail.ratingCount, 12);
    });

    test('rates a visited place and returns the new average', () async {
      backend.places.add(
        locationJson(
          4,
          visitedAt: '2026-10-02T10:00:00Z',
          averageRating: 3,
          ratingCount: 2,
        ),
      );

      final detail = await (await source()).rate(4, 5);

      final sent = backend.sent('/locations/4/rating', method: 'PUT');
      expect(sent, hasLength(1));
      expect(sent.single.body, '{"rating":5}');
      expect(detail.rating, 5);
      expect(detail.ratingCount, 3);
      expect(detail.averageRating, closeTo(11 / 3, 1e-9));
    });

    test('rating again replaces the rating', () async {
      backend.places.add(
        locationJson(
          4,
          visitedAt: '2026-10-02T10:00:00Z',
          rating: 2,
          averageRating: 2,
          ratingCount: 1,
        ),
      );

      final detail = await (await source()).rate(4, 4);

      expect(detail.rating, 4);
      expect(detail.ratingCount, 1);
      expect(detail.averageRating, 4);
    });

    test('a place not visited cannot be rated', () async {
      expect(
        (await source()).rate(1, 4),
        throwsA(isA<LocationsApiException>()),
      );
    });

    test('a place nobody rated has no ratings', () async {
      final detail = await (await source()).load(1);

      expect(detail.rating, isNull);
      expect(detail.averageRating, isNull);
      expect(detail.ratingCount, 0);
    });

    test('a visited place has an empty fact list', () async {
      final detail = await (await source()).load(3);

      expect(detail.isVisited, isTrue);
      expect(detail.visitedAt, DateTime.utc(2026, 10, 2, 10));
      expect(detail.facts, isEmpty);
    });

    test('loads a place in the fog with its name and position', () async {
      final detail = await (await source()).load(2);

      expect(detail.name, 'Místo 2');
      expect(detail.latitude, _lat);
      expect(detail.isGuessed, isFalse);
      expect(detail.isVisited, isFalse);
      expect(detail.category, isNull);
      expect(detail.facts, isNull);
    });

    test('never loads a place the backend does not list', () async {
      await expectLater(
        (await source()).load(99),
        throwsA(isA<PlaceNotFound>()),
      );
    });

    test('passes a failing backend on', () async {
      final places = await source();
      backend.locations = () => null;

      await expectLater(
        places.load(1),
        throwsA(
          isA<LocationsApiException>().having(
            (e) => e.kind,
            'kind',
            LocationsErrorKind.network,
          ),
        ),
      );
    });
  });

  group('visit', () {
    test('records a visit to a place in the fog', () async {
      final outcome = await (await source()).visit(2, near(40));

      expect(outcome, isA<VisitConfirmed>());
      expect((outcome as VisitConfirmed).place.isVisited, isTrue);
      expect(
        backend.sent('/locations/2/progress', method: 'POST'),
        hasLength(1),
      );
    });

    test('outside the radius sends nothing', () async {
      final outcome = await (await source()).visit(1, near(1500));

      expect(outcome, isA<VisitTooFar>());
      expect(outcome.distanceMeters, closeTo(1500, 1));
      expect(backend.sent('/locations/1/progress'), isEmpty);
    });

    test(
      'on the spot records the visit and returns the visited card',
      () async {
        await cache.write(becov);

        final outcome = await (await source()).visit(1, near(40));

        expect(outcome, isA<VisitConfirmed>());
        final confirmed = outcome as VisitConfirmed;
        expect(confirmed.distanceMeters, closeTo(40, 1));
        expect(confirmed.wafersEarned, 50);
        expect(
          backend.sent('/locations/1/progress', method: 'POST'),
          hasLength(1),
        );
        expect(confirmed.place.isVisited, isTrue);
        expect(confirmed.place.visitedAt, DateTime.utc(2026, 10, 10, 10));
        expect(
          confirmed.place.guessedAt,
          DateTime.utc(2026, 10, 9, 21, 13, 43),
        );
        expect(confirmed.place.facts, isEmpty);
        expect(confirmed.place.source, 'datazapad.cz · CC BY');
        expect(confirmed.nearby, isEmpty);
        expect(confirmed.nearbySource, isNull);
      },
    );

    test('takes the visit radius from the configuration', () async {
      const wide = GameConfig(
        maxStars: 5,
        maxRating: 5,
        placeOfTheDayClues: 5,
        freePlayClues: 3,
        hitRadiusMeters: 1000,
        visitRadiusMeters: 500,
        timeZone: 'Europe/Prague',
      );

      expect(
        await (await source(config: wide)).visit(1, near(400)),
        isA<VisitConfirmed>(),
      );
    });

    test('a failing backend throws and records nothing', () async {
      final places = await source();
      backend.progress = () => null;

      await expectLater(
        places.visit(1, near(40)),
        throwsA(isA<LocationsApiException>()),
      );
    });
  });

  test('sourceLine joins what the backend knows about the source', () {
    String? line(PlaceSourceInfo? source) => HttpPlaceSource.sourceLine(
      RevealedPlace(
        id: 1,
        name: 'x',
        latitude: 0,
        longitude: 0,
        category: '',
        description: '',
        source: source,
      ),
    );

    expect(line(null), isNull);
    expect(line(const PlaceSourceInfo()), isNull);
    expect(line(const PlaceSourceInfo(licenseCode: 'CC0')), 'CC0');
    expect(
      line(const PlaceSourceInfo(attributionText: 'Krajský úřad')),
      'Krajský úřad',
    );
  });
}
