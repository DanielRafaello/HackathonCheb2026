import 'dart:ui';

import 'package:flutter_test/flutter_test.dart';
import 'package:maplibre_gl/maplibre_gl.dart';

import 'package:kde_na_zapade/map/map_projection.dart';

void main() {
  const loket = LatLng(50.1859, 12.7541);
  const projection = MapProjection(
    target: loket,
    zoom: 8.3,
    size: Size(376, 442),
  );

  test('the camera target is in the middle of the frame', () {
    final point = projection.toScreen(loket);
    expect(point.dx, closeTo(188, 1e-6));
    expect(point.dy, closeTo(221, 1e-6));
  });

  test('north is up and east is right', () {
    final centre = projection.toScreen(loket);
    final north = projection.toScreen(const LatLng(50.30, 12.7541));
    final east = projection.toScreen(const LatLng(50.1859, 12.90));
    expect(north.dy, lessThan(centre.dy));
    expect(north.dx, closeTo(centre.dx, 1e-6));
    expect(east.dx, greaterThan(centre.dx));
    expect(east.dy, closeTo(centre.dy, 1e-6));
  });

  test('the world is 512 px wide at zoom 0', () {
    const world = MapProjection(
      target: LatLng(0, 0),
      zoom: 0,
      size: Size(512, 512),
    );
    // A quarter of the world either side of the middle.
    expect(world.toScreen(const LatLng(0, 90)).dx, closeTo(384, 1e-6));
    expect(world.toScreen(const LatLng(0, -90)).dx, closeTo(128, 1e-6));
  });

  test('a point goes back to the same position', () {
    const position = LatLng(50.2579, 12.5012);
    final back = projection.toPosition(projection.toScreen(position));
    expect(back.latitude, closeTo(position.latitude, 1e-9));
    expect(back.longitude, closeTo(position.longitude, 1e-9));
  });
}
