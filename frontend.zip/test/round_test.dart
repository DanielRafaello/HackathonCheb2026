import 'dart:async';

import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/config/game_config.dart';
import 'package:kde_na_zapade/game/region.dart';
import 'package:kde_na_zapade/round/active_round_store.dart';
import 'package:kde_na_zapade/round/fake_round_api.dart';
import 'package:kde_na_zapade/round/guess_map.dart';
import 'package:kde_na_zapade/round/round.dart';
import 'package:kde_na_zapade/round/round_api.dart';
import 'package:kde_na_zapade/round/round_controller.dart';
import 'package:kde_na_zapade/round/round_copy.dart';

/// The target of the test place: Loket.
const target = GeoPoint(50.1859, 12.7541);

/// About 8 km north of the target, inside the region: a miss, well
/// outside the hit radius.
const near = GeoPoint(50.2579, 12.7541);

/// About 220 m east of the target: a hit.
const onTarget = GeoPoint(50.1859, 12.7572);

/// In Bavaria, outside the region.
const abroad = GeoPoint(49.95, 12.10);

FakePlace testPlace({int id = 7, GeoPoint location = target}) => FakePlace(
  card: PlaceCard(
    id: id,
    name: 'Tajné místo $id',
    type: 'Hrad',
    description: 'Popis.',
    location: location,
    source: 'datazapad.cz',
    licence: 'CC BY',
  ),
  clues: const [
    Clue(ClueKind.riddle, 'Hádanka'),
    Clue(ClueKind.placeType, 'Hrad'),
    Clue(ClueKind.numbers, '1234'),
    Clue(ClueKind.detail, 'Řeka'),
  ],
);

/// A mutable clock, 10 October 2026 at noon in Prague.
class TestClock {
  DateTime now = DateTime.utc(2026, 10, 10, 10);

  DateTime call() => now;
}

FakeRoundApi fakeApi(TestClock clock, {List<FakePlace>? places}) =>
    FakeRoundApi(
      places: places ?? [testPlace()],
      clock: clock.call,
      latency: Duration.zero,
    );

/// A round API whose answers the test releases by hand.
class ManualRoundApi implements RoundApi {
  final dailyCalls = <Completer<DailyRound>>[];
  final guessCalls = <Completer<GuessOutcome>>[];
  final refreshCalls = <Completer<RoundState>>[];

  @override
  Future<DailyRound> placeOfTheDay({String? resumeToken}) {
    final call = Completer<DailyRound>();
    dailyCalls.add(call);
    return call.future;
  }

  @override
  Future<RoundState> refresh(String token) {
    final call = Completer<RoundState>();
    refreshCalls.add(call);
    return call.future;
  }

  @override
  Future<GuessOutcome> guess(String token, GeoPoint position) {
    final call = Completer<GuessOutcome>();
    guessCalls.add(call);
    return call.future;
  }
}

/// A store whose storage is unavailable, as in a private browser window.
class BrokenStore implements ActiveRoundStore {
  @override
  Future<String?> readDailyToken() => Future.error(StateError('no storage'));

  @override
  Future<void> writeDailyToken(String token) =>
      Future.error(StateError('no storage'));

  @override
  Future<void> clearDailyToken() => Future.error(StateError('no storage'));
}

RoundState openRound({int wrong = 0, String token = 't1'}) => RoundState(
  token: token,
  day: DateTime.utc(2026, 10, 10),
  clues: const [Clue(ClueKind.riddle, 'Hádanka'), Clue(ClueKind.placeType)],
  wrongGuesses: wrong,
);

const revealedPlace = PlaceCard(
  id: 42,
  name: 'Hrad Loket',
  type: 'Hrad',
  description: 'Popis.',
  location: target,
  source: 'datazapad.cz',
  licence: 'CC BY',
);

/// A round the backend ended with a hit on the second guess.
RoundState hitRound({String token = 't1'}) => RoundState(
  token: token,
  day: DateTime.utc(2026, 10, 10),
  clues: const [
    Clue(ClueKind.riddle, 'Hádanka'),
    Clue(ClueKind.placeType, 'Hrad'),
  ],
  wrongGuesses: 1,
  result: const RoundResult(
    stars: 4,
    guesses: 2,
    distanceMeters: 220,
    place: revealedPlace,
  ),
);

/// Loads [api] into a fresh controller and releases the daily round.
Future<RoundController> manualController(
  ManualRoundApi api,
  RoundController Function(RoundApi api) create, {
  RoundState? round,
}) async {
  final c = create(api);
  unawaited(c.load());
  await pumpEventQueue();
  api.dailyCalls.single.complete(DailyRoundReady(round ?? openRound()));
  await pumpEventQueue();
  return c;
}

void main() {
  group('GameConfig rules', () {
    const config = GameConfig.defaults;

    test('stars drop by one per wrong guess down to one', () {
      expect(
        [for (var wrong = 0; wrong <= 7; wrong++) config.starsAvailable(wrong)],
        [5, 4, 3, 2, 1, 1, 1, 1],
      );
    });

    test('one clue at the start, one more per wrong guess', () {
      expect(
        [
          for (var wrong = 0; wrong <= 5; wrong++)
            config.cluesUnlocked(wrong, 4),
        ],
        [1, 2, 3, 4, 4, 4],
      );
    });

    test('the compass turns on when every clue has missed', () {
      expect(config.placeOfTheDayClues, 4);
      expect(config.compassActive(3), isFalse);
      expect(config.compassActive(4), isTrue);
      expect(config.compassActive(40), isTrue);
    });
  });

  group('FakeRoundApi', () {
    late TestClock clock;

    setUp(() => clock = TestClock());

    Future<RoundState> start(FakeRoundApi api) async =>
        (await api.placeOfTheDay() as DailyRoundReady).round;

    test('starts with only the first clue unlocked', () async {
      final round = await start(fakeApi(clock));
      expect(round.clues.map((c) => c.kind), [
        ClueKind.riddle,
        ClueKind.placeType,
        ClueKind.numbers,
        ClueKind.detail,
      ]);
      expect(round.clues.map((c) => c.text), ['Hádanka', null, null, null]);
      expect(round.wrongGuesses, 0);
      expect(round.compass, isNull);
      expect(round.result, isNull);
      expect(round.day, DateTime.utc(2026, 10, 10));
    });

    test('refresh returns the saved round', () async {
      final api = fakeApi(clock);
      final round = await start(api);
      await api.guess(round.token, near);
      final refreshed = await api.refresh(round.token);
      expect(refreshed.wrongGuesses, 1);
      expect(refreshed.lastGuess, near);
      expect(
        () => api.refresh('nope'),
        throwsA(
          isA<RoundApiException>().having(
            (e) => e.kind,
            'kind',
            RoundErrorKind.roundNotFound,
          ),
        ),
      );
    });

    test('gives the same round all day and resumes it by token', () async {
      final api = fakeApi(clock);
      final first = await start(api);
      await api.guess(first.token, near);
      final again = await start(api);
      final resumed = (await api.placeOfTheDay(
        resumeToken: first.token,
      ) as DailyRoundReady).round;
      expect(again.token, first.token);
      expect(resumed.wrongGuesses, 1);
    });

    test('a guess outside the region does not count', () async {
      final api = fakeApi(clock);
      final round = await start(api);
      expect(await api.guess(round.token, abroad), isA<GuessOutsideRegion>());
      expect((await start(api)).wrongGuesses, 0);
    });

    test('a miss unlocks the next clue', () async {
      final api = fakeApi(clock);
      final round = await start(api);
      final outcome = await api.guess(round.token, near) as GuessMissed;
      expect(outcome.round.wrongGuesses, 1);
      expect(outcome.round.clues.map((c) => c.text), [
        'Hádanka',
        'Hrad',
        null,
        null,
      ]);
      expect(outcome.round.lastGuess, near);
    });

    test(
      'the compass points from the fourth miss on, without distance',
      () async {
        final api = fakeApi(clock);
        final round = await start(api);
        for (var i = 1; i <= 3; i++) {
          final missed = await api.guess(round.token, near) as GuessMissed;
          expect(missed.round.compass, isNull, reason: 'miss $i');
        }
        final fourth = await api.guess(round.token, near) as GuessMissed;
        // The target is due south of the guess.
        expect(fourth.round.compass!.bearingDegrees, closeTo(180, 0.5));
        // From a guess west of the target, it points east.
        final west = await api.guess(
          round.token,
          const GeoPoint(50.1859, 12.65),
        ) as GuessMissed;
        expect(west.round.compass!.bearingDegrees, closeTo(90, 0.5));
      },
    );

    test('a hit ends the round with the stars and the place', () async {
      final api = fakeApi(clock);
      final round = await start(api);
      await api.guess(round.token, near);
      final hit = await api.guess(round.token, onTarget) as GuessHit;
      final result = hit.round.result!;
      expect(result.stars, 4);
      expect(result.guesses, 2);
      expect(result.distanceMeters, closeTo(220, 10));
      expect(result.place.name, 'Tajné místo 7');
      expect(hit.round.compass, isNull);
    });

    test('the hit radius is 3 km', () async {
      expect(GameConfig.defaults.hitRadiusMeters, 3000);
      final api = fakeApi(clock);
      final round = await start(api);
      // About 3.5 km and 2.5 km north of the target.
      expect(
        await api.guess(round.token, const GeoPoint(50.2174, 12.7541)),
        isA<GuessMissed>(),
      );
      expect(
        await api.guess(round.token, const GeoPoint(50.2084, 12.7541)),
        isA<GuessHit>(),
      );
    });

    test('a hit after many misses still earns one star', () async {
      final api = fakeApi(clock);
      final round = await start(api);
      for (var i = 0; i < 8; i++) {
        await api.guess(round.token, near);
      }
      final hit = await api.guess(round.token, onTarget) as GuessHit;
      expect(hit.round.result!.stars, 1);
      expect(hit.round.result!.guesses, 9);
    });

    test('a finished round takes no more guesses', () async {
      final api = fakeApi(clock);
      final round = await start(api);
      await api.guess(round.token, onTarget);
      expect(
        () => api.guess(round.token, onTarget),
        throwsA(
          isA<RoundApiException>().having(
            (e) => e.kind,
            'kind',
            RoundErrorKind.roundFinished,
          ),
        ),
      );
      expect((await start(api)).isFinished, isTrue);
    });

    test('a round from yesterday has expired', () async {
      final api = fakeApi(clock, places: [testPlace(id: 1), testPlace(id: 2)]);
      final round = await start(api);
      clock.now = clock.now.add(const Duration(days: 1));
      expect(
        () => api.guess(round.token, near),
        throwsA(
          isA<RoundApiException>().having(
            (e) => e.kind,
            'kind',
            RoundErrorKind.roundExpired,
          ),
        ),
      );
      final today = await start(api);
      expect(today.token, isNot(round.token));
      expect(today.day, DateTime.utc(2026, 10, 11));
    });

    test('an unknown token is not found', () async {
      expect(
        () => fakeApi(clock).guess('nope', near),
        throwsA(
          isA<RoundApiException>().having(
            (e) => e.kind,
            'kind',
            RoundErrorKind.roundNotFound,
          ),
        ),
      );
    });

    test('a guessed place never comes back', () async {
      final api = fakeApi(clock);
      final round = await start(api);
      await api.guess(round.token, onTarget);
      clock.now = clock.now.add(const Duration(days: 1));
      expect(await api.placeOfTheDay(), isA<AllPlacesGuessed>());
    });

    test('with every place guessed there is no place of the day', () async {
      final api = FakeRoundApi(
        places: [testPlace()],
        guessedPlaceIds: [7],
        latency: Duration.zero,
      );
      expect(await api.placeOfTheDay(), isA<AllPlacesGuessed>());
    });

    test('failNext makes the next call fail once', () async {
      final api = fakeApi(clock)
        ..failNext(const RoundApiException(RoundErrorKind.network));
      await expectLater(api.placeOfTheDay(), throwsA(isA<RoundApiException>()));
      expect(await api.placeOfTheDay(), isA<DailyRoundReady>());
    });

    test('the demo places lie in the region and have four clues', () {
      for (final place in FakeRoundApi.demoPlaces) {
        expect(
          Region.contains(place.card.location),
          isTrue,
          reason: place.card.name,
        );
        expect(place.clues.map((c) => c.kind), [
          ClueKind.riddle,
          ClueKind.placeType,
          ClueKind.numbers,
          ClueKind.detail,
        ], reason: place.card.name);
      }
    });
  });

  group('RoundController', () {
    late TestClock clock;
    late FakeRoundApi api;
    late MemoryActiveRoundStore store;
    late RoundController controller;
    late List<RoundNotice> notices;

    RoundController create({RoundApi? with_, ActiveRoundStore? store_}) {
      final c = RoundController(
        api: with_ ?? api,
        store: store_ ?? store,
        clock: clock.call,
      );
      c.notices.listen(notices.add);
      return c;
    }

    setUp(() async {
      clock = TestClock();
      api = fakeApi(clock, places: [testPlace(id: 1), testPlace(id: 2)]);
      store = MemoryActiveRoundStore();
      notices = [];
      controller = create();
      await controller.load();
    });

    tearDown(() => controller.dispose());

    test('loads today\'s round and saves its token', () async {
      expect(controller.phase, RoundPhase.playing);
      expect(controller.starsAvailable, 5);
      expect(controller.pin, isNull);
      expect(await store.readDailyToken(), controller.round!.token);
    });

    test('a guess needs a pin', () async {
      await controller.confirmGuess();
      expect(controller.round!.wrongGuesses, 0);
    });

    test('a miss shows the new clue and clears the pin', () async {
      controller.placePin(near);
      await controller.confirmGuess();
      final miss = controller.miss!;
      expect(miss.newClue!.kind, ClueKind.placeType);
      expect(miss.newClueNumber, 2);
      expect(miss.starsAvailable, 4);
      expect(miss.compass, isNull);
      expect(controller.pin, isNull);
      expect(controller.round!.lastGuess, near);
      expect(controller.starsAvailable, 4);

      // The pin stays put until the player goes on.
      controller.placePin(onTarget);
      expect(controller.pin, isNull);
      controller.dismissMiss();
      controller.placePin(onTarget);
      expect(controller.pin, onTarget);
    });

    test('four clues, then the compass for as long as it takes', () async {
      Future<MissFeedback> miss() async {
        controller.dismissMiss();
        controller.placePin(near);
        await controller.confirmGuess();
        return controller.miss!;
      }

      expect((await miss()).newClueNumber, 2);
      expect((await miss()).newClueNumber, 3);
      final third = await miss();
      expect(third.newClueNumber, 4);
      expect(third.compass, isNull);
      // Every clue is out: the next miss turns the compass on.
      expect(third.compassNext, isTrue);

      final fourth = await miss();
      expect(fourth.newClue, isNull);
      expect(fourth.compass, isNotNull);
      expect(fourth.compassIsNew, isTrue);
      expect(fourth.compassNext, isFalse);
      expect(fourth.starsAvailable, 1);

      for (var i = 5; i <= 12; i++) {
        final later = await miss();
        expect(later.compass, isNotNull, reason: 'miss $i');
        expect(later.compassIsNew, isFalse, reason: 'miss $i');
        expect(later.starsAvailable, 1);
      }
      // There is no limit: the round is still open.
      expect(controller.phase, RoundPhase.playing);
      expect(controller.round!.wrongGuesses, 12);
      controller.dismissMiss();
      expect(controller.canGuess, isTrue);
    });

    test('a hit finishes the round', () async {
      controller.placePin(onTarget);
      await controller.confirmGuess();
      expect(controller.phase, RoundPhase.finished);
      expect(controller.round!.result!.stars, 5);
      expect(controller.pin, isNull);
      controller.placePin(near);
      expect(controller.pin, isNull);
    });

    test('a double tap sends one guess', () async {
      final manual = ManualRoundApi();
      final c = create(with_: manual);
      unawaited(c.load());
      await pumpEventQueue();
      manual.dailyCalls.single.complete(DailyRoundReady(openRound()));
      await pumpEventQueue();
      c.placePin(near);
      unawaited(c.confirmGuess());
      unawaited(c.confirmGuess());
      expect(manual.guessCalls, hasLength(1));
      expect(c.submitting, isTrue);
      expect(c.canGuess, isFalse);
      // Moving the pin while the guess is on its way does nothing.
      c.placePin(onTarget);
      expect(c.pin, near);
      manual.guessCalls.single.complete(GuessMissed(openRound(wrong: 1)));
      await pumpEventQueue();
      expect(c.submitting, isFalse);
      c.dispose();
    });

    test(
      'a guess outside the region keeps the pin and is not counted',
      () async {
        controller.placePin(abroad);
        await controller.confirmGuess();
        await pumpEventQueue();
        expect(notices.single.kind, RoundNoticeKind.outsideRegion);
        expect(controller.pin, abroad);
        expect(controller.round!.wrongGuesses, 0);
        expect(controller.miss, isNull);
      },
    );

    for (final (error, notice) in [
      (RoundErrorKind.network, RoundNoticeKind.network),
      (RoundErrorKind.timeout, RoundNoticeKind.timeout),
      (RoundErrorKind.server, RoundNoticeKind.server),
      (RoundErrorKind.unauthorized, RoundNoticeKind.unauthorized),
      (RoundErrorKind.rateLimited, RoundNoticeKind.rateLimited),
    ]) {
      test('a $error failure keeps the pin for another try', () async {
        controller.placePin(near);
        api.failNext(RoundApiException(error));
        await controller.confirmGuess();
        await pumpEventQueue();
        expect(notices.single.kind, notice);
        expect(controller.pin, near);
        expect(controller.submitting, isFalse);
        expect(controller.phase, RoundPhase.playing);
        expect(controller.miss, isNull);
        expect(controller.round!.wrongGuesses, 0);

        await controller.confirmGuess();
        expect(controller.round!.wrongGuesses, 1);
      });
    }

    group('a guess whose answer was lost', () {
      late ManualRoundApi manual;
      late RoundController c;

      setUp(() async {
        manual = ManualRoundApi();
        c = await manualController(
          manual,
          (api) => create(with_: api),
          round: openRound(),
        );
        c.placePin(near);
        unawaited(c.confirmGuess());
        manual.guessCalls.single.completeError(
          const RoundApiException(RoundErrorKind.timeout),
        );
        await pumpEventQueue();
      });

      tearDown(() => c.dispose());

      test('is looked up instead of being sent again', () {
        expect(manual.refreshCalls, hasLength(1));
        expect(manual.guessCalls, hasLength(1));
        expect(c.submitting, isTrue);
      });

      test('that did not land keeps the pin', () async {
        manual.refreshCalls.single.complete(openRound());
        await pumpEventQueue();
        expect(notices.single.kind, RoundNoticeKind.timeout);
        expect(c.pin, near);
        expect(c.miss, isNull);
        expect(c.submitting, isFalse);
        expect(c.round!.wrongGuesses, 0);
      });

      test('that landed as a miss is shown as the miss', () async {
        manual.refreshCalls.single.complete(
          RoundState(
            token: 't1',
            day: DateTime.utc(2026, 10, 10),
            clues: const [
              Clue(ClueKind.riddle, 'Hádanka'),
              Clue(ClueKind.placeType, 'Hrad'),
            ],
            wrongGuesses: 1,
            compass: const Compass(180),
          ),
        );
        await pumpEventQueue();
        expect(notices, isEmpty);
        expect(c.pin, isNull);
        expect(c.round!.wrongGuesses, 1);
        // The backend returns no coordinates; the pin is the guess.
        expect(c.round!.lastGuess, near);
        final miss = c.miss!;
        expect(miss.newClue!.kind, ClueKind.placeType);
        expect(miss.compass!.bearingDegrees, 180);
        expect(c.submitting, isFalse);
      });

      test('that landed as a hit finishes the round', () async {
        manual.refreshCalls.single.complete(hitRound());
        await pumpEventQueue();
        expect(notices, isEmpty);
        expect(c.phase, RoundPhase.finished);
        expect(c.pin, isNull);
        expect(c.miss, isNull);
      });

      test('on a round that has expired loads today\'s', () async {
        manual.refreshCalls.single.completeError(
          const RoundApiException(RoundErrorKind.roundExpired),
        );
        await pumpEventQueue();
        expect(notices.single.kind, RoundNoticeKind.dayChanged);
        expect(manual.dailyCalls, hasLength(2));
      });

      test('whose lookup also fails keeps the pin', () async {
        manual.refreshCalls.single.completeError(
          const RoundApiException(RoundErrorKind.network),
        );
        await pumpEventQueue();
        expect(notices.single.kind, RoundNoticeKind.timeout);
        expect(c.pin, near);
        expect(c.submitting, isFalse);
      });
    });

    test('an unexpected exception becomes a server notice', () async {
      final manual = ManualRoundApi();
      final c = create(with_: manual);
      unawaited(c.load());
      await pumpEventQueue();
      manual.dailyCalls.single.complete(DailyRoundReady(openRound()));
      await pumpEventQueue();
      c.placePin(near);
      unawaited(c.confirmGuess());
      manual.guessCalls.single.completeError(const FormatException('bad'));
      await pumpEventQueue();
      expect(notices.single.kind, RoundNoticeKind.server);
      expect(c.pin, near);
      expect(c.submitting, isFalse);
      c.dispose();
    });

    test('a hit without a result is treated as a server error', () async {
      final manual = ManualRoundApi();
      final c = create(with_: manual);
      unawaited(c.load());
      await pumpEventQueue();
      manual.dailyCalls.single.complete(DailyRoundReady(openRound()));
      await pumpEventQueue();
      c.placePin(near);
      unawaited(c.confirmGuess());
      manual.guessCalls.single.complete(GuessHit(openRound()));
      await pumpEventQueue();
      expect(notices.single.kind, RoundNoticeKind.server);
      expect(c.phase, RoundPhase.playing);
      c.dispose();
    });

    test('at midnight the round expires and today\'s is loaded', () async {
      final yesterday = controller.round!.token;
      clock.now = clock.now.add(const Duration(days: 1));
      controller.placePin(near);
      await controller.confirmGuess();
      await pumpEventQueue();
      expect(notices.single.kind, RoundNoticeKind.dayChanged);
      expect(controller.phase, RoundPhase.playing);
      expect(controller.round!.token, isNot(yesterday));
      expect(controller.round!.wrongGuesses, 0);
    });

    test('a round finished elsewhere is loaded again', () async {
      await api.guess(controller.round!.token, onTarget);
      controller.placePin(near);
      await controller.confirmGuess();
      await pumpEventQueue();
      expect(notices.single.kind, RoundNoticeKind.finishedElsewhere);
      expect(controller.phase, RoundPhase.finished);
    });

    test('a lost round forgets the token and loads again', () async {
      final manual = ManualRoundApi();
      final c = create(with_: manual);
      unawaited(c.load());
      await pumpEventQueue();
      manual.dailyCalls.single.complete(DailyRoundReady(openRound()));
      await pumpEventQueue();
      c.placePin(near);
      unawaited(c.confirmGuess());
      manual.guessCalls.single.completeError(
        const RoundApiException(RoundErrorKind.roundNotFound),
      );
      await pumpEventQueue();
      expect(notices.single.kind, RoundNoticeKind.roundLost);
      expect(c.phase, RoundPhase.loading);
      expect(manual.dailyCalls, hasLength(2));
      manual.dailyCalls.last.complete(DailyRoundReady(openRound(token: 't2')));
      await pumpEventQueue();
      expect(c.round!.token, 't2');
      c.dispose();
    });

    test('a failed load can be retried', () async {
      final c = create();
      api.failNext(const RoundApiException(RoundErrorKind.network));
      await c.load();
      expect(c.phase, RoundPhase.loadFailed);
      expect(c.loadError, RoundErrorKind.network);
      expect(c.round, isNull);
      await c.load();
      expect(c.phase, RoundPhase.playing);
      c.dispose();
    });

    test('an unexpected load exception is a server failure', () async {
      final manual = ManualRoundApi();
      final c = create(with_: manual);
      unawaited(c.load());
      await pumpEventQueue();
      manual.dailyCalls.single.completeError(StateError('boom'));
      await pumpEventQueue();
      expect(c.phase, RoundPhase.loadFailed);
      expect(c.loadError, RoundErrorKind.server);
      c.dispose();
    });

    test('the round works when storage fails', () async {
      final c = create(store_: BrokenStore());
      await c.load();
      expect(c.phase, RoundPhase.playing);
      c.placePin(near);
      await c.confirmGuess();
      expect(c.round!.wrongGuesses, 1);
      c.dispose();
    });

    test('closing and opening the round again resumes it', () async {
      controller.placePin(near);
      await controller.confirmGuess();
      controller.dispose();

      controller = create();
      await controller.load();
      expect(controller.round!.wrongGuesses, 1);
      expect(controller.round!.lastGuess, near);
      expect(controller.starsAvailable, 4);
      expect(controller.miss, isNull);
    });

    test('a round left with the compass on resumes with it', () async {
      for (var i = 0; i < 5; i++) {
        controller.dismissMiss();
        controller.placePin(near);
        await controller.confirmGuess();
      }
      // The player leaves without a hit; nothing ends the round.
      controller.dispose();

      controller = create();
      await controller.load();
      final round = controller.round!;
      expect(controller.phase, RoundPhase.playing);
      expect(round.wrongGuesses, 5);
      expect(round.unlockedClues, 4);
      expect(round.compass, isNotNull);
      expect(controller.starsAvailable, 1);
      expect(controller.canGuess, isTrue);
    });

    test('an answer to an older load is dropped', () async {
      final manual = ManualRoundApi();
      final c = create(with_: manual);
      unawaited(c.load());
      await pumpEventQueue();
      unawaited(c.load());
      await pumpEventQueue();
      expect(manual.dailyCalls, hasLength(2));
      manual.dailyCalls.last.complete(DailyRoundReady(openRound(token: 'new')));
      await pumpEventQueue();
      manual.dailyCalls.first.complete(
        DailyRoundReady(openRound(token: 'old')),
      );
      await pumpEventQueue();
      expect(c.round!.token, 'new');
      c.dispose();
    });

    test('a guess answered after a reload is dropped', () async {
      final manual = ManualRoundApi();
      final c = create(with_: manual);
      unawaited(c.load());
      await pumpEventQueue();
      manual.dailyCalls.single.complete(DailyRoundReady(openRound()));
      await pumpEventQueue();
      c.placePin(near);
      unawaited(c.confirmGuess());
      unawaited(c.load());
      await pumpEventQueue();
      manual.guessCalls.single.complete(GuessMissed(openRound(wrong: 1)));
      await pumpEventQueue();
      expect(c.phase, RoundPhase.loading);
      expect(c.miss, isNull);
      c.dispose();
    });

    test('an answer after dispose is ignored', () async {
      final manual = ManualRoundApi();
      final c = create(with_: manual);
      unawaited(c.load());
      await pumpEventQueue();
      c.dispose();
      manual.dailyCalls.single.complete(DailyRoundReady(openRound()));
      await pumpEventQueue();
      expect(c.round, isNull);
    });

    test('with every place guessed there is no round', () async {
      final c = create(
        with_: FakeRoundApi(
          places: [testPlace()],
          guessedPlaceIds: [7],
          latency: Duration.zero,
        ),
      );
      await c.load();
      expect(c.phase, RoundPhase.allGuessed);
      c.dispose();
    });

    test('an invalid pin is ignored', () {
      controller.placePin(const GeoPoint(double.nan, 12));
      controller.placePin(const GeoPoint(50, double.infinity));
      expect(controller.pin, isNull);
    });

    test('coming back on a new day loads the new round', () async {
      final yesterday = controller.round!.token;
      controller.reloadIfDayChanged();
      expect(controller.phase, RoundPhase.playing);

      clock.now = clock.now.add(const Duration(days: 1));
      controller.reloadIfDayChanged();
      expect(controller.phase, RoundPhase.loading);
      await pumpEventQueue();
      expect(controller.round!.token, isNot(yesterday));
    });
  });

  group('RoundCopy', () {
    test('directions', () {
      expect(RoundCopy.direction(0), 'na sever');
      expect(RoundCopy.direction(359), 'na sever');
      expect(RoundCopy.direction(44), 'na severovýchod');
      expect(RoundCopy.direction(135), 'na jihovýchod');
      expect(RoundCopy.direction(180), 'na jih');
      expect(RoundCopy.direction(270), 'na západ');
      expect(RoundCopy.direction(-90), 'na západ');
      expect(RoundCopy.direction(double.nan), 'na sever');
    });

    test('distances', () {
      expect(RoundCopy.distance(0), '0 m');
      expect(RoundCopy.distance(548), '550 m');
      expect(RoundCopy.distance(996), '1 km');
      expect(RoundCopy.distance(1234), '1,2 km');
      expect(RoundCopy.distance(2000), '2 km');
      expect(RoundCopy.distance(9970), '10 km');
      expect(RoundCopy.distance(14400), '14 km');
      expect(RoundCopy.distance(double.nan), '–');
      expect(RoundCopy.distance(-1), '–');
    });

    test('the overline counts guesses without a limit', () {
      expect(RoundCopy.overline(1), 'MÍSTO DNE\u00A0· POKUS 1');
      expect(RoundCopy.overline(17), 'MÍSTO DNE\u00A0· POKUS 17');
    });

    test('the share text has the date, guesses and stars only', () {
      final text = RoundCopy.shareText(
        day: DateTime.utc(2026, 10, 10),
        guesses: 2,
        stars: 4,
        maxStars: 5,
      );
      expect(text, contains('10. 10. 2026'));
      expect(text, contains('Trefa na 2. pokus'));
      expect(text, contains('4 z 5 hvězd'));
      expect(text, contains('★★★★☆'));
    });

    test('the pin label names the nearest town', () {
      expect(
        RoundCopy.nearTown(const GeoPoint(50.18, 12.64)),
        'kousek od Sokolova',
      );
      expect(
        RoundCopy.nearTown(const GeoPoint(50.146, 12.5297)),
        '3 km od Kynšperka nad Ohří',
      );
      expect(RoundCopy.nearTown(const GeoPoint(48.0, 10.0)), isNull);
    });

    test('every notice has a text', () {
      for (final kind in RoundNoticeKind.values) {
        expect(RoundCopy.notice(RoundNotice(kind)), isNotEmpty);
      }
      expect(
        RoundCopy.notice(
          const RoundNotice(
            RoundNoticeKind.rateLimited,
            retryAfter: Duration(seconds: 30),
          ),
        ),
        contains('30 sekund'),
      );
    });
  });

  test('the pin is picked up by its head', () {
    const tip = Offset(200, 300);
    final handle = GuessMap.handle(tip);
    // The head is about 30 px above the tip.
    expect(handle.contains(const Offset(200, 270)), isTrue);
    expect(handle.contains(tip), isTrue);
    expect(handle.width, greaterThanOrEqualTo(44));
    // A tap beside the pin still reaches the map.
    expect(handle.contains(const Offset(240, 280)), isFalse);
    expect(handle.contains(const Offset(200, 330)), isFalse);
  });
}
