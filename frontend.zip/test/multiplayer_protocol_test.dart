import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';

import 'package:kde_na_zapade/multiplayer/protocol.dart';
import 'package:kde_na_zapade/round/geo.dart';

import 'fake_multiplayer_server.dart';

ServerMessage parse(Map<String, Object?> json) =>
    ServerMessage.parse(jsonEncode(json));

void main() {
  group('server messages', () {
    test('parses welcome with the limits and defaults', () {
      final welcome = parse(welcomeJson()) as WelcomeMessage;

      expect(welcome.playerId, 'p1');
      expect(welcome.resumeToken, 'resume-1');
      expect(welcome.nickname, 'Eva');
      expect(welcome.isGuest, isTrue);
      expect(welcome.limits.maxPlaceCount, 20);
      expect(welcome.limits.penaltyDistanceMeters, 100000);
      expect(welcome.defaults.durationSeconds, 300);
    });

    test('numbers a nickname that two players share', () {
      final game = finishedGameJson();
      final rows = [
        for (final row in game['leaderboard']! as List)
          {...(row as Map<String, Object?>), 'nickname': 'Alice'},
      ];
      rows.add({...rows.first, 'playerId': 'p9', 'rank': 3});
      game['leaderboard'] = rows;
      final state = parse(
        stateJson(
          phase: 'finished',
          players: [
            playerJson('p1', 'Alice', host: true),
            playerJson('p3', 'Bob'),
            playerJson('p2', 'Alice'),
          ],
          game: game,
        ),
      ) as StateMessage;
      final lobby = state.lobby!;

      expect(lobby.players.map((p) => p.nickname), [
        'Alice',
        'Bob',
        'Alice (2)',
      ]);
      expect(
        {
          for (final row in lobby.game!.leaderboard!)
            row.playerId: row.nickname,
        },
        {'p2': 'Alice (2)', 'p1': 'Alice', 'p9': 'Alice (3)'},
      );
    });

    test('parses a waiting lobby', () {
      final state = parse(stateJson(hostId: 'p2')) as StateMessage;
      final lobby = state.lobby!;

      expect(state.serverNow, serverEpoch);
      expect(lobby.code, 'K7M2QX');
      expect(lobby.phase, LobbyPhase.waiting);
      expect(lobby.isHost, isFalse);
      expect(lobby.self!.nickname, 'Eva');
      expect(lobby.players.map((p) => p.isHost), [false, true]);
      expect(lobby.settings.placeCount, 3);
      expect(lobby.game, isNull);
    });

    test('parses a state without a lobby', () {
      final state = parse(stateJson(noLobby: true)) as StateMessage;
      expect(state.lobby, isNull);
    });

    test('a running game holds only the current place name', () {
      final state = parse(
        stateJson(phase: 'playing', game: playingGameJson(guessed: 1)),
      ) as StateMessage;
      final game = state.lobby!.game!;

      expect(game.status, GameStatus.playing);
      expect(game.endsAt, serverEpoch.add(const Duration(minutes: 5)));
      expect(game.self!.currentIndex, 1);
      expect(game.self!.currentPlaceName, 'Místo 2');
      expect(game.self!.rounds, hasLength(1));
      expect(game.self!.round(0)!.distanceMeters, 1200);
      expect(
        game.self!.round(0)!.place!.location,
        const GeoPoint(50.1859, 12.7541),
      );
      expect(game.leaderboard, isNull);
      expect(game.places, isNull);
      expect(game.guesses, isNull);
    });

    test('parses a finished game with the leaderboard and all guesses', () {
      final state = parse(
        stateJson(phase: 'finished', game: finishedGameJson()),
      ) as StateMessage;
      final game = state.lobby!.game!;

      expect(game.status, GameStatus.finished);
      expect(game.leaderboard!.map((r) => r.nickname), ['Adam', 'Eva']);
      expect(game.leaderboard!.first.averageDistanceMeters, 800);
      expect(game.places, hasLength(3));
      expect(game.guesses!['p2']![0], isNull);
      expect(game.guesses!['p2']![1]!.distanceMeters, 400);
      expect(game.guesses!['p1']![0]!.position, const GeoPoint(50.2, 12.8));
    });

    test('parses a guess result and its place card', () {
      final result = parse(guessResultJson(2)) as GuessResultMessage;
      final card = result.place.toCard();

      expect(result.index, 2);
      expect(result.distanceMeters, 1500);
      expect(card.name, 'Místo 3');
      expect(card.type, 'Hrady, tvrze a zříceniny');
      expect(card.source, 'datazapad.cz');
      expect(card.licence, 'CC BY');
      expect(card.isSpring, isFalse);
    });

    test('marks a spring so its card warns about the water', () {
      final json = placeJson(0)..['category'] = 'Prameny';
      expect(PlaceReveal.fromJson(json).isSpring, isTrue);
    });

    test('parses errors and pong', () {
      final error = parse(errorJson('lobby.full')) as ErrorMessage;
      expect(error.code, 'lobby.full');
      expect(parse({'type': 'pong'}), isA<PongMessage>());
    });

    test('ignores unknown types and frames that are not JSON', () {
      expect(parse({'type': 'confetti'}), isA<UnknownMessage>());
      expect(ServerMessage.parse('not json'), isA<UnknownMessage>());
      expect(ServerMessage.parse('[1, 2]'), isA<UnknownMessage>());
    });

    test('a known type with a broken shape throws', () {
      expect(
        () => parse({'type': 'welcome', 'playerId': 1}),
        throwsA(isA<ProtocolException>()),
      );
    });
  });

  group('client messages', () {
    Map<String, Object?> json(ClientMessage message) =>
        (jsonDecode(message.encode()) as Map).cast<String, Object?>();

    test('hello carries only what is given', () {
      expect(json(const HelloMessage(nickname: 'Eva')), {
        'type': 'hello',
        'nickname': 'Eva',
      });
      expect(json(const HelloMessage(token: 'jwt', resumeToken: 'r')), {
        'type': 'hello',
        'token': 'jwt',
        'resumeToken': 'r',
      });
    });

    test('guess, join, and settings', () {
      expect(
        json(const GuessMessage(index: 2, position: GeoPoint(50.1, 12.5))),
        {'type': 'guess', 'index': 2, 'latitude': 50.1, 'longitude': 12.5},
      );
      expect(json(const JoinLobbyMessage('K7M2QX')), {
        'type': 'joinLobby',
        'code': 'K7M2QX',
      });
      expect(json(const UpdateSettingsMessage(placeCount: 15)), {
        'type': 'updateSettings',
        'settings': {'placeCount': 15},
      });
      expect(json(const CreateLobbyMessage()), {'type': 'createLobby'});
      expect(json(const ReturnToLobbyMessage()), {'type': 'returnToLobby'});
    });
  });
}
