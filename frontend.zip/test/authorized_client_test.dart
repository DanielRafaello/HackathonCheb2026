import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

import 'package:kde_na_zapade/account/account_api.dart';
import 'package:kde_na_zapade/account/session.dart';
import 'package:kde_na_zapade/account/token_storage.dart';
import 'package:kde_na_zapade/api/authorized_client.dart';
import 'package:kde_na_zapade/config/api_config.dart';

import 'session_test.dart' show FakeBackend;

void main() {
  final config = ApiConfig(baseUrl: Uri.parse('https://example.cz/api/'));
  late FakeBackend backend;
  late Session session;

  /// A signed-in session whose JWT the backend still accepts.
  Future<Session> signedIn() async {
    final session = Session(
      api: AccountApi(config: config, client: backend.client),
      storage: MemoryTokenStorage(),
    );
    await session.signIn(email: 'eva@example.cz', password: 'tajneheslo');
    return session;
  }

  /// The game endpoints: `/api/ping` answers 200 with the bearer it saw
  /// when the backend knows the JWT, otherwise 401.
  http.Client gameClient({Duration delay = Duration.zero}) =>
      MockClient((request) async {
        if (delay > Duration.zero) await Future<void>.delayed(delay);
        final token = request.headers['Authorization']?.substring(7);
        if (!backend.validTokens.contains(token)) {
          return http.Response('{"error":true,"status":401}', 401);
        }
        return http.Response(jsonEncode({'token': token}), 200);
      });

  setUp(() async {
    backend = FakeBackend();
    session = await signedIn();
  });

  test('sends the bearer token and JSON headers', () async {
    final client = AuthorizedClient(
      config: config,
      session: session,
      client: gameClient(),
    );
    final response = await client.get('ping');
    expect(response.statusCode, 200);
    expect(jsonBody(response)['token'], session.token);
  });

  test('refreshes an expired JWT once and retries', () async {
    backend.validTokens.clear();
    final client = AuthorizedClient(
      config: config,
      session: session,
      client: gameClient(),
    );
    final response = await client.post('ping', {'a': 1});
    expect(response.statusCode, 200);
    expect(jsonBody(response)['token'], 'jwt2');
    expect(session.token, 'jwt2');
  });

  test('requests failing together share one refresh', () async {
    backend.validTokens.clear();
    final client = AuthorizedClient(
      config: config,
      session: session,
      client: gameClient(),
    );
    final responses = await Future.wait([
      client.get('ping'),
      client.get('ping'),
      client.get('ping'),
    ]);
    expect(responses.map((r) => r.statusCode), everyElement(200));
    final refreshes = backend.requests.where(
      (r) => r.url.path == '/api/auth/refresh',
    );
    expect(refreshes.length, 1);
  });

  test('a rejected refresh token signs the player out', () async {
    backend.validTokens.clear();
    backend.validRefreshTokens.clear();
    final client = AuthorizedClient(
      config: config,
      session: session,
      client: gameClient(),
    );
    await expectLater(
      client.get('ping'),
      throwsA(
        isA<ApiTransportException>().having(
          (e) => e.error,
          'error',
          ApiTransportError.unauthorized,
        ),
      ),
    );
    expect(session.isSignedIn, isFalse);
  });

  test('a guest has no authorized requests', () async {
    final guest = Session(
      api: AccountApi(config: config, client: backend.client),
      storage: MemoryTokenStorage(),
    );
    final client = AuthorizedClient(
      config: config,
      session: guest,
      client: gameClient(),
    );
    await expectLater(
      client.get('ping'),
      throwsA(isA<ApiTransportException>()),
    );
  });

  test('never retries after a second 401', () async {
    var calls = 0;
    final always401 = MockClient((request) async {
      calls++;
      return http.Response('{"error":true,"status":401}', 401);
    });
    final client = AuthorizedClient(
      config: config,
      session: session,
      client: always401,
    );
    await expectLater(
      client.get('ping'),
      throwsA(isA<ApiTransportException>()),
    );
    expect(calls, 2);
  });

  test('other statuses come back to the caller', () async {
    final client = AuthorizedClient(
      config: config,
      session: session,
      client: MockClient(
        (request) async => http.Response(
          '{"error":true,"status":409,"message":"round.not_active"}',
          409,
          headers: {'retry-after': '7'},
        ),
      ),
    );
    final response = await client.get('ping');
    expect(response.statusCode, 409);
    expect(jsonBody(response)['message'], 'round.not_active');
    expect(retryAfter(response), const Duration(seconds: 7));
  });

  test('a lost connection and a timeout are told apart', () async {
    final offline = AuthorizedClient(
      config: config,
      session: session,
      client: MockClient((request) async => throw http.ClientException('x')),
    );
    await expectLater(
      offline.get('ping'),
      throwsA(
        isA<ApiTransportException>().having(
          (e) => e.error,
          'error',
          ApiTransportError.network,
        ),
      ),
    );

    final slow = AuthorizedClient(
      config: config,
      session: session,
      client: gameClient(delay: const Duration(milliseconds: 300)),
      timeout: const Duration(milliseconds: 20),
    );
    await expectLater(
      slow.get('ping'),
      throwsA(
        isA<ApiTransportException>().having(
          (e) => e.error,
          'error',
          ApiTransportError.timeout,
        ),
      ),
    );
  });

  test('a body that is not a JSON object reads as empty', () {
    expect(jsonBody(http.Response('not json', 500)), isEmpty);
    expect(jsonBody(http.Response('[1]', 200)), isEmpty);
    expect(retryAfter(http.Response('', 429)), isNull);
  });
}
