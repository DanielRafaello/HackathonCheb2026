# Kde na západě – Data Specification

This document describes the location catalog that is currently stored and seeded by the backend. It also records the data work still required by [PRODUCT_SPECIFICATION.md](PRODUCT_SPECIFICATION.md). Product requirements are not described as implemented unless the required fields and import logic exist in this repository.

- **Owner:** backend team
- **Status:** audited against migrations, seeders, tests, and the 112-row seed on 10 October 2026

## 1. Current state

| Item | Implemented value |
|------|-------------------|
| Primary catalog source | [DATA ZÁPAD](https://www.datazapad.cz/search?collection=dataset), the open-data portal of the Karlovy Vary Region |
| Primary datasets used | 5 CSV datasets |
| Seeded locations | 112 |
| Categories | 5 |
| Districts | 3 |
| Stored ORPs | 7 |
| Coordinate system | WGS 84 longitude/latitude (EPSG:4326) |
| Source provenance | Publisher, canonical portal URL, licence, attribution, retrieval time, portal item ID, and portal-modified timestamp for all five datasets |
| External statistical source | None used by the current clues; the former ČSÚ population enrichment was removed from `hint2` |
| Description and clue references | Source-dataset narrative fields plus 83 public pages recorded in `content_source_url` |
| Import mechanism | A checked-in normalized JSON seed loaded by Doctrine DBAL seeders |
| Import schedule | Manual preparation; migrations and seeders run during backend deployment |

The number of datasets available on DATA ZÁPAD is intentionally not recorded here because the portal catalog changes and its total does not affect this import.

## 2. Seeded datasets

The `sources` table and [`sources.json`](../migrations/Seeders/data/sources.json) store the downloaded filename together with verified DATA ZÁPAD provenance. DATA ZÁPAD does not publish a semantic version number, so the stable ArcGIS item ID plus the portal's last-modified timestamp form the source-version identity.

| `source_id` | Dataset / checked-in source filename | Rows | Category | Record ID | Name | Narrative used for `description` |
|-------------|--------------------------------------|------|----------|-----------|------|----------------------------------|
| 1 | `Hrady__tvrze_a_zříceniny_v_Karlovarském_kraji_WFL1_8648591209228732528.csv` | 29 | Hrady, tvrze a zříceniny | `objekt_id` | `název` | Factual Czech paraphrase of a public reference page |
| 2 | `Koupací_místa_s_kontrolou_kvality_vod_r_2026_WFL1_-1111043040365173288.csv` | 26 | Koupací místa | `objekt_id` | `název` | Original `popis`; two sparse records were supplemented from public sources |
| 3 | `Lanová_a_zábavní_centra_v_KVK_WFL1_-3632380198616414150.csv` | 22 | Lanová a zábavní centra | `objekt_id` | `název` | Factual Czech paraphrase of a public reference page |
| 4 | `Letiště_v_Karlovarském_kraji_WFL1_5594178904668020710.csv` | 6 | Letiště | `objekt_id` | `název` | Czech summary of structured fields such as opening year, elevation, runway, and airport type |
| 5 | `Památkově_chráněná_území_WFL1_6714778677998953677.csv` | 29 | Památkově chráněná území | `Objekt ID` | `Název` | Original `Popis` |

| `source_id` | Publisher / data provider | Licence | Canonical DATA ZÁPAD record | Portal modified | File retrieved |
|-------------|---------------------------|---------|----------------------------|-----------------|----------------|
| 1 | Krajské inovační centrum Karlovarského kraje, p.o. | CC BY 4.0 | [Hrady a jejich zříceniny](https://www.datazapad.cz/datasets/c3a42c283f0649248326a0bbd7dc5cc3_0/about) | 2026-06-11 10:11:01 UTC | 2026-10-09 16:58:32 Europe/Prague |
| 2 | Krajská hygienická stanice Karlovarského kraje; Krajské inovační centrum Karlovarského kraje, p.o. | CC BY 4.0 | [Koupací místa 2026](https://www.datazapad.cz/datasets/239805159c8649609d1bd40a30439623_0/about) | 2026-08-04 07:36:08 UTC | 2026-10-09 09:19:25 Europe/Prague |
| 3 | Krajské inovační centrum Karlovarského kraje, p.o. | CC BY 4.0 | [Lanová a zábavní centra](https://www.datazapad.cz/datasets/90441fa783444e1ead5ad71464504d6a_0/about) | 2026-07-17 09:10:08 UTC | 2026-10-09 16:58:29 Europe/Prague |
| 4 | Krajské inovační centrum Karlovarského kraje, p.o. | CC BY 4.0 | [Letiště](https://www.datazapad.cz/datasets/fc44327a17e04959b7c5209d9ce32820_0/about) | 2026-07-23 10:44:17 UTC | 2026-10-09 09:21:17 Europe/Prague |
| 5 | Krajský úřad Karlovarského kraje | CC0 1.0 | [Památkově chráněná území](https://www.datazapad.cz/datasets/54223e92a9b04a0ba27e9800f41c4f1f_0/about) | 2026-02-26 10:19:13 UTC | 2026-10-09 16:58:43 Europe/Prague |

All 112 source records have a unique record ID within their dataset and non-empty coordinates. The protected-area source contains 29 records but only 28 unique names because `Jáchymov` represents two different protected-area records.

The former schools dataset is deliberately excluded. Its 269 old seed rows, category, and source are deleted by `LocationSeeder` so existing installations are cleaned up as well as fresh databases.

## 3. Geometry and administrative fields

### Coordinates

All five CSV files contain point records and explicit WGS 84 longitude and latitude columns. The import uses those named columns directly; it does not reproject data and does not calculate polygon centroids.

The source geometry text is written in the unusual order `POINT(latitude longitude)`. Standard WKT normally uses x/y, or longitude/latitude. The import therefore must not parse that text as ordinary WKT without first confirming its axis order. The additional `x2` and `y2` columns are not imported.

The database validates longitude as −180…180 and latitude as −90…90 and indexes `(latitude, longitude)`. It stores ordinary numeric columns, not a PostGIS geometry. PostGIS and point-in-polygon queries are not currently used.

### Districts, ORPs, and municipalities

The source CSVs supply all three administrative levels needed during normalization:

- district name and code;
- ORP name and code (`název/kód obce s rozšířenou působností`);
- actual municipality name and code (`název/kód obce`).

The current schema persists the three districts and seven ORPs. It does **not** persist the 57 individual municipalities represented by single-municipality rows.

| `orp_id` | Stored name | ORP code | District |
|----------|-------------|----------|----------|
| 1 | Aš | 4101 | Cheb |
| 2 | Cheb | 4102 | Cheb |
| 3 | Karlovy Vary | 4103 | Karlovy Vary |
| 4 | Kraslice | 4104 | Sokolov |
| 5 | Mariánské Lázně | 4105 | Cheb |
| 6 | Ostrov | 4106 | Karlovy Vary |
| 7 | Sokolov | 4107 | Sokolov |

The lookup is stored in `orps`, using `orp_id` and the four-digit `orp_code`. Consequently:

- the backend cannot return the actual municipality name/code from the database;
- it cannot generate a municipality-letter clue from stored structured data;
- it cannot compare municipality populations at runtime;
- a separate municipality table would be needed if those deferred product ideas are reintroduced.

No municipality, ORP, or region boundary dataset is imported. Consequently, the backend cannot currently determine the municipality or ORP of an arbitrary guess or reject a guess by a spatial region-boundary lookup.

### Product areas

The product specification defines three game areas that map directly to the stored districts:

| Area | `district_id` | Stored district |
|------|---------------|-----------------|
| Chebsko | 1 | Cheb |
| Karlovarsko | 2 | Karlovy Vary |
| Sokolovsko | 3 | Sokolov |

No separate `area` column is necessary if this fixed mapping is used. The current API does not expose area-progress totals, so that behavior still needs implementation.

## 4. External and supporting sources

| Data | Current use | Source | Licence / attribution | Stored representation |
|------|-------------|--------|-----------------------|-----------------------|
| Municipality population | Not used by the current seed; retained only as a possible future numeric clue | ČSÚ [Population – condition and age structure (OBY02A)](https://csu.gov.cz/produkty/spv_oby02_cr), CSV distribution, indicator `2406P`, sex `0`, reference date 1 January 2026 | [ČSÚ data are CC BY 4.0](https://csu.gov.cz/podminky_pro_vyuzivani_a_dalsi_zverejnovani_statistickych_udaju_csu). If reintroduced, the game must credit ČSÚ and identify bands as derived data. | Not stored in the current catalog. |
| Location facts | Supplies or verifies `description` and `hint1` | Public pages in `content_source_url`; original `popis` / `Popis` where sufficient | Terms vary by page. External prose is paraphrased rather than copied. A page URL is provenance, not proof that its contents have an open licence. | 83 rows have a URL; all 29 protected-area rows use `NULL` because their text comes directly from the source dataset. |
| Elevation | Not used by the current four-clue model; possible future compass enrichment | Not selected | Not selected | Not imported or stored. Airport elevation is only part of airport-specific prose, not a general place-elevation field. |
| Photos | Optional on the product place card | Not selected | Not selected | Not imported or stored. |
| Map tiles | Required by the frontend map | Provider not selected in the frontend implementation | Depends on provider | Not part of the backend catalog. |

No external API is called by the seeders. Every external fact is already baked into the checked-in seed JSON.

## 5. Database representation

### Sources

The canonical source-provenance artifact is [`migrations/Seeders/data/sources.json`](../migrations/Seeders/data/sources.json). `SourceSeeder` upserts every field below:

| Database field | Meaning |
|----------------|---------|
| `source_id` | Stable internal source key referenced by locations |
| `external_id` | Stable 32-character ArcGIS item ID |
| `title` | Human-readable dataset title from the portal |
| `file_name` | Exact downloaded CSV filename |
| `portal_url` | Canonical public DATA ZÁPAD metadata page |
| `publisher` | Publisher or source providers stated in portal metadata |
| `license_code`, `license_url` | Machine-readable licence identity and canonical Creative Commons URL |
| `attribution_text` | Czech display-ready attribution for the primary dataset |
| `retrieved_at` | Timestamp of the imported CSV download |
| `source_updated_at` | Portal last-modified timestamp used as the dataset version marker |

The added provenance columns are nullable at schema level so the migration remains compatible with a legacy school source that is deleted by the seed process. Unit tests require every active source in `sources.json` to have complete metadata.

### Locations

The canonical seed artifact is [`migrations/Seeders/data/locations.json`](../migrations/Seeders/data/locations.json). Each row has these fields:

| Database field | Source / transformation | Current constraint or meaning |
|----------------|-------------------------|-------------------------------|
| `id` | Manually assigned sequential catalog ID | Integer primary key; currently 1–112 |
| `source_id` | One of the five source files | Foreign key to `sources` |
| `source_record_id` | Source `objekt_id` / `Objekt ID`, kept as text | Unique together with `source_id` |
| `name` | Source `název` / `Název` | Non-empty in the seed; no database non-empty check |
| `district_id` | Source district code mapped to the three-row lookup | Foreign key to `districts` |
| `orp_id` | Source ORP code mapped to the seven-row `orps` lookup | Foreign key paired with `district_id` |
| `category_id` | Determined by source dataset | Foreign key to `categories` |
| `longitude`, `latitude` | Explicit WGS 84 source columns | Range checks in PostgreSQL |
| `description` | Original source narrative or curated factual paraphrase | Required text |
| `hint1` | Short distinctive fact selected from `description` | Required text; limited to 100 Unicode characters; excludes the exact location name and direct category terms |
| `hint2` | WGS 84 distance band from the district capital | Required text; recomputed and checked from coordinates in the seed test |
| `content_source_url` | Public page used for the description/clue | Nullable text; URL form is checked only by the seed unit test |

The following stored fields or relationships are still missing:

- Required for controlled catalog selection: verification state, verifier, verification time, playability, and place-of-the-day eligibility.
- Deferred product ideas: facts, photo metadata, nearby tips, and per-place visit radius.

The three stored clue inputs are complete in the seed. The fourth clue is generated at response time from `locations.name`, so it does not require an additional clue column.

Potential future enrichments that are not stored include:

- actual municipality ID, name, and code;
- numeric population and its reference date;
- general elevation.

These future enrichments would be inputs only if the deferred municipality-letter, population, elevation, or richer compass ideas are reintroduced. An area label can be derived directly from `district_id` and does not require another stored location field.

### User progress and daily assignments

`user_locations` is intentionally used for both persistent location progress and the current test implementation of daily rounds:

| Database field | Meaning |
|----------------|---------|
| `id` | Generated row identifier returned as the round id |
| `user_id`, `location_id` | Owner and assigned catalog location |
| `daily_date` | Prague calendar date of a daily assignment; `NULL` for a row created only by the progress endpoint |
| `attempts` | Number of guesses submitted for this daily row, constrained to a non-negative integer with no upper limit |
| `guessed_at`, `visited_at` | Progress timestamps |

There can be multiple rows for the same user and location because an unfinished location remains eligible for a later random daily selection. A partial unique index allows only one non-null `daily_date` per user. `GET /locations` aggregates all rows for a user/location and uses the earliest non-null progress timestamps.

`user_location_guesses` stores each submitted pin against `user_locations.id`, including its positive attempt number, WGS 84 coordinates, server-calculated distance and direction, hit flag, and creation time. Distance and direction are retained for server state, but the API withholds both for the first three misses and exposes compass feedback from the fourth miss onward.

## 6. Current clues and descriptions

### `description`

- Bathing sites and protected areas retain the narrative supplied in `popis` / `Popis`, except that two extremely short bathing records are enriched with sourced facts.
- Castle and activity descriptions are Czech factual paraphrases of public reference pages.
- Airport descriptions are generated from structured fields in the airport dataset.
- The seed does not store the date on which an external page was read or a snapshot of that page.

### `hint1`

`hint1` is the current first clue. It is a short, distinctive fact rather than a generic category description. Automated validation ensures that it is present, no longer than 100 Unicode characters, and does not contain the exact full `name` value.

Validation also rejects direct category terms such as `hrad`, `koupaliště`, `lanové centrum`, and `letiště`. It does not detect every indirect spoiler, alias, shortened name, or grammatical variant, so human review can still be necessary.

### `hint2`

`hint2` is a geographic clue calculated as straight-line distance from the location to its district capital. It does not repeat the distinctive fact or category clue.

| `district_id` | Reference | WGS 84 reference point |
|---------------|-----------|------------------------|
| 1 | Cheb | 50.07935, 12.370353 |
| 2 | Karlovy Vary | 50.22768, 12.879553 |
| 3 | Sokolov | 50.1813, 12.6401 |

Distance is calculated with the Haversine formula and placed into `<5`, `5–10`, `10–20`, `20–30`, `30–40`, or `40+ km` bands. These are deliberately approximate game reference points, not administrative geometry. `hint1` is separately curated and tested not to contain a distance-from-city clue or state the category directly.

The former municipality-population bands were removed from the current seed: they offered less geographic help, carried repeated date text, and depended on municipality data that the current ORP-only schema does not persist. Population remains a possible future alternative where it provides a better clue.

### Product clue mapping

The product specification and catalog now use the same four-clue model:

- clue 1 is `hint1`, the initial distinctive fact;
- clue 2 is the category name resolved through `category_id`;
- clue 3 is `hint2`, the approximate distance from the district capital.
- clue 4 is generated at response time from the first and last Unicode letter in `locations.name`.

The current product does not define a numbers clue or municipality-name clue. Population, general elevation, and actual municipality remain optional future enrichments rather than missing current clues. The generated name-edge clue uses no external or supporting data.

There is no content-verification workflow or metadata. The product's playability and daily-eligibility rules therefore cannot yet be evaluated from the database.

## 7. IDs and catalog updates

Current location IDs are manually assigned ranges:

| IDs | Source |
|-----|--------|
| 1–29 | Castles, fortresses, and ruins |
| 30–55 | Bathing sites |
| 56–77 | Rope and amusement centres |
| 78–83 | Airports |
| 84–112 | Protected heritage areas |

`LocationSeeder` upserts on `locations.id`; the database separately enforces uniqueness of `(source_id, source_record_id)`. Regeneration must preserve both mappings. Reordering source rows and assigning IDs again would break identity.

There is no automated policy for a changed or removed source record. The seeder updates rows that remain in the JSON but does not delete stale non-school locations. The only explicit cleanup is for the removed school category. Before periodic imports are introduced, the project must decide whether removed places are archived, disabled, or deleted and how historical rounds continue to reference them.

Daily assignment history is stored directly in `user_locations` through `daily_date` and `attempts`; there is no separate rotation table. Each daily row references its selected `locations.id`, so later catalog growth does not change an assignment already stored for a user and date.

## 8. Deduplication

No automatic deduplication is performed. Distinct source records remain distinct locations even when their names or points overlap.

Known exact coordinate overlaps in the current seed are:

- IDs 90 `Bečov nad Teplou` and 109 `Bečovsko`;
- IDs 92 and 111, both named `Jáchymov` but representing different protected-area types;
- IDs 96 `Valeč` and 110 `Valečsko`.

These may be legitimate city-versus-landscape records, but the game needs an explicit product decision on whether both records are independently playable. A future deduplication rule should use source/type semantics as well as distance and name; distance alone would merge legitimate related records.

## 9. Import and deployment

### Inputs and reproducibility

The downloaded CSV files and the script/process that produced the final normalized JSON are not checked into this repository. The current repository is therefore sufficient to seed the database but not to reproduce the catalog from raw source downloads.

The checked-in artifacts are:

- lookup seeders for categories, districts, ORPs, and sources;
- the normalized `locations.json` file;
- migrations defining the tables and clue provenance column;
- unit tests for the JSON contract.

### Commands

With dependencies and database environment variables configured:

```shell
composer migrate
composer db:seed
```

For a disposable development database only, `composer db:fresh` rolls migrations back, reapplies them, and seeds the catalog. It must not be used against production data.

Deployment runs migrations and then `php bin/seed.php`. `DatabaseSeeder` runs all lookup and location seeders in one database transaction. A thrown exception rolls back that seed run. Each table uses targeted upserts, and the school cleanup runs after location upserts.

### Validation currently committed

`tests/Unit/LocationSeedDataTest.php` verifies:

- exactly 112 rows with IDs 1–112;
- required descriptions and clues;
- no legacy `keywords` field;
- `hint1` length and exact-name exclusion;
- no school source/category;
- complete and unique source IDs, portal URLs, licences, attribution, retrieval timestamps, and version timestamps;
- URL presence rules;
- the computed district-capital distance in `hint2` and the absence of category or distance duplication in `hint1`.

The repository has no committed integration test that migrates and seeds an isolated PostgreSQL database. Adding one would protect foreign keys, migration ordering, upsert behavior, and school cleanup.

## 10. Nearby tips and other product datasets

Nearby tips are not implemented as a separate dataset or relationship.

| Product tip | Current data |
|-------------|--------------|
| Spring | No spring dataset imported |
| Bathing site | The 26 bathing sites exist as seeded catalog locations, but no nearest-tip query or maximum distance is implemented |
| Cinema or theatre | No cinema or theatre dataset imported |

Facts unlocked by a visit are also not stored. The spring safety warning in the product specification is not relevant to the current catalog because there are no spring records, but it remains a requirement if springs are added.

## 11. Licensing and attribution

### Primary dataset licences

The official portal metadata was checked per dataset. Sources 1–4 are CC BY 4.0; source 5 is CC0 1.0. The database stores each publisher, canonical record URL, licence code and URL, attribution text, retrieval timestamp, ArcGIS item ID, and portal-modified timestamp. The CC BY attribution text explicitly states that the data was modified for the catalog.

The stored attribution can support a future place-card endpoint, but the current `/locations` response does not expose it. `content_source_url` is a separate factual reference for a location description; it does not grant a licence to copy that page. Photo records and photo licences are still absent.

### Confirmed ČSÚ attribution

ČSÚ publishes its statistical information under CC BY 4.0 and requires derived values to be identified as modified or derived. Population is not used by the current seed. If a derived population band is reintroduced, a suitable attribution is:

> Zdroj: Český statistický úřad, datová sada OBY02A, stav k 1. 1. 2026. Hodnota byla převedena do populačního pásma. Licence CC BY 4.0.

This text would need a place in the API/card data model before population data is reintroduced.

### Public reference pages

Only factual paraphrases should be stored from public pages unless their terms clearly allow copying. If the application displays a quotation, image, or other protected material, it needs per-item author, licence, and attribution metadata. A source link alone is insufficient.

## 12. Known data and design issues

1. The ORP lookup is stored correctly, but actual municipalities are not persisted; this blocks only deferred municipality-based features.
2. Numeric population, general elevation, and their provenance are not stored; they are not part of the current four clues.
3. The raw-to-normalized transformation is not reproducible from files in the repository.
4. There is no refresh schedule or stale-record policy.
5. External page facts have URLs but no access dates or verification metadata and may change.
6. `hint1` validation catches only the exact full location name and selected direct category terms, not every alias or partial spoiler.
7. Three coordinate pairs are shared by conceptually related protected-area records; there is no playability/deduplication decision.
8. No boundary geometry is available for region validation, ORP lookup of guesses, or municipality lookup.
9. Area progress, nearby tips, photos, visit facts, and per-place visit radii are not represented as product-ready data or relationships.
10. Content-verification, playability, and daily-eligibility metadata are not represented.
11. Per-player daily assignment, clue unlocking, compass feedback, expiry at Prague midnight, and completed place-card responses are implemented. Server-verified visits and dedicated area-progress responses remain unimplemented; the older progress endpoint still accepts a direct visited state.

## 13. Decisions required before the game catalog is production-ready

1. Check in a repeatable raw-data import/enrichment script or define an auditable manual curation workflow.
2. Define archive/removal behavior and stable IDs for future imports.
3. Decide how overlapping city, landscape, and monument records participate in play.
4. Add content-verification metadata and explicit playability/eligibility state.
5. Decide whether deferred facts, nearby tips, photos, boundary checks, or richer compass comparisons remain in scope; import their data only when selected.
6. Add an isolated PostgreSQL migration-and-seed integration test.

Municipality, population, and elevation are no longer blockers for the current clue model. If their deferred features return, add authoritative sources, provenance, reference dates, and tests with them.
