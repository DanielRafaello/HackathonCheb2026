# Kde na západě – Frontend Specification

**Status:** WIP. Sections marked `TODO(frontend)` are open.
**Owner:** frontend team.

This document describes the technical design of the frontend. It does not cover UX or UI: screens, layouts, navigation, interactions, and visual design live in the separate UI design. The rules of the game, the account behaviour, and the configuration values are defined in [PRODUCT_SPECIFICATION.md](PRODUCT_SPECIFICATION.md). When this document conflicts with the product specification, the product specification wins. The API that the frontend calls is described in [BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md). Terms follow the glossary in the product specification.

## 1. Responsibilities

- Show the map, take guesses, and display clues, the compass, and the place card.
- Keep a guest's progress on the device and switch to the server for an account.
- Check the device location for a visit.
- Share the place-of-the-day result.
- Provide the account functions.
- Play the multiplayer game with the socket server over a WebSocket.

The frontend never decides whether a guess is a hit and never holds the target of an unfinished round. The backend does that.

## 2. Technology

| Item | Choice |
|------|--------|
| Framework | Flutter |
| Map library | MapLibre GL (Flutter plugin) |
| Base map | Vector tiles from OpenStreetMap data (also recorded in the data specification) |
| Hosting (web version) | Server `aether217.zcu.cz` (ZČU cloud): nginx container behind Traefik on `https://aether217.zcu.cz/`; the Game API is on the same site under `/api` |
| Web build | `flutter build web --wasm` (see `Dockerfile`). The browser loads Dart compiled to WebAssembly with the skwasm renderer. A browser without WasmGC, such as Safari 18, loads the JavaScript build with the CanvasKit renderer instead. The page is not cross-origin isolated, so skwasm runs single-threaded |
| Test framework | Flutter's default (`flutter_test`) |
| Multiplayer connection | `web_socket_channel` (WebSocket on Android, iOS, and the web) |
| Lobby QR code | `qr` (pure Dart encoder); the app draws the modules itself |

Targets: one Flutter codebase for three platforms:

- Android app,
- iOS app,
- web app (mobile browsers first, desktop works too).

Supported versions: operating systems and browsers released in the last two years. As of October 2026, this means:

- Android 15 (API level 35) and newer,
- iOS 18 and newer,
- current versions of Chrome, Safari, Firefox, and Edge, back to the versions released in October 2024 (Safari 18 and newer).

Review the minimums with each release.

Distribution: none yet. The mobile apps run as development builds only.

Every platform-specific feature (location, sharing, storage, sessions, deep links) must have a web variant. The sections below name both where they differ.

## 3. Map

- Vector tiles from OpenStreetMap data, rendered by MapLibre GL with a minimal style. The game needs very little map data, so the style contains only the layers that the UI design uses.
- The game covers one region, so a small extract of the region and its surroundings is enough. Tile source: a self-hosted regional extract. The build in `tools/map` turns an OpenStreetMap extract into one PMTiles archive (`kvk.pmtiles`) with only the layers the style draws; `tools/map/README.md` lists them. The app bundles the archive as an asset (`assets/map/kvk.pmtiles`), so the map needs no tile server and no network for tiles. A new build of the archive is copied there and committed together with the style changes that need it; a test checks that the bundled archive holds exactly the layers that the style draws.
- The style lives in the app (`lib/map/map_style.dart`) and names the archive with the `pmtiles://` scheme. On Android and iOS the app copies the archive to a file in its cache directory, which MapLibre Native reads itself. On the web the app loads the asset into memory and registers it with the `pmtiles` protocol handler of MapLibre GL JS before it builds the first map. Label fonts (glyphs) come from the URL template in the build setting `MAP_GLYPHS_URL`.
- The map always carries the attribution "© OpenStreetMap contributors": MapLibre's info button in the bottom right corner of the map opens it.
- The region border is a layer of the tile set (`region`), so the map draws it without a backend call. The build also writes the border as `region.geojson`, a static file the app can bundle when it needs the geometry itself. The backend does not serve the border.

## 4. Sharing

- The share text must not contain the place's name or location (product specification). The text itself is part of the UI design.
- Uses the system share sheet on mobile and the Web Share API in the browser. The fallback, for example on desktop browsers, is copy to clipboard. Plugin: TODO(frontend).

## 5. Geolocation

- The device location service with high accuracy, through the `geolocator` plugin, which also supports the web (browser Geolocation API).
- The app asks for "while in use" location permission only when the player starts a visit, not at start-up. It does not need background location.
- The permission request texts for Android and iOS are in Czech.
- On the web, location works only over HTTPS. Desktop browsers usually have imprecise location, so a visit is realistic only on a phone.
- The frontend sends the position and its accuracy to the backend visit endpoint. It does not store the position.
- The frontend distinguishes a denied permission, an unavailable location, a timeout, and too great a distance, so that the UI can show the right message.
- The place card may show the distance to the place ("31 km od tebe") only when the permission is already granted; it never asks for it.
- Every place on my map opens its place card, a place in the fog too: it shows the name, the position, navigation and "Jsem tu!", with the status "Neobjeveno". A visit to it is recorded like any other visit (PRODUCT_SPECIFICATION.md, "Places in the fog can be browsed").
- Navigation to a place opens the platform's maps app with directions from the current position, through the `url_launcher` plugin: Apple Maps (`maps.apple.com`) on iOS, Google Maps (`google.com/maps/dir`) elsewhere. On the web the browser's platform decides. The app passes only the destination; the maps app reads the position itself.
- **Rating:** the card of a visited place lets an account rate it with 1–5 stars (`PUT /locations/{id}/rating`) and change the rating later; a guest sees an invitation to sign in instead, because guests cannot rate. The card shows the average and count from `GET /locations` for every place. The profile lists the places the player rated, from the same list.
- **Place card texts:** the card of a guessed or visited place shows the description, the category, and the data source with its licence. The client takes them from the card it kept after the hit, or else from `GET /locations/{id}/description`, and keeps that answer too. A place in the fog asks for nothing: the backend answers `403 location.in_fog`, and its card shows the name, the position and navigation only.
- **Wafers:** the profile shows the account's balance (`wafers` from `GET /me/profile`). The hit screen and the visit result show the wafers the request earned (`wafers_earned`); the client never computes them. A guest earns no wafers.

## 6. Sessions and deep links

The session is a JWT issued by the backend (see the backend specification).

- **Mobile (Android, iOS):** the backend returns the JWT at sign-in. The app stores it in the platform's secure storage (Keychain on iOS, Keystore on Android) and sends it as `Authorization: Bearer <JWT>`. When the backend issues a fresh JWT, the app replaces the stored one. Plugin: TODO(frontend).
- **Web:** the backend sets the JWT in an HttpOnly, Secure cookie. The web app never reads or stores the JWT itself and sends requests with credentials.
- Sign-out deletes the JWT on mobile. On the web, the backend clears the cookie.
- **Current backend (interim):** the implemented backend (`/auth/register`, `/auth/login`, `/auth/refresh`, `/auth/logout`, `GET /me`) returns a short-lived JWT and a one-use refresh token in the body and accepts only `Authorization: Bearer`, with no cookie. Until it sets the cookie, the client uses Bearer on every platform and keeps both tokens in `flutter_secure_storage` (encrypted local storage on the web). The client refreshes an expired JWT at start-up; a rejected refresh token signs the player out.
- **Password reset link:** the link points to the web app's password reset page. On a phone with the app installed, the same link opens the app (Android App Links, iOS Universal Links). Link domain: TODO(frontend), depends on web hosting.

## 7. Client progress store

One interface for the UI, two implementations.

- **Interface:** read place statuses and counts, record a hit, record a visit, read and write the place-of-the-day result, save and resume the active round.
- **Guest implementation:** local storage on the device; on the web, browser local storage (plugin: TODO(frontend)). It stores:
  - `placeId → { status: guessed | visited, stars, guessedAt, visitedAt, rating?, card, facts?, nearby? }` (`rating` only for an account; guests cannot rate);
  - the active daily round (token + guesses);
  - place-of-the-day results by date.
  It does not store unknown places. Storage access is wrapped so that the app still works when storage fails (for example in a private browser window).
- **Account implementation:** reads from and writes to the Game API.
- The store does not record expired places as guessed.
- Derived values: "in the fog" = total − guessed − visited, with the totals from the backend stats endpoint. Progress per area = (guessed + visited in the area) / total in the area.
- A rejected JWT (expired, or revoked by a password change) signs the player out and switches to an empty guest store.
- After registration or sign-in, the store uploads guest progress for merge, clears local progress after success, and switches to the account implementation. Sign-out switches back to an empty guest store.

Storage key names and versioning of the stored format: TODO(frontend).

## 8. Language and texts

- The whole UI is in Czech.
- No text may encourage drinking from springs.
- Mapping of API error codes to Czech messages: TODO(frontend), aligned with the backend error codes.

## 9. Tests

Testing principles are in the product specification.

- **Client progress store** (automated seam): tested with `flutter_test` through its public interface over fake storage and a fake API. It covers status transitions (unknown → guessed → visited; expired places are not recorded as guessed), one place of the day per day, resuming today's active round, the "in the fog" and per-area counts, and switching from guest to account with a merge.
- **Multiplayer state** (automated): tested with `flutter_test` over a fake connection and an injected clock. See section 10.
- **Everything else** (map, sharing, location, sessions, deep links): checked by hand at the hackathon on an Android phone, an iOS phone, and a mobile browser. Widget tests are optional. Automated end-to-end (integration) tests are out of scope.

## 10. Multiplayer

The rules of the multiplayer game are in the product specification (Multiplayer rules). The socket server is described in [BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md) §5, and its message protocol in `API_SPECIFICATION.md` §7 of the backend repository.

### 10.1 Configuration

- The socket URL comes from the build setting `MULTIPLAYER_URL` (`--dart-define`), read by `MultiplayerConfig.fromEnvironment()` in `lib/config/multiplayer_config.dart`. Without the setting, the defaults follow the API base URL:
  - release build: `wss://aether217.zcu.cz/ws`;
  - debug build: `ws://localhost:8090/ws`;
  - debug build on the Android emulator: `ws://10.0.2.2:8090/ws`.
- `config/local.json` sets `MULTIPLAYER_URL` for local runs with `--dart-define-from-file=config/local.json`.
- The production web app is served over HTTPS, so the browser accepts only a `wss://` socket.
- Multiplayer limits and defaults (players, places, game timer, penalty distance) come from the server in the `welcome` message. Widgets never hold them as literals.

### 10.2 Connection

- The client uses one WebSocket connection (`web_socket_channel`) for one multiplayer session. The first message is `hello`:
  - a signed-in player sends the access token, refreshed first when it has expired. On `auth.invalid_token`, the client refreshes the token once and sends `hello` again;
  - a guest sends a nickname. The client remembers the last nickname in local storage, wrapped so that the game still works when storage fails.
- **Reconnect:** when the connection drops, the client reconnects automatically and sends the `resumeToken` from `welcome`. The server keeps the seat for the reconnect grace period, so a short outage keeps the player in the lobby and in the game. The UI shows that it is reconnecting.
  - A connection can die without closing, for example when a phone sleeps or loses its signal. The client sends `ping` every 15 seconds, and again when the app returns to the foreground. When no message arrives within 10 seconds of a `hello` or a `ping`, the client treats the connection as lost and reconnects.
  - On `resume.invalid`, the seat is gone. The client joins the same lobby code again as a new player and tells the player so. When that join fails (`lobby.not_found`, `lobby.full`), the player starts again from the entry screen.
  - Any other error that answers the `hello`, the create, or the join (for example `server.error`) sends the player back to the entry screen with a message. During a reconnect, the client tries again instead.
  - When the server closes the connection with code `4001`, the same seat was resumed on another connection, for example in another browser tab. The client does not reconnect by itself, because the two connections would keep taking the seat from each other. It says that the game is open in another window and takes the seat back only when the player asks. When the player leaves instead, the client also forgets the seat it stored, so that entering multiplayer again in this window does not take the seat back from the other one.
  - The client keeps the `resumeToken` in memory for the lifetime of the multiplayer session. It also stores it locally, wrapped like other storage, together with the lobby code and who took the seat (the account, or a guest). A stored seat is resumed only by the same account, or by a guest when a guest took it; otherwise it is forgotten. On the web the stored seat is kept per browser tab (`sessionStorage`), because all tabs share local storage. The choice to play as a guest is kept in the same tab storage, so a guest who reloads the page during a game returns to the seat without the sign-in page.
- **Clock:** the countdown uses `endsAt` from the server, corrected by the difference between `serverNow` and the device clock when the `state` message arrived. The server ends the game; the client countdown is only a display.
- The client sends one `guess` per place and disables the confirm button until the answer arrives. It never computes the offset.
- Before the player's own guess on a place, the client holds only the name of that place, never its coordinates or texts (the recorded exception in the product specification). It does not cache or log places.
- The multiplayer game does not use the client progress store and records nothing in progress.

### 10.3 Screens and routes

- Routes: `/multiplayer` and `/multiplayer/:code`. The second one is the lobby link: it joins the lobby with that code. Both are full-screen routes outside the tab shell. When the session redirect sends a player to sign in first, the player returns to the same route afterwards.
- The „Hra s kamarády“ tile on the Minihry tab opens `/multiplayer`.
- Screens:
  1. **Entry:** a nickname field for guests, a button to create a lobby, and a lobby code field with a button to join.
  2. **Lobby:** the lobby code with copy and share of the link, the players (host and connection state), and the settings. The host changes the settings within the limits and starts the game; the options always include the server's defaults. Players with the same nickname are told apart by a number, for example „Alice (2)“; the others see them read-only. Every player can leave.
  3. **Game:** progress (for example 3/10), the countdown, the name of the current place, and the full-screen guess map with one confirmed guess. After the guess, the offset and a short reveal of the place, then the next place. A player who has guessed every place waits and sees the others' progress until the game ends.
  4. **Results:** the leaderboard (rank, nickname, average offset, places guessed; the player's own row highlighted) and the player's own result for each place. Buttons to return to the lobby and to leave.
- The guess map is injected, so that widget tests can replace it.

### 10.4 Tests

- Protocol parsing of every server message.
- The multiplayer state over a fake connection with an injected clock: create, join, settings, start, guess, game end, return to the lobby, reconnect with the `resumeToken`, and the countdown.
- Widget tests of the main screens with a stubbed map are optional, as elsewhere.

## 11. Open questions

- TODO(frontend): where the label fonts (glyphs, `MAP_GLYPHS_URL` in section 3) are hosted. The tile archive is bundled with the app.
- TODO(frontend): plugins for sharing, local storage, and secure storage.
- TODO(frontend): password reset link domain and app links setup.
