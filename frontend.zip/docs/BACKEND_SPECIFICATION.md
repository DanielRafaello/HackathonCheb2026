# Kde na západě – Backend Specification

**Owner:** backend team.

This document describes the technical design of the backend. The rules of the game, the account behaviour, and the configuration values are defined in [PRODUCT_SPECIFICATION.md](PRODUCT_SPECIFICATION.md). When this document conflicts with the product specification, the product specification wins. The data sources and the import are described in [DATA_SPECIFICATION.md](DATA_SPECIFICATION.md). Terms follow the glossary in the product specification.

## 1. Responsibilities

- Build the place catalog from data already put in seeder /migration/Seeders/*.
- Keep the place catalog and answer spatial queries.
- Choose a separate random place of the day for each player.
- Evaluate guesses and compute clues and the compass, without revealing the target before the round ends.
- Confirm visits.
- Manage accounts, sessions, and account progress.
- Run the multiplayer game in a separate socket server: lobbies, the game timer, guess evaluation, and the leaderboard (section 5).
- Provide all of this through the Game API.

## 2. Technology

| Item                   | Choice                                           |
|------------------------|--------------------------------------------------|
| Language and framework | SLIM FRAMEWORK API                               |
| Database               | PosgreSQL                           |
| Multiplayer socket server | Node.js 22, TypeScript (ESM), `ws`, `pg`, `jsonwebtoken`; tests with `vitest` |

## 3. Modules

Middlewares (done in SLIM FRAMEWORK) handle sessions, JWTs, and CORS. The modules are:

### 3.1 Architecture ADR - action domain responder
- Routes call actions, which call domain services, which call repositories. Actions return responders, which produce HTTP responses.
- Action uses ALWAYS REQUEST. Domain services use only the data passed to them, never the HTTP request or session. Repositories use only the data passed to them, never the HTTP request or session.

- THERE IS NO CONTROLLER LAYER. The action is the controller.
- CLEAN CODE IS VERY IMPORTANT. The domain services are the core of the game logic. They are tested through the Game API.

- We use DEPENDENCY INJECTION for all services and repositories. The DI container is configured in /app/dependencies.php.

- We use JWT for sessions - already implemented. The JWT is signed with a secret key and has a short lifetime. The JWT is sent as a Bearer header or as a cookie. The backend checks the JWT on every request and issues a new one on activity.



## 4. Game API

HTTP + JSON. Game endpoints work for guests and accounts. With a valid session, the server also records progress. Paths below are working names.

written in /app/routes.php

The full reference (requests, responses, errors) is in [API_SPECIFICATION.md](API_SPECIFICATION.md); the OpenAPI description is in [openapi.yaml](openapi.yaml).

### Account

| Endpoint                              | Purpose                                           |
|---------------------------------------|---------------------------------------------------|
| `POST /auth/register`                 | Register with e-mail, password. Starts a session. |
| `POST /auth/login`                    | Sign in. Starts a session.                        |
| `POST /auth/logout`                   | Sign out.                                         |
| `POST /auth/refresh`                  | Refresh token.                                    |
| `GET /me`                             | Current account (e-mail, nickname) or "guest".    |

### Locations

| Endpoint                        | Purpose                                                                                |
|---------------------------------|----------------------------------------------------------------------------------------|
| `GET /locations`                | Obtain locations and their guessed/visited state                                       |
| `POST /locations/{id}/progress` | Mark a location as guessed or visited                                                  |
| `PUT /locations/{id}/rating`    | Rate a visited location 1–5; the list returns each location's average and count       |
| `GET /locations/{id}/description` | The description, category and source of a guessed or visited location; `403 location.in_fog` otherwise |

Wafers: `users.wafers` holds an account's balance (migration `Version20261010000500`, which credited existing hits and visits). A round hit adds 2 per star in the same transaction as the hit; the first visit through `POST /locations/{id}/progress` adds 50. Both responses return `wafers_earned`; `GET /me` and `GET /me/profile` return `wafers`. The amounts are constants in `App\Services\Profile\Scoring`.


`GET /locations/{id}/description` serves the texts of the place card: the description, the category, and the primary data source with its licence, in the shape of `round.location` after a hit. The client fills the rest of the card from `GET /locations`.

TODO(backend): the rest of the place card that the client opens from my map, once the data exists:

- the stars of the hit, when the place is guessed;
- the number of facts; the facts themselves only when the caller has visited the place;
- after a visit, the nearby tips (spring, swimming, when it rains: name and distance) with their data source.

For a place in the fog (neither guessed nor visited) the backend serves no texts: the client shows its name, position and navigation only (PRODUCT_SPECIFICATION.md, System overview).

TODO(backend): the visit. `POST /locations/{id}/progress` with `visited` trusts the client. The product specification asks the backend to confirm a visit from the device position (stories 52, 53, 54, 77): the client sends the position and its accuracy, and the backend answers whether the player stands within the visit radius, with the distance when not. It does not store the position. Until then, the client evaluates the visit itself against the visit radius.

### Rounds

| Endpoint                    | Purpose                                       |
|-----------------------------|-----------------------------------------------|
| `GET /rounds/daily`         | Obtain today’s daily round                    |
| `GET /rounds/{id}`          | Resume or obtain the current state of a round |
| `POST /rounds/{id}/guesses` | Submit a guess for the daily round            |

All round endpoints currently require the existing JWT bearer token. The token identifies whose attempts and location progress are being read or changed; it does not change the location-oriented endpoint design.

`GET /rounds/daily` uses the `Europe/Prague` calendar date. It returns the caller's existing assignment for today or inserts a new `user_locations` row whose location is selected randomly from locations the caller has not successfully guessed. Different players therefore receive independent selections. At midnight, an unfinished older assignment expires and the next request creates the new day's assignment.

A guess body contains WGS 84 `latitude` and `longitude`. The backend calculates Haversine distance to the hidden target. A distance of at most 3,000 metres is a hit. The first clue is visible before any guess; misses one through three unlock the category, area-narrowing, and name-edge clues without exposing compass data. The generated fourth clue reveals the first and last Unicode letter of the location name. The fourth miss activates the compass, and that miss plus every later miss returns the distance and an eight-point direction (`N`, `NE`, `E`, `SE`, `S`, `SW`, `W`, or `NW`). There is no attempt limit. A hit awards `max(1, 6 - attempt_number)` stars.

Active and expired-round responses never contain the target id, name, coordinates, description, or provenance. Only a guessed-round response includes the location card and primary-source attribution. A successful guess also stamps `user_locations.guessed_at` automatically.

Daily state is stored in:

- `user_locations`: the generated round id, owner, hidden target, daily date, attempt count, and guessed/visited timestamps;
- `user_location_guesses`: every submitted pin, its server-calculated distance and direction, and whether it hit.

## 5. Multiplayer server

The multiplayer game (PRODUCT_SPECIFICATION.md, Multiplayer rules) runs in a separate process, the socket server. Its source is in this repository under `multiplayer/`. It shares the database, the JWT secret, and the deployment with the PHP backend, but no code. The message protocol is in [API_SPECIFICATION.md](API_SPECIFICATION.md) §7.

### 5.1 Process

- One Node.js process with one HTTP server on `MP_PORT` (default `8090`).
  - `GET /ws/health` answers `200` with `{"status":"ok"}`.
  - A WebSocket upgrade on the path `/ws` opens a player connection.
  - Every other request answers `404`.
- **Origin check:** when the upgrade request has an `Origin` header, it must equal one of the origins in `FRONTEND_URL` (a comma-separated list is allowed). Otherwise the server refuses the upgrade with `403`. A request without `Origin` (a mobile app) is allowed.
- Exactly one instance runs, because lobbies and games live in its memory. A restart ends every lobby and game.
- On `SIGTERM`, the server stops accepting connections, closes the open ones, and exits.
- npm scripts: `build` (tsc), `start` (`node dist/index.js`), `dev` (`tsx watch src/index.ts`), `test` (`vitest run`), `typecheck`.

### 5.2 Deployment

| Environment | How it runs | Client URL |
|-------------|-------------|------------|
| Development | Service `multiplayer` in `docker-compose.yml` (`node:22-alpine`, source mounted, `npm run dev`), port `8090` | `ws://localhost:8090/ws` |
| Production | `docker-compose.multiplayer.yml`, compose project `kdz-multiplayer`, image from `multiplayer/Dockerfile`, manual CI job `deploy-multiplayer` | `wss://aether217.zcu.cz/ws` |

In production, Traefik routes ``Host(`${DOMAIN}`) && PathPrefix(`/ws`)`` on the `websecure` entry point to port `8090`, through the `zcu-only` middleware. The prefix is not stripped. Traefik passes the WebSocket upgrade through and ends TLS. Deployment details are in `docker/production/README.md`.

### 5.3 Configuration

The server reads its configuration from environment variables. In production they come from the same `ENV_FILE` as the backend.

| Variable | Default | Meaning |
|----------|---------|---------|
| `MP_PORT` | `8090` | Listen port. |
| `MP_MAX_PLAYERS` | `8` | Default and hard cap of players per lobby. |
| `MP_MIN_PLAYERS` | `1` | Players needed to start a game. |
| `MP_PLACES_PER_GAME` | `10` | Default number of places per game. |
| `MP_MAX_PLACES_PER_GAME` | `20` | Highest number of places the host may set. |
| `MP_GAME_DURATION_SECONDS` | `300` | Default game timer. |
| `MP_MIN_GAME_DURATION_SECONDS`, `MP_MAX_GAME_DURATION_SECONDS` | `60`, `1800` | Limits of the game timer for the host. |
| `MP_PENALTY_DISTANCE_METERS` | `100000` | Offset of an unguessed place. |
| `MP_RECONNECT_GRACE_SECONDS` | `60` | How long a disconnected player keeps their seat. |
| `MP_LOBBY_IDLE_TTL_SECONDS` | `1800` | After this idle time, a lobby is deleted. |
| `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` | – | The backend database. `DB_DRIVER` is ignored. |
| `JWT_SECRET` | – | The backend's HS256 secret, used to verify account tokens. |
| `FRONTEND_URL` | – | The allowed `Origin` values. |

### 5.4 Data access

- The server reads the database directly with `pg`. It only reads: the schema belongs to the Doctrine migrations of the backend, and the multiplayer game writes nothing.
- Places for a game, N distinct places at random:

  ```sql
  SELECT l.id, l.name, l.latitude, l.longitude, l.description, l.content_source_url, c.name AS category,
         s.title, s.publisher, s.portal_url, s.license_code, s.license_url, s.attribution_text, s.retrieved_at, s.source_updated_at
  FROM locations l JOIN categories c ON c.category_id = l.category_id JOIN sources s ON s.source_id = l.source_id
  ORDER BY random() LIMIT $1
  ```

- The account name for a signed-in player: `SELECT name FROM users WHERE id = $1`.

### 5.5 Players and authentication

- Browsers cannot set headers on a WebSocket, so the access token travels in the first message (`hello`), not in the URL. This also keeps it out of proxy logs.
- With a token, the server verifies the JWT with `JWT_SECRET` (HS256, claims `sub`, `role`, `iat`, `exp`) and takes the nickname from `users.name`. It verifies the token only at `hello`; a token that expires later does not end the connection.
- Without a token, the player is a guest and must send a nickname.
- Every player gets a random `playerId` and a secret `resumeToken`. A client that reconnects within `MP_RECONNECT_GRACE_SECONDS` sends the `resumeToken` in `hello` and gets its seat back. An account id never identifies a player in the protocol.

### 5.6 Game logic

- The lobby and game state machine, scoring, and geometry are pure code, separate from the WebSocket transport. They take the clock and the place source as dependencies.
- **Offset:** haversine distance with the Earth radius 6,371,008.8 m, rounded to whole metres, the same calculation as `src/Services/Round/GeoCalculator.php`.
- **Region check:** a guess must have finite coordinates in the WGS 84 ranges and lie inside the region outline. The outline is a copy of `Region.outline` from the frontend (`lib/game/region.dart`), tested by ray casting. When the outline changes, update both copies.
- **Ranking:** average offset with `MP_PENALTY_DISTANCE_METERS` for each unguessed place, then more guesses, then the earlier last guess, then nickname.
- The server sends each player a personalized `state` snapshot after every change. A snapshot never holds the coordinates or texts of a place that the player has not guessed, and never holds another player's guesses before the game ends.

### 5.7 Robustness

- Messages are JSON text frames of at most 4 KiB. Invalid JSON or an unknown message type answers `error` with `message.invalid` and keeps the connection open.
- A ping every 30 seconds detects dead connections. The server terminates a connection that does not answer with a pong; other messages do not count as an answer.
- Each connection may send about 20 messages per 5 seconds. The server drops excess messages and answers only the first of them with `rate_limited`. When the connection keeps sending until another 20 messages are dropped, the server closes it with code `1008`.
- The server terminates a connection whose unsent output grows past 2 MiB, because its client does not read.
- One connection is one player. A second `hello` on the same connection answers `hello.duplicate`.

### 5.8 Tests

`npm test` runs `vitest`. The tests cover the game logic through its public interface, with an injected clock and a fake place source: the lobby lifecycle, host change, settings limits, the game timer, guesses, offsets, ranking and tie-breaks, reconnection, and what each player's snapshot may contain. Distances are checked against known point pairs, not against a second implementation of the formula. The tests need no database.
