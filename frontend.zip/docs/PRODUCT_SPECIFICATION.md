# Kde na západě – Product Specification

This document defines what the game does and the rules it follows. Related documents:

The data baseline was audited against the 112-row seed on 10 October 2026. Items marked **Deferred** are product ideas that the current catalog cannot support; they are not part of the active data contract.

| Document | Content | Owner | Status |
|----------|---------|-------|--------|
| [DATA_SPECIFICATION.md](DATA_SPECIFICATION.md) | Which data the game uses, where it comes from, how the import builds the place catalog | Backend team | Draft |
| [BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md) | Backend modules, Game API, accounts and authentication, storage, backend tests | Backend team | WIP |
| [FRONTEND_SPECIFICATION.md](FRONTEND_SPECIFICATION.md) | Screens, map, sharing, geolocation, client progress store, frontend tests | Frontend team | WIP |

The game UI is in Czech. Czech UI labels appear in parentheses where they help.

## Glossary

Use these terms consistently in all documents, the UI, and the code.

- **Place** (UI: „místo“) – a real point from the region's open data that a player can guess, for example a castle, bathing site, activity centre, airport, or protected heritage area.
- **Place catalog** – the stored places that may be offered by the game. The current catalog has 112 records; content verification and explicit playability status are not yet stored.
- **Round** – the guessing of one place. A daily round accepts guesses until the player hits the target or the round expires at Prague midnight.
- **Guess** (UI: „tip“) – a pin that the player placed on the map and confirmed.
- **Hit** (UI: „trefa“) – a guess within the hit radius of the target.
- **Clue** (UI: „klíč“) – a hint about the place. Clues unlock one at a time.
- **Compass** (UI: „kompas“) – distance and direction from the player's guess to the target, activated by the fourth wrong guess.
- **Place of the day** (UI: „Místo dne“) – one independently selected daily place per player, with four progressively unlocked clues.
- **Place status** – the per-player state of a place: unknown → guessed → visited.
- **Visit** (UI: „návštěva“) – the confirmation, by GPS, that the player stands within the visit radius of a place, guessed or still in the fog.
- **Fact** (UI: „zajímavost“) – a deferred text type intended to unlock only during a visit; facts are not currently stored.
- **Nearby tips** (UI: „tipy poblíž“) – a deferred relationship to nearby places from other datasets; nearby tips are not currently stored.
- **Area** (UI: „oblast“) – Chebsko, Sokolovsko, or Karlovarsko (the districts of Cheb, Sokolov, and Karlovy Vary).
- **ORP** – a municipality with extended powers (Czech administrative district).
- **My map** (UI: the „Mapa“ tab; the „Profil“ tab shows the account, the badges, the player's ratings, and sign-out) – the map of every place in the region with the player's guessed and visited places. A place the player has neither guessed nor visited is **in the fog**: a gray dot whose card shows only the name, the position, and navigation.
- **Account** – a registered player who signs in with e-mail and password. The server stores the account's progress.
- **Guest** – a player who is not signed in. The device stores the guest's progress.
- **Rating** (UI: „hodnocení“) – a player's 1–5 star verdict on a place they have visited. Not the same as the **stars** a round awards: stars score a guess, a rating says whether the place is worth the trip.
- **Wafers** (UI: „oplatky“, after the Karlovy Vary spa wafers) – the game's currency in an account's balance. A hit and a first visit earn wafers. Not the same as **points**, which only measure the level; wafers will be spendable later.
- **Progress** – one player's place statuses, stars, ratings, wafers, unlocked facts, and place-of-the-day results.
- **Multiplayer game** (UI: „Hra s kamarády“) – a game in which the players of one lobby guess the same places in the same order against one game timer and are ranked by average offset. Each place is one round with exactly one guess. A multiplayer game has no clues, no compass, no hits, and no stars.
- **Lobby** (UI: „místnost“) – the group of players who play multiplayer games together. A lobby outlives a game: after a game, its players can return to it and start another one.
- **Lobby code** (UI: „kód místnosti“) – six characters that identify a lobby. A player joins a lobby by entering its code or by opening a link that contains it.
- **Host** (UI: „zakladatel“) – the player who created the lobby, or who took the role over when the previous host left. Only the host changes the lobby settings and starts a game.
- **Participant** – a player who takes part in a running multiplayer game. Players who join the lobby during a game wait for the next one.
- **Game timer** – the time limit of a whole multiplayer game, shared by all participants.
- **Offset** (UI: „odchylka“) – the distance in whole metres between a participant's guess and the place, computed by the server.
- **Penalty distance** – the offset that counts for a place that a participant did not guess before the game ended.
- **Average offset** – a participant's offsets over all places of a multiplayer game, with the penalty distance for each unguessed place, divided by the number of places. Lower is better.
- **Leaderboard** (UI: „pořadí“) – the ranking of the participants of one multiplayer game by average offset. It belongs to that game only and is not stored.

## Problem Statement


At the same time, residents and visitors do not know many places near them. They have no reason to learn about these places and no prompt to go and see them. Existing map and travel apps offer lists, not an experience. What is missing is a short, low-effort daily activity that reveals places in the region step by step and motivates people to visit them in person.

## Solution

„Kde na západě“ is a mobile game for Android, iOS, and the web: a daily puzzle over a map of the Karlovy Vary Region.

- The game picks a real place from the open data and shows the first clue. It does not reveal the name or the location.
- The player places a pin on the map. A guess within 3 km is a hit and ends the round. The first three misses unlock the remaining clues without compass data. The fourth clue reveals the first and last letter of the location name. If the fourth guess is also wrong, the compass activates with distance and direction, and the player can then continue guessing without an attempt limit until a hit or midnight expiry.
- A hit earns 1–5 stars, two wafers per star, and a place card with a short description, primary data source, and licence. The guessed place goes onto the player's personal map.
- Once a day, the player receives a random **place of the day** that they have not successfully guessed. Different players may receive different places.
- When the player visits a place in person (GPS within 1 km), guessed or still in the fog, the place changes to "visited". After the visit the player can rate the place with 1–5 stars. Facts and nearby tips are deferred until their datasets and relationships exist.
- **My map (frontend responsibility)** shows what the player knows in the region and their progress per area. Places the player has neither guessed nor visited stay "in the fog": gray dots that the player can browse and visit, without their texts.

Every place goes through three states (unknown → guessed → visited), and the game pushes the player along that path. The initial catalog combines five regional datasets; more can be added through the documented catalog workflow.

**Multiplayer game:** friends play together in a lobby that one of them creates and the others join with a lobby code. Everyone gets the same places, sees only the name of each place, and places one guess per place before the game timer runs out. The leaderboard ranks the players by the average distance of their guesses from the places.


## User Stories

### Basic round

1. As a player, I want to see the first clue at the start of a round without the place's name or location, so that I have something to solve and the game is not spoiled.
2. As a player, I want to see a map of the whole Karlovy Vary Region, so that I know where to search.
3. As a player, I want to zoom and pan the map with my fingers, so that I can place my guess precisely.
4. As a player, I want to place a pin on the map and move it before I confirm, so that I do not submit a guess by accident.
5. As a player, I want to confirm a guess explicitly with a button, so that I control when an attempt counts.
6. **Deferred:** rejecting a guess outside the region requires region boundary geometry or another authoritative spatial lookup.
7. As a player, I want to know immediately whether my guess is a hit, so that I know whether the round is over.
8. As a player, I want a guess within 3 km of the target to count as a hit, so that I do not need to know the exact location.
9. As a player, I want a miss to unlock the next clue, so that I have more information for my next attempt.
10. As a player, I want to see whether the compass is active, so that I understand what feedback the next guess provides.
11. As a player, I want to see all unlocked clues at once, so that I can combine them.
12. As a player, I want to see my earlier guesses of the round on the map, so that I do not repeat them.
13. As a player, I want to continue guessing after the fourth miss until I hit the target, so that the compass helps me finish the round instead of revealing the answer.
14. As a player, I want an expired, unguessed place to stay off my map, so that the map shows only what I really guessed.
15. As a player, I want 5 stars for a hit on the first attempt, one fewer through the fifth attempt, and at least 1 star for every later hit, so that completing the round is always rewarded.
16. As a player, I want an unfinished round to survive closing and reopening the app, so that I do not lose attempts.

### Clues

17. As a player, I want clues to go from vague to specific, so that guessing is hard at first and gets easier.
18. As a player, I want the first clue to be a short, distinctive fact, so that the start of the round is useful and memorable.
19. As a player, I want the second clue to be the place type (for example "national cultural monument, castle and chateau"), so that I can narrow down what I am looking for.
20. As a player, I want the third clue to narrow the area by giving an approximate straight-line distance from the relevant district capital, so that I can search in a more specific part of the region.
21. As a player, I want the fourth clue to reveal the first and last letter of the location name, so that I receive one final strong clue before the compass activates.
22. As a player, I want further guesses to continue without another clue after all four clues are visible, so that the compass still matters.
23. As a player, I want every daily place to use the same four-clue contract, with each clue giving different information, so that the rules remain consistent across the catalog.

### Compass

24. As a player, I want to see the distance to the target from the fourth miss onward, so that I know how far off I am once the compass is active.
25. As a player, I want to see the direction to the target as an arrow from the fourth miss onward, so that I know where to move my next guess.
26. **Deferred:** higher/lower comparison requires an elevation source for both the catalog and arbitrary guesses.
27. **Deferred:** municipality-size comparison requires municipality boundaries and population data that are not stored.
28. **Deferred:** same/different ORP comparison requires ORP boundary geometry or another authoritative spatial lookup that is not available.
29. As a player, I want to see the compass for each guess from the fourth attempt onward, so that I can compare the results without exposing compass data during the clue-only phase.
30. As a player, I want the compass to work consistently in every daily round, so that I do not have to learn changing rules.

### Place of the day

31. As a player, I want a random daily place that I have not successfully guessed, so that the game helps me discover more of the catalog.
32. As a player, I want a new place of the day after midnight Czech time even when yesterday's round is unfinished, so that each date has a fresh assignment.
33. As a player, I want only one assignment per calendar day, so that repeated requests resume the same round.
34. As a player, I want to see that I have finished today's place and when the next one comes, so that I know what to do next.
35. As a player, I want to share my place-of-the-day result (date, attempts, stars, how my distances developed) without revealing the place, so that I can show off without spoiling the game for others.
36. As a player, I want to share the result through my phone's share sheet or copy it to the clipboard, so that I can send it anywhere.
37. As a player, I want the game to have no daily streak, so that I lose nothing when I skip a day.

### Place card and learning

45. As a player, I want to see a place card with the name, the type, and one sentence on what makes the place interesting after a hit, so that I learn something.
46. As a player, I want to see the place's location on a map on the card, so that I know exactly where it is.
47. **Deferred:** photos require a selected source plus per-photo author and licence metadata.
48. As a player, I want every card to show its primary data source and licence, so that I know where the catalog record came from and how it may be reused.
49. As a player, I want to open a card again at any time from my map, so that I can recall the place.
50. **Deferred:** if springs are added, their cards must warn when the water is not hygienically monitored.

### Visiting in person

51. As a player, I want to visit any place in person at any time, guessed or still in the fog, so that I have a reason to go there.
52. As a player, I want an "I am here" button on the card of every place that checks my location by GPS, so that I can confirm my visit.
53. As a player, I want the place to change to "visited" when I am within 1 km of it, so that I am rewarded for the trip.
54. As a player, I want a clear message, including the distance, when I am too far from the place, so that I know how far to walk.
55. As a player, I want a clear message when the app has no access to my location, so that I know how to allow it.
56. **Deferred:** visit facts require a verified facts dataset that is not currently stored.
57. **Deferred:** nearby tips require the missing datasets, relationships, and distance rules.
58. As a player, I want visits not to be tied to the day of the puzzle, so that I can go whenever it suits me.
59. **Deferred:** unlocked facts can be persisted after facts are introduced.
59a. As a player, I want to rate a place 1–5 stars once I have visited it, so that I can tell others whether it is worth the trip.
59b. As a player, I want to change my rating later, so that it reflects my latest opinion.
59c. As a player, I want to see the average rating and the number of ratings of any place, visited or not, so that I can decide whether to go there.
59d. As a player, I want to see the places I have rated, with my rating, in my profile, so that I can look back at where I liked it.
59e. As a player, I want to earn wafers for every hit, more for more stars, so that a quick hit feels rewarded.
59f. As a player, I want to earn more wafers for visiting a place in person than for any hit, so that I have a reason to go there.
59g. As a player, I want to see my wafer balance in my profile and how many wafers a hit or a visit just earned, so that I know what I have collected.

### My map

60. As a player, I want to see guessed and visited places on the region map with two different markers, so that I can see at a glance where I have been.
61. As a player, I want places I have neither guessed nor visited to appear as gray dots "in the fog" whose card shows only the name, the position, and navigation, so that I can browse the region and plan a trip without texts that would spoil a future puzzle.
62. As a player, I want to see the number of places still "in the fog", so that I know how many remain.
63. As a player, I want to see my progress per area (Chebsko, Sokolovsko, Karlovarsko) as "x of y", so that I have a goal to complete.
64. As a player, I want to open the card of any place from my map, so that I can return to it or plan a visit.
65. As a guest, I want my progress saved on my device without registration, so that I can start playing at once.

### Account

66. As a player, I want to register with e-mail and password, so that I do not lose my progress when I lose or replace my phone.
68. As a player, I want to sign in on another device and see the same progress there, so that I can play on my phone and my computer.
69. As a guest, I want my existing progress to move into my account when I register or first sign in, so that I do not start over.
70. As a player, I want the merge of progress to keep the better place status (visited over guessed) and the higher star count, so that merging loses nothing.
71. As a player, I want to stay signed in after closing the app, so that I do not have to sign in every day.
72. As a player, I want to sign out, so that I can lend my device to someone else.
73. As a player, I want to reset a forgotten password through a link in an e-mail, so that I can get back to my progress.
74. As a player, I want only one daily assignment per account, even on several devices, so that every device resumes the same result.
75. As a player, I want to finish today's unfinished place on another device, so that I do not lose attempts before midnight.
77. As a player, I want to know that the game does not store my location, only the fact that I visited a place, so that I do not worry about being tracked.
78. As a player, I want clear error messages during registration and sign-in (e-mail already used, weak password, wrong password), so that I know what to fix.

### Multiplayer

90. As a player, I want to create a lobby and get a short lobby code and a link, so that I can invite my friends.
91. As a player, I want to join a lobby by entering its code or by opening its link, so that I can play with my friends without searching for them.
92. As a guest, I want to play a multiplayer game with only a nickname, so that I do not need an account to play with friends.
93. As a signed-in player, I want to appear under my account name, so that my friends recognise me.
94. As a player in a lobby, I want to see who else is in the lobby, who the host is, and whose connection has dropped, so that I know when we are ready.
95. As the host, I want to set the number of places, the game timer, and the maximum number of players within limits, so that the game fits our group and our time.
96. As the host, I want to start the game when everyone is ready, so that all participants start at the same moment.
97. As a participant, I want to see the name of the current place, my progress (for example 3/10), and the remaining time, so that I know what to guess and how fast to go.
98. As a participant, I want exactly one confirmed guess per place, so that every guess counts and nobody improves by trial and error.
99. As a participant, I want to see my offset and the true location of the place right after my guess, so that I learn where the place is before I move on.
100. As a participant, I want to move through the places at my own pace, so that a slow guess does not hold up the others.
101. As a participant, I want to see how many places the others have guessed, but not their guesses, so that I feel the race without getting hints.
102. As a participant, I want the game to end when the game timer runs out or when every participant has guessed every place, so that nobody waits longer than necessary.
103. As a participant, I want to see the leaderboard and every participant's guesses on every place at the end, so that we can compare and talk about the results.
104. As a participant, I want to return to the same lobby after the game or to leave it, so that we can play again without a new code.
105. As a participant, I want to get my seat back when my connection drops for a moment, so that a short outage does not throw me out of the game.
106. As a player, I want multiplayer guesses to stay off my map and out of my progress, so that playing with friends does not change my daily game.

## Implementation Decisions

This section records product-level decisions: the rules of the game and what the system guarantees. The technical design lives in [BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md) and [FRONTEND_SPECIFICATION.md](FRONTEND_SPECIFICATION.md).

### System overview

- A mobile app for Android and iOS and a web app, built from one codebase (frontend), and a backend.
- **The backend holds the place catalog and evaluates guesses.** The round endpoints hide the target's name and coordinates until completion. The authenticated `GET /locations` endpoint remains a separate catalog/progress endpoint that returns stored names and coordinates. The multiplayer game is the one recorded exception: it shows the name of the current place before the guess, and nothing else (see Multiplayer rules). Protection against deliberate cheating is not a goal: the single-player modes are not competitive, and the multiplayer game is played among friends (see Multiplayer rules).
- **A socket server runs the multiplayer game.** It is a separate process next to the backend. It reads places from the same database, verifies the same account tokens, and keeps lobbies and games in memory. The client talks to it over a WebSocket. Before a guess, it sends a participant only the name of the place, never its coordinates or texts (see Multiplayer rules). See [BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md) §5.
- **Places in the fog can be browsed.** My map shows every place, and the place card of a place in the fog shows its name, position and navigation, so that the player can see what the region offers and plan a trip. A visit to a place in the fog counts, and it clears the fog. Texts stay hidden until the place is guessed or visited. Accepted trade-off (2026-10-10): a player can look up the place of the day on my map.
- **Progress lives in one of two places.** For a guest, progress lives only on the device. For an account, progress lives on the server, and the server is the source of truth.
- The backend currently stores descriptions, two text hints, categories, coordinates, districts, ORPs, and source references. It does not yet store verification metadata, visit facts, photos, nearby tips, or general numeric population/elevation data. The texts in the screen designs are illustrative.
- The design has four main mobile screens: Place of the day, Hit, My map, and On site. Account screens are added for registration, sign-in, and password reset.
- The multiplayer game adds four screens: entry (nickname and lobby code), lobby, game, and results.

### Round rules

- A round has no attempt limit. It remains active until a hit or Prague-midnight expiry.
- A **hit** is a guess with distance ≤ the hit radius (default 3 km).
- **Stars** = `max(1, 6 − hitting attempt)`: attempts 1–5 award 5–1 stars and every later hit awards 1 star.
- Rejecting a guess outside the region is deferred until authoritative region boundary data or a spatial service is available.

### Clues

Every round supplies exactly four clues, ordered from vague to specific. Clue *n* is visible before attempt *n*. The first three come from the catalog; clue 4 is generated from the location name. After clue 4 is visible, further guesses get no new clue. A fourth miss activates the compass, which then stays active until the player hits the target or the round expires.

| # | Clue | Current Bečov example | Stored source |
|---|------|------------------------|---------------|
| 1 | Distinctive fact | "A rare reliquary lay hidden under the chapel floor for forty years." | `locations.hint1`, curated from `description` |
| 2 | Place type | "Castles, fortresses and ruins." | `categories.name` through `category_id` |
| 3 | Area narrowing | "Approximately 10–20 km as the crow flies from the centre of Karlovy Vary." | `locations.hint2`, generated from WGS 84 coordinates and `district_id` |
| 4 | Name edges | "The name starts with B and ends with u." | Generated at response time from the first and last Unicode letter in `locations.name` |

The English examples above translate the Czech seed values. The application displays the Czech values. The catalog has no current numbers clue or municipality-name clue: municipality population, general elevation, and actual municipality are not stored. They must not be synthesized or displayed as fallbacks. The name-edge clue uses the location name already stored in the catalog and needs no extra column.

### Compass

With the data currently available, the fourth miss and every later miss compare the guess with the target and show, for example, `13 km ↘`:

- distance, rounded to whole km (to hundreds of metres below 1 km);
- direction in 8 compass points, shown as an arrow;

Higher/lower, municipality-size, and same/different ORP comparisons are deferred. They require elevation, actual municipality population, and administrative boundary data respectively; none is stored in the current catalog.

The compass works the same in every daily round. The distance circle around a guess is **not shown** (decision: too strong a hint).

### Modes

- **Place of the day:** one independently selected place per player and Prague calendar day. It uses three catalog clues and the generated name-edge clue. The backend chooses randomly from locations the player has not successfully guessed. A new assignment becomes available after midnight even when the previous day's round was unfinished; that older round expires without revealing its target. Repeated requests during the same date return the same assignment.
- There is no daily streak.
- **Multiplayer game** (UI: „Hra s kamarády“): the players of one lobby guess the same places against one game timer and are ranked by average offset. It has no clues, no compass, no hits, and no stars. See Multiplayer rules.

### Multiplayer rules

These rules apply only to the multiplayer game. Where they differ from the rules of the place of the day, the multiplayer rule wins inside the multiplayer game.

**Lobby**

- A player creates a lobby and becomes its host. The server gives the lobby a six-character lobby code. The code alphabet leaves out the look-alike characters 0, O, 1, I, and L, and the code is not case-sensitive.
- Other players join with the lobby code or with a link that contains it. A full lobby refuses new players. A player is in at most one lobby; joining another lobby leaves the current one.
- A player may join while a game is running. They wait in the lobby and take part from the next game.
- The host changes the lobby settings (number of places, game timer, maximum number of players) within the configured limits, whenever no game is running: before the first game and between games. The maximum number of players cannot go below the current number of players. The other players see the settings but cannot change them.
- The host starts a game. Starting needs at least the minimum number of players (default 1) waiting in the lobby, including the host. The players who wait in the lobby when the game starts are its participants.
- When the host leaves, the player who has been in the lobby the longest becomes the host. An empty lobby is deleted, and so is a lobby that stays idle for the idle lobby lifetime (default 30 minutes).
- A player whose connection drops keeps their seat for the reconnect grace period (default 60 s) and gets it back when they reconnect. After that, the server removes them. A participant removed during a game keeps their row in the results, and their unguessed places count with the penalty distance.

**Game**

- All participants get the same places (default 10), in the same order. The server picks them at random from the place catalog.
- One game timer (default 300 s) runs for the whole game. Each participant moves through the places at their own pace.
- Before a guess, a participant sees only the name of the current place and its position in the game (for example 3/10). There are no clues, no compass, no category, no description, no photo, and no coordinates.
- **Recorded exception:** in the single-player modes, the client never holds the name of a place that the player has not guessed. In the multiplayer game the name is the puzzle, so the server sends the name of the current place before the guess. The client still never receives the coordinates, description, category, or data source of a place before the participant's own guess on that place.
- Each place gets exactly one guess. A guess outside the region is rejected and does not count, so the participant places it again. There is no hit radius and there are no stars.
- The server computes the offset as the haversine distance on a sphere with a radius of 6,371,008.8 m, rounded to whole metres, the same calculation as for a daily round.
- After a guess, only the participant who made it receives the offset, the true location and the place card of that place, and the name of the next place.
- During the game, the other players see only how many places each participant has guessed. They never see the guesses or offsets of others before the game ends.
- The game ends when the game timer runs out or when every participant still in the lobby has guessed every place, whichever comes first.

**Results**

- The leaderboard ranks the participants by average offset, rounded to whole metres. Each unguessed place counts with the penalty distance (default 100 km). Lower is better.
- Ties are broken, in this order, by more guesses made, by the earlier time of the last guess, and by nickname. Every participant gets a different rank.
- When the game ends, every participant sees the leaderboard and the full results: every place revealed with its place card, and every participant's guesses and offsets on every place.
- After the game, each participant returns to the lobby (the same lobby with the same code) or leaves it. The results of the last game stay available in the lobby until the next game starts.
- Multiplayer guesses are not recorded in progress or on my map, and they do not affect the place of the day. Results are not stored: they live only in the memory of the socket server and are lost when it restarts.

**Players and privacy**

- Guests and accounts can both play. A guest enters a nickname of 2–24 characters. An account plays under its account name: the client sends its access token, and the server verifies it.
- The nickname or account name is visible to the other players in the lobby. No e-mail address, account id, or location is shown to other players.
- The socket server keeps nicknames, guesses, and results only in memory, for the lifetime of the lobby. The multiplayer game writes nothing to the database.

### Visit

- Any place can be visited at any time, guessed or still in the fog, independent of the day of the puzzle.
- The visit succeeds when the device's location is within the visit radius (default 1 km) of the place. The place then changes to "visited". Visit facts and nearby tips remain planned features; the current catalog does not store them and they must not be presented as available content.
- The game uses the normal device GPS and does not check for spoofing.

### Rating

- Only an account can rate, and only a place it has visited. One rating per account and place, 1–5 whole stars; rating again replaces it.
- The average (rounded to one decimal) and the number of ratings are shown for every place, independent of the player's own status.
- Individual ratings are never shown to other players, only the average and count.
- The player sees their own rating on the place card and the list of the places they rated in their profile.

### Wafers

- Only an account earns wafers; the balance is stored on the server.
- A round hit earns **2 wafers per star** (10 for a first-attempt hit, 2 for a hit with the compass). Every hit earns them, also a later hit of a place guessed before.
- The first visit of a place earns **50 wafers**, guessed or in the fog. A repeated visit earns none.
- A miss earns none, and nothing takes wafers away.
- Spending wafers is a future feature (for example, an extra clue); until then the balance only grows.
- Wafers are separate from the points and the level, which stay as they are.

### My map

- Guessed and visited places appear with two different markers, places in the fog as gray dots. Each opens its place card.
- The card of a place in the fog shows only the name, the position, and navigation. The count of places in the fog is shown too.
- Progress per area: guessed + visited places in the area out of all playable places in the area.

### Place card

- After a round ends with a hit, the current catalog can supply the name, category, description, coordinates, primary dataset title, publisher, portal URL, licence, attribution, retrieval time, source-version timestamp, and an optional factual-reference URL.
- Photos, visit facts, and nearby tips require additional data before they can be shown reliably.
- If springs are introduced, their cards must show the applicable water-monitoring warning. The current catalog has no spring records.

### Accounts

- Playing without an account is always possible.
- Registration with e-mail, password (at least 8 characters), and nickname. The e-mail is unique.
- The player stays signed in for 30 days from their last activity.
- A forgotten password is reset through an e-mailed link that is valid for 1 hour.
- After registration or sign-in, guest progress on the device moves into the account. Merge rules:
  - place status: visited wins over guessed;
  - stars: the higher value wins;
  - ratings: not merged; guests cannot rate;
  - times: the earlier guess and visit times win;
  - place-of-the-day results: for a date that the account already has, the account's result wins.
- An unfinished round of an account can be finished on another device.
- Deleting an account removes all its data at once.

### Data and content

- The current place catalog contains 112 locations from five DATA ZÁPAD datasets. Every location has WGS 84 coordinates, a district, an ORP, a category, a description, `hint1`, and `hint2`. [DATA_SPECIFICATION.md](DATA_SPECIFICATION.md) is the authoritative source for provenance and field mapping.
- `hint1` is a short distinctive fact curated from the description. The category name is clue 2. `hint2` is generated as a distance band from the capital of the stored district. Tests reject direct category and distance duplication in `hint1`.
- The catalog does not store actual municipalities, population, general elevation, administrative boundary geometry, photos, visit facts, nearby-tip relationships, content verification, playability, or place-of-the-day eligibility. Primary dataset provenance and licences are stored for all five sources.
- All 112 rows satisfy the structural seed checks, but this is not equivalent to editorial verification or a product decision that every overlapping record should be playable.
- The catalog grows by reviewing and changing the checked-in normalized JSON and seed lookup data; the raw CSV-to-JSON transformation is not currently reproducible from repository files.

### Configuration

Easy-to-change constants:

- hit radius: default **3 km** (raised from 1 km on 2026-10-10);
- visit radius: default **1 km** (raised from 100 m to 300 m on 2026-10-10 because 100 m was too tight for castles, spa parks and imprecise phone GPS, then to 1 km the same day so that a visit also counts from the edge of a large site or from the nearest car park);
- compass activation: fourth wrong guess;
- minimum stars for a hit: 1;
- wafers: 2 per star of a hit, 50 for the first visit of a place;
- time zone: Europe/Prague;
- session lifetime: 30 days;
- password reset link lifetime: 1 hour.

Multiplayer constants, set in the environment of the socket server. The host may change the marked values per lobby, within the limits:

- maximum players per lobby: default and hard cap **8** (host may lower it);
- minimum players to start a game: **1**;
- places per game: default **10**, at most **20** (host);
- game timer: default **300 s**, from 60 s to 1,800 s (host);
- penalty distance: **100 km**;
- reconnect grace period: **60 s**;
- idle lobby lifetime: **30 minutes**.

### Content safety and privacy

- No text may encourage drinking from springs. No spring records or automated text-verification workflow currently exist.
- Every production card should show the stored primary data source and licence. If photos are introduced, every photo must separately show its author and licence; the UI must not infer those from the primary dataset metadata.
- Personal data is limited to e-mail, nickname, password hash, and progress (including ratings and the wafer balance). The game never stores the player's location, only the fact and time of a visit.

## Testing Decisions

### What makes a good test

- A test checks observable behaviour through a public interface, not internal structure. For example, "before the fourth attempt all four clues are visible", not "function X was called".
- Tests are deterministic. The clock, randomness, external services, and the catalog come from outside (fixed date, fixed seed, fakes, small test catalog).
- Tests do not repeat the implementation of a calculation. They use known pairs of points with a distance and direction checked by hand.

### Test seams

The fewer seams, the better. The proposed seams, from the highest:

1. **Game API** – the main seam. All game rules, accounts, and account progress in this document are tested through the backend's HTTP interface. See [BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md).
2. **Client progress store** – guest progress, resuming a round, derived counts, and the switch from guest to account. See [FRONTEND_SPECIFICATION.md](FRONTEND_SPECIFICATION.md).
3. **Data import** – the resulting catalog from small fixtures. See [BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md).
4. **Multiplayer** – the lobby and game rules in this document (lobby lifecycle, host change, game timer, guesses, offsets, ranking, and what each player may see) are tested on the socket server's game logic with an injected clock and an injected place source, apart from the WebSocket transport. The client's multiplayer state is tested over a fake connection with an injected clock. See [BACKEND_SPECIFICATION.md](BACKEND_SPECIFICATION.md) and [FRONTEND_SPECIFICATION.md](FRONTEND_SPECIFICATION.md).

At the hackathon, the screens, map, sharing, and GPS are checked by hand on a phone. Automated end-to-end tests are out of scope.

### Current test baseline

The repository contains catalog tests plus focused round tests for coordinate validation, delayed compass feedback, clue unlocking, target secrecy, scoring, unlimited attempts, progress updates, and expired-round rejection. Full HTTP and isolated-database integration coverage is still required.

## Out of Scope

- Sign-in through third parties (Google, Apple, Facebook, and others).
- E-mail address verification at registration.
- Global or persistent leaderboards, rankings across games, and any comparison of players outside a multiplayer game. The leaderboard of a single multiplayer game is in scope (see Multiplayer rules).
- Stored multiplayer results, match history, and more than one socket server process.
- Protection against cheating in the multiplayer game, for example looking a place up in another map during the game.
- Daily streaks and penalties for a missed day.
- Protection against GPS spoofing and cheating while guessing.
- The distance circle around a guess.
- Different hit or visit radii by place type or by building density (for now, one constant per radius).
- Automatic generation of distinctive-fact prose. The distance clue is generated from coordinates; prose still requires editorial preparation and review.
- Counting the total number of places and planning how long the place of the day lasts. The catalog grows over time.
- An offline mode.
- Languages other than Czech.
- An admin interface for content or user management (content is edited in files).

## Further Notes

- **Tuning the radii:** 3 km for a hit is an estimate. In towns with densely packed places, it can be too large. 1 km for a visit may still be not enough for large sites (golf courses, ski resorts). For this reason, both radii are configurable. After the first play on real data, consider per-place radius overrides.
- **Facts in the design:** examples outside the checked-in catalog are illustrative. The current seed has no verification metadata, so public use still needs editorial review.
- **Licences:** all five primary DATA ZÁPAD sources now have verified publisher, canonical URL, licence URL, attribution text, portal item ID, source-version timestamp, and file retrieval timestamp. These fields do not cover the separate public pages used to fact-check descriptions or any future photos.
- **Personal data (GDPR):** accounts make the game process personal data (e-mail, nickname, progress). Before public launch, the operator must publish a privacy notice and name the data controller.
