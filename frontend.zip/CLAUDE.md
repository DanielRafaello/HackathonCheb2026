# CLAUDE.md

This file guides Claude Code in this repository.

## Project

Flutter client for „Kde na západě“, a daily map-guessing game over the Karlovy Vary Region. One codebase targets Android, iOS, and the web. The backend is a separate repository at `../backend`. The multiplayer game talks to a separate socket server (Node.js, `../backend/multiplayer/`) over a WebSocket. `lib/` so far holds only the map (`lib/map/`) and its configuration (`lib/config/`).

## Specifications come first

The specifications in `docs/` are the source of truth. Read the relevant one before you design or change a feature.

- `docs/PRODUCT_SPECIFICATION.md` wins every conflict. Change it first, then the others.
- `docs/FRONTEND_SPECIFICATION.md` covers this repository.
- `docs/BACKEND_SPECIFICATION.md` section 4 defines the Game API that this client calls. Section 5 describes the multiplayer socket server; its message protocol is in `../backend/docs/API_SPECIFICATION.md` section 7.
- `docs/DATA_SPECIFICATION.md` covers data sources and attribution texts.

The backend repository holds identical copies in `../backend/docs/`. When you edit a specification, edit both copies and keep them identical.

Open decisions are marked `TODO(frontend)` and `TODO(backend)`. To list the frontend ones, run `grep -n "TODO(frontend)" docs/*.md`. Don't settle an open decision silently. Ask, or record the decision in the specification in the same change.

## Rules the code must keep

These rules come from the product and frontend specifications. Breaking one breaks the game.

- The client never decides whether a guess is a hit. The backend evaluates every guess. In the multiplayer game, the socket server computes every offset and the leaderboard.
- The client never holds the target of an unfinished round. The round token is opaque.
  - Recorded exception: in the multiplayer game, the client receives the name of the current place before the guess (`docs/PRODUCT_SPECIFICATION.md`, Multiplayer rules). It still never holds the coordinates, description, category, or source of a place before the player's own guess on it.
- My map shows places in the fog as gray dots, and their place card shows the name, position and navigation, so that the player can browse the region and visit a place before guessing it. Texts and facts of a place in the fog are not shown. "In the fog" = total − guessed − visited.
- A revealed or skipped place is not recorded in progress. Multiplayer guesses are not recorded in progress either.
- The share text never contains the place name or location.
- The client sends the visit position to the backend and never stores it.
- The app asks for "while in use" location permission only when the player starts a visit, never at start-up.
- No text may encourage drinking from springs. A spring's card always shows the "not hygienically monitored" warning.
- The map always shows "© OpenStreetMap contributors". Every place card shows the data source and the licence.
- Game constants (hit radius, visit radius, attempts, time zone, lifetimes) come from configuration, never from literals in widgets. Multiplayer limits and defaults (players, places, game timer, penalty distance) come from the server's `welcome` message.

## Platforms

Every platform-specific feature needs a web variant: location, sharing, storage, sessions, and deep links.

- **Mobile sessions:** store the JWT in secure storage. Send it as `Authorization: Bearer <JWT>`. Replace it when the backend issues a fresh one.
- **Web sessions:** the backend sets an HttpOnly cookie. The web app never reads or stores the JWT. It sends requests with credentials.
- **Storage:** wrap local storage access so that the app still works when storage fails, for example in a private browser window.
- **Location on the web:** works only over HTTPS.
- **Multiplayer socket:** `web_socket_channel` on every platform. The URL comes from the dart-define `MULTIPLAYER_URL` (`lib/config/multiplayer_config.dart`; `config/local.json` sets `ws://localhost:8090/ws`). Production uses `wss://aether217.zcu.cz/ws`, because the web app is served over HTTPS. Reconnect with the `resumeToken`; keep it in memory or in wrapped storage, per browser tab on the web (`docs/FRONTEND_SPECIFICATION.md` §10.2).

## Client progress store

The store is the only automated test seam in this repository. Keep one interface for the UI with two implementations:

- the guest implementation, backed by local storage;
- the account implementation, backed by the Game API.

After registration or sign-in, the store uploads guest progress for merge, clears local progress on success, and switches to the account implementation. Sign-out and a rejected JWT switch to an empty guest store. The full contract is in `docs/FRONTEND_SPECIFICATION.md` section 7.

## Language and naming

- All UI text is Czech. Code, comments, docs, and commit messages are English.
- Use the glossary terms in `docs/PRODUCT_SPECIFICATION.md` for names in code: place, round, guess, hit, clue, compass, place of the day, free play, visit, fact, nearby tips, area, my map, account, guest, progress, multiplayer game, lobby, lobby code, host, participant, game timer, offset, average offset, penalty distance, leaderboard. Write `Guess`, not `Tip` or `Attempt`. Write `Clue`, not `Hint`.

## Design system

The app UI follows the design system in `design-system/`:

- `design-system/DESIGN.md`: rules, colors, typography, layout, illustrations. Read it before you work on the UI.
- `design-system/components.md`: components with sizes, variants, and states.
- `design-system/copy.md`: how to write Czech texts in the app.
- `design-system/tokens.json` (source of truth) and `design-system/tokens.css` (`--knz-*` variables).
- `design-system/assets/`: the Vřídlík mascot, the region map, markers, icons (SVG).

Rules: no hex colors or sizes written directly, only tokens. Color carries the game state (blue action/guessed, gold stars/visited, red guess/compass, turquoise "Luštit dál", green hit). Buttons and cards have a 3D bottom edge. Typeface is Nunito 700–900 only. Texts are Czech, informal "tykání", button labels in CAPITAL LETTERS. The detailed procedure is in the `kde-na-zapade-ui` skill.

## Commands

```sh
flutter pub get        # install dependencies
flutter analyze        # lints from package:flutter_lints
flutter test           # run all tests
flutter test test/<file>_test.dart   # run one test file
flutter run -d chrome  # run the web app
flutter run -d <device-id>           # run on a device; list devices with `flutter devices`
flutter run -d chrome --dart-define-from-file=config/local.json   # local backend and socket server
```

The local socket server runs from the backend repository: `docker compose up multiplayer` in `../backend` serves `ws://localhost:8090/ws`.

Run `flutter analyze` and `flutter test` before you commit.

## Tests

- Test the client progress store with `flutter_test` through its public interface, over fake storage and a fake API. Cover the cases listed in `docs/FRONTEND_SPECIFICATION.md` section 9.
- Test observable behaviour, not internal calls. Keep tests deterministic: inject the clock, randomness, storage, and the API.
- Widget tests are optional. Integration and end-to-end tests are out of scope.
- The map, sharing, location, sessions, and deep links are checked by hand on devices.

## Out of scope

Don't build these without a change to the product specification: third-party sign-in, e-mail verification, global or persistent leaderboards (the leaderboard of one multiplayer game is in scope), daily streaks, the distance circle around a guess, an offline mode, languages other than Czech, and an admin interface.
