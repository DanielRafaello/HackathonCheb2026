package com.example.kde_na_zapade

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
