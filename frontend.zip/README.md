# Kde na západě – frontend

„Kde na západě“ is a daily puzzle over a map of the Karlovy Vary Region. The game picks a real place from the region's open data on [datazapad.cz](https://www.datazapad.cz) and gives the player a clue. The player places a pin on the map. A miss unlocks the next clue and a compass that compares the guess with the target. A hit within 1 km earns stars and a place card, and the place goes onto the player's personal map. When the player later stands within 100 m of a guessed place, the place changes to "visited" and unlocks extra facts.

This repository holds the Flutter client for Android, iOS, and the web. The backend lives in a separate repository. It holds the place catalog and evaluates every guess, so the client never knows the target of an unfinished round.

The game UI is in Czech.

## Status

The project is at the hackathon stage. The app shows the map of the region. No game code exists yet.

The mobile apps run as development builds only. Web hosting is not decided yet.

## Documentation

The specifications in `docs/` define the product. Read them before you change behaviour.

| Document | Content |
|----------|---------|
| [Product specification](docs/PRODUCT_SPECIFICATION.md) | Glossary, game rules, user stories, configuration values, and scope. This document wins every conflict. |
| [Frontend specification](docs/FRONTEND_SPECIFICATION.md) | Technology, map, sharing, geolocation, sessions, the client progress store, and frontend tests. |
| [Backend specification](docs/BACKEND_SPECIFICATION.md) | Backend modules and the Game API that this client calls. |
| [Data specification](docs/DATA_SPECIFICATION.md) | Data sources, the import, and attribution texts. |

The same four files exist in the backend repository. Change them in both places.

## Technology

- [Flutter](https://flutter.dev), one codebase for Android, iOS, and the web.
- MapLibre GL with vector tiles from OpenStreetMap data.
- `flutter_test` for automated tests.

Supported platforms are Android 15 (API level 35) and newer, iOS 18 and newer, and current versions of Chrome, Safari, Firefox, and Edge back to October 2024 (Safari 18).

## Run the app

You need the Flutter SDK on the stable channel, with Dart 3.13.5 or newer. For the mobile apps, you also need Android Studio or Xcode.

1. Install the dependencies:

	```sh
	flutter pub get
	```

2. List the available devices:

	```sh
	flutter devices
	```

3. Start the app on a device:

	```sh
	flutter run -d <device-id>
	```

	To start the web version in Chrome, use `flutter run -d chrome`.

A debug build (`flutter run`) calls the local backend; a release build calls the deployed one (`https://aether217.zcu.cz/api`). To pick a backend yourself, pass `--dart-define=API_BASE_URL=<url>`. The multiplayer game connects to its own socket server, picked the same way with `--dart-define=MULTIPLAYER_URL=<url>` (local `ws://localhost:8090/ws`, deployed `wss://aether217.zcu.cz/ws`).

## Run against a local backend

1. Start the backend from the sibling repository `../backend`. The API runs on `http://localhost:8080`, with no `/api` prefix:

	```sh
	cd ../backend
	docker compose up -d --build
	docker exec app_backend composer migrate -- --no-interaction
	```

2. Start the app in debug mode. It calls `http://localhost:8080`, or `http://10.0.2.2:8080` on Android, which is the host machine as the emulator sees it.

	| Target | Command |
	|--------|---------|
	| Web | `flutter run -d chrome` |
	| iOS simulator, Android emulator, desktop | `flutter run -d <device-id>` |
	| Android phone over USB | `adb reverse tcp:8080 tcp:8080` and `adb reverse tcp:8090 tcp:8090` (the multiplayer socket server), then `flutter run -d <device-id> --dart-define-from-file=config/local.json` |

	The web app runs on `http://localhost:5173` (`web_dev_config.yaml`), because the backend allows exactly one CORS origin, `FRONTEND_URL`, which is `http://localhost:5173` in `../backend/.env.development`. A `--web-port` flag overrides the file and then fails with a CORS error. To use another port, change both `web_dev_config.yaml` and `FRONTEND_URL` in a gitignored `../backend/.env`.

	To try a debug build against the deployed backend, pass `--dart-define=API_BASE_URL=https://aether217.zcu.cz/api --dart-define=MULTIPLAYER_URL=wss://aether217.zcu.cz/ws`.

## Map tiles

The map renders the region's own tile set, a PMTiles archive that `tools/map` builds from OpenStreetMap data (see [tools/map/README.md](tools/map/README.md)). The app bundles the archive as the asset `assets/map/kvk.pmtiles`, so `flutter run` needs no tile server on any platform.

To change the map data, build the tiles again and copy the archive into the app:

```sh
tools/map/build_tiles.sh ~/Downloads/czech-republic-latest.osm.pbf build/map
cp build/map/kvk.pmtiles assets/map/kvk.pmtiles
```

Commit the archive together with the style changes that need it. `flutter test` fails when the bundled archive does not hold exactly the layers that the style draws. When the build stops at step 5 because the local tilemaker binary crashes, run it with `TILEMAKER=podman`.

Map labels load their fonts from the URL template in `MAP_GLYPHS_URL`; the default is the public OpenMapTiles font server.

The app needs a running backend. The backend URL setting is not defined yet.

## Check the code

```sh
flutter analyze
flutter test
```

Automated tests cover the client progress store. The map, sharing, location, sessions, and deep links are checked by hand on an Android phone, an iOS phone, and a mobile browser.

## Data and licences

Place data comes from datazapad.cz under CC0 or CC BY. Map data is © OpenStreetMap contributors under the ODbL. The map always shows this attribution, and every place card shows the data source and the licence.
