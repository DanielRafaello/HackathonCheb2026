# Text in the app

The whole app is in Czech. This guide is written in English; every quoted string is the actual Czech UI text. These rules apply to every new text.

## Tone

- **Use informal address (tykání).** "Najdeš ho?", "Přihlas se", "Tvůj tip", "Navštiv ho naživo".
- **Playful, short, no blame.** A failure never sounds like the player's mistake: "Tentokrát to nevyšlo. Nevadí, o půlnoci tu bude nové místo."
- **No pressure to visit daily.** The game has no streak. Don't write "Neztrať sérii", "Nezapomeň dnes hrát", or similar.
- **Vřídlík speaks in the first person, only in the bubble.** The rest of the UI is factual.
- Celebrations are short and concrete: "Trefa na 2. pokus!", "Jsi tady!".

## Text shapes

| Element | Shape | Examples |
|---|---|---|
| Button | CAPITAL LETTERS, an infinitive or a noun, 1–3 words | POTVRDIT TIP, TIPNOUT NA MAPĚ, HRÁT MÍSTO DNE, TIPNOUT ZNOVU, POKRAČOVAT, SDÍLET, PŘESKOČIT, LUŠTIT DÁL, ZPĚT DOMŮ, JSEM TU!, NAVIGOVAT NA MÍSTO, PŘIHLÁSIT SE, ZKUSIT BEZ ÚČTU |
| Overline, label | CAPITAL LETTERS, parts separated by " · " | MÍSTO DNE · POKUS 3, KLÍČ 2 · TYP MÍSTA, UHODNUTO · 4 HVĚZDY |
| Heading | A sentence, first letter capital, exclamation mark only for results | Kde to je?, Moje mapa, Vedle! Kompas ti poradí. |
| Caption, hint | A full sentence with a period, addressing the player as "ty" | Posuň špendlík tažením, mapu přiblížíš dvěma prsty. |
| Navigation | CAPITAL LETTERS, one word | DNES, MINIHRY, PROFIL |
| Link in text | A sentence, no period | Zapomenuté heslo?, Zaregistruj se |

## Czech typography

- Use a no-break space (U+00A0) after one-letter prepositions and conjunctions (v, k, s, z, o, u, a, i) and between a number and its unit: `14 km`, `550 m`, `100 m`.
- Decimal comma: `1,4 km`. Thousands separated by a space: `1 000`. Format with `Intl.NumberFormat('cs-CZ')`.
- Date: `9. 10.`, with the weekday `ČT 9. 10.` (in an overline). Use `Intl.DateTimeFormat('cs-CZ')`.
- Fractions of guesses and clues with spaces: `2 / 5`. Counts in an area: `9 ze 148`.
- Quotation marks „like this“, an en dash in a range `500–600 m n. m.`, three dots as one character `…`.
- Don't separate the " · " separator from the preceding word (a no-break space before the dot).

## Declension

Always use `Intl.PluralRules('cs')` (categories `one`, `few`, `many`, `other`):

| Word | 1 | 2–4 | 5+ / 0 |
|---|---|---|---|
| místo (place) | místo | místa | míst |
| hvězda (star) | hvězda | hvězdy | hvězd |
| pokus (guess) | pokus | pokusy | pokusů |
| klíč (clue) | klíč | klíče | klíčů |
| zajímavost (fact) | zajímavost | zajímavosti | zajímavostí |

Mind the gender in verb forms: "Odemkl jsi 3 zajímavosti" reveals a gender. If you don't want to deal with the player's gender, write neutrally: "Odemčené zajímavosti: 3" or "Máš odemčené 3 zajímavosti".

## Vocabulary

Use the Czech terms in the UI. The code uses the English glossary terms from `docs/PRODUCT_SPECIFICATION.md`.

| Use (Czech) | Don't use | Code term | Meaning |
|---|---|---|---|
| Místo dne | denní výzva | place of the day | one place per day, the same for everyone |
| Luštit dál | volná hra, nekonečný režim | free play | further places without limit |
| Mapa | moje mapa, sbírka | my map | the tab with every place in the region and the player's progress (**changed**: my map was on PROFIL) |
| Profil | účet | profile | the screen with the account, the level, the badges, and sign-out |
| odznak | achievement, trofej | badge | a goal reached by guessing or visiting places (**added**) |
| klíč | nápověda, hint | clue | one hint for a place (Riddle, Place type, Numbers, Surroundings, Almost revealed) |
| kompas | — | compass | comparing the guess with the target after a wrong guess |
| tip, špendlík | odhad, pin | guess | the player's guess on the map |
| trefa | správně, výhra | hit | a guess within the set distance |
| uhodnuto / navštíveno | vyřešeno / check-in | guessed / visited | place states |
| v mlze | zamčené, skryté | in the fog | places the player does not know yet |
| zajímavosti | odměny | facts | content unlocked by a live visit |
| Tipy poblíž | doporučení | nearby tips | spring, swimming, "Když prší" |
| ORP, obec | okres | — | the administrative district in the compass |
| Chebsko, Sokolovsko, Karlovarsko | — | area | areas in progress |

## Required texts

- **Springs:** every spring carries the sentence "Voda není hygienicky sledovaná." Never encourage drinking.
- **Data source:** every place card states the source and the licence, for example "datazapad.cz · CC BY" or "Zdroj dat: datazapad.cz, Národní kulturní památky · licence CC BY".
- **Unverified facts:** the place texts and place counts in the design are illustrative. Only verified texts from the game content belong in the app.
- Write a value missing from the design or a prototype as `[název]`. Never invent it.

## Accessibility of text

- Icon buttons: an `aria-label` with a verb or a target ("Zavřít", "Zpět na mapu", "Přiblížit", "Zobrazit heslo").
- Graphic indicators have text: "Pokus 1 z 5", "4 z 5 hvězd", "Mapa: 28 míst".
- The map has a state description: "Mapa kraje: trefa u Bečova nad Teplou".
