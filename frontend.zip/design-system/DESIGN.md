# Kde na západě: design system

A playful mobile game about guessing places in the Karlovy Vary Region. The look is inspired by Duolingo (not its mechanics): rounded bold type, solid colors, "3D" buttons and cards with a bottom edge, and a mascot that guides the player. The colors come from the region: regional blue, spa gold, Cheb red, the Vřídlo spring, and the Slavkovský les forest.

Source of truth: the "Kde na západě – mobilní app" canvas (10 screens + a style board). The values in this directory are taken from it 1:1. Anything the design lacked and was added later is marked **(added)**.

All UI text stays Czech (see `copy.md`). Czech strings in this directory are quoted as UI text; the descriptions around them are English.

## Files

| File | Contents |
|---|---|
| `tokens.json` | All tokens in the W3C Design Tokens (DTCG) format. Source of truth for colors, type, spacing, radii, edges, and sizes. |
| `tokens.css` | The same tokens as CSS variables with the `--knz-` prefix, plus the helper classes `.knz-text-*`. |
| `components.md` | Component inventory: anatomy, sizes, variants, states. |
| `copy.md` | How to write the Czech UI text: tone, text shapes, typography, declension, vocabulary. |
| `assets/mascot/` | Vřídlík in five moods (SVG). |
| `assets/map/` | The illustrated region map, the region outline, and the map markers (SVG). |
| `assets/icons/` | 31 icons, 24×24 (stroke icons use `currentColor`). |

## Core rules

1. **Never write a hex value directly.** Use semantic tokens (`--knz-primary`, `--knz-text-muted`, …). Use primitive tokens (`--knz-blue-500`) only where no semantic token exists, typically in illustrations.
2. **One color = one meaning.** Colors carry the game state, not decoration:
   - **blue** `primary`: the main action, place of the day, *guessed*,
   - **gold** `accent`: stars, clues, *visited*, the Play button,
   - **red** `danger`: the player's guess, the pin, the compass, a wrong guess,
   - **turquoise** `explore`: the free play mode, water, the mascot,
   - **green** `success`: a hit.
3. **3D edge.** Colored and tappable surfaces have a `border-bottom` in a darker shade (`*-edge`): buttons 5 px, cards 4–5 px, large surfaces 6 px. White cards have a 2 px `--knz-border` frame and a 4–5 px bottom edge in the same color. Blurred shadows (`box-shadow` with blur) are not used.
4. **Typeface is Nunito only**, weights 700–900. Text is bold even in the body (700). Buttons, labels, and section headings are in CAPITAL LETTERS with letter spacing. The type roles are in `tokens.css` (`.knz-text-title-md` etc.).
5. **Rounding is generous:** button 16, card 20, map 22, hero 24, chips pill. Nothing has sharp corners.
6. **White background, colored blocks.** The screen is white (`--knz-surface`). Color comes in solid blocks (hero card, header, bottom panel) and in tints (`*-tint`).
7. **Text on color:** white on blue, red, and green; always ink (`--knz-text`) or `gold-900` on gold. The green button uses the background `success-strong` (#2A8443), not `success`, for contrast. Turquoise text is `explore-text` (#0F6E79), never `explore`.
8. **The mascot speaks, the UI does not.** Encouragement, losses, and explanations belong in Vřídlík's speech bubble. All other text is factual.
9. **Accessibility is part of the design:** touch target ≥ 44 px, icon buttons have an `aria-label`, ratings and guesses have a text description ("4 z 5 hvězd", "Pokus 1 z 5"), decorative SVGs are `aria-hidden`. State is never distinguished by color alone (guessed = blue dot, visited = gold flag, in the fog = gray dot).
10. **Respect `prefers-reduced-motion`** **(added)**: animations (button press, confetti, mascot bounce) are turned off.

## Colors

The full palette is in `tokens.json`. The most common semantic tokens:

| Token | Value | Use |
|---|---|---|
| `--knz-text` | #1E2A46 | main text (Ink) |
| `--knz-text-secondary` | #46506A | descriptions, form labels |
| `--knz-text-muted` | #5A6580 | captions, section headings, inactive navigation |
| `--knz-text-disabled` | #6B7690 | inactive button |
| `--knz-surface` | #FFFFFF | screen and card background |
| `--knz-surface-subtle` | #F2F5F9 | locked clues, info rows, chips |
| `--knz-border` | #E2E7EF | frame of cards, bubbles, navigation |
| `--knz-border-strong` | #D3DAE5 | frame of buttons, inputs, map |
| `--knz-primary` / `-edge` / `-tint` | #2B59C3 / #1D3F91 / #E6EEFC | Regional blue |
| `--knz-accent` / `-edge` / `-text` / `-tint` | #FFC531 / #E0A100 / #B98200 / #FFF8E1 | Spa gold |
| `--knz-danger` / `-edge` / `-tint` / `-soft` | #D63B2C / #A62A1D / #FFEDEA / #F08A7E | Cheb red |
| `--knz-explore` / `-edge` / `-text` / `-tint` | #1FB2C1 / #148A97 / #0F6E79 / #DDF5F7 | Vřídlo |
| `--knz-success` / `-strong` / `-edge` / `-text` | #3BAA57 / #2A8443 / #1D6331 / #23803D | Slavkovský les |

Place states: `state-guessed` (blue), `state-visited` (gold), `state-unknown` (gray #9AA4B8), `state-tip` (red), `state-hit` (green).

Areas on My map: Chebsko = blue, Sokolovsko = turquoise, Karlovarsko = gold (`gold-600` for the progress bar).

**Dark mode** is not in the design. If you want it, add a set of semantic tokens under `@media (prefers-color-scheme: dark)`. The components do not change because they use semantic variables only.

## Typography

Nunito 600–900 from Google Fonts (`tokens.css` imports it; in the native app, bundle it as a file). Fallback font: `'Varela Round', system-ui, sans-serif`.

| Role | Size / weight / line height | Example |
|---|---|---|
| display | 32 / 900 / 1.1, −0.5 px | Trefa na 2. pokus! |
| title-xl | 28 / 900 / 1.15 | Kde to je? |
| title-lg | 25 / 900 / 1.15 | Hrad a zámek Bečov nad Teplou |
| title-md | 22 / 900 / 1.2 | Vedle! Kompas ti poradí. |
| title-sm | 18 / 900 / 1.2 | Tipy poblíž |
| card-title | 17 / 900 | Luštit dál (list row) |
| clue | 19 / 800 / 1.3 | clue text |
| body-lg | 16 / 800 / 1.35 | mascot bubble |
| body | 15 / 700 / 1.4 | regular text |
| body-sm | 14 / 700 / 1.4 | captions |
| caption | 13 / 800 | chips, legend |
| micro | 12 / 800 | footnotes, data source |
| overline | 13 / 900, 1.2 px, CAPS | MÍSTO DNE · POKUS 1 Z 5 |
| label | 12 / 900, 1 px, CAPS | KLÍČ 1 · HÁDANKA |
| badge | 11 / 900, 0.6 px, CAPS | NOVĚ ODEMČENO |
| button | 17 / 900, 1 px, CAPS | POTVRDIT TIP |
| button-sm | 15 / 900, 1 px, CAPS | SDÍLET |
| nav | 12 / 900, 0.4 px, CAPS | PROFIL |

## Layout

- The design is for a 390 × 844 phone. Screen margin 20 px (sign-in 24 px).
- Spacing comes from the scale 4 · 6 · 8 · 10 · 12 · 14 · 16 · 20 · 24. Between cards on a screen 12–14 px, inside a card 8–12 px.
- Game screen structure: top bar (close, guesses, stars) → content → footer with the main action (padding 14 / 20 / 28).
- Main screen structure: header → content → bottom navigation (DNES · MINIHRY · MAPA · PROFIL).
- The main action is always at the bottom, full width, 54 px high.
- Colored headers (sign-in, On the spot) have bottom corners of 32–36 px and a 6 px bottom edge. The bottom panel (compass) has top corners of 30 px.

## Illustrations

- **Flat style without outlines or gradients.** Shapes in solid colors, layered from light to dark within one color family (a landscape on blue: #3D69D2, #5A84E4, #7AA0F0, silhouettes #244CA8). Clouds are white ellipses with 0.92 opacity.
- **Region motifs:** the colonnade and spa houses, a castle, the Ore Mountains (Krušné hory), conifers, the Ohře river, fog (= an unknown place).
- **Vřídlík** (`assets/mascot/`) is a drop from the Vřídlo spring. Moods: `wave` (hello, home, sign-in), `think` (while guessing), `cheer` (hit, visit), `sad` (failed), `happy` (default). Sizes in the design: 72, 84, 88, 96, 110, 112, 120 px wide; height = width × 7/6. Never distort or recolor the mascot.
- **Mascot motion (added).** Vřídlík moves by its mood; the SVGs stay the only drawing (`lib/design_system/mascot_motion.dart` cuts them into parts: arms, eyes, pupils, steam, tear, hand, thought bubbles). Every mood breathes, blinks at uneven intervals, and lets its steam sway. On top: `wave` waves three times every 3.6 s and leans into it; `happy` wiggles every 4.8 s; `cheer` hops three times with squash and stretch while the shadow shrinks, then rests; `think` looks up to the side, taps its chin, and the thought bubbles pop in and float; `sad` sighs every 5 s with drooping arms while a tear keeps rolling. Except `cheer`, which starts hopping, each mood lands with a short drop wobble when it appears. The app draws each part from an image rendered once and moves at 30 frames per second, which is enough for these slow moves and keeps mobile browsers responsive. With reduced motion, the mascot stands still as drawn.
- **Round motion (added).** The round moves one thing at a time, with the `motion` tokens (`duration-slow` per step, `ease-out` for things that enter and leave, `ease-in-out` for things that change size). After a miss, the full-screen map slides away, the clues and the TIPNOUT NA MAPĚ button fold away, the miss panel rises like a sheet, and then the clue or compass the guess unlocked pops in (fade, a 12 px rise, a slight `ease-bounce` scale). The clues keep the round from before the guess until the panel is up, so the panel is the first to show the new clue. On TIPNOUT ZNOVU the panel sinks, the clues unfold, and the new clue rises into its place. Between round phases (loading, playing, hit) the screens cross-fade. With reduced motion, every step is instant.
- **Region map** (`assets/map/region-base.svg`, viewBox 400×300) is illustrated, not geographic: outline, Ohře and Teplá rivers, forests, Krušné hory, Slavkovský les, Doupovské hory, six towns. It has six states (blank, pin, compass, hit, reveal, my map); see `components.md`. Real play needs a real map layer; use the illustrated map for previews and cards.
- Icons: stroke, 24×24, stroke width 2.4 (2.6–3.2 for small and emphasized ones), round caps. No emoji.

## What the design lacks (and how to proceed)

- Pressed, hover, and focus states of buttons are added in `components.md` following the convention of 3D buttons.
- Form error states, empty states, loading, registration, and onboarding are not designed. Build them from existing components and tokens, with the mascot in a bubble.
- The place texts and place counts on the canvas are illustrative. Don't use them as data.
