# Components

Dimensions are in px at a screen width of 390. Colors are given as tokens (the `--knz-` prefix is omitted). The screen from the canvas where the component appears is in parentheses. **(added)** = not in the design, derived.

The component names are proposed code names (English, PascalCase). The Czech names in parentheses match the canvas. Quoted strings are Czech UI text.

---

## Basic elements

### Button (tlačítko)
A 3D button with a bottom edge. Everything in CAPITAL LETTERS, role `button` (17 px) or `button-sm` (15 px).

| Variant | Background | Bottom edge 5 px | Text | Where |
|---|---|---|---|---|
| `primary` | primary | primary-edge | white | POTVRDIT TIP, PŘIHLÁSIT SE, LUŠTIT DÁL |
| `accent` | accent | accent-edge | text (ink) | HRÁT MÍSTO DNE |
| `danger` | danger | danger-edge | white | TIPNOUT ZNOVU |
| `success` | success-strong | success-edge | white | POKRAČOVAT |
| `secondary` | surface, 2 px border-strong frame (5 px at the bottom) | — | primary, or text-secondary for neutral actions | SDÍLET, PŘESKOČIT, Google, Apple |
| `ghost` | none | — | primary (or explore-text) | ZPĚT DOMŮ, ZKUSIT BEZ ÚČTU |

- Height: 54 (main action in the footer), 52 (regular), 50 (social sign-in), 40–44 (`ghost`).
- Radius `radius-lg` (16). A 20 px icon to the left of the text, gap 8.
- **States:**
  - *disabled*: background surface-disabled, edge border-strong, text text-disabled, the `disabled` attribute (Luštit dál, until the player places a pin).
  - *pressed* **(added)**: `transform: translateY(3px)`, bottom edge 2 px. The total height stays, so nothing shifts. Transition `duration-fast`.
  - *focus-visible* **(added)**: `box-shadow: shadow-focus` (4 px ring of blue-100).
  - *hover* **(added, web only)**: background 4 % lighter (`filter: brightness(1.04)`).
- Two actions side by side: a 2-column grid, gap 10 (Hit: SDÍLET + POKRAČOVAT). Secondary on the left. Luštit dál: ratio 1 : 1.6.
- *compact* **(added)**: two long labels side by side (Place card: NAVIGOVAT + JSEM TU!, ratio 4 : 5) use the `button-sm` role and 12 px side padding at the regular height; on a narrow phone the label scales down to fit instead of being cut off.

### IconButton
A 44×44 touch target, icon 24–26 px. Close (`close`, color icon-subtle), Back (`back`, icon-muted). On an illustration: a white square with radius 14, `shadow-raised-md`, icon in the text color (Place card). Always has an `aria-label` ("Zavřít", "Zpět", "Zpět na mapu").

### TextField (pole formuláře) (Sign-in)
- Label above the field: role `caption` weight 900, color text-secondary, gap 5.
- Field: height 50, padding 0 14, 2 px border-strong frame, radius `md` (14), background surface-input, text 16/700.
- Placeholder: text-placeholder.
- *focus*: frame primary, background surface, `shadow-focus`.
- *error* **(added)**: frame danger; below the field a 13/800 text in danger-edge with the `info` icon.
- Password: an `eye` icon button on the right inside the field (44×44, `aria-label="Zobrazit heslo"`), right padding 52.
- A link next to the label ("Zapomenuté heslo?"): 13/800 primary.

### Divider "NEBO"
Two 2 px border lines around the text NEBO (13/900, 1 px letter spacing, text-disabled), gap 12.

### Pill / Chip
- **Place type label**: background primary-tint, text blue-700, role `badge`, padding 2–3 × 8–9, pill. ("NÁRODNÍ KULTURNÍ PAMÁTKA")
- **Status label**: UHODNUTO · 4 HVĚZDY (background primary, white text 13/900, icon `done`); NAVŠTÍVENO (background text/ink, white text 12/900, gold star).
- **Chip on a colored surface**: background primary-edge, white text 13/800, padding 5 × 10 ("5 klíčů", "5 pokusů", "až 5 hvězd").
- **Mode chip**: explore-tint, text explore-text 14/900, icon `done` ("dnes navíc 3").
- **Info chip**: surface-subtle, text-secondary 13/800, radius 12, 16 px icon text-muted ("31 km od tebe", "uhodnuto 9. 10.").
- **NOVĚ ODEMČENO**: background accent, ink text, role `badge`.

### WaferPill (oplatky) **(added)**
The game's currency, wafers (oplatky): a pill on accent-tint with a 2 px accent frame, padding 6 14 6 8, the `wafer` icon 24 px (coloured: a gold-200 spa wafer with a gold-700 rim and a gold-600 grid) and the amount 16/900 gold-900. The balance reads "112 oplatek" (`aria-label="Máš 112 oplatek"`); what a hit or a visit just earned reads "+10 oplatek" (`aria-label="Získáváš 10 oplatek"`). Plural: 1 oplatka, 2–4 oplatky, 5+ oplatek. Used on the Hit screen under the StarRating, at the top of the On the spot result, and in the profile next to "Oplatky dostáváš za trefy a ještě víc za návštěvy míst." (body-sm text-muted) under the level card. Shown only when the backend sent the amount and it is above 0.

### Toast (oznámení) **(added)**
A short factual message, for example a failed load: floating at the bottom, 20 px from the sides, 12 px above the navigation; background text (ink), white text 14/800, radius 14, no shadow. One at a time; a new one replaces the old. No mascot: errors in a toast stay factual.

### SegmentedControl (přepínač) (My map)
Container track (#EEF1F6), radius 14, padding 4, one equal column per option (My map has 4: Vše · Neobjevené · Uhodnuté · Navštívené). Segment height 36, radius 11. Active: surface, `shadow-raised-sm`, text 14/900 text. Inactive: transparent, 14/800 text-muted. `role="group"`, buttons with `aria-pressed`.

### ProgressBar (postup oblasti)
Track, height 10 (Home) or 12 (My map), pill. The fill is in the area's color with `min-width: 14px`, so even small progress is visible. Row: name 15/800 · track · "9 ze 148" 13/800 text-muted (grid 96 / 1fr / 64).

---

## Game components

### GameTopBar (horní lišta kola) (Place of the day, Compass, Failed)
A row: IconButton Close (margin-left −10) · AttemptProgress (flex 1) · StarCounter. Padding 18 20 8, gap 14.
- *full-screen map* **(added)**: IconButton `back` "Zpět na klíče" instead of Close.
- *multiplayer* **(added)**: Close ("Odejít ze hry") · a ProgressBar of the places guessed (`aria-label` "Uhodnutá místa: 3 z 10") with a "3 / 10" caption 13/800 text-muted · a CountdownPill instead of the StarCounter. On the full-screen map: `back` "Zpět na místo".

### AttemptProgress (ukazatel pokusů)
5 segments, height 14 (Luštit dál 12), gap 6, pill.
- *current*: primary + `inset 0 -4px 0 primary-edge` (Luštit dál: explore + explore-edge),
- *missed*: danger-soft (#F08A7E),
- *empty*: surface-disabled.
- `aria-label="Pokus 2 z 5"`, after the guesses run out "Všech 5 pokusů vyčerpáno". Luštit dál has a text counter "1 / 5" next to it.
- **Place of the day (changed):** a round there has no guess limit. The 5 segments are the star ladder: each miss turns one red, and from the 4th miss on the last segment stays *current* for every further guess. `aria-label="Pokus 3"`, with the compass on "Pokus 6, kompas je zapnutý". The overline drops the total: "MÍSTO DNE · POKUS 3".

### StarCounter / StarRating
- **Counter** in the bar: a 22 px star + a number 16/900 in accent-text. At 0 the star is empty and the number is icon-muted.
- **Rating** (Hit): 5 stars of 40 px, gap 6, filled `star`, empty `star-empty`. `aria-label="4 z 5 hvězd"`. Stars = 6 − the number of the guess. Smaller (18 px) in a RatedPlaceRow.
- **StarPicker** **(added)** (Place card): the player's rating of a visited place. 5 stars of 36 px, each centred in a 44×44 touch target, no gap; tapping star *n* rates *n* and fills stars 1–*n*; all `star-empty` while unrated. Pressed, a star scales to 88 %. Each star is a button `aria-label="Ohodnotit: 4 z 5 hvězd"`, the current one marked selected. Disabled while the rating is being saved.

### SpeechBubble (bublina maskota)
Mascot on the left + a bubble. Bubble: 2 px border frame (4 px at the bottom for a clue), radius 18, padding 12 14, text `body` or `body-lg`. Tail: a 14×14 square rotated by 45°, left and bottom frame, placed at `left: -9px` next to the mascot's mouth. Mascot 72–88 px.

### ClueCard (karta klíče)
- Header: a 16 px `key` icon + role `label` in accent-text: "KLÍČ 1 · HÁDANKA".
- Text: role `clue` (19/800).
- Variants:
  - *in a bubble* (Place of the day): it is a SpeechBubble with a 4 px bottom edge,
  - *newly unlocked* (Compass): 2 px accent frame, 5 px bottom, radius 18, a NOVĚ ODEMČENO label on the right,
  - *Luštit dál*: explore frame, 5 px bottom, radius 20, background teal-50, label in explore-text ("KLÍČ 1 ZE 3 · HÁDANKA"), text 20/800.
- Clue order: Riddle (Hádanka), Place type (Typ místa), Numbers (Čísla), Surroundings (Okolí), Almost revealed (Skoro prozrazení). Luštit dál uses only Riddle, Place type, Surroundings.

### LockedClue (zamčený klíč)
A surface-subtle tile, 2 px **dashed** border-strong frame, radius 14, a 16 px `lock` icon icon-subtle, text 12–13/800 icon-muted. In a row with gap 8, `flex: 1`. Labels: Typ, Čísla, Okolí, Skoro.

### MapFrame (rámeček mapy)
2 px border-strong frame, 5 px bottom, radius 22, `overflow: hidden`. Overlays inside:
- **Zoom**: top right (10 px from the edge), a white column with radius 12, 2 px border-strong frame, 40×40 buttons "+" and "−" 22/900 text-secondary, separated by a 2 px border line. `aria-label` Přiblížit / Oddálit.
- **Guess label**: bottom left, a white pill, 13/800 text-secondary, a 14 px pin icon ("Tvůj tip: kousek od Sokolova").
- **Instruction**: in the center, a pill in the text (ink) color, white text 14/800, icon `tap` ("Klepni do mapy a polož špendlík").
- **Legend** (My map): top right, a white box with radius 12, 12/800.
- **Place of the day** **(added)**: on the round screen the map is a preview. It shows the whole region and the pins, takes no gestures, and has no zoom buttons; the instruction reads "Klepni na mapu a polož svůj tip." A tap on it, or the TIPNOUT NA MAPĚ button under it, opens the **full-screen guess map**: GameTopBar (*full-screen map*), the compass card once the compass points, the map edge to edge between 2 px border lines with the zoom, the guess label once the pin is down, and the footer with POTVRDIT TIP and, above it, the instruction "Klepni do mapy a polož špendlík." before the pin is down, then the hint. The instruction sits in the footer, not on the map, so that it covers none of the region. Here the player places, drags, and confirms the pin. A miss or a hit closes it and the round screen shows the result; a guess that did not count (outside the region, no connection) keeps it open with the pin. Going back keeps the unconfirmed pin, and the preview shows it.
- **Attribution** **(added)**: MapLibre's info button, bottom right; it opens "© OpenStreetMap contributors". No text overlay in the corner.
- **My map** **(added)**: fully zoomed out, the whole region fits the frame (12 px around it), the map does not pan, and "−" is disabled. It zooms in down to street level (the map's maximum zoom), where "+" is disabled. Zoomed in, it pans; zooming back out re-centres the region. On a touch screen (phone app or mobile browser), a one-finger drag that starts on the map pans it when zoomed in and scrolls the page when fully zoomed out; two fingers always zoom the map; a drag that starts outside the map never moves it. In a desktop browser the mouse wheel scrolls the page, not the map.

### Map markers (značky na mapě) (`assets/map/marker-*.svg`)
| Marker | File | Description |
|---|---|---|
| Your guess | `marker-guess` | red pin with a white dot, 2.5 white outline; below it two transparent danger circles (0.15 and 0.2) |
| Missed guess | `marker-guess-missed` | red pin with a white cross |
| Old guess | `marker-guess-old` | gray pin (#9AA4B8) scaled to 0.7, with an ordinal number on reveal |
| Hit | `marker-hit` | green pin with a check mark |
| Target | `marker-target` | gold circle with a white star and a gold aura; with a dark name label on reveal |
| Guessed | `marker-guessed` | blue dot with a white outline and a blue ring |
| Visited | `icons/flag` **(added)** | gold flag with a gold-700 outline on an ink pole; replaces `marker-visited` on My map. On the MapLibre map: `tools/map/icons/marker-flag.svg` (with a white outline), anchored at the pole foot. On ink surfaces (the NAVŠTÍVENO label) `icons/flag-on-dark` **(added)**, the same flag with a white pole |
| In the fog | gray dot **(added)** | a `state-unknown` dot with a white ring; every place is on My map from the start (PRODUCT_SPECIFICATION.md, story 65). `marker-in-fog` (cloud) is no longer used on the map |

**Compass circle**: around the guess, radius = distance to the target, stroke 2.5 danger, dash 7 6, danger fill with 0.06 opacity. A direction arrow in ink 3 px and a distance label (a text/ink pill, white text 12/900, "14 km"). After a hit, the old circle is gray (#9AA4B8, dash 5 6).

### RegionMap (ilustrovaná mapa kraje)
`assets/map/region-base.svg`. States: `blank` (with towns), `pin`, `compass`, `hit`, `reveal`, `mine`. The `mine` state hides the towns, colors the areas (Chebsko blue-100, Sokolovsko #D5F1F3, Karlovarsko #FDF0CB, borders white dashed), adds fog (white clouds), the guessed/visited markers, and area names in CAPITAL LETTERS (11/900, ink 55 %). Always `role="img"` with a state description, for example "Mapa kraje: tip u Sokolova a kružnice 14 km, na které leží cíl".

### CompassPanel (panel kompasu) (Compass)
Bottom panel: background danger-tint, top corners 30, padding 18 20 28, gap 12.
- Header: a 40 px danger circle with a white `compass` icon · heading "Vedle! Kompas ti poradí." (22/900, danger-edge) · subheading 14/700 red-900.
- **CompassStat** ×4 in a 2×2 grid, gap 8: a white tile with radius 14, 3 px red-200 bottom edge, padding 10 12; a 26 px danger icon; value 17/900; caption 12/800 text-muted.
  - distance and direction (`direction-*`): "14 km" / "na jihovýchod",
  - elevation (`elevation`): "Výš" / "cíl leží výš",
  - municipality size (`municipality`): "Menší" / "cílová obec",
  - ORP (`administrative-district`): "Jiné ORP" / "jiný správní obvod".
- Below that, a ClueCard *newly unlocked* and a Button `danger` TIPNOUT ZNOVU (`margin-top: auto`).

### ResultStat (výsledková dlaždice) (Hit)
A 3-column grid, gap 10. Tile: 2 px frame in the tile's color, radius 16; header in a solid color, role `badge` (11/900), padding 4 0; value 20/900 in a darker shade, padding 8 0, centered.
- OD CÍLE: success / text success-text ("550 m")
- POKUSY: primary / text primary-edge ("2 / 5"; on the place of the day just "2", there is no limit)
- KLÍČE: accent / header with ink text, value gold-800 ("2 / 5")

### PlaceCard (karta místa, kompaktní) (Hit)
2 px border frame, 5 px bottom, radius 20, padding 12.
- Top: illustration 92×92 radius 14 on primary-tint · type label · name 18/900 · sentence 14/700 text-secondary.
- Footer (separated by a 2 px track line): on the left the status ("Přidáno na tvou mapu", 13/800 primary-edge, with a guessed dot), on the right the source "datazapad.cz · CC BY" (11/700 text-muted).
- *multiplayer* **(added)**: without the status line, since a multiplayer guess is not recorded on my map; the source and licence stay.

### PlaceDetail (karta místa, celá obrazovka) (Place card)
- Illustration 250 px on the background #DCE7FB, with a floating Back button and a status label.
- The content slides over the illustration: `margin-top: -26px`, top corners 28, white background.
- Type label, name `title-lg`, description 15/700, a row of info chips.
- **VisitPrompt** (výzva k návštěvě): 2 px **dashed** accent-edge frame, radius 20, background accent-tint; an icon in a 40 px accent tile with radius 12; heading 17/900 "Navštiv ho naživo"; subheading 13/700 gold-900; 3 locked facts (white 64 px tiles, 3 px gold-200 edge, `lock` icon gold-700, placeholder line gold-100).
- Data source 12/700 text-muted. Main action NAVIGOVAT NA MÍSTO (icon `navigate`).
- **Footer (added, from the profile):** guessed: NAVIGOVAT (`secondary`, `navigate`) + JSEM TU! (`primary`, `flag`), both *compact*; visited: NAVIGOVAT + SDÍLET (`share`), both `secondary`.
- **Info chips (added):** "31 km od tebe" only when the location permission is already granted; "uhodnuto 9. 10."; visited: "navštíveno 10. 10." on accent-tint with the `flag` icon, text gold-900 (gender-neutral instead of "byl jsi tu"). From `GET /locations` (added): the average rating "4,3 · 12 hodnocení" with the `star` icon, or "zatím bez hodnocení" with `star-empty`; the coordinates "50,0811° s. š., 12,3660° v. d." with the `place` icon. A long label wraps inside the chip.
- **RatingCard (added):** on a visited place only, below the facts, and on On the spot (see there): Card `tinted` `accent`, padding 16 16 10; heading card-title "Jak se ti tu líbilo?"; body text-secondary "Ohodnoť místo hvězdami. Ostatním poradíš, jestli stojí za výlet.", once rated "Tvoje hodnocení: 4 hvězdy. Změnit ho můžeš kdykoli."; a centred StarPicker. A tap saves at once (toast "Díky! Hodnocení je uložené.", on failure "Hodnocení se nepodařilo uložit. Zkontroluj připojení.") and updates the average chip.
- **Visited (added):** the status label is NAVŠTÍVENO · N HVĚZD in ink with the `flag-on-dark` icon; instead of the VisitPrompt, a "Tvoje zajímavosti" card: accent-tint, 3 px gold-200 frame with a 5 px bottom, radius 20, an accent pill "3 z 3", numbered facts (26 px gold circles, text 15/700).

### VisitSheet (Ještě nejsi na místě) **(added)**
A bottom sheet over the Place card: top corners 30, a 44×6 border-strong handle, Close (`close`) top right. Vřídlík `think` 96 + heading `title-md` "Ještě nejsi na místě" + 16/800 text-secondary "Na mapu si ho uložíš, až budeš do 1 km od něj." Below it a schematic way sketch (not a map): radius 22, green-50 meadow, teal-200 river, a dotted primary way from the player (blue dot in a white ring, label TY) to `marker-target` in a dashed accent-edge circle labelled "1 km", and a white distance pill ("31 km"). A row with the `locate` icon: "Poloha zjištěna právě teď · přesnost ±12 m" (14/800 text-muted). Actions: NAVIGOVAT NA MÍSTO (`primary`, cta) and JSEM TU, ZKUSIT ZNOVU (`secondary`, cta). When the position is unavailable, the same sheet shows Vřídlík `sad`, the reason (location off, permission denied, no signal, timeout), OTEVŘÍT NASTAVENÍ where the system settings can help (not on the web), and ZKUSIT ZNOVU.

### RevealCard (prozrazené místo) (Failed)
Not on the place of the day: a round there has no guess limit and ends only with a hit; the player can only leave it and continue later.

A card with a 2 px border frame / 5 px at the bottom, radius 20: overline "HLEDANÉ MÍSTO BYLO", name 22/900, type and surroundings 14/700, an info row (surface-subtle, radius 12, icon `info`): "Na tvou mapu se tohle místo nezapíše."

### FactItem (zajímavost) (On the spot)
A card: 2 px border frame, 4 px at the bottom, radius 18, padding 12 14, gap 12. On the left a 30 px gold circle with a number 15/900, on the right text 14/700 / 1.4.

### NearbyTip (tip poblíž) (On the spot)
A 3-column grid, gap 8. Tile radius 16, padding 10, no frame, background tint by type:
- Spring: explore-tint, icon and heading explore-text, **always with the warning** "Voda není hygienicky sledovaná." (10.5/700),
- Swimming: primary-tint, blue-700,
- When it rains (cinema, theater): red-100, danger-edge.
Row: heading 13/900, "[name] · 1,4 km" 12/700.

### ProfileHeader (hlavička profilu) (Profile) **(added)**
An 84 px avatar: a primary circle with a 5 px accent ring and the nickname's initial (display, white); a guest gets the `profile` icon. Next to it, gap 16: overline PROFIL text-muted · nickname title-xl · e-mail body-lg text-muted.

The profile (`07b`), top to bottom: ProfileHeader, the level card, the wafer balance (WaferPill), the **summary pill** (surface-subtle, radius 22, padding 12 16: a guessed dot + count, a flag + count, "z 540 míst kraje" caption text-muted, "Mapa ›" text-link; the whole pill links to the MAPA tab), the heading "Odznaky" title-md with "6 z 8" body-lg text-muted, a Badge grid (4 columns, gap 8, rows 16 apart), "Tvoje hodnocení" title-md with RatedPlaceRows (gap 10, the latest rating first; without any, body text-muted "Zatím tu nic není. Navštiv místo a ohodnoť ho hvězdami."), "Po oblastech" with ProgressRows, and Button `secondary` `danger` ODHLÁSIT SE with the `sign-out` icon.

### RatedPlaceRow (ohodnocené místo) (Profile) **(added)**
A tappable Card `outlined` (ListCard), padding 12 16: the place name card-title (at most 2 lines) and, right, StarRating at 18 px. The whole row links to the place card.

### Badge (odznak) (Profile) **(added)**
A 72 px medal: a 4 px ring, then (2 px in) a circle with a 4 px 3D bottom edge and a 30 px icon. Name below, gap 6: caption at 900, centered, up to 2 lines.
- *earned*: the circle in the badge's sentiment `solid` with its `edge`, the icon in `onSolid`, the ring in `line` at 40 %, the name text.
- *locked*: the circle surface-subtle with a border-strong edge, the icon icon-subtle, the ring border-strong, a 24 px white lock chip (2 px border-strong frame, 14 px `lock` icon-muted) at the bottom right, the name text-muted, and the progress "9 / 148" (micro, text-muted) under it.
- Read as one element: "První trefa, získáno" or "Celé Chebsko, zamčeno, 9 ze 148".
- The colour follows the game state: guessing badges blue, visiting badges gold, area badges in the area's colour.
- **Placeholder:** the Game API has no badges yet. The client counts eight generic ones from `GET /locations`: První trefa (1 guessed), Bystré oko (10), Sběratel (50), Výletník (1 visited), Poutník (10), and Celé Chebsko / Sokolovsko / Karlovarsko (every place in the area guessed or visited; only when the places carry an area).

### MyMapScreen (Mapa) (My map) **(added)**
The MAPA tab (`07`): the heading "Mapa kraje" title-xl with the place count ("540 míst", caption text-muted) on the right, the three CountTiles, the SegmentedControl, and then the map edge to edge over the rest of the screen above the BottomNav (2 px border line on top, no frame). The Legend is a white pill (2 px border frame, 3 px edge) centered 16 px above the map's bottom edge. Map gestures, zoom buttons, and taps as in **My map** above.

### CountTile (počítadlo) (My map)
A 3-column grid, gap 8. Tile: 2 px border frame, 4 px at the bottom, radius 16, padding 10 10 8; marker + number 22/900; caption 12/800 text-muted. Variant *in the fog*: 2 px **dashed** ink-300 frame, background #F5F7FA, number text-muted.

---

## Screens and compositions

### AppHeader (hlavička aplikace) (Home)
The `logo-pin` logo 30 px + "Kde na **západě**" (21/900, "západě" in primary). On the right a pill with a star and the place count (2 px border frame, 15/800), linking to My map. **(added)** Before it, for an account, the compact WaferPill: the `wafer` icon and the balance as a number, 44 px tall (`aria-label="Máš 112 oplatek"`).

### DailyHeroCard (hero Místo dne) (Home)
Background primary, radius 24, 6 px bottom edge primary-edge, white text.
- Overline "MÍSTO DNE · ČT 9. 10." and the round's state in blue-on: "Zatím bez pokusu", "Rozehráno · 2 pokusy", "Dnes dohráno · 3 pokusy".
- Heading "Kde to je?" 30/900.
- A 120 px landscape illustration with fog and a gold pin with a "?".
- Chips (4 klíče · kompas · až 5 hvězd), Button `accent` HRÁT MÍSTO DNE, or HRÁT DÁL for a started round.

### ListCard (řádek s odkazem) (Home)
2 px border frame, 5 px at the bottom, radius 20, padding 14 16, gap 14. A 48 px icon tile with radius 14 in the mode tint, title 17/900, subtitle 14/700 text-muted, a 22 px `next` arrow icon-subtle. The whole card is an `<a>`.
- *locked* **(added)**: a game mode that is not playable yet. The `dashed` card, the icon tile in surface-disabled with an icon-muted icon, the title in text-muted, a 22 px `lock` instead of the arrow. Not a link; the subtitle says why ("Připravujeme, už brzy").
- **Minihry (changed, was Luštit):** the MINIHRY tab shows the mini games under the heading "Minihry" (`title-lg`) and "Vyber si, jak chceš hrát." as two **GameTiles** that share the height down to the bottom navigation (gap 14, each at least 180 px; a shorter screen scrolls). GameTile: Card `tinted` in the game's sentiment, radius 22, padding 20; top left a 72 px icon tile in the solid colour with a 4 px edge and a 36 px icon in the on-colour; bottom: the name `title-md`, one line `body` text-secondary, and `next` 28 px in the sentiment ink. Místo dne (`calendar`, primary): "Každý den jedno nové místo. Čtyři klíče, pak kompas." Hra s kamarády (`players`, explore): "Stejná místa pro všechny, vyhraje nejpřesnější." The whole tile opens the game.

### BottomNav (spodní navigace) (Home, My map)
One column per item, padding 10 14 22, 2 px border top line, background surface.
- Item: a 26 px icon above the label (role `nav`).
- *active*: the icon in a pill (padding 6 18, radius 14, background primary-tint, 2 px blue-200 frame), icon and text primary, icon with a white fill, `aria-current="page"`.
- *inactive*: icon icon-muted, text text-muted, transparent frame (so nothing shifts).
- Items: DNES (`calendar`), MINIHRY (`compass`, **changed**, was LUŠTIT), MAPA (`map`, **added**), PROFIL (`profile`, **added**).

### HeroHeader (barevná hlavička)
- Sign-in: primary, height 268, bottom corners 36, edge 6 px, landscape + Vřídlík `wave` 120 px.
- On the spot: accent, bottom corners 32, 6 px accent-edge edge, Vřídlík `cheer` 110 px, a NAVŠTÍVENO label, heading "Jsi tady!" 32/900, "GPS: 40 m od cíle" 13/800 gold-900. Below it **(added)**: "Máš odemčené 3 zajímavosti" (`title-sm`, gender-neutral instead of "Odemkl jsi"), FactItems, "Tipy poblíž" with NearbyTips, and at the bottom a success-tint banner (radius 16) "Uloženo na tvou mapu" with a `done` icon and a "Zobrazit ›" link back to my map, then the data source of the tips.
  **(added)** Under the hero: the WaferPill "+50 oplatek" for a first visit; "O místě" (`title-sm`) with the description (`body-lg` text-secondary) and its data source and licence (12/700 text-muted), when the client knows them; then the RatingCard "Jak se ti tu líbilo?"; then the facts and the nearby tips.

### Feedback screens (round results)
| Result | Mascot | Heading | Color | Action |
|---|---|---|---|---|
| Missed | — (compass panel) | Vedle! Kompas ti poradí. | danger | TIPNOUT ZNOVU |
| Hit | `cheer` 112 + confetti | Trefa na N. pokus! (success-text) | success | SDÍLET + POKRAČOVAT |
| Failed (not on the place of the day) | `sad` 84 in a bubble | "Tentokrát to nevyšlo…" | neutral | LUŠTIT DÁL + ZPĚT DOMŮ |
| On the spot | `cheer` 110 | Jsi tady! | accent | JSEM TU! |

### Multiplayer (Hra s kamarády) **(added)**
Not in the design; composed from the components above. Full-screen screens outside the bottom navigation (`/multiplayer`, invite link `/multiplayer/K7M2QX`). Every screen: GameTopBar *multiplayer* → content (margin 20, max 480) → footer with the main action. Toasts sit above a two-button footer.

- **Entry**: heading "Hra s kamarády" (`title-lg`), Vřídlík `wave` in a SpeechBubble, TextField "Tvoje přezdívka" for a guest (2–24 characters; a signed-in player gets an info row "Hraješ jako Eva" with the `profile` icon instead), Button ZALOŽIT MÍSTNOST (`primary`, `players` icon), Divider "NEBO", TextField "Kód místnosti" and Button `secondary` PŘIPOJIT SE. Errors go under their field ("Místnost s tímhle kódem neexistuje.").
- **LobbyCode**: a `tinted` primary card: overline KÓD MÍSTNOSTI primary-edge, the code in `display` with 6 px letter spacing (screen reader spells it), the invite link as a QR code **(added)** (`size-qr-code` 168, dark modules in `text` on an `outlined` neutral card, 4-module quiet zone, error correction M, announced "QR kód s odkazem do místnosti"), a 14/700 hint "Pošli kód nebo odkaz kamarádům. Kdo je u tebe, načte QR kód fotoaparátem.", and two `secondary` *compact* buttons KOPÍROVAT KÓD + SDÍLET ODKAZ (`share`; the link goes to the clipboard until a sharing plugin is chosen).
- **PlayerRow**: a card (`outlined`; the player's own row `tinted` primary), padding 10 14: a 44 px circle with the initial (primary, white `title-sm`; surface-disabled with text-muted when the player has no connection), the nickname `card-title`, pills HOSTITEL (`accent`) and TY (`primary`), and the status 14/700 text-muted: "V místnosti", "Hraje · 3 / 10", "Prohlíží výsledky", "Bez spojení". Section heading `overline` text-muted "HRÁČI · 3 Z 8".
- **Settings**: for the host, one SegmentedControl per setting under a 13/900 text-secondary label: "Počet míst", "Čas na hru" ("5 min"), "Nejvýš hráčů"; only options within the server's limits are offered. Other players see the values as info chips ("10 míst", "5 min", "nejvýš 8 hráčů").
- **Lobby footer**: the host's START HRY (`accent`, cta, disabled until enough players are in the lobby and no game runs); others read "Hru spustí hostitel." 14/700 text-muted. Below it ODEJÍT (`ghost`). A player who joins during a game waits with Vřídlík `think`: "Právě běží hra…".
- **CountdownPill**: the game timer "4:05" in a pill, min width 64, padding 6 12, 2 px frame; surface-subtle / border, text `title-sm` ink with tabular figures. Under 30 s: danger-tint / danger-soft, text danger-edge (the digits still carry the state). `aria-label` "Zbývají 4 minuty a 5 sekund" (the verb agrees with the first number: "Zbývá 1 minuta", "Zbývá 9 sekund").
- **ReconnectBanner**: while the connection is restored, an info row under the top bar (surface-subtle, radius 12, `info` 16 icon-muted, 13/800 text-secondary) "Spojení se přerušilo, připojuji znovu…", a live region. The screen stays; guessing waits. When it cannot be restored, Vřídlík `sad` with ZKUSIT ZNOVU and ODEJÍT.
- **PlacePrompt**: the place to find, the only thing a player sees before the guess: a raised SpeechBubble with Vřídlík `think` 72, label "MÍSTO 3 Z 10" in accent-text, "Kde je tohle místo?" 14/700 and the place name `title-md`. Below it the MapFrame preview, which takes the remaining height but at least 160; on a short screen the prompt and the preview scroll above the footer TIPNOUT NA MAPĚ; the full-screen guess map shows the label and the name `title-sm` under the top bar, and the hint "Na každé místo máš jen jeden tip…". POTVRDIT TIP sends the one guess.
- **PlaceResult**: after each guess: overline "MÍSTO 3 Z 10", Vřídlík in a bubble (`cheer` under 1 km, `happy` under 15 km, `sad` otherwise), ResultStat OD CÍLE (`primary`, full width), PlaceCard *multiplayer*, footer DALŠÍ MÍSTO (HOTOVO after the last place, and when the game ended meanwhile; the Results follow). After the last place Vřídlík does not point to a next place.
- **WaitingRoom**: after the last place: Vřídlík `happy` "Máš hotovo! Počkáme na ostatní…", heading POSTUP HRÁČŮ and one ProgressBar row per participant (nickname · bar · "7 z 10"; the player's own bar primary and its name marked "(ty)", the others neutral). Only counts, never other players' guesses.
- **LeaderboardRow**: the PlayerRow card with a 44 px rank circle (`title-sm`; accent for the first place, track otherwise), the nickname and TY, "10 z 10 míst" 14/700 text-muted, and on the right `badge` PRŮMĚR over the average distance `title-sm` primary-edge. One `aria-label` per row: "1. místo: Eva (ty), průměr 1,2 km, uhodnuto 10 z 10 míst".
- **Results**: overline HRA SKONČILA, heading "Výsledky", Vřídlík (`cheer` for the winner) with the player's average, POŘADÍ with LeaderboardRows, a 14/700 note on the ranking and the penalty for a place without a guess, MÍSTA VE HŘE: one card per place (type pill, "3. Hrad Loket" `card-title`, TVŮJ TIP distance or "bez tipu", "Nejblíž: Adam · 400 m", source and licence 12/700). Footer ZPĚT DO MÍSTNOSTI (`primary`, cta) + ODEJÍT (`ghost`).
- **LeaveGameSheet**: the VisitSheet pattern: handle, Vřídlík `sad` 72, `title-md` "Odejít ze hry?", 15/800 text-secondary explanation, HRÁT DÁL (`primary`, cta) and ODEJÍT (`secondary` danger, cta). The system back in a game opens it too, except on the full-screen guess map, where back returns to the place like `back` "Zpět na místo"; in the lobby, back leaves.

### Screen map
00 Sign-in → 01 Home → 02 Place of the day (first guess) → 03 Missed (compass) → 04 Hit / 05 Failed → 06 Luštit dál (MINIHRY tab) → 07 Map (my map) / 07b Profile → 08 Place card (guessed) → 09 On the spot (visited). **(added)** Luštit → Hra s kamarády: Entry → Lobby → Place → full-screen map → PlaceResult → … → WaitingRoom → Results → Lobby.
