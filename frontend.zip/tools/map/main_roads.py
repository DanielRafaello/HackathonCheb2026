"""Turn the main roads into one line per road: the motorway and the class
I roads.

Usage: main_roads.py <roads.geojsonseq> > main-roads.geojsonseq

The input is a GeoJSON text sequence of highway=motorway, trunk and primary
ways from `osmium export`. A way that carries several routes has a ref like
"D6;21"; the script keeps the first motorway (D…) or class I (one or two
digits) number in it and drops ways without one, such as the German B roads
that reach into the bounding box.

The ways of one road meet at shared OSM nodes, so they form a graph. Where
they do not (a roundabout without the ref, the two carriageways of the
motorway, which meet only through ramps), a loose end is joined to the
nearest node of another part of the same road within BRIDGE_KM. A dual
carriageway then runs twice through the graph, and junctions add short
branches. For each connected part of the graph the script takes two nodes
far apart as the crow flies and keeps only the shortest path between them,
which follows one carriageway from one end of the road to the other. (The
longest path would run out on one carriageway and back on the other.) It
prints a GeoJSON text sequence of lines that hold only "ref".
"""

import heapq
import json
import math
import re
import sys

KM_PER_DEG_LAT = 110.57
MAIN_REF = re.compile(r"^(D\d+|\d{1,2})$")
BRIDGE_KM = 0.5


def main_ref(ref):
    for part in (ref or "").split(";"):
        part = part.strip()
        if MAIN_REF.match(part):
            return part
    return None


def distance_km(a, b):
    kx = KM_PER_DEG_LAT * math.cos(math.radians((a[1] + b[1]) / 2))
    return math.hypot((a[0] - b[0]) * kx, (a[1] - b[1]) * KM_PER_DEG_LAT)


def shortest_path(graph, start, goal):
    """Dijkstra from start to goal; returns the nodes of the path."""
    dist = {start: 0.0}
    prev = {}
    heap = [(0.0, start)]
    while heap:
        d, node = heapq.heappop(heap)
        if node == goal:
            break
        if d > dist[node]:
            continue
        for other, w in graph[node].items():
            nd = d + w
            if nd < dist.get(other, math.inf):
                dist[other] = nd
                prev[other] = node
                heapq.heappush(heap, (nd, other))
    path = [goal]
    while path[-1] != start:
        path.append(prev[path[-1]])
    return path


def components(graph):
    """Map each node to the index of its connected part."""
    part = {}
    for start in graph:
        if start in part:
            continue
        index = len(set(part.values()))
        part[start] = index
        stack = [start]
        while stack:
            node = stack.pop()
            for other in graph[node]:
                if other not in part:
                    part[other] = index
                    stack.append(other)
    return part


def bridge_gaps(graph):
    """Join each loose end to the nearest node of another part within
    BRIDGE_KM, until no loose end can be joined."""
    joined = True
    while joined:
        joined = False
        part = components(graph)
        for end in [n for n in graph if len(graph[n]) == 1]:
            best, best_d = None, BRIDGE_KM
            for node in graph:
                if part[node] != part[end]:
                    d = distance_km(end, node)
                    if d < best_d:
                        best, best_d = node, d
            if best is not None:
                graph[end][best] = best_d
                graph[best][end] = best_d
                joined = True
                break


def road_lines(graph):
    """One path per connected part of the graph, between two of its nodes
    that lie far apart as the crow flies. Two sweeps find them: the node
    farthest from any node, then the node farthest from that one. Loose
    ends do not help: a road can end in a roundabout or leave the region on
    both carriageways."""
    part = components(graph)
    for index in sorted(set(part.values())):
        nodes = [n for n in graph if part[n] == index]
        a = max(nodes, key=lambda n: distance_km(nodes[0], n))
        b = max(nodes, key=lambda n: distance_km(a, n))
        if a != b:
            yield shortest_path(graph, a, b)


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__, file=sys.stderr)
        return 2
    graphs = {}  # ref -> {node: {node: km}}
    with open(sys.argv[1], encoding="utf-8") as f:
        for line in f:
            line = line.strip().lstrip("\x1e")
            if not line:
                continue
            feature = json.loads(line)
            ref = main_ref(feature.get("properties", {}).get("ref"))
            if ref is None or feature["geometry"]["type"] != "LineString":
                continue
            graph = graphs.setdefault(ref, {})
            coords = [tuple(c) for c in feature["geometry"]["coordinates"]]
            for a, b in zip(coords, coords[1:]):
                if a == b:
                    continue
                w = distance_km(a, b)
                graph.setdefault(a, {})[b] = w
                graph.setdefault(b, {})[a] = w

    lines = 0
    for ref in sorted(graphs):
        bridge_gaps(graphs[ref])
        for path in road_lines(graphs[ref]):
            if len(path) < 2:
                continue
            print(json.dumps({
                "type": "Feature",
                "properties": {"ref": ref},
                "geometry": {"type": "LineString", "coordinates": [list(p) for p in path]},
            }))
            lines += 1
    print(f"{sys.argv[1]}: {lines} lines of {len(graphs)} main roads", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
