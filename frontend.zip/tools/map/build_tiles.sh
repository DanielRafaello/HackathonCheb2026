#!/usr/bin/env bash
# Build the vector tile set for the game map from an OpenStreetMap extract.
#
# Input:  a Geofabrik .osm.pbf that covers Karlovarský kraj, for example
#         czech-republic-latest.osm.pbf.
# Output: <out>/kvk.pmtiles        vector tiles, zoom 0-14, for MapLibre GL
#         <out>/region.geojson     the rounded region polygon (static file)
#         <out>/border.geojson     the same ring as a line
#         <out>/mask.geojson       the bounding box minus the region
#         <out>/water.geojson      the large reservoirs, rounded
#         <out>/waterway.geojson   the rivers, rounded
#         <out>/road.geojson       the motorway and the class I roads, rounded
#         <out>/wood.geojson       one circle per large forest, with its area
#         <out>/peak.geojson       the highest peaks
#         <out>/landform.geojson   label points of the mountain ranges
#         <out>/country.geojson    label point of the neighbouring country
#         <out>/kvk.osm.pbf        the clipped OSM extract (for reruns)
#
# Requires osmium-tool (brew install osmium-tool), tilemaker 3.x and python3.
#
# Usage: tools/map/build_tiles.sh <input.osm.pbf> [<out dir>]
#
# Intermediate files are kept in <out dir>/work so that reruns skip the slow
# steps. Delete that directory to start from scratch.
set -euo pipefail

input="${1:?usage: build_tiles.sh <input.osm.pbf> [<out dir>]}"
out="${2:-build/map}"
work="$out/work"
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Set TILEMAKER to a binary that is not on PATH, or to "podman" or "docker"
# to run the official container image (ghcr.io/systemed/tilemaker).
tilemaker="${TILEMAKER:-tilemaker}"

# Bounding box of Karlovarský kraj with a margin, minlon,minlat,maxlon,maxlat.
# Keep it equal to "bounding_box" in config.json.
bbox="11.9,49.7,13.6,50.6"
region_name="Karlovarský kraj"

# The map is stylised. These settings decide how little detail it keeps.
rivers="Ohře,Teplá"
landforms=("Krušné hory" "Slavkovský les" "Doupovské hory")
peak_count=4           # the highest peaks get a mountain icon
peak_spacing_km=5      # a peak this close to a higher one is skipped
min_water_km2=2     # reservoirs smaller than this are dropped
min_wood_patch_km2=1   # forest patches smaller than this are ignored
wood_cluster=1.1       # patches whose equivalent circles (times this) overlap merge into one blob
min_wood_km2=20        # blobs smaller than this are dropped
wood_dedupe_km=1       # a patch of the same size this close to another is the same patch
region_tolerance=0.015   # Douglas-Peucker tolerance in degrees (~1 km)
shape_tolerance=0.004    # the same for lakes and rivers (~300 m)
smooth=3                 # Chaikin corner-cutting iterations for the region
shape_smooth=2           # the same for lakes and rivers
road_tolerance=0.002     # the same for the main roads (~150 m)
min_road_km=2            # road pieces shorter than this after merging are dropped

simplify="python3 -I $here/simplify_features.py"

mkdir -p "$work"

echo "1/5 bbox extract"
if [ ! -f "$work/bbox.osm.pbf" ]; then
  osmium extract --bbox "$bbox" -s smart -S types=multipolygon,boundary \
    --overwrite -o "$work/bbox.osm.pbf" "$input"
fi

echo "2/5 region border"
osmium tags-filter "$work/bbox.osm.pbf" r/boundary=administrative r/admin_level=6 \
  --overwrite -o "$work/admin6.osm.pbf"
osmium export "$work/admin6.osm.pbf" -f geojsonseq --geometry-types=polygon \
  --overwrite -o "$work/admin6.geojsonseq"
# The exact border clips the data; the rounded border is what the map shows.
python3 -I "$here/pick_region.py" "$work/admin6.geojsonseq" "$region_name" > "$work/region-exact.geojson"
$simplify "$work/admin6.geojsonseq" --names "$region_name" \
  --tolerance "$region_tolerance" --smooth "$smooth" --output polygon > "$out/region.geojson"
# The same ring as a line, for the outline and its shadow.
$simplify "$work/admin6.geojsonseq" --names "$region_name" \
  --tolerance "$region_tolerance" --smooth "$smooth" --output outline > "$out/border.geojson"
python3 -I "$here/region_mask.py" "$out/region.geojson" ${bbox//,/ } > "$out/mask.geojson"

echo "3/5 clip to the region"
osmium extract --polygon "$work/region-exact.geojson" -s smart -S types=multipolygon,boundary \
  --overwrite -o "$out/kvk.osm.pbf" "$work/bbox.osm.pbf"

echo "4/5 shapes"
osmium tags-filter "$out/kvk.osm.pbf" nwr/natural=water nwr/landuse=reservoir \
  --overwrite -o "$work/water.osm.pbf"
osmium export "$work/water.osm.pbf" -f geojsonseq --geometry-types=polygon \
  --overwrite -o "$work/water.geojsonseq"
$simplify "$work/water.geojsonseq" --exclude water=river,canal,stream \
  --min-area "$min_water_km2" --inside "$work/region-exact.geojson" \
  --tolerance "$shape_tolerance" --smooth "$shape_smooth" --output polygon \
  --properties name,area > "$out/water.geojson"

osmium tags-filter "$out/kvk.osm.pbf" w/waterway=river \
  --overwrite -o "$work/waterway.osm.pbf"
osmium export "$work/waterway.osm.pbf" -f geojsonseq --geometry-types=linestring \
  --overwrite -o "$work/waterway.geojsonseq"
# Short leftovers (side arms, river areas) would show as dots, so they go.
$simplify "$work/waterway.geojsonseq" --names "$rivers" --merge --min-length 5 \
  --tolerance "$shape_tolerance" --smooth "$shape_smooth" --output line > "$out/waterway.geojson"

# The motorway and the class I roads, one rounded line per road number
# (main_roads.py keeps one carriageway and drops the junction branches).
osmium tags-filter "$out/kvk.osm.pbf" w/highway=motorway,trunk,primary \
  --overwrite -o "$work/road.osm.pbf"
osmium export "$work/road.osm.pbf" -f geojsonseq --geometry-types=linestring \
  --overwrite -o "$work/road.geojsonseq"
python3 -I "$here/main_roads.py" "$work/road.geojsonseq" > "$work/main-road.geojsonseq"
$simplify "$work/main-road.geojsonseq" --group ref --min-length "$min_road_km" \
  --tolerance "$road_tolerance" --smooth "$shape_smooth" --output line \
  --properties ref > "$out/road.geojson"

osmium tags-filter "$out/kvk.osm.pbf" nwr/landuse=forest nwr/natural=wood \
  --overwrite -o "$work/wood.osm.pbf"
osmium export "$work/wood.osm.pbf" -f geojsonseq --geometry-types=polygon \
  --overwrite -o "$work/wood.geojsonseq"
# Forests become circles with the area of the merged patches, so that the
# blobs scale with the map.
$simplify "$work/wood.geojsonseq" --min-area "$min_wood_patch_km2" \
  --inside "$work/region-exact.geojson" --dedupe "$wood_dedupe_km" \
  --cluster "$wood_cluster" --min-cluster-area "$min_wood_km2" \
  --output circle --properties area > "$out/wood.geojson"

osmium tags-filter "$out/kvk.osm.pbf" n/natural=peak \
  --overwrite -o "$work/peak.osm.pbf"
osmium export "$work/peak.osm.pbf" -f geojsonseq --geometry-types=point \
  --overwrite -o "$work/peak.geojsonseq"
python3 -I "$here/top_peaks.py" "$work/peak.geojsonseq" "$work/region-exact.geojson" \
  "$peak_count" "$peak_spacing_km" > "$out/peak.geojson"

osmium tags-filter "$work/bbox.osm.pbf" w/natural=mountain_range \
  --overwrite -o "$work/landform.osm.pbf"
osmium export "$work/landform.osm.pbf" -f geojsonseq --geometry-types=linestring \
  --overwrite -o "$work/landform.geojsonseq"
python3 -I "$here/landform_points.py" "$work/landform.geojsonseq" "$work/region-exact.geojson" \
  "${landforms[@]}" > "$out/landform.geojson"

# Hand-placed labels outside the region (the neighbouring country).
cp "$here/data/country.geojson" "$out/country.geojson"

echo "5/5 tiles"
# tilemaker resolves the GeoJSON sources in config.json against the working
# directory, so it runs inside the output directory.
if [ "$tilemaker" = "podman" ] || [ "$tilemaker" = "docker" ]; then
  # No tilemaker binary on this machine: run the official image instead.
  # The on-disk store keeps memory use below the limits of small VMs.
  out_abs="$(cd "$out" && pwd)"
  "$tilemaker" run --rm -v "$out_abs:/data" -v "$here:/profile:ro" -w /data \
    ghcr.io/systemed/tilemaker:master \
    --input kvk.osm.pbf --output kvk.pmtiles --store work/store \
    --config /profile/config.json --process /profile/process.lua
else
  (cd "$out" && "$tilemaker" --input kvk.osm.pbf --output kvk.pmtiles \
    --config "$here/config.json" --process "$here/process.lua")
fi

echo "done: $out/kvk.pmtiles"
