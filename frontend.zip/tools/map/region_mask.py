"""Make the mask polygon: everything inside a bounding box except the region.

Usage: region_mask.py <region.geojson> <minlon> <minlat> <maxlon> <maxlat>

The style paints the mask in the background colour above the forests and
rivers. Features of the clipped OSM extract may stick out of the region,
because the extract keeps every way that has at least one node inside it.
The mask hides those parts without cutting the geometries.
"""

import json
import sys


def main() -> int:
    region_path = sys.argv[1]
    minlon, minlat, maxlon, maxlat = (float(v) for v in sys.argv[2:6])
    with open(region_path, encoding="utf-8") as f:
        geometry = json.load(f)["features"][0]["geometry"]

    polygons = geometry["coordinates"]
    if geometry["type"] == "Polygon":
        polygons = [polygons]

    # Outer ring counterclockwise, holes clockwise (RFC 7946).
    outer = [[minlon, minlat], [maxlon, minlat], [maxlon, maxlat], [minlon, maxlat], [minlon, minlat]]
    holes = [list(reversed(rings[0])) for rings in polygons]

    mask = {
        "type": "FeatureCollection",
        "features": [{
            "type": "Feature",
            "properties": {"name": "mask"},
            "geometry": {"type": "Polygon", "coordinates": [outer, *holes]},
        }],
    }
    print(json.dumps(mask))
    return 0


if __name__ == "__main__":
    sys.exit(main())
