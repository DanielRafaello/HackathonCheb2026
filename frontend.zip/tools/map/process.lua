-- Tilemaker profile for the „Kde na západě" base map.
--
-- The game map is stylised (see the UI design): a rounded region polygon,
-- six cities, two rivers, the main roads, the large reservoirs, forest
-- blobs, a few peaks and labels for the mountain ranges. All shapes but the cities are
-- prepared by build_tiles.sh and enter tilemaker as GeoJSON sources listed
-- in config.json. This file only handles the cities, which come straight
-- from OSM.
--
-- Layers (see config.json):
--   region    polygon   rounded border of Karlovarský kraj (GeoJSON)
--   border    line      the same ring as a line, for outlines (GeoJSON)
--   mask      polygon   everything outside the region (GeoJSON)
--   water     polygon   the large reservoirs, rounded (GeoJSON)
--   waterway  line      Ohře and Teplá, rounded (GeoJSON)
--   road      line      the motorway and class I roads, "ref" (GeoJSON)
--   wood      polygon   one circle per forest massif, "area" in km² (GeoJSON)
--   peak      point     the highest peaks, "name" and "ele" (GeoJSON)
--   landform  point     labels of the mountain ranges (GeoJSON)
--   country   point     label of the neighbouring country (GeoJSON, data/)
--   place     point     the six cities (name, class = city|town)   <- here

-- Tilemaker only passes nodes and ways with one of these keys to the
-- functions below. Everything else is skipped before Lua runs.
node_keys = { "place" }
way_keys = { "natural=peak" }

-- The six cities shown on the map.
local cities = {
  ["Aš"] = true,
  ["Cheb"] = true,
  ["Sokolov"] = true,
  ["Karlovy Vary"] = true,
  ["Ostrov"] = true,
  ["Mariánské Lázně"] = true,
}

function node_function()
  local place = Find("place")
  local name = Find("name")
  if (place == "city" or place == "town") and cities[name] then
    Layer("place", false)
    Attribute("name", name)
    Attribute("class", place)
  end
end

function way_function()
  -- Nothing: every way-based shape comes from the GeoJSON sources.
end
