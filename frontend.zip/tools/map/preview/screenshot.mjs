// Render the preview page with the installed Chrome and save a PNG.
//
// Usage: node screenshot.mjs <url> <out.png> [<width>x<height>]
//
// Example, with the output directory served on port 8765:
//   python3 -I tools/map/preview/serve.py build/map 8765
//   npm --prefix tools/map/preview install
//   node tools/map/preview/screenshot.mjs "http://127.0.0.1:8765/preview/index.html" map.png
//
// The page writes "idle" into <pre id="status"> once MapLibre has drawn
// every tile; the script waits for that before it takes the screenshot.
// Set CHROME to the browser binary if it is not at the macOS default path.

import puppeteer from "puppeteer-core";

const [url, out, size = "1200x900"] = process.argv.slice(2);
if (!url || !out) {
  console.error("usage: screenshot.mjs <url> <out.png> [<width>x<height>]");
  process.exit(2);
}
const [width, height] = size.split("x").map(Number);
const chrome = process.env.CHROME || "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";

const browser = await puppeteer.launch({
  executablePath: chrome,
  headless: true,
  args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"],
});
try {
  const page = await browser.newPage();
  await page.setViewport({ width, height, deviceScaleFactor: 1 });
  page.on("console", (m) => console.log(`[${m.type()}] ${m.text()}`));
  page.on("pageerror", (e) => console.log(`[pageerror] ${e.message}`));
  if (process.env.DEBUG) {
    // Log every request with its Range header and the response size.
    page.on("response", async (r) => {
      const range = r.request().headers()["range"] || "";
      console.log(`[http] ${r.status()} ${r.url()} ${range} -> ${r.headers()["content-length"] || "?"} bytes`);
    });
  }
  await page.goto(url, { waitUntil: "load" });
  await page.waitForFunction(
    () => /idle/.test(document.getElementById("status")?.textContent ?? ""),
    { timeout: 60000 },
  );
  await page.screenshot({ path: out });
  console.log(out);
} finally {
  await browser.close();
}
