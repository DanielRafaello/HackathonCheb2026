#!/usr/bin/env bash
# Rasterise the map icons for the app.
#
# Writes assets/map/<name>.png at 1x, and 2.0x/ and 3.0x/ variants, from
# the SVG sources next to this script. Requires rsvg-convert
# (brew install librsvg). Run it after changing an SVG and commit the PNGs.
#
# Usage: tools/map/icons/render_icons.sh
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
assets="$here/../../../assets/map"
mkdir -p "$assets/2.0x" "$assets/3.0x"

for svg in "$here"/*.svg; do
  name="$(basename "$svg" .svg)"
  rsvg-convert --zoom 1 -o "$assets/$name.png" "$svg"
  rsvg-convert --zoom 2 -o "$assets/2.0x/$name.png" "$svg"
  rsvg-convert --zoom 3 -o "$assets/3.0x/$name.png" "$svg"
  echo "$name"
done
