"""Pick one named polygon from a GeoJSON text sequence and print it as GeoJSON.

Usage: pick_region.py <features.geojsonseq> <name>

osmium export writes one feature per line (RFC 8142 with a leading record
separator). The script prints a FeatureCollection with the first feature
whose "name" property equals the given name. It exits with status 1 when
there is no such feature.
"""

import json
import sys


def main() -> int:
    path, wanted = sys.argv[1], sys.argv[2]
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip().lstrip("\x1e")
            if not line:
                continue
            feature = json.loads(line)
            if feature.get("properties", {}).get("name") == wanted:
                print(json.dumps({"type": "FeatureCollection", "features": [feature]}, ensure_ascii=False))
                return 0
    print(f"no polygon named {wanted!r} in {path}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
