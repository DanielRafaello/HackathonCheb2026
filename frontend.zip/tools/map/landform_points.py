"""Make one label point per named landform from OSM ridge lines.

Usage: landform_points.py <lines.geojsonseq> <region.geojson> <name> [<name> ...]

OSM maps mountain ranges as long natural=mountain_range ways along the
ridge. Some ridges continue far outside the region, so the label point is
the middle vertex of the part of the line that lies inside the region
polygon. The script prints a GeoJSON FeatureCollection of points with a
"name" property, one per name that was found.
"""

import json
import sys


def ring_contains(ring, x, y):
    """Ray casting point-in-polygon test for one ring."""
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > y) != (yj > y):
            x_cross = (xj - xi) * (y - yi) / (yj - yi) + xi
            if x < x_cross:
                inside = not inside
        j = i
    return inside


def polygon_contains(geometry, x, y):
    polygons = geometry["coordinates"]
    if geometry["type"] == "Polygon":
        polygons = [polygons]
    for rings in polygons:
        if ring_contains(rings[0], x, y) and not any(ring_contains(r, x, y) for r in rings[1:]):
            return True
    return False


def read_features(path):
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip().lstrip("\x1e")
            if line:
                yield json.loads(line)


def main() -> int:
    lines_path, region_path, names = sys.argv[1], sys.argv[2], sys.argv[3:]
    with open(region_path, encoding="utf-8") as f:
        region = json.load(f)["features"][0]["geometry"]

    # Collect the vertices of every way of each named landform.
    vertices = {name: [] for name in names}
    for feature in read_features(lines_path):
        name = feature.get("properties", {}).get("name")
        if name not in vertices:
            continue
        geometry = feature["geometry"]
        if geometry["type"] == "LineString":
            vertices[name].extend(geometry["coordinates"])
        elif geometry["type"] == "MultiLineString":
            for part in geometry["coordinates"]:
                vertices[name].extend(part)

    features = []
    for name in names:
        inside = [v for v in vertices[name] if polygon_contains(region, v[0], v[1])]
        if not inside:
            print(f"warning: no part of {name!r} lies inside the region", file=sys.stderr)
            continue
        x, y = inside[len(inside) // 2]
        features.append({
            "type": "Feature",
            "properties": {"name": name},
            "geometry": {"type": "Point", "coordinates": [round(x, 5), round(y, 5)]},
        })

    print(json.dumps({"type": "FeatureCollection", "features": features}, ensure_ascii=False))
    return 0 if features else 1


if __name__ == "__main__":
    sys.exit(main())
