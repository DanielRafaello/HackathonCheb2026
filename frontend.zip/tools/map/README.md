# Map tiles

Builds the vector tile set for the game map from OpenStreetMap data. The
map is stylised, like a hand-drawn overview: a rounded region, six cities,
two rivers, the main roads, the large reservoirs, forests as blobs, peaks, and the names of
three mountain ranges. The tile set holds only these features, with very
few vertices. See `docs/FRONTEND_SPECIFICATION.md` section 3.

## Requirements

- [osmium-tool](https://osmcode.org/osmium-tool/): `brew install osmium-tool`
- [tilemaker](https://github.com/systemed/tilemaker) 3.x, built from source,
  or podman/docker for the official image
- python3

## Build

1. Download a Czech Republic extract, for example
   `czech-republic-latest.osm.pbf` from Geofabrik.
2. Run the build. The second argument is the output directory
   (default `build/map`, which git ignores):

   ```sh
   tools/map/build_tiles.sh ~/Downloads/czech-republic-latest.osm.pbf build/map
   ```

   Without a tilemaker binary on `PATH`, point `TILEMAKER` at one, or at
   `podman` or `docker` to use the official image:

   ```sh
   TILEMAKER=podman tools/map/build_tiles.sh ~/Downloads/czech-republic-latest.osm.pbf build/map
   ```

The script cuts a bounding box around the region, exports the region
border, clips the data to the exact border, turns the lakes, rivers, main
roads and forests into simple rounded shapes (`simplify_features.py`,
`main_roads.py`), and runs
tilemaker with `config.json` and `process.lua`. Intermediate files stay in
`build/map/work`, so a rerun skips the slow bounding box extract.

The thresholds and the amount of rounding are variables at the top of
`build_tiles.sh`: minimum reservoir and forest areas, the minimum road
length, the simplification tolerances, and the number of smoothing passes.

## Output

| File | Content |
| --- | --- |
| `kvk.pmtiles` | Vector tiles, zoom 0–14 |
| `region.geojson` | The rounded region polygon, usable as a static file in the app |
| `border.geojson` | The same ring as a line |
| `mask.geojson` | The bounding box minus the region |
| `water.geojson`, `waterway.geojson`, `road.geojson`, `wood.geojson`, `landform.geojson` | The prepared shapes that went into the tiles |
| `kvk.osm.pbf` | The clipped OSM extract |

The app bundles the archive as the asset `assets/map/kvk.pmtiles`. Copy
each new build there:

```sh
cp build/map/kvk.pmtiles assets/map/kvk.pmtiles
```

## Layers

| Layer | Geometry | Attributes | Source |
| --- | --- | --- | --- |
| `region` | polygon | `name` | boundary of Karlovarský kraj (admin_level 6), simplified and rounded |
| `border` | line | `name` | the same ring as a line; draw outlines from it, not from `region`, because a clipped polygon's ring runs along tile edges |
| `mask` | polygon | | everything inside the bounding box but outside the region; paint it in the background colour to hide features that stick out of the region |
| `place` | point | `name`, `class` (`city` or `town`) | Aš, Cheb, Sokolov, Karlovy Vary, Ostrov, Mariánské Lázně |
| `waterway` | line | `name` | Ohře and Teplá, merged into one line each, simplified and rounded |
| `road` | line | `ref` | the motorway D6 and the class I roads (6, 13, 20, 21, 25, 64), one line per road and connected stretch: one carriageway, no junction branches (`main_roads.py`), simplified and rounded |
| `water` | polygon | `name`, `area` (km²) | reservoirs of at least 2 km², simplified and rounded |
| `wood` | polygon | `area` (km²) | one circle per forest massif of at least 20 km², with the massif's area; neighbouring forest patches are merged first |
| `peak` | point | `name`, `ele` | the highest peaks, from the top down, skipping peaks closer than a few km to a higher one (`top_peaks.py`) |
| `landform` | point | `name` | Krušné hory, Slavkovský les, Doupovské hory |
| `country` | point | `name` | "Německo", a hand-placed label outside the region (`data/country.geojson`) |

The list of cities is in `process.lua`; everything else is prepared by
`build_tiles.sh`. The mountain range labels sit in the middle
of the part of the OSM ridge line that lies inside the region
(`landform_points.py`).

## Icons

`icons/` holds the SVG sources of the map icons: `mountain` (two peaks)
and `mountain-snow` (three peaks, snow cap), drawn after the UI design.
`icons/render_icons.sh` rasterises them with rsvg-convert
(`brew install librsvg`) into `assets/map/` at 1x, 2.0x and 3.0x. The app
adds the 2.0x PNGs to the map under the icon names, and the style draws
them at `icon-size` 0.5. The preview page embeds the same SVGs; keep the
two in step.

The style shows an icon for every peak in the `peak` layer, the
snow-capped one from 1100 m. The icons are always visible and grow with
the zoom; peak names appear from zoom 10. How many peaks the layer holds,
and how far apart they must be, are variables in `build_tiles.sh`.

## Preview

`preview/index.html` shows the tiles with a first draft of the game map
style. Serve the output directory with a server that supports HTTP range
requests (PMTiles needs them) and open the page:

```sh
python3 -I tools/map/preview/serve.py build/map 8765
open "http://127.0.0.1:8765/preview/index.html"
```

The page takes `?lon=12.87&lat=50.23&z=12` to open at another view. The
preview page must be copied, or symlinked, into `build/map/preview/` to be
served from the same origin as the tiles.

For a screenshot without a browser window:

```sh
npm --prefix tools/map/preview install
node tools/map/preview/screenshot.mjs "http://127.0.0.1:8765/preview/index.html" map.png
```

## Attribution

The tiles contain OpenStreetMap data, © OpenStreetMap contributors, ODbL.
The map must always show "© OpenStreetMap contributors".
