"""Turn OSM features into the simple, rounded shapes of the game map.

Usage: simplify_features.py <in.geojsonseq> [options] > out.geojson

The input is a GeoJSON text sequence from `osmium export`. The script
filters the features, merges split lines, simplifies the geometry with
Douglas-Peucker, rounds it with Chaikin's corner cutting, and prints a
GeoJSON FeatureCollection.

Options:
  --names "A,B"         keep only features with one of these names
  --exclude key=v1,v2   drop features whose tag has one of these values
  --min-area KM2        drop polygons smaller than this (km²)
  --inside region.geojson
                        keep only features whose centroid lies in the region
  --dedupe KM           drop a polygon of the same area whose centroid lies
                        within this distance of one already kept (OSM often
                        holds the same wood as a way and as a relation)
  --cluster FACTOR      merge polygons into blobs: two blobs merge while
                        their equivalent circles, scaled by FACTOR, overlap;
                        areas add up, the centre is the area-weighted mean
                        (only with --output point or circle)
  --min-cluster-area KM2
                        drop blobs smaller than this after clustering
  --merge               chain lines that share an end point (per name)
  --group TAG           merge lines per value of this tag instead of the
                        name, and write it as the property TAG
  --min-length KM       drop lines shorter than this after merging
  --tolerance DEG       Douglas-Peucker tolerance in degrees (0 = off)
  --smooth N            Chaikin iterations (0 = off)
  --output polygon|outline|line|point|circle
                        geometry to write; "outline" writes the polygon's
                        ring as a line, "point" writes the centroid,
                        "circle" a circle around it with the same area
  --vertices N          vertices of a circle (default 32)
  --properties a,b      properties to keep (default: name); "area" adds the
                        polygon area in km²

Holes of polygons are dropped: the map shows blobs, not islands.
"""

import argparse
import json
import math
import sys

KM_PER_DEG_LAT = 110.57


def read_features(path):
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip().lstrip("\x1e")
            if line:
                yield json.loads(line)


# --- geometry helpers, all on [lon, lat] pairs ---------------------------

def project(ring):
    """Equirectangular projection to kilometres around the ring's latitude."""
    lat0 = sum(p[1] for p in ring) / len(ring)
    kx = KM_PER_DEG_LAT * math.cos(math.radians(lat0))
    return [(p[0] * kx, p[1] * KM_PER_DEG_LAT) for p in ring]


def ring_area_km2(ring):
    pts = project(ring)
    area = 0.0
    for i in range(len(pts) - 1):
        area += pts[i][0] * pts[i + 1][1] - pts[i + 1][0] * pts[i][1]
    return abs(area) / 2


def ring_centroid(ring):
    pts = project(ring)
    area = 0.0
    cx = cy = 0.0
    for i in range(len(pts) - 1):
        cross = pts[i][0] * pts[i + 1][1] - pts[i + 1][0] * pts[i][1]
        area += cross
        cx += (pts[i][0] + pts[i + 1][0]) * cross
        cy += (pts[i][1] + pts[i + 1][1]) * cross
    if abs(area) < 1e-9:
        lon = sum(p[0] for p in ring) / len(ring)
        lat = sum(p[1] for p in ring) / len(ring)
        return [lon, lat]
    cx /= 3 * area
    cy /= 3 * area
    lat = cy / KM_PER_DEG_LAT
    lon = cx / (KM_PER_DEG_LAT * math.cos(math.radians(lat)))
    return [lon, lat]


def ring_contains(ring, x, y):
    inside = False
    j = len(ring) - 1
    for i in range(len(ring)):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


def polygon_contains(geometry, x, y):
    polygons = geometry["coordinates"]
    if geometry["type"] == "Polygon":
        polygons = [polygons]
    return any(ring_contains(rings[0], x, y) for rings in polygons)


def point_segment_distance(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    if dx == 0 and dy == 0:
        return math.hypot(p[0] - a[0], p[1] - a[1])
    t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy)
    t = max(0.0, min(1.0, t))
    return math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy))


def douglas_peucker(points, tolerance):
    """Iterative Douglas-Peucker; keeps the first and the last point."""
    if tolerance <= 0 or len(points) < 3:
        return list(points)
    keep = [False] * len(points)
    keep[0] = keep[-1] = True
    stack = [(0, len(points) - 1)]
    while stack:
        start, end = stack.pop()
        best, best_i = 0.0, -1
        for i in range(start + 1, end):
            d = point_segment_distance(points[i], points[start], points[end])
            if d > best:
                best, best_i = d, i
        if best > tolerance:
            keep[best_i] = True
            stack.append((start, best_i))
            stack.append((best_i, end))
    return [p for p, k in zip(points, keep) if k]


def simplify_ring(ring, tolerance):
    """Douglas-Peucker on a closed ring, split at the farthest point so
    that the ring does not collapse onto its start."""
    if tolerance <= 0 or len(ring) < 5:
        return list(ring)
    pts = ring[:-1]
    far = max(range(len(pts)), key=lambda i: math.hypot(pts[i][0] - pts[0][0], pts[i][1] - pts[0][1]))
    first = douglas_peucker(pts[: far + 1], tolerance)
    second = douglas_peucker(pts[far:] + [pts[0]], tolerance)
    return first + second[1:]


def chaikin(points, iterations, closed):
    pts = list(points)
    for _ in range(iterations):
        if closed:
            core = pts[:-1]
            out = []
            for i in range(len(core)):
                a, b = core[i], core[(i + 1) % len(core)]
                out.append([0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1]])
                out.append([0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1]])
            out.append(out[0])
        else:
            out = [pts[0]]
            for i in range(len(pts) - 1):
                a, b = pts[i], pts[i + 1]
                out.append([0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1]])
                out.append([0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1]])
            out.append(pts[-1])
        pts = out
    return pts


def rounded(coords):
    return [[round(c[0], 5), round(c[1], 5)] for c in coords]


def distance_km(a, b):
    kx = KM_PER_DEG_LAT * math.cos(math.radians((a[1] + b[1]) / 2))
    return math.hypot((a[0] - b[0]) * kx, (a[1] - b[1]) * KM_PER_DEG_LAT)


def circle_ring(centre, area_km2, vertices):
    """A closed ring approximating the circle of the given area."""
    r = math.sqrt(area_km2 / math.pi)
    dlat = r / KM_PER_DEG_LAT
    dlon = r / (KM_PER_DEG_LAT * math.cos(math.radians(centre[1])))
    ring = []
    for i in range(vertices):
        t = 2 * math.pi * i / vertices
        ring.append([centre[0] + dlon * math.cos(t), centre[1] + dlat * math.sin(t)])
    ring.append(ring[0])
    return ring


def cluster_blobs(blobs, factor):
    """Merge blobs (area, centre, tags) whose scaled equivalent circles
    overlap, until no pair overlaps. Largest first keeps the tags of the
    largest member."""
    blobs = [list(b) for b in blobs]
    merged = True
    while merged:
        merged = False
        for i in range(len(blobs)):
            for j in range(i + 1, len(blobs)):
                a1, c1, _ = blobs[i]
                a2, c2, _ = blobs[j]
                reach = factor * (math.sqrt(a1 / math.pi) + math.sqrt(a2 / math.pi))
                if distance_km(c1, c2) < reach:
                    a = a1 + a2
                    blobs[i][0] = a
                    blobs[i][1] = [(c1[0] * a1 + c2[0] * a2) / a, (c1[1] * a1 + c2[1] * a2) / a]
                    del blobs[j]
                    merged = True
                    break
            if merged:
                break
    return [tuple(b) for b in blobs]


# --- feature handling ----------------------------------------------------

def outer_rings(geometry):
    if geometry["type"] == "Polygon":
        return [geometry["coordinates"][0]]
    if geometry["type"] == "MultiPolygon":
        return [rings[0] for rings in geometry["coordinates"]]
    return []


def lines(geometry):
    if geometry["type"] == "LineString":
        return [geometry["coordinates"]]
    if geometry["type"] == "MultiLineString":
        return list(geometry["coordinates"])
    return []


def merge_lines(parts):
    """Chain lines that share an end point. Greedy, good enough for rivers."""
    parts = [list(p) for p in parts]
    merged = True
    while merged and len(parts) > 1:
        merged = False
        for i in range(len(parts)):
            for j in range(len(parts)):
                if i == j:
                    continue
                a, b = parts[i], parts[j]
                if a[-1] == b[0]:
                    parts[i] = a + b[1:]
                elif a[-1] == b[-1]:
                    parts[i] = a + list(reversed(b))[1:]
                elif a[0] == b[-1]:
                    parts[i] = b + a[1:]
                elif a[0] == b[0]:
                    parts[i] = list(reversed(b)) + a[1:]
                else:
                    continue
                del parts[j]
                merged = True
                break
            if merged:
                break
    return parts


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("--names", default="")
    ap.add_argument("--exclude", default="")
    ap.add_argument("--min-area", type=float, default=0.0)
    ap.add_argument("--inside")
    ap.add_argument("--dedupe", type=float, default=0.0)
    ap.add_argument("--cluster", type=float, default=0.0)
    ap.add_argument("--min-cluster-area", type=float, default=0.0)
    ap.add_argument("--merge", action="store_true")
    ap.add_argument("--group", default="name")
    ap.add_argument("--min-length", type=float, default=0.0)
    ap.add_argument("--tolerance", type=float, default=0.0)
    ap.add_argument("--smooth", type=int, default=0)
    ap.add_argument("--output", choices=["polygon", "outline", "line", "point", "circle"], default="polygon")
    ap.add_argument("--vertices", type=int, default=32)
    ap.add_argument("--properties", default="name")
    args = ap.parse_args()

    names = {n.strip() for n in args.names.split(",") if n.strip()}
    exclude_key, exclude_values = None, set()
    if args.exclude:
        exclude_key, values = args.exclude.split("=", 1)
        exclude_values = set(values.split(","))
    region = None
    if args.inside:
        with open(args.inside, encoding="utf-8") as f:
            region = json.load(f)["features"][0]["geometry"]
    props = [p.strip() for p in args.properties.split(",") if p.strip()]

    # Collect geometry parts per feature name (lines merge per --group).
    polygons = []  # (properties, ring)
    line_parts = {}  # group value -> [line]
    for feature in read_features(args.input):
        tags = feature.get("properties", {})
        name = tags.get("name", "")
        if names and name not in names:
            continue
        if exclude_key and tags.get(exclude_key) in exclude_values:
            continue
        geometry = feature["geometry"]
        if args.output == "line":
            line_parts.setdefault(tags.get(args.group, ""), []).extend(lines(geometry))
        else:
            for ring in outer_rings(geometry):
                polygons.append((tags, ring))

    features = []

    # Largest first, so that --dedupe and --cluster keep the larger member.
    measured = [(ring_area_km2(ring), tags, ring) for tags, ring in polygons]
    measured.sort(key=lambda m: -m[0])
    kept = []  # (area, centroid, tags, ring)

    for area, tags, ring in measured:
        if area < args.min_area:
            continue
        centroid = ring_centroid(ring)
        if region and not polygon_contains(region, centroid[0], centroid[1]):
            continue
        if args.dedupe > 0 and any(
                distance_km(centroid, c) < args.dedupe and abs(a - area) <= 0.1 * a
                for a, c, _, _ in kept):
            continue
        kept.append((area, centroid, tags, ring))

    if args.cluster > 0:
        if args.output not in ("point", "circle"):
            ap.error("--cluster needs --output point or circle")
        blobs = cluster_blobs([(a, c, t) for a, c, t, _ in kept], args.cluster)
        kept = [(a, c, t, None) for a, c, t in blobs if a >= args.min_cluster_area]

    for area, centroid, tags, ring in kept:
        out = {p: tags[p] for p in props if p in tags and p != "area"}
        if "area" in props:
            out["area"] = round(area, 2)
        if args.output == "point":
            geometry = {"type": "Point", "coordinates": rounded([centroid])[0]}
        elif args.output == "circle":
            geometry = {"type": "Polygon", "coordinates": [rounded(circle_ring(centroid, area, args.vertices))]}
        else:
            ring = simplify_ring(ring, args.tolerance)
            if len(ring) < 4:
                continue
            ring = chaikin(ring, args.smooth, closed=True)
            if args.output == "outline":
                # A line layer drawn from a polygon would also draw the tile
                # edges of the clipped polygon; a line clips cleanly.
                geometry = {"type": "LineString", "coordinates": rounded(ring)}
            else:
                geometry = {"type": "Polygon", "coordinates": [rounded(ring)]}
        features.append({"type": "Feature", "properties": out, "geometry": geometry})

    for group, parts in line_parts.items():
        if args.merge:
            parts = merge_lines(parts)
        for part in parts:
            length = sum(distance_km(part[i], part[i + 1]) for i in range(len(part) - 1))
            if length < args.min_length:
                continue
            part = douglas_peucker(part, args.tolerance)
            if len(part) < 2:
                continue
            part = chaikin(part, args.smooth, closed=False)
            out = {args.group: group} if args.group in props and group else {}
            features.append({"type": "Feature", "properties": out,
                             "geometry": {"type": "LineString", "coordinates": rounded(part)}})

    print(json.dumps({"type": "FeatureCollection", "features": features}, ensure_ascii=False))
    print(f"{args.input}: {len(features)} features", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
