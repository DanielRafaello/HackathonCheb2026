"""Pick the highest peaks for the map.

Usage: top_peaks.py <peaks.geojsonseq> <region.geojson> <count> [<spacing km>]

The input is a GeoJSON text sequence of natural=peak nodes from
`osmium export`. The script keeps named peaks with an elevation inside the
region, takes them from the highest down, and skips a peak closer than
the spacing to one already taken, so that the icons do not pile up on one
ridge. It prints a FeatureCollection of points with "name" and "ele".
"""

import json
import math
import sys

KM_PER_DEG_LAT = 110.57


def ring_contains(ring, x, y):
    inside = False
    j = len(ring) - 1
    for i in range(len(ring)):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


def polygon_contains(geometry, x, y):
    polygons = geometry["coordinates"]
    if geometry["type"] == "Polygon":
        polygons = [polygons]
    return any(ring_contains(rings[0], x, y) for rings in polygons)


def distance_km(a, b):
    kx = KM_PER_DEG_LAT * math.cos(math.radians((a[1] + b[1]) / 2))
    return math.hypot((a[0] - b[0]) * kx, (a[1] - b[1]) * KM_PER_DEG_LAT)


def main() -> int:
    path, region_path, count = sys.argv[1], sys.argv[2], int(sys.argv[3])
    spacing = float(sys.argv[4]) if len(sys.argv) > 4 else 0.0
    with open(region_path, encoding="utf-8") as f:
        region = json.load(f)["features"][0]["geometry"]

    peaks = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip().lstrip("\x1e")
            if not line:
                continue
            feature = json.loads(line)
            tags = feature.get("properties", {})
            name = tags.get("name")
            try:
                ele = float(str(tags.get("ele", "")).replace(",", "."))
            except ValueError:
                continue
            point = feature["geometry"]["coordinates"]
            if name and polygon_contains(region, point[0], point[1]):
                peaks.append((ele, name, point))
    peaks.sort(key=lambda p: -p[0])

    chosen = []
    for ele, name, point in peaks:
        if len(chosen) >= count:
            break
        if any(distance_km(point, c[2]) < spacing for c in chosen):
            continue
        chosen.append((ele, name, point))

    features = [{
        "type": "Feature",
        "properties": {"name": name, "ele": round(ele)},
        "geometry": {"type": "Point", "coordinates": [round(point[0], 5), round(point[1], 5)]},
    } for ele, name, point in chosen]
    print(json.dumps({"type": "FeatureCollection", "features": features}, ensure_ascii=False))
    print("peaks: " + ", ".join(f"{name} ({round(ele)} m)" for ele, name, _ in chosen), file=sys.stderr)
    return 0 if features else 1


if __name__ == "__main__":
    sys.exit(main())
