#!/usr/bin/env bash
# Build the app icons for the web, Android and iOS from the Vřídlík mascot.
#
# Reads design-system/assets/mascot/mascot-wave.svg and writes:
#
# Web
#   web/favicon.svg                 the drop alone, cropped square, transparent
#   web/favicon.png                 32 px fallback of the same
#   web/icons/Icon-{192,512}.png    Vřídlík on a blue tile with a 3D edge
#   web/icons/Icon-maskable-{192,512}.png  full-bleed blue, mascot in the
#                                   maskable safe zone (80 % circle)
#   web/icons/apple-touch-icon.png  180 px full-bleed blue (iOS rounds it)
#
# Android (android/app/src/main/res/)
#   mipmap-*/ic_launcher.png        the blue tile, for launchers before 8.0
#   mipmap-*/ic_launcher_foreground.png  the mascot in the adaptive icon's
#                                   66 dp safe zone, on a 108 dp layer
#   mipmap-*/ic_launcher_monochrome.png  a one-colour silhouette for themed
#                                   icons (Android 13)
#   mipmap-anydpi-v26/ic_launcher.xml, values/ic_launcher_background.xml
#
# iOS (ios/Runner/Assets.xcassets/AppIcon.appiconset/)
#   Icon-App-*.png                  full-bleed blue, opaque (the App Store
#                                   rejects alpha); iOS rounds the corners
#
# Colours are the design tokens primary (#2B59C3) and primary-edge
# (#1D3F91). Requires rsvg-convert (brew install librsvg). Run it after
# changing the mascot and commit the results.
#
# Usage: tools/app_icons/render_icons.sh
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
mascot="$root/design-system/assets/mascot/mascot-wave.svg"
web="$root/web"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

primary='#2B59C3'
primary_edge='#1D3F91'

# The mascot's shapes without the <svg> wrapper and the C2PA metadata.
body="$(sed -E 's/<metadata>.*<\/metadata>//' "$mascot" | grep -v -E '^<svg|^</svg>')"
# The drop alone: no shadow under it and no steam above it, which are only
# noise at 16 px.
drop="$(printf '%s\n' "$body" | grep -v -E 'cy="134"|#9BE4EB')"

# Favicon: the drop and its arms span x 12–112, y 16–132 of the 120×140
# mascot; a 120×120 crop from y 14 keeps it whole and square.
cat > "$web/favicon.svg" <<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 14 120 120" width="120" height="120">
$drop
</svg>
SVG
rsvg-convert -w 32 -h 32 -o "$web/favicon.png" "$web/favicon.svg"

# App icon: a rounded blue tile with a darker bottom edge, like the 3D
# buttons and the sign-in header; the whole mascot centred on the face.
cat > "$tmp/icon.svg" <<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
<defs><clipPath id="tile"><rect width="512" height="512" rx="112"/></clipPath></defs>
<g clip-path="url(#tile)">
<rect width="512" height="512" fill="$primary_edge"/>
<rect width="512" height="488" rx="112" fill="$primary"/>
<rect width="512" height="200" fill="$primary"/>
</g>
<g transform="translate(102 64) scale(2.5714)">
$body
</g>
</svg>
SVG

# Maskable: the platform crops to any shape inside the 80 % safe circle,
# so the 120×140 mascot is scaled to fit a circle of radius 204.
cat > "$tmp/maskable.svg" <<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
<rect width="512" height="512" fill="$primary"/>
<g transform="translate(130 109) scale(2.1)">
$body
</g>
</svg>
SVG

# Apple touch icon and the iOS app icons: iOS adds its own rounded corners
# and allows no transparency. Every pixel is opaque, so rsvg-convert writes
# RGB without an alpha channel (the App Store rejects alpha).
cat > "$tmp/ios.svg" <<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 180 180" width="180" height="180">
<rect width="180" height="180" fill="$primary"/>
<g transform="translate(36 27) scale(0.9)">
$body
</g>
</svg>
SVG

for size in 192 512; do
  rsvg-convert -w $size -h $size -o "$web/icons/Icon-$size.png" "$tmp/icon.svg"
  rsvg-convert -w $size -h $size \
    -o "$web/icons/Icon-maskable-$size.png" "$tmp/maskable.svg"
done
rsvg-convert -w 180 -h 180 -o "$web/icons/apple-touch-icon.png" "$tmp/ios.svg"

echo "Wrote web/favicon.{svg,png} and web/icons/*.png"

# --- Android -------------------------------------------------------------

res="$root/android/app/src/main/res"

# The adaptive icon's foreground: a 108 dp layer of which launchers show at
# least the central 66 dp circle (radius 132 px at 432 px). The mascot's
# farthest point from its centre (60, 70) is the top of the steam, 70 units
# away, so a scale of 1.8 keeps all of it inside the circle.
cat > "$tmp/foreground.svg" <<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 432 432" width="432" height="432">
<g transform="translate(108 90) scale(1.8)">
$body
</g>
</svg>
SVG

# Themed icons take only the alpha channel: the drop and arms as a
# silhouette with the eyes, pupils and mouth cut out of it.
monochrome_mask="$(printf '%s\n' "$drop" | grep -E 'rotate\((25|30) |M60 16 ' |
  sed -E 's/fill="#[0-9A-Fa-f]+"/fill="#FFFFFF"/')"
cat > "$tmp/monochrome.svg" <<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 432 432" width="432" height="432">
<defs><mask id="face" maskUnits="userSpaceOnUse" x="0" y="0" width="120" height="140">
$monochrome_mask
<circle cx="46" cy="84" r="12" fill="#000"/>
<circle cx="74" cy="84" r="12" fill="#000"/>
<circle cx="48" cy="86" r="6.5" fill="#FFF"/>
<circle cx="76" cy="86" r="6.5" fill="#FFF"/>
<path d="M50 99 Q60 113 70 99 Q60 103 50 99 Z" fill="#000"/>
</mask></defs>
<g transform="translate(108 90) scale(1.8)">
<rect width="120" height="140" fill="#FFFFFF" mask="url(#face)"/>
</g>
</svg>
SVG

for density in mdpi:1 hdpi:1.5 xhdpi:2 xxhdpi:3 xxxhdpi:4; do
  name="${density%%:*}"
  scale="${density##*:}"
  dir="$res/mipmap-$name"
  mkdir -p "$dir"
  legacy="$(awk "BEGIN { print int(48 * $scale) }")"
  layer="$(awk "BEGIN { print int(108 * $scale) }")"
  rsvg-convert -w "$legacy" -h "$legacy" -o "$dir/ic_launcher.png" "$tmp/icon.svg"
  rsvg-convert -w "$layer" -h "$layer" \
    -o "$dir/ic_launcher_foreground.png" "$tmp/foreground.svg"
  rsvg-convert -w "$layer" -h "$layer" \
    -o "$dir/ic_launcher_monochrome.png" "$tmp/monochrome.svg"
done

mkdir -p "$res/mipmap-anydpi-v26"
cat > "$res/mipmap-anydpi-v26/ic_launcher.xml" <<XML
<?xml version="1.0" encoding="utf-8"?>
<!-- Generated by tools/app_icons/render_icons.sh. -->
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
    <monochrome android:drawable="@mipmap/ic_launcher_monochrome"/>
</adaptive-icon>
XML
cat > "$res/values/ic_launcher_background.xml" <<XML
<?xml version="1.0" encoding="utf-8"?>
<!-- Generated by tools/app_icons/render_icons.sh: the primary token. -->
<resources>
    <color name="ic_launcher_background">$primary</color>
</resources>
XML
echo "Wrote the Android launcher icons"

# --- iOS -----------------------------------------------------------------

appicon="$root/ios/Runner/Assets.xcassets/AppIcon.appiconset"
for spec in 20:1 20:2 20:3 29:1 29:2 29:3 40:1 40:2 40:3 60:2 60:3 \
  76:1 76:2 83.5:2 1024:1; do
  points="${spec%%:*}"
  scale="${spec##*:}"
  px="$(awk "BEGIN { print int($points * $scale + 0.5) }")"
  rsvg-convert -w "$px" -h "$px" \
    -o "$appicon/Icon-App-${points}x${points}@${scale}x.png" "$tmp/ios.svg"
done
echo "Wrote the iOS app icons"
